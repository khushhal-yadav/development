package com.citi.icg.cioidark;

import com.citi.icg.cioidark.chronicle.messaging.queue.OMSOut;
import org.apache.commons.configuration.ConfigurationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class OMSApplicationContextProviderTest {

    private final OMSOut omsOut = OMSOutFactory.get();

    @Before
    public void init() throws ConfigurationException {
        OMSApplicationContextProvider.initialize(omsOut);
    }

    @Test
    public void getOmsSystemProperty() {
        Assert.assertEquals(OMSApplicationContextProvider.getOmsSystemProperty(),
                OMSApplicationContextProvider.getOmsSystemProperty());
    }

    @Test
    public void getOrderManager() {
        Assert.assertEquals(OMSApplicationContextProvider.getOrderManager(),
                OMSApplicationContextProvider.getOrderManager());
    }

    @Test
    public void getOrderCache() {
        Assert.assertEquals(OMSApplicationContextProvider.getOrderCache(),
                OMSApplicationContextProvider.getOrderCache());
    }

    @Test
    public void marketDataMessageMap() {
        Assert.assertEquals(OMSApplicationContextProvider.marketDataMessageMap(),
                OMSApplicationContextProvider.marketDataMessageMap());
    }

    @Test
    public void getInboundFixThreadPool() {
        Assert.assertEquals(OMSApplicationContextProvider.getInboundFixThreadPool(),
                OMSApplicationContextProvider.getInboundFixThreadPool());
    }

    @Test
    public void getCrossingEngineThreadPool() {
        Assert.assertEquals(OMSApplicationContextProvider.getCrossingEngineThreadPool(),
                OMSApplicationContextProvider.getCrossingEngineThreadPool());
    }

    @Test
    public void getExecutionReportBuilder() {
        Assert.assertNotEquals(OMSApplicationContextProvider.getExecutionReportBuilder(),
                OMSApplicationContextProvider.getExecutionReportBuilder());
    }

    @Test
    public void getInboundHandler() {
        Assert.assertNotEquals(OMSApplicationContextProvider.getInboundHandler(),
                OMSApplicationContextProvider.getInboundHandler());
    }

    @Test
    public void getFixInboundProcessor() {
        Assert.assertNotEquals(OMSApplicationContextProvider.getFixInboundProcessor(),
                OMSApplicationContextProvider.getFixInboundProcessor());
    }

    @Test
    public void getEngineInboundProcessor() {
        Assert.assertNotEquals(OMSApplicationContextProvider.getEngineInboundProcessor(),
                OMSApplicationContextProvider.getEngineInboundProcessor());
    }

    @Test
    public void getSubscribeToMarketDataService() {
        Assert.assertNotEquals(OMSApplicationContextProvider.getSubscribeToMarketDataService(),
                OMSApplicationContextProvider.getSubscribeToMarketDataService());
    }

    @Test
    public void getCioiDarkOrderValidator() {
        Assert.assertNotEquals(OMSApplicationContextProvider.getCioiDarkOrderValidator(),
                OMSApplicationContextProvider.getCioiDarkOrderValidator());
    }

    @Test
    public void getAckPublisher() {
        Assert.assertNotEquals(OMSApplicationContextProvider.getAckPublisher(),
                OMSApplicationContextProvider.getAckPublisher());
    }

    @Test
    public void getRejectPublisher() {
        Assert.assertNotEquals(OMSApplicationContextProvider.getRejectPublisher(),
                OMSApplicationContextProvider.getRejectPublisher());
    }

    @Test
    public void getOutboundPublisher() {
        Assert.assertNotEquals(OMSApplicationContextProvider.getOutboundPublisher(),
                OMSApplicationContextProvider.getOutboundPublisher());
    }

}