package com.citi.icg.cioidark.oms.component.processor;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.oms.component.dto.OrderState;
import com.citi.icg.cioidark.oms.component.enricher.CioiDarkOrderEnricher;
import com.citi.icg.cioidark.oms.component.order.Order;
import com.citi.icg.cioidark.oms.component.order.OrderCache;
import com.citi.icg.cioidark.oms.component.order.OrderManager;
import com.citi.icg.cioidark.oms.component.publisher.OutboundPublisher;
import com.citi.icg.cioidark.oms.component.publisher.RejectPublisher;
import com.citi.icg.cioidark.oms.component.validator.CioiDarkOrderValidator;
import com.citi.icg.cioidark.oms.component.validator.ValidationUtil;
import com.citi.icg.cioidark.oms.component.validator.exception.ValidationException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;
import software.chronicle.fix.datamodel.AbstractDataModel;

@RunWith(PowerMockRunner.class)
@PrepareForTest(OMSApplicationContextProvider.class)
class FixInboundProcessorTest {

    @Mock
    private OrderCache orderCache;
    @Mock
    private OrderManager orderManager;
    @Mock
    private CioiDarkOrderValidator cioiDarkOrderValidator;
    @Mock
    private CioiDarkOrderEnricher cioiDarkOrderEnricher;
    @Mock
    private OutboundPublisher outboundPublisher;
    @Mock
    private RejectPublisher rejectPublisher;

    private final String orderId = "orderId";
    private final String clOrdID = "clOrdID";
    private final String symbol = "symbol";
    private FixInboundProcessor fixInboundProcessor;

    public FixInboundProcessorTest() {
    }

    @Before
    public void init() {
        PowerMockito.mockStatic(OMSApplicationContextProvider.class);
        PowerMockito.when(orderManager.getOrderCache()).thenReturn(orderCache);
        PowerMockito.when(OMSApplicationContextProvider.getOrderManager()).thenReturn(orderManager);
        PowerMockito.when(OMSApplicationContextProvider.getCioiDarkOrderValidator()).thenReturn(cioiDarkOrderValidator);
        PowerMockito.when(OMSApplicationContextProvider.getCioiDarkOrderEnricher()).thenReturn(cioiDarkOrderEnricher);
        PowerMockito.when(OMSApplicationContextProvider.getOutboundPublisher()).thenReturn(outboundPublisher);
        PowerMockito.when(OMSApplicationContextProvider.getRejectPublisher()).thenReturn(rejectPublisher);

        fixInboundProcessor = new FixInboundProcessor();
    }

    @Test
    public void onMessageNewSingleOrderSuccess() {

        final DefaultNewOrderSingle newOrderSingle = Mockito.mock(DefaultNewOrderSingle.class);
        PowerMockito.when(newOrderSingle.symbol()).thenReturn(symbol);
        final Order order = Mockito.mock(Order.class);
        final OrderState orderState = Mockito.mock(OrderState.class);

        PowerMockito.when(orderState.getOrderID()).thenReturn(orderId);
        PowerMockito.when(order.getOrderState()).thenReturn(orderState);
        PowerMockito.when(newOrderSingle.clOrdID()).thenReturn(clOrdID);
        PowerMockito.when(newOrderSingle.ordType()).thenReturn(OrdType.LIMIT);
        PowerMockito.when(orderCache.containsClOrdId(clOrdID)).thenReturn(false);
        PowerMockito.when(orderManager.newOrderSingle(newOrderSingle)).thenReturn(order);

        fixInboundProcessor.onMessage(newOrderSingle);

        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validate(newOrderSingle);
        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validateNewOrderSingle(newOrderSingle, true);
        Mockito.verify(cioiDarkOrderEnricher, Mockito.times(1)).enrich(newOrderSingle, symbol);
        Mockito.verify(newOrderSingle, Mockito.times(1)).orderID(orderId);
        Mockito.verify(outboundPublisher, Mockito.times(1)).sendForCrossing(newOrderSingle);
    }

    @Test
    public void onMessageNewSingleOrderFailure() throws Exception {

        final DefaultNewOrderSingle newOrderSingle = Mockito.mock(DefaultNewOrderSingle.class);

        PowerMockito.when(newOrderSingle.clOrdID()).thenReturn(clOrdID);
        PowerMockito.when(newOrderSingle.ordType()).thenReturn(OrdType.LIMIT);
        PowerMockito.when(orderCache.containsClOrdId(clOrdID)).thenReturn(true);
        PowerMockito.doReturn(new DefaultExecutionReport()).when(rejectPublisher, "rejectNewOrderSingle", newOrderSingle, ValidationUtil.DUPLICATE_CLORDID, 6);

        fixInboundProcessor.onMessage(newOrderSingle);

        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validate(newOrderSingle);
        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validateNewOrderSingle(newOrderSingle, true);
        Mockito.verify(cioiDarkOrderEnricher, Mockito.never()).enrich(ArgumentMatchers.any(AbstractDataModel.class), ArgumentMatchers.anyString());
        Mockito.verify(newOrderSingle, Mockito.never()).orderID(orderId);
        Mockito.verify(rejectPublisher, Mockito.times(1)).rejectNewOrderSingle(newOrderSingle, ValidationUtil.DUPLICATE_CLORDID, 6);

    }

    @Test
    public void onMessageOrderCancelRequestSuccess() {

        final DefaultOrderCancelRequest orderCancelRequest = Mockito.mock(DefaultOrderCancelRequest.class);
        PowerMockito.when(orderCancelRequest.symbol()).thenReturn(symbol);
        final Order cxlOrder = Mockito.mock(Order.class);

        PowerMockito.when(orderManager.cancelRequest(orderCancelRequest)).thenReturn(cxlOrder);

        fixInboundProcessor.onMessage(orderCancelRequest);

        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validate(orderCancelRequest);
        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validateOrderCancelRequest(orderCancelRequest);
        Mockito.verify(cioiDarkOrderEnricher, Mockito.times(1)).enrich(orderCancelRequest, symbol);
        Mockito.verify(outboundPublisher, Mockito.times(1)).sendForCrossing(orderCancelRequest);
    }

    @Test
    public void onMessageOrderCancelRequestFailure() {

        final DefaultOrderCancelRequest orderCancelRequest = Mockito.mock(DefaultOrderCancelRequest.class);
        PowerMockito.when(orderCancelRequest.symbol()).thenReturn(symbol);
        PowerMockito.when(orderManager.cancelRequest(orderCancelRequest)).thenThrow(new ValidationException(ValidationUtil.ORDER_NOT_FOUND, 99));

        fixInboundProcessor.onMessage(orderCancelRequest);

        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validate(orderCancelRequest);
        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validateOrderCancelRequest(orderCancelRequest);
        Mockito.verify(cioiDarkOrderEnricher, Mockito.times(1)).enrich(orderCancelRequest, symbol);
        Mockito.verify(rejectPublisher, Mockito.times(1)).rejectCancelRequest(orderCancelRequest, ValidationUtil.ORDER_NOT_FOUND, 99);
    }

    @Test
    public void onMessageOrderCancelReplaceRequestSuccess() {

        final DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = Mockito.mock(DefaultOrderCancelReplaceRequest.class);
        PowerMockito.when(orderCancelReplaceRequest.symbol()).thenReturn(symbol);
        PowerMockito.when(orderCancelReplaceRequest.ordType()).thenReturn(OrdType.LIMIT);
        final Order replaceOrder = Mockito.mock(Order.class);

        PowerMockito.when(orderManager.cancelReplaceRequest(orderCancelReplaceRequest)).thenReturn(replaceOrder);

        fixInboundProcessor.onMessage(orderCancelReplaceRequest);

        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validate(orderCancelReplaceRequest);
        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validateOrderCancelReplaceRequest(orderCancelReplaceRequest, true);
        Mockito.verify(cioiDarkOrderEnricher, Mockito.times(1)).enrich(orderCancelReplaceRequest, symbol);
        Mockito.verify(outboundPublisher, Mockito.times(1)).sendForCrossing(orderCancelReplaceRequest);
    }

    @Test
    public void onMessageOrderCancelReplaceRequestFailure() {

        final DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = Mockito.mock(DefaultOrderCancelReplaceRequest.class);
        PowerMockito.when(orderCancelReplaceRequest.symbol()).thenReturn(symbol);
        PowerMockito.when(orderCancelReplaceRequest.ordType()).thenReturn(OrdType.MARKET);
        PowerMockito.when(orderManager.cancelReplaceRequest(orderCancelReplaceRequest)).thenThrow(new ValidationException(ValidationUtil.ORDER_NOT_FOUND, 99));

        fixInboundProcessor.onMessage(orderCancelReplaceRequest);

        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validate(orderCancelReplaceRequest);
        Mockito.verify(cioiDarkOrderValidator, Mockito.times(1)).validateOrderCancelReplaceRequest(orderCancelReplaceRequest, false);
        Mockito.verify(cioiDarkOrderEnricher, Mockito.times(1)).enrich(orderCancelReplaceRequest, symbol);
        Mockito.verify(rejectPublisher, Mockito.times(1)).rejectCancelReplaceRequest(orderCancelReplaceRequest, ValidationUtil.ORDER_NOT_FOUND, 99);
    }

}