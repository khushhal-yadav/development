package com.citi.icg.cioidark.oms.component.order;

import org.junit.Assert;
import org.junit.Test;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;

public class OrderCacheTest {

    private OrderCache orderCache = new OrderCache();

    @Test
    public void add() {
        DefaultNewOrderSingle newOrderSingle = OrderFactory.createNewOrderSingle();
        Order order = new Order(newOrderSingle);

        orderCache.add(order);

        Assert.assertTrue(orderCache.containsClOrdId(OrderFactory.clOrdID));
        Assert.assertNotNull(orderCache.get(OrderFactory.clOrdID, null));
        Assert.assertNotNull(orderCache.get(OrderFactory.clOrdID, null).getOrderState().getCurrentMsg());
        Assert.assertNotNull(orderCache.get(null, OrderFactory.clOrdID).getOrderState().getCurrentMsg());

        orderCache.clearAll();

        Assert.assertFalse(orderCache.containsClOrdId(OrderFactory.clOrdID));
        Assert.assertNull(orderCache.get(OrderFactory.clOrdID, null));
        Assert.assertNull(orderCache.get(OrderFactory.clOrdID, null));
    }


}
