package com.citi.icg.cioidark.oms.component.processor;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.oms.component.order.OrderManager;
import com.citi.icg.cioidark.oms.component.publisher.AckPublisher;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;

@RunWith(PowerMockRunner.class)
@PrepareForTest(OMSApplicationContextProvider.class)
public class EngineInboundProcessorTest {

    @Mock
    private OrderManager orderManager;
    @Mock
    private AckPublisher ackPublisher;
    @Mock
    private DefaultExecutionReport resultExecutionReport;

    private EngineInboundProcessor engineInboundProcessor;

    @Before
    public void init() {
        PowerMockito.mockStatic(OMSApplicationContextProvider.class);
        PowerMockito.when(OMSApplicationContextProvider.getOrderManager()).thenReturn(orderManager);
        PowerMockito.when(OMSApplicationContextProvider.getAckPublisher()).thenReturn(ackPublisher);

        engineInboundProcessor = new EngineInboundProcessor();
    }

    @Test
    public void onMessage() {
        final ExecutionReport executionReport = Mockito.mock(ExecutionReport.class);
        PowerMockito.when(orderManager.ackOrFill(executionReport)).thenReturn(resultExecutionReport);

        engineInboundProcessor.onMessage(executionReport);

        Mockito.verify(ackPublisher, Mockito.times(1)).executionReport(resultExecutionReport);
    }

    @Test
    public void onMessageWithNullFill() {
        final ExecutionReport executionReport = Mockito.mock(ExecutionReport.class);
        PowerMockito.when(orderManager.ackOrFill(executionReport)).thenReturn(null);

        engineInboundProcessor.onMessage(executionReport);

        Mockito.verify(ackPublisher, Mockito.never()).executionReport(resultExecutionReport);
    }

}