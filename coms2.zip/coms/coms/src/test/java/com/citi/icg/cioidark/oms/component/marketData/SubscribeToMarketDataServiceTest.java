package com.citi.icg.cioidark.oms.component.marketData;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.OMSSystemProperty;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;
import com.citi.icg.cioidark.chronicle.messaging.queue.OMSOut;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(OMSApplicationContextProvider.class)
public class SubscribeToMarketDataServiceTest {

    @Mock
    private OMSOut omsOut;
    @Mock
    private OMSSystemProperty omsSystemProperty;

    private String bookSymbol = "bookSymbol";
    private String marketDataSymbol = "marketDataSymbol";
    private SubscribeToMarketDataService subscribeToMarketDataService;

    @Before
    public void init() {
        PowerMockito.mockStatic(OMSApplicationContextProvider.class);
        PowerMockito.when(OMSApplicationContextProvider.getOmsSystemProperty()).thenReturn(omsSystemProperty);
        PowerMockito.when(omsSystemProperty.getOmsOut()).thenReturn(omsOut);

        subscribeToMarketDataService = new SubscribeToMarketDataService();
    }

    @Test
    public void subscribeSuccess() throws Exception {

        final GMDTickSubscriptionMsg gmdTickSubscriptionMsg = new GMDTickSubscriptionMsg(bookSymbol, marketDataSymbol, true);
        PowerMockito.doNothing().when(omsOut, "subscribeTick", gmdTickSubscriptionMsg);

        final boolean subscribe = subscribeToMarketDataService.subscribe(bookSymbol, marketDataSymbol, true);

        Assert.assertTrue(subscribe);
        Mockito.verify(omsOut, Mockito.times(1)).subscribeTick(gmdTickSubscriptionMsg);
    }

    @Test
    public void subscribeFailure() {

        final GMDTickSubscriptionMsg gmdTickSubscriptionMsg = new GMDTickSubscriptionMsg(bookSymbol, marketDataSymbol, true);
        final boolean subscribe = subscribeToMarketDataService.subscribe(null, marketDataSymbol, true);

        Assert.assertFalse(subscribe);
        Mockito.verify(omsOut, Mockito.never()).subscribeTick(gmdTickSubscriptionMsg);
    }
}