package com.citi.icg.cioidark.oms.component.publisher;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;

@RunWith(PowerMockRunner.class)
@PrepareForTest(OMSApplicationContextProvider.class)
public class AckPublisherTest extends AbstractPublisher{

    private AckPublisher ackPublisher;

    @Before
    public void init() throws Exception {
        super.init();
        ackPublisher = new AckPublisher();
    }

    @Test
    public void executionReport() {
        final DefaultExecutionReport executionReport = Mockito.mock(DefaultExecutionReport.class);
        ackPublisher.executionReport(executionReport);

        Mockito.verify(omsOut, Mockito.times(1)).clientExecutionReport(executionReport);
    }
}