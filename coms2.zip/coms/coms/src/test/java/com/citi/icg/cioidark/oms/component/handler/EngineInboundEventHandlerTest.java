package com.citi.icg.cioidark.oms.component.handler;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.oms.component.processor.EngineInboundProcessor;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;

@RunWith(PowerMockRunner.class)
@PrepareForTest(OMSApplicationContextProvider.class)
class EngineInboundEventHandlerTest {

    @Mock
    private EngineInboundProcessor engineInboundProcessor;
    @Mock
    private ExecutionReport executionReport;

    private EngineInboundEventHandler engineInboundEventHandler;

    public EngineInboundEventHandlerTest() {
    }

    @Before
    public void init() {
        PowerMockito.mockStatic(OMSApplicationContextProvider.class);
        PowerMockito.when(OMSApplicationContextProvider.getEngineInboundProcessor()).thenReturn(engineInboundProcessor);

        engineInboundEventHandler = new EngineInboundEventHandler(executionReport);
    }

    @Test
    public void run() {
        engineInboundEventHandler.run();

        Mockito.verify(engineInboundProcessor, Mockito.times(1)).onMessage(executionReport);
    }

    @Test
    public void equal() {
        final DefaultExecutionReport executionReport = new DefaultExecutionReport();
        final EngineInboundEventHandler engineInboundEventHandler = new EngineInboundEventHandler(executionReport);
        final EngineInboundEventHandler equalEngineInboundEventHandler = new EngineInboundEventHandler(executionReport);

        Assert.assertEquals(engineInboundEventHandler, equalEngineInboundEventHandler);
        Assert.assertEquals(engineInboundEventHandler.hashCode(), equalEngineInboundEventHandler.hashCode());

    }
}