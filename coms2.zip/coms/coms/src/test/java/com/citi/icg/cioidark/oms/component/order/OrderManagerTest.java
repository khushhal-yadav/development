package com.citi.icg.cioidark.oms.component.order;

import com.citi.icg.cioidark.oms.component.dto.OrderState;
import com.citi.icg.cioidark.oms.component.processor.exception.InvalidStateChangeException;
import com.citi.icg.cioidark.oms.component.validator.exception.ValidationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import software.chronicle.fix.codegen.fields.OrdStatus;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;

public class OrderManagerTest {

    private final String orderID = "orderID";
    private final String clOrdID = "clOrdID";
    private final String symbol = "IBM";
    private OrderManager orderManager;

    @Before
    public void init() {
        orderManager = new OrderManager();
    }

    @Test
    public void newOrderSingle() {
        DefaultNewOrderSingle newOrderSingle = createNewOrderSingle();
        final Order order = orderManager.newOrderSingle(newOrderSingle);

        final OrderState orderState = order.getOrderState();
        Assert.assertEquals(orderState.getOrdStatus(), OrdStatus.PENDING_NEW);
        Assert.assertNotEquals(orderState.getOrderID(), orderID);
        Assert.assertEquals(orderState.getClOrdID(), clOrdID);
        Assert.assertTrue(orderManager.getOrderCache().containsClOrdId(clOrdID));
        orderManager.getOrderCache().clearAll();
    }

    @Test
    public void cancelReplaceRequest() {
        final Order order = orderManager.newOrderSingle(createNewOrderSingle());
        order.getOrderState().setOrdStatus(OrdStatus.NEW);
        DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = createOrderCancelReplaceRequest();
        final Order replaceOrder = orderManager.cancelReplaceRequest(orderCancelReplaceRequest);
        Assert.assertEquals(replaceOrder.getOrderState().getOrdStatus(), OrdStatus.PENDING_REPLACE);
    }

    @Test(expected = ValidationException.class)
    public void cancelReplaceRequestWithoutNewOrder() {
        DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = createOrderCancelReplaceRequest();
        orderManager.cancelReplaceRequest(orderCancelReplaceRequest);
    }

    @Test(expected = InvalidStateChangeException.class)
    public void cancelReplaceRequestWithoutNewInPendingState() {
        orderManager.newOrderSingle(createNewOrderSingle());
        DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = createOrderCancelReplaceRequest();
        orderManager.cancelReplaceRequest(orderCancelReplaceRequest);
        orderManager.getOrderCache().clearAll();
    }

    private DefaultOrderCancelReplaceRequest createOrderCancelReplaceRequest() {
        DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = new DefaultOrderCancelReplaceRequest();
        orderCancelReplaceRequest.clOrdID(clOrdID);
        orderCancelReplaceRequest.symbol(symbol);
        return orderCancelReplaceRequest;
    }

    private DefaultNewOrderSingle createNewOrderSingle() {
        DefaultNewOrderSingle newOrderSingle = new DefaultNewOrderSingle();
        newOrderSingle.orderID(orderID);
        newOrderSingle.clOrdID(clOrdID);
        newOrderSingle.symbol(symbol);
        return newOrderSingle;
    }

}