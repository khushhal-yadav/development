package com.citi.icg.cioidark.oms.component.handler;


import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.oms.component.order.OrderFactory;
import com.citi.icg.cioidark.oms.component.processor.FixInboundProcessor;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

@RunWith(PowerMockRunner.class)
@PrepareForTest(OMSApplicationContextProvider.class)
class FixInboundEventHandlerTest {

    @Mock
    private FixInboundProcessor fixInboundProcessor;

    public FixInboundEventHandlerTest() {
    }

    @Before
    public void init() {
        PowerMockito.mockStatic(OMSApplicationContextProvider.class);
        PowerMockito.when(OMSApplicationContextProvider.getFixInboundProcessor())
                .thenReturn(fixInboundProcessor);
    }

    @Test
    public void runNewOrderSingle() {
        final DefaultNewOrderSingle newOrderSingle = Mockito.mock(DefaultNewOrderSingle.class);
        final FixInboundEventHandler fixInboundEventHandler =
                new FixInboundEventHandler(newOrderSingle);

        fixInboundEventHandler.run();

        Mockito.verify(fixInboundProcessor, Mockito.times(1)).onMessage(newOrderSingle);
    }

    @Test
    public void runOrderCancelRequest() {
        final DefaultOrderCancelRequest orderCancelRequest = Mockito.mock(DefaultOrderCancelRequest.class);
        final FixInboundEventHandler fixInboundEventHandler =
                new FixInboundEventHandler(orderCancelRequest);

        fixInboundEventHandler.run();

        Mockito.verify(fixInboundProcessor, Mockito.times(1)).onMessage(orderCancelRequest);
    }

    @Test
    public void runOrderCancelReplaceRequest() {
        final DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = Mockito.mock(DefaultOrderCancelReplaceRequest.class);
        final FixInboundEventHandler fixInboundEventHandler =
                new FixInboundEventHandler(orderCancelReplaceRequest);

        fixInboundEventHandler.run();

        Mockito.verify(fixInboundProcessor, Mockito.times(1)).onMessage(orderCancelReplaceRequest);
    }

    @Test
    public void equal() {
        final DefaultNewOrderSingle newOrderSingle = OrderFactory.createNewOrderSingle();
        final FixInboundEventHandler engineInboundEventHandler = new FixInboundEventHandler(newOrderSingle);
        final FixInboundEventHandler equalFixInboundEventHandler = new FixInboundEventHandler(newOrderSingle);

        Assert.assertEquals(engineInboundEventHandler, equalFixInboundEventHandler);
        Assert.assertEquals(engineInboundEventHandler.hashCode(), equalFixInboundEventHandler.hashCode());

    }

}