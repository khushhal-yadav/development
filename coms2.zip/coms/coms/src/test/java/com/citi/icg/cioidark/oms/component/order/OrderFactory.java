package com.citi.icg.cioidark.oms.component.order;

import software.chronicle.fix.codegen.fields.LocateReqd;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.OrderCapacity;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

public class OrderFactory {

    public final static String symbol = "symbol";
    public final static char side = Side.BUY;
    public final static char ordType = OrdType.LIMIT;
    public final static double orderQty = 1000.0;
    public final static double price = 101.0;
    public final static String clOrdID = "clOrdID";
    public final static String account = "account";
    public final static char orderCapacity = OrderCapacity.PRINCIPAL;
    public final static String senderSubID = "senderSubID";
    public final static String tradingAcct = "tradingAcct";
    public final static char locateReqd = LocateReqd.YES;

    public final static String replaceClOrdID = "replaceClOrdID";

    public final static String cancelClOrdID = "cancelClOrdID";

    public static DefaultNewOrderSingle createNewOrderSingle() {
        DefaultNewOrderSingle newOrderSingle = new DefaultNewOrderSingle();
        newOrderSingle.symbol(symbol);
        newOrderSingle.side(side);
        newOrderSingle.ordType(ordType);
        newOrderSingle.orderQty(orderQty);
        newOrderSingle.price(price);
        newOrderSingle.clOrdID(clOrdID);
        newOrderSingle.account(account);
        newOrderSingle.orderCapacity(orderCapacity);
        newOrderSingle.senderSubID(senderSubID);
        newOrderSingle.tradingAcct(tradingAcct);
        newOrderSingle.locateReqd(locateReqd);
        return newOrderSingle;
    }

    public static DefaultOrderCancelReplaceRequest createOrderCancelReplaceRequest() {
        DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = new DefaultOrderCancelReplaceRequest();
        orderCancelReplaceRequest.symbol(symbol);
        orderCancelReplaceRequest.side(side);
        orderCancelReplaceRequest.ordType(ordType);
        orderCancelReplaceRequest.orderQty(orderQty);
        orderCancelReplaceRequest.price(price);
        orderCancelReplaceRequest.origClOrdID(clOrdID);
        orderCancelReplaceRequest.clOrdID(replaceClOrdID);
        orderCancelReplaceRequest.account(account);
        orderCancelReplaceRequest.orderCapacity(orderCapacity);
        orderCancelReplaceRequest.senderSubID(senderSubID);
        orderCancelReplaceRequest.tradingAcct(tradingAcct);
        orderCancelReplaceRequest.locateReqd(locateReqd);
        return orderCancelReplaceRequest;
    }

    public static DefaultOrderCancelRequest createOrderCancelRequest() {
        DefaultOrderCancelRequest orderCancelRequest = new DefaultOrderCancelRequest();
        orderCancelRequest.symbol(symbol);
        orderCancelRequest.side(side);
        orderCancelRequest.orderQty(orderQty);
        orderCancelRequest.price(price);
        orderCancelRequest.origClOrdID(clOrdID);
        orderCancelRequest.clOrdID(cancelClOrdID);
        orderCancelRequest.account(account);
        orderCancelRequest.senderSubID(senderSubID);
        return orderCancelRequest;
    }
}
