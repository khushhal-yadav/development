package com.citi.icg.cioidark;

import com.citi.icg.cioidark.chronicle.messaging.queue.OMSOut;
import org.apache.commons.configuration.ConfigurationException;
import org.junit.Assert;
import org.junit.Test;

public class OMSDirectorTest {

    @Test
    public void getInstance() {
        Assert.assertEquals(OMSDirector.getInstance(), OMSDirector.getInstance());
    }

    @Test
    public void initialize() throws ConfigurationException {
        final OMSOut omsOut = OMSOutFactory.get();
        OMSDirector.getInstance().initialize(omsOut);
        Assert.assertEquals(OMSApplicationContextProvider.getOmsSystemProperty().getOmsOut(),
                omsOut);
    }
}