package com.citi.icg.cioidark.oms.component.publisher;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.OMSSystemProperty;
import com.citi.icg.cioidark.chronicle.messaging.queue.OMSOut;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;

public class AbstractPublisher {

    @Mock
    protected OMSOut omsOut;
    @Mock
    private OMSSystemProperty omsSystemProperty;

    public void init() throws Exception {
        PowerMockito.mockStatic(OMSApplicationContextProvider.class);
        PowerMockito.when(OMSApplicationContextProvider.getOmsSystemProperty()).thenReturn(omsSystemProperty);
        PowerMockito.when(omsSystemProperty.getOmsOut()).thenReturn(omsOut);
    }

}
