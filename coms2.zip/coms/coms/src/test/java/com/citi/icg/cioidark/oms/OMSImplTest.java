package com.citi.icg.cioidark.oms;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.OMSDirector;
import com.citi.icg.cioidark.OMSOutFactory;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.OMSOut;
import com.citi.icg.cioidark.oms.component.handler.InboundHandler;
import com.citi.icg.cioidark.oms.component.marketData.SubscribeToMarketDataService;
import com.citi.icg.cioidark.oms.component.order.OrderFactory;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

@RunWith(PowerMockRunner.class)
@PrepareForTest({OMSDirector.class, OMSApplicationContextProvider.class})
public class OMSImplTest {
    @Mock
    private SubscribeToMarketDataService subscribeToMarketDataService;
    @Mock
    private InboundHandler inboundHandler;
    @Mock
    private OMSDirector omsDirector;

    private Map<String, MarketDataMessage> marketDataMessageMap = new HashMap<>();

    private OMSOut omsOut;
    private OMSImpl omsImpl;

    @Before
    public void init() throws Exception {
        omsOut = OMSOutFactory.get();
        PowerMockito.mockStatic(OMSDirector.class);
        PowerMockito.mockStatic(OMSApplicationContextProvider.class);
        PowerMockito.when(OMSDirector.getInstance()).thenReturn(omsDirector);
        PowerMockito.doNothing().when(omsDirector, "initialize", omsOut);
        PowerMockito.when(OMSApplicationContextProvider.getSubscribeToMarketDataService()).thenReturn(subscribeToMarketDataService);
        PowerMockito.when(OMSApplicationContextProvider.getInboundHandler()).thenReturn(inboundHandler);
        PowerMockito.when(OMSApplicationContextProvider.marketDataMessageMap()).thenReturn(marketDataMessageMap);

        omsImpl = new OMSImpl(omsOut);
    }


    @Test
    public void clientNewOrderSingle() {
        final NewOrderSingle inboundMessage = OrderFactory.createNewOrderSingle();
        omsImpl.clientNewOrderSingle(inboundMessage);

        DefaultNewOrderSingle newOrderSingle = new DefaultNewOrderSingle();
        inboundMessage.copyTo(newOrderSingle);

        final String bookSymbol = newOrderSingle.symbol() + (newOrderSingle.symbolSfx() == null ? "" : newOrderSingle.symbolSfx());

        Mockito.verify(subscribeToMarketDataService, Mockito.times(1))
                .subscribe(bookSymbol, newOrderSingle.symbol(), true);
        Mockito.verify(inboundHandler, Mockito.times(1)).fixInbound(newOrderSingle);
    }

    @Test
    public void clientOrderCancelRequest() {
        final OrderCancelRequest inboundMessage = OrderFactory.createOrderCancelRequest();
        omsImpl.clientOrderCancelRequest(inboundMessage);

        DefaultOrderCancelRequest orderCancelRequest = new DefaultOrderCancelRequest();
        inboundMessage.copyTo(orderCancelRequest);

        Mockito.verify(inboundHandler, Mockito.times(1)).fixInbound(orderCancelRequest);
    }

    @Test
    public void clientOrderCancelReplaceRequest() {
        final OrderCancelReplaceRequest inboundMessage = OrderFactory.createOrderCancelReplaceRequest();

        omsImpl.clientOrderCancelReplaceRequest(inboundMessage);

        DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = new DefaultOrderCancelReplaceRequest();
        inboundMessage.copyTo(orderCancelReplaceRequest);

        Mockito.verify(inboundHandler, Mockito.times(1)).fixInbound(orderCancelReplaceRequest);
    }

    @Test
    public void executionReport() {
        final ExecutionReport inboundMessage = new DefaultExecutionReport();
        omsImpl.executionReport(inboundMessage);

        DefaultExecutionReport executionReport = new DefaultExecutionReport();
        inboundMessage.copyTo(executionReport);

        Mockito.verify(inboundHandler, Mockito.times(1)).engineInbound(executionReport);
    }

    @Test
    public void marketData() {
        final MarketDataMessage marketDataMessage = new MarketDataMessage(100.0, 100.0, OrderFactory.symbol, 1000L);
        omsImpl.marketData(marketDataMessage);

        Assert.assertEquals(marketDataMessage, OMSApplicationContextProvider.marketDataMessageMap().get(OrderFactory.symbol));
    }

    @Test
    public void testDate () {

        final LocalDateTime now = LocalDateTime.now();
        now.plus(Duration.of(30, ChronoUnit.MINUTES));

        System.out.println(now);
    }

}