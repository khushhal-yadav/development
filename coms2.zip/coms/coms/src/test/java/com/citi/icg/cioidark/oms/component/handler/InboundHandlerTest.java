package com.citi.icg.cioidark.oms.component.handler;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.oms.component.order.OrderFactory;
import com.citi.icg.cioidark.util.threadpool.CioiDarkThreadPool;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;
import software.chronicle.fix.datamodel.AbstractDataModel;

@RunWith(PowerMockRunner.class)
@PrepareForTest(OMSApplicationContextProvider.class)
public class InboundHandlerTest {

    @Mock
    private CioiDarkThreadPool<AbstractDataModel> inboundThreadPool;
    @Mock
    private CioiDarkThreadPool<ExecutionReport> crossingEngineThreadPool;

    private InboundHandler inboundHandler;

    @Before
    public void init() {
        PowerMockito.mockStatic(OMSApplicationContextProvider.class);
        PowerMockito.when(OMSApplicationContextProvider.getInboundFixThreadPool()).thenReturn(inboundThreadPool);
        PowerMockito.when(OMSApplicationContextProvider.getCrossingEngineThreadPool()).thenReturn(crossingEngineThreadPool);

        inboundHandler = new InboundHandler();
    }

    @Test
    public void fixInboundNewOrderSingle() {
        final DefaultNewOrderSingle newOrderSingle = OrderFactory.createNewOrderSingle();
        inboundHandler.fixInbound(newOrderSingle);

        Mockito.verify(inboundThreadPool, Mockito.times(1)).submit(new FixInboundEventHandler(newOrderSingle), OrderFactory.symbol);
    }

    @Test
    public void fixInboundOrderCancelRequest() {
        final DefaultOrderCancelRequest orderCancelRequest = OrderFactory.createOrderCancelRequest();
        inboundHandler.fixInbound(orderCancelRequest);

        Mockito.verify(inboundThreadPool, Mockito.times(1)).submit(new FixInboundEventHandler(orderCancelRequest), OrderFactory.symbol);
    }

    @Test
    public void fixInboundOrderCancelReplaceRequest() {
        final DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = OrderFactory.createOrderCancelReplaceRequest();
        inboundHandler.fixInbound(orderCancelReplaceRequest);

        Mockito.verify(inboundThreadPool, Mockito.times(1)).submit(new FixInboundEventHandler(orderCancelReplaceRequest), OrderFactory.symbol);
    }

    @Test
    public void engineInbound() {
        final DefaultExecutionReport executionReport = Mockito.mock(DefaultExecutionReport.class);
        PowerMockito.when(executionReport.symbol()).thenReturn(OrderFactory.symbol);

        inboundHandler.engineInbound(executionReport);

        Mockito.verify(crossingEngineThreadPool, Mockito.times(1)).submit(new EngineInboundEventHandler(executionReport), OrderFactory.symbol);
    }
}