package com.citi.icg.cioidark;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.OMSOut;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReject;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;

public class OMSOutFactory {

    private final static OMSOut omsOut = new OMSOut() {
        @Override
        public void clientExecutionReport(ExecutionReport executionReport) {}

        @Override
        public void clientOrderCancelReject(OrderCancelReject orderCancelReject) {}

        @Override
        public void newOrderSingle(NewOrderSingle newOrderSingle) {}

        @Override
        public void orderCancelRequest(OrderCancelRequest orderCancelRequest) {}

        @Override
        public void orderCancelReplaceRequest(OrderCancelReplaceRequest orderCancelReplaceRequest) {}

        @Override
        public void executionReport(ExecutionReport executionReport) {}

        @Override
        public void subscribeTick(GMDTickSubscriptionMsg gmdTickSubscriptionMsg) {}

    };

    public static OMSOut get() {
        return omsOut;
    }
}
