package com.citi.icg.cioidark.oms.component.builder;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.OMSOutFactory;
import com.citi.icg.cioidark.util.objectPool.ObjectPool;
import org.apache.commons.configuration.ConfigurationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReject;

public class ExecutionReportBuilderObjectsPoolTest {

    @Before
    public void init() throws ConfigurationException {
        OMSApplicationContextProvider.initialize(OMSOutFactory.get());
    }

    @Test
    public void objectPool() throws Exception {

        final ObjectPool<DefaultExecutionReport> executionReportObjectPool = OMSApplicationContextProvider.getExecutionReportObjectPool();
        final DefaultExecutionReport executionReport = executionReportObjectPool.borrowObject();

        Assert.assertNotNull(executionReport);

        executionReportObjectPool.returnObject(executionReport);

        final ObjectPool<DefaultOrderCancelReject> orderCancelRejectObjectPool = OMSApplicationContextProvider.getOrderCancelRejectObjectPool();
        final DefaultOrderCancelReject orderCancelReject = orderCancelRejectObjectPool.borrowObject();

        Assert.assertNotNull(orderCancelReject);

        orderCancelRejectObjectPool.returnObject(orderCancelReject);

        final DefaultExecutionReport secondExecutionReport = executionReportObjectPool.borrowObject();

        Assert.assertNotNull(secondExecutionReport);
        Assert.assertTrue(executionReport == secondExecutionReport);

        executionReportObjectPool.returnObject(secondExecutionReport);

        final DefaultOrderCancelReject secondOrderCancelReject = orderCancelRejectObjectPool.borrowObject();

        Assert.assertNotNull(secondOrderCancelReject);
        Assert.assertTrue(orderCancelReject == secondOrderCancelReject);

        orderCancelRejectObjectPool.returnObject(secondOrderCancelReject);
    }
}
