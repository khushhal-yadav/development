package com.citi.icg.cioidark.oms.component.publisher;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

@RunWith(PowerMockRunner.class)
@PrepareForTest(OMSApplicationContextProvider.class)
public class OutboundPublisherTest extends AbstractPublisher {

    private OutboundPublisher outboundPublisher;

    @Before
    public void init() throws Exception {
        super.init();
        outboundPublisher = new OutboundPublisher();
    }

    @Test
    public void sendForCrossingNewOrderSingle() {
        final DefaultNewOrderSingle newOrderSingle = Mockito.mock(DefaultNewOrderSingle.class);
        outboundPublisher.sendForCrossing(newOrderSingle);

        Mockito.verify(omsOut, Mockito.times(1)).newOrderSingle(newOrderSingle);
    }

    @Test
    public void sendForCrossingOrderCancelRequest() {
        final DefaultOrderCancelRequest orderCancelRequest = Mockito.mock(DefaultOrderCancelRequest.class);
        outboundPublisher.sendForCrossing(orderCancelRequest);

        Mockito.verify(omsOut, Mockito.times(1)).orderCancelRequest(orderCancelRequest);
    }

    @Test
    public void sendForCrossingOrderCancelReplaceRequest() {
        final DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = Mockito.mock(DefaultOrderCancelReplaceRequest.class);
        outboundPublisher.sendForCrossing(orderCancelReplaceRequest);

        Mockito.verify(omsOut, Mockito.times(1)).orderCancelReplaceRequest(orderCancelReplaceRequest);

    }
}