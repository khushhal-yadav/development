package com.citi.icg.cioidark.oms.component.publisher;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.oms.component.builder.ExecutionReportBuilder;
import com.citi.icg.cioidark.oms.component.order.Order;
import com.citi.icg.cioidark.oms.component.order.OrderCache;
import com.citi.icg.cioidark.oms.component.order.OrderFactory;
import com.citi.icg.cioidark.oms.component.validator.ValidationUtil;
import com.citi.icg.cioidark.util.objectPool.ObjectPool;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReject;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

@RunWith(PowerMockRunner.class)
@PrepareForTest(OMSApplicationContextProvider.class)
public class RejectPublisherTest extends AbstractPublisher {

    @Mock
    private ObjectPool<DefaultExecutionReport> executionReportObjectPool;
    @Mock
    private ObjectPool<DefaultOrderCancelReject> orderCancelRejectObjectPool;

    private OrderCache orderCache = new OrderCache();
    private RejectPublisher rejectPublisher;

    @Before
    public void init() throws Exception {
        super.init();
        PowerMockito.when(executionReportObjectPool.borrowObject()).thenReturn(new DefaultExecutionReport());
        PowerMockito.when(orderCancelRejectObjectPool.borrowObject()).thenReturn(new DefaultOrderCancelReject());
        PowerMockito.when(OMSApplicationContextProvider.getOrderCache()).thenReturn(orderCache);
        PowerMockito.when(OMSApplicationContextProvider.getExecutionReportObjectPool()).thenReturn(executionReportObjectPool);
        PowerMockito.when(OMSApplicationContextProvider.getOrderCancelRejectObjectPool()).thenReturn(orderCancelRejectObjectPool);
        rejectPublisher = new RejectPublisher();
    }

    @Test
    public void rejectNewOrderSingle() {
        PowerMockito.when(OMSApplicationContextProvider.getExecutionReportBuilder()).thenReturn(new ExecutionReportBuilder());

        final DefaultNewOrderSingle newOrderSingle = OrderFactory.createNewOrderSingle();
        final DefaultExecutionReport executionReport = rejectPublisher.rejectNewOrderSingle(newOrderSingle, ValidationUtil.DUPLICATE_CLORDID, 6);

        Assert.assertNotNull(executionReport);
        Mockito.verify(omsOut, Mockito.times(1)).clientExecutionReport(executionReport);

    }

    @Test
    public void rejectCancelRequest() {
        PowerMockito.when(OMSApplicationContextProvider.getExecutionReportBuilder()).thenReturn(new ExecutionReportBuilder());

        final DefaultNewOrderSingle newOrderSingle = OrderFactory.createNewOrderSingle();
        final Order order = new Order(newOrderSingle);
        orderCache.add(order);

        final DefaultOrderCancelRequest orderCancelRequest = OrderFactory.createOrderCancelRequest();

        DefaultOrderCancelReject orderCancelReject = rejectPublisher.rejectCancelRequest(orderCancelRequest, ValidationUtil.ORDER_NOT_FOUND, 99);

        Assert.assertNotNull(orderCancelReject);
        Assert.assertEquals(OrderFactory.cancelClOrdID, orderCancelReject.clOrdID());
        Assert.assertNotEquals(orderCancelReject.orderID(), "NOT_FOUND");
        Mockito.verify(omsOut, Mockito.times(1)).clientOrderCancelReject(orderCancelReject);

        orderCache.clearAll();

        orderCancelReject = rejectPublisher.rejectCancelRequest(orderCancelRequest, ValidationUtil.ORDER_NOT_FOUND, 99);

        Assert.assertNotNull(orderCancelReject);
        Assert.assertEquals(OrderFactory.cancelClOrdID, orderCancelReject.clOrdID());
        Assert.assertEquals("NOT_FOUND", orderCancelReject.orderID());
        Mockito.verify(omsOut, Mockito.times(2)).clientOrderCancelReject(orderCancelReject);

    }

    @Test
    public void rejectCancelReplaceRequest() {
        PowerMockito.when(OMSApplicationContextProvider.getExecutionReportBuilder()).thenReturn(new ExecutionReportBuilder());

        final DefaultNewOrderSingle newOrderSingle = OrderFactory.createNewOrderSingle();
        final Order order = new Order(newOrderSingle);
        orderCache.add(order);

        final DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = OrderFactory.createOrderCancelReplaceRequest();

        DefaultOrderCancelReject orderCancelReject = rejectPublisher.rejectCancelReplaceRequest(orderCancelReplaceRequest, ValidationUtil.ORDER_NOT_FOUND, 99);

        Assert.assertNotNull(orderCancelReject);
        Assert.assertEquals(OrderFactory.replaceClOrdID, orderCancelReject.clOrdID());
        Assert.assertNotEquals("NOT_FOUND", orderCancelReject.orderID());
        Mockito.verify(omsOut, Mockito.times(1)).clientOrderCancelReject(orderCancelReject);

        orderCache.clearAll();

        orderCancelReject = rejectPublisher.rejectCancelReplaceRequest(orderCancelReplaceRequest, ValidationUtil.ORDER_NOT_FOUND, 99);

        Assert.assertNotNull(orderCancelReject);
        Assert.assertEquals(OrderFactory.replaceClOrdID, orderCancelReject.clOrdID());
        Assert.assertEquals("NOT_FOUND", orderCancelReject.orderID());
        Mockito.verify(omsOut, Mockito.times(2)).clientOrderCancelReject(orderCancelReject);

    }
}