package com.citi.icg.cioidark;

import com.citi.icg.cioidark.chronicle.messaging.message.admin.AbstractSystemProperty;
import com.citi.icg.cioidark.chronicle.messaging.queue.OMSOut;
import org.apache.commons.configuration.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OMSSystemProperty extends AbstractSystemProperty {

    private static final Logger logger = LoggerFactory.getLogger(OMSSystemProperty.class);

    private final OMSOut omsOut;

    public OMSSystemProperty(OMSOut omsOut) throws ConfigurationException {
        super("oms.properties");

        this.omsOut = omsOut;

        logger.info("OMSSystemProperty loaded: {}", this.toString());
    }

    public OMSOut getOmsOut() {
        return omsOut;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
