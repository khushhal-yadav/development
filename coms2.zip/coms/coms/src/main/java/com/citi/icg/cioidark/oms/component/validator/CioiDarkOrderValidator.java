package com.citi.icg.cioidark.oms.component.validator;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.enumeration.ShortSaleRestriction;
import com.citi.icg.cioidark.oms.component.validator.exception.ValidationException;
import com.citi.icg.cioidark.util.FixTagUtil;
import org.joda.time.DateTime;
import software.chronicle.fix.codegen.fields.Account;
import software.chronicle.fix.codegen.fields.ClOrdID;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.OrderCapacity;
import software.chronicle.fix.codegen.fields.OrderQty;
import software.chronicle.fix.codegen.fields.OrigClOrdID;
import software.chronicle.fix.codegen.fields.Price;
import software.chronicle.fix.codegen.fields.ShortSaleExemptReason;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.fields.Symbol;
import software.chronicle.fix.codegen.fields.SymbolSfx;
import software.chronicle.fix.codegen.fields.TimeInForce;
import software.chronicle.fix.codegen.fields.TimeToLive;
import software.chronicle.fix.codegen.fields.TransactTime;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;
import software.chronicle.fix.datamodel.AbstractDataModel;
import software.chronicle.fix.sessioncode.fields.SenderCompID;
import software.chronicle.fix.sessioncode.fields.SenderSubID;

public class CioiDarkOrderValidator implements ValidationUtil {

    public final void validate(AbstractDataModel message) {
        requireTags(message, ClOrdID.FIELD, SenderCompID.FIELD, SenderSubID.FIELD, Symbol.FIELD);

        if (FixTagUtil.isValueSet(message.getLong(TimeToLive.FIELD))) {
            DateTime timeToLive = new DateTime(message.getLong(TimeToLive.FIELD));
            if (timeToLive.isBeforeNow())
                throw new ValidationException(TIME_TO_LIVE);
        }

        MarketDataMessage md = OMSApplicationContextProvider.marketDataMessageMap().get(message.getString(Symbol.FIELD));
        if (FixTagUtil.isValueSet(message.getString(SymbolSfx.FIELD)) && "WI".equals(message.getString(SymbolSfx.FIELD)))
            throw new ValidationException(REJECT_WHEN_ISSUED);

        if (Side.SELL_SHORT_EXEMPT == message.getChar(Side.FIELD) && !(md.getShortSaleRestricted() == ShortSaleRestriction.SHORT_SALE_RESTRICTION_ACTIVATED.value())
                && "1".equals(message.getString(ShortSaleExemptReason.FIELD))) {
            throw new ValidationException(REJECT_INCOMING_SSE);
        }
    }


    /**
     * Order New/Mod validations
     **/
    public void validateNewOrderSingle(DefaultNewOrderSingle newOrderSingle, boolean limitOrder) {
        requiredTagsNewMod(newOrderSingle);
        requireTags(newOrderSingle, OrderQty.FIELD);
        if (limitOrder) {
            validTags(newOrderSingle, Price.FIELD);
            // TODO: move this to engine?
            // require(isWithinMaxOrderValue(newOrderSingle, book), UNDER_MIN_NOTIONAL_REJECT);
        }
    }

    public void validateOrderCancelRequest(DefaultOrderCancelRequest orderCancelRequest) {
        requireTags(orderCancelRequest, ClOrdID.FIELD, OrigClOrdID.FIELD, Side.FIELD, Symbol.FIELD, TransactTime.FIELD);
    }

    private void requiredTagsNewMod(AbstractDataModel msg) {
        requireTags(msg, OrdType.FIELD, Side.FIELD, ClOrdID.FIELD, SenderCompID.FIELD, SenderSubID.FIELD, Symbol.FIELD
                , Account.FIELD, OrderQty.FIELD, TransactTime.FIELD, OrderCapacity.FIELD, TimeInForce.FIELD);
        requireTagValueOneOf(msg, TimeInForce.FIELD, String.valueOf(TimeInForce.DAY));
        requireTagValueOneOf(msg, OrdType.FIELD, String.valueOf(OrdType.MARKET), String.valueOf(OrdType.LIMIT));
    }

    /**
     * Order New/Mod validations
     **/
    public void validateOrderCancelReplaceRequest(AbstractDataModel msg, boolean limitOrder) {
        requiredTagsNewMod(msg);
        requireTags(msg, OrderQty.FIELD, OrigClOrdID.FIELD);
        if (limitOrder) {
            validTags(msg, Price.FIELD);
            // TODO: move this to engine?
            // require(isWithinMaxOrderValue(msg, book), UNDER_MIN_NOTIONAL_REJECT);
        }
    }

}
