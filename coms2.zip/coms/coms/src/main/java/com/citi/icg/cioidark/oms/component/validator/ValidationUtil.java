package com.citi.icg.cioidark.oms.component.validator;

import java.util.Arrays;

import com.citi.icg.cioidark.fix.field.FixFieldClass;
import com.citi.icg.cioidark.oms.component.validator.exception.ValidationException;
import com.citi.icg.cioidark.util.FixTagUtil;
import software.chronicle.fix.datamodel.AbstractDataModel;

public interface ValidationUtil {

    String REJECT_PREFIX = "CIOIDARK:";
    String TIME_TO_LIVE = REJECT_PREFIX + "Message Delayed Past Time-to-live";
    String REJECT_WHEN_ISSUED = REJECT_PREFIX + "When issued symbol not accepted";
    String REJECT_INCOMING_SSE = REJECT_PREFIX + "Incoming Exemption when short sale not active";
    String DUPLICATE_CLORDID = REJECT_PREFIX + "Duplicate Client Order Id";
    String ORDER_NOT_FOUND = REJECT_PREFIX + "Order not found for clOrdId: {0} origClOrdID: {1}";

    String MISSING_TAG_REJECT = REJECT_PREFIX + "missing tag {0,number,#}";
    String UNEXPECTED_VALUE_REJECT = REJECT_PREFIX + "unexpected value [{0}] for tag {1}";

    default void require(boolean condition, String rejectText, Object... args) {
        if (!condition) {
            throw new ValidationException(rejectText, args);
        }
    }

    default void requireTags(AbstractDataModel msg, int... tags) {
        Arrays.stream(tags).filter(FixFieldClass.FIX_STRING_TYPE_FIELDS::contains).forEach(tag
                -> require(FixTagUtil.isValueSet(msg.getString(tag)), MISSING_TAG_REJECT, tag));
        Arrays.stream(tags).filter(FixFieldClass.FIX_DOUBLE_TYPE_FIELDS::contains).forEach(tag
                -> require(FixTagUtil.isValueSet(msg.getDouble(tag)), MISSING_TAG_REJECT, tag));
        Arrays.stream(tags).filter(FixFieldClass.FIX_CHAR_TYPE_FIELDS::contains).forEach(tag
                -> require(FixTagUtil.isValueSet(msg.getChar(tag)), MISSING_TAG_REJECT, tag));
        Arrays.stream(tags).filter(FixFieldClass.FIX_LONG_TYPE_FIELDS::contains).forEach(tag
                -> require(FixTagUtil.isValueSet(msg.getLong(tag)), MISSING_TAG_REJECT, tag));
    }

    default void validTags(AbstractDataModel msg, int... tags) {
        Arrays.stream(tags).filter(FixFieldClass.FIX_DOUBLE_TYPE_FIELDS::contains).forEach(tag
                -> require(msg.getDouble(tag) != Double.NaN, MISSING_TAG_REJECT, tag));
    }

    default void requireTagValueOneOf(AbstractDataModel msg, int tag, String... validValues) {
        String actualValue = msg.getString(tag);
        require(Arrays.stream(validValues).anyMatch(v -> v.equals(msg.getString(tag))), UNEXPECTED_VALUE_REJECT, actualValue, tag);
    }
}
