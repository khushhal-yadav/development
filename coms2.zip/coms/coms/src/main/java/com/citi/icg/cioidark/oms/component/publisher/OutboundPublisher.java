package com.citi.icg.cioidark.oms.component.publisher;

import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

public class OutboundPublisher extends Publisher {

    public void sendForCrossing(final DefaultNewOrderSingle newOrderSingle) {
        omsOut.newOrderSingle(newOrderSingle);
    }

    public void sendForCrossing(final DefaultOrderCancelRequest orderCancelReject) {
        omsOut.orderCancelRequest(orderCancelReject);
    }

    public void sendForCrossing(final DefaultOrderCancelReplaceRequest orderCancelReplaceRequest) {
        omsOut.orderCancelReplaceRequest(orderCancelReplaceRequest);
    }
}
