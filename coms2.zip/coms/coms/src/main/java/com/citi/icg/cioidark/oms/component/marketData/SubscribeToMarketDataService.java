package com.citi.icg.cioidark.oms.component.marketData;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SubscribeToMarketDataService {

    private static final Logger logger = LoggerFactory.getLogger(SubscribeToMarketDataService.class);

    public boolean subscribe(final String bookSymbol, final String marketDataSymbol,
                             final boolean subscribe) {

        if (StringUtils.isEmpty(bookSymbol)) {
            logger.warn("Booksymbol: {} is empty and marketDataSymbol: {}, so didn't subscribe : subcribeValue {} ", bookSymbol, marketDataSymbol, subscribe);
            return false;
        }

        OMSApplicationContextProvider.getOmsSystemProperty()
                .getOmsOut().subscribeTick(getGmdTickSubscriptionMsg(bookSymbol, marketDataSymbol, subscribe));

        logger.info("Subscription message sent to marketData for Booksymbol: {} and marketDataSymbol: {}", bookSymbol, marketDataSymbol);

        return true;

    }

    private GMDTickSubscriptionMsg getGmdTickSubscriptionMsg(String bookSymbol, String marketDataSymbol, boolean subscribe) {
        return new GMDTickSubscriptionMsg(bookSymbol, marketDataSymbol, subscribe);
    }
}
