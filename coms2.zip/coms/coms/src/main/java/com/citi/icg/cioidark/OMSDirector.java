package com.citi.icg.cioidark;

import com.citi.icg.cioidark.chronicle.messaging.queue.OMSOut;
import org.apache.commons.configuration.ConfigurationException;

public class OMSDirector {

    private final static OMSDirector director = new OMSDirector();

    private OMSDirector() {}

    public static OMSDirector getInstance() {
        return  director;
    }

    public void initialize(final OMSOut omsOut) throws ConfigurationException {
        OMSApplicationContextProvider.initialize(omsOut);
    }
}
