package com.citi.icg.cioidark.oms.component.order;

import java.math.BigDecimal;
import java.util.Objects;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.oms.component.dto.OrderState;
import com.citi.icg.cioidark.oms.component.processor.exception.InvalidStateChangeException;
import com.citi.icg.cioidark.oms.component.validator.ValidationUtil;
import com.citi.icg.cioidark.oms.component.validator.exception.ValidationException;
import net.openhft.chronicle.core.Maths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.fields.ExecTransType;
import software.chronicle.fix.codegen.fields.ExecType;
import software.chronicle.fix.codegen.fields.OrdStatus;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;
import software.chronicle.fix.datamodel.AbstractDataModel;

public class OrderManager {

    private final static Logger logger = LoggerFactory.getLogger(OrderManager.class);

    private final OrderCache orderCache;

    public OrderManager() {
        this.orderCache = OMSApplicationContextProvider.getOrderCache();
    }

    public OrderCache getOrderCache() {
        return orderCache;
    }

    public Order newOrderSingle(DefaultNewOrderSingle newOrderSingle) {
        Order order = new Order(newOrderSingle);
        order.getOrderState().setOrdStatus(OrdStatus.PENDING_NEW);
        orderCache.add(order);
        return order;
    }

    public Order cancelReplaceRequest(final OrderCancelReplaceRequest orderCancelReplaceRequest) {

        synchronized (orderCancelReplaceRequest.symbol()) {
            Order replaceOrder = orderCache.get(orderCancelReplaceRequest.clOrdID(), orderCancelReplaceRequest.origClOrdID());

            if (Objects.isNull(replaceOrder))
                throw new ValidationException(ValidationUtil.ORDER_NOT_FOUND,
                        orderCancelReplaceRequest.clOrdID(), orderCancelReplaceRequest.origClOrdID());

            if (replaceOrder.isPending() || replaceOrder.isOut())
                throw new InvalidStateChangeException("was: " + replaceOrder.getOrderState().getOrdStatus());

            replaceOrder.getOrderState().setOrdStatus(OrdStatus.PENDING_REPLACE);

            return replaceOrder;
        }
    }

    public Order cancelRequest(OrderCancelRequest cancelRequest) {

        synchronized (cancelRequest.symbol()) {
            final Order cxlOrder = orderCache.get(cancelRequest.clOrdID(), cancelRequest.origClOrdID());

            if (Objects.isNull(cxlOrder))
                throw new ValidationException(ValidationUtil.ORDER_NOT_FOUND,
                        cancelRequest.clOrdID(), cancelRequest.origClOrdID());

            if (cxlOrder.isPending() || !cxlOrder.isOpen())
                throw new InvalidStateChangeException("was: " + cxlOrder.getOrderState().getOrdStatus());

            cxlOrder.getOrderState().setOrdStatus(OrdStatus.PENDING_CANCEL);

            return cxlOrder;
        }
    }

    public DefaultExecutionReport ackOrFill(ExecutionReport executionReport) {
        final String clOrdId = executionReport.clOrdID();
        final String origClOrdId = executionReport.origClOrdID();
        final Order order = orderCache.get(clOrdId, origClOrdId);

        if (isCancelledByAnEvent(executionReport)) {
            logger.warn("Removing the order from Cache with clOrdID: {}, origClOrdID: {} as " +
                            "order cancellation event: {} was triggered", clOrdId,
                    origClOrdId, executionReport.cxlReason());
            orderCache.remove(clOrdId, origClOrdId);
            return null;
        }

        if (Objects.nonNull(order) && !isTrade(executionReport))
            return ack(order, executionReport);

        return fill(order, executionReport);
    }

    private DefaultExecutionReport fill(Order order, ExecutionReport executionReport) {
        OrderState orderState = order.getOrderState()
                .setCrossID(executionReport.crossID());

        double lastShares = executionReport.lastShares();
        double lastPx = executionReport.lastPx();

        double newCumQty = 0;
        double newAvgPx = 0;
        double leavesQty;

        if (isTrade(executionReport)) {
            double cumQty = orderState.getCumQty();
            double avgPx = orderState.getAvgPx();
            newCumQty = lastShares + cumQty;
            newAvgPx = ((lastShares * lastPx) + (cumQty * avgPx)) / newCumQty;
        }
        leavesQty = orderState.getOrderQty() - newCumQty;
        orderState.setAvgPx(Maths.round2(newAvgPx));
        orderState.setCumQty(newCumQty);
        orderState.setLeavesQty(leavesQty);
        orderState.setLastPx(lastPx);
        orderState.setLastShares(lastShares);

        if (BigDecimal.ZERO.compareTo(BigDecimal.valueOf(leavesQty)) == 0 )
            orderState.setOrdStatus(OrdStatus.FILLED);
        else
            orderState.setOrdStatus(OrdStatus.PARTIALLY_FILLED);

        return OMSApplicationContextProvider.getExecutionReportBuilder().crossFill(order);
    }

    private DefaultExecutionReport ack(Order order, ExecutionReport executionReport) {
        final AbstractDataModel abstractDataModel = orderCache.get(executionReport.clOrdID(), executionReport.origClOrdID()).getOrderState().getCurrentMsg();

        if (abstractDataModel instanceof DefaultNewOrderSingle)
            return ack(order, (DefaultNewOrderSingle) abstractDataModel);
        else if (abstractDataModel instanceof DefaultOrderCancelReplaceRequest)
            return ack(order, (DefaultOrderCancelReplaceRequest) abstractDataModel);
        else if (abstractDataModel instanceof DefaultOrderCancelRequest)
            return ack(order, (DefaultOrderCancelRequest) abstractDataModel);

        return null;
    }

    private DefaultExecutionReport ack(Order newOrder, DefaultNewOrderSingle newOrderSingle) {
        newOrder.getOrderState().setOrdStatus(OrdStatus.NEW);
        return OMSApplicationContextProvider.getExecutionReportBuilder().newAck(newOrder, newOrderSingle);
    }

    private DefaultExecutionReport ack(Order replaceOrder, DefaultOrderCancelReplaceRequest orderCancelReplaceRequest) {
        replaceOrder.addOrderToStates(replaceOrder.getOrderState().deepCopy());

        OrderState orderState = replaceOrder.getOrderState();
        orderState.setClOrdID(orderCancelReplaceRequest.clOrdID())
                .ordType(orderCancelReplaceRequest.ordType())
                .setOrderQty(orderCancelReplaceRequest.orderQty())
                .setPrice(orderCancelReplaceRequest.price())
                .setOrdStatus(OrdStatus.REPLACED)
                .setCurrentMsg(orderCancelReplaceRequest)
                .incrementOrderVersion();


        return OMSApplicationContextProvider.getExecutionReportBuilder()
                .modAck(replaceOrder, orderCancelReplaceRequest);
    }

    private DefaultExecutionReport ack(final Order cxlOrder, final DefaultOrderCancelRequest orderCancelRequest) {
        cxlOrder.addOrderToStates(cxlOrder.getOrderState().deepCopy());

        OrderState orderState = cxlOrder.getOrderState();
        orderState.setOrdStatus(OrdStatus.CANCELED)
                .setCurrentMsg(orderCancelRequest)
                .incrementOrderVersion();


        return OMSApplicationContextProvider.getExecutionReportBuilder().cxlAck(cxlOrder, orderCancelRequest);
    }


    private static boolean isTrade(ExecutionReport executionReport) {
        return ((executionReport.execType() == ExecType.PARTIAL_FILL
                || executionReport.execType() == ExecType.FILL) && executionReport.execTransType() == ExecTransType.NEW)
                || executionReport.execType() == ExecType.TRADE;
    }

    private boolean isCancelledByAnEvent(final ExecutionReport executionReport) {
        return executionReport.execType() == ExecType.CANCELED
                && executionReport.ordStatus() == OrdStatus.CANCELED
                && Objects.nonNull(executionReport.cxlReason());
    }


}
