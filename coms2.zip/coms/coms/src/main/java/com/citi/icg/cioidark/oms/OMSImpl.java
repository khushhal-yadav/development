package com.citi.icg.cioidark.oms;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.OMSDirector;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.OMSIn;
import com.citi.icg.cioidark.chronicle.messaging.queue.OMSOut;
import com.citi.icg.cioidark.chronicle.service.AbstractChronicleService;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

@SuppressWarnings({"WeakerAccess", "unused"})
//Suppressed warnings as this class is being used as chronicle service impl class
public class OMSImpl extends AbstractChronicleService implements OMSIn {

    private static final Logger logger = LoggerFactory.getLogger(OMSImpl.class);

    public OMSImpl(final OMSOut omsOut) throws ConfigurationException {
        OMSDirector.getInstance().initialize(omsOut);
    }

    @Override
    public void clientNewOrderSingle(NewOrderSingle inboundMessage) {
        logger.info("OMS_IN: Client FIX Inbound Message: NewOrderSingle | {} ", inboundMessage);

        final String symbol = inboundMessage.symbol();
        if (StringUtils.isEmpty(symbol)) {
            logger.warn("ITRSALERT|NewOrderSingle received with symbol={}, dropping message", symbol);
            return;
        }
        DefaultNewOrderSingle newOrderSingle = new DefaultNewOrderSingle();
        inboundMessage.copyTo(newOrderSingle);

        final String suffix = newOrderSingle.symbolSfx() == null ? "" : newOrderSingle.symbolSfx();
        final String bookSymbol = newOrderSingle.symbol() + suffix;
        OMSApplicationContextProvider.getSubscribeToMarketDataService().subscribe(bookSymbol, newOrderSingle.symbol(), true);

        OMSApplicationContextProvider.getInboundHandler().fixInbound(newOrderSingle);
    }

    @Override
    public void clientOrderCancelRequest(OrderCancelRequest inboundMessage) {
        logger.info("OMS_IN: Client FIX Inbound Message: OrderCancelRequest |{}", inboundMessage);

        final String symbol = inboundMessage.symbol();
        if (StringUtils.isEmpty(symbol)) {
            logger.warn("ITRSALERT|OrderCancelRequest received with getSymbol={}, dropping message", symbol);
            return;
        }
        DefaultOrderCancelRequest orderCancelRequest = new DefaultOrderCancelRequest();
        inboundMessage.copyTo(orderCancelRequest);
        OMSApplicationContextProvider.getInboundHandler().fixInbound(orderCancelRequest);
    }

    @Override
    public void clientOrderCancelReplaceRequest(OrderCancelReplaceRequest inboundMessage) {
        logger.info("OMS_IN: Client FIX Inbound Message: OrderCancelReplaceRequest |{}", inboundMessage);

        final String symbol = inboundMessage.symbol();
        if (StringUtils.isEmpty(symbol)) {
            logger.warn("ITRSALERT|OrderCancelReplaceRequest received with symbol={}, dropping message", symbol);
            return;
        }
        DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = new DefaultOrderCancelReplaceRequest();
        inboundMessage.copyTo(orderCancelReplaceRequest);

        OMSApplicationContextProvider.getInboundHandler().fixInbound(orderCancelReplaceRequest);
    }

    @Override
    public void executionReport(ExecutionReport inboundMessage) {
        logger.info("OMS_IN: Crossing Engine Ack or Fill: ExecutionReport |{}", inboundMessage);

        DefaultExecutionReport executionReport = new DefaultExecutionReport();
        inboundMessage.copyTo(executionReport);

        OMSApplicationContextProvider.getInboundHandler().engineInbound(executionReport);
    }

    @Override
    public void marketData(MarketDataMessage inboundMessage) {
        logger.info("OMS_IN: Market data being put in map |{}", inboundMessage);

        MarketDataMessage marketData = new MarketDataMessage();
        inboundMessage.copyTo(marketData);

        OMSApplicationContextProvider.marketDataMessageMap().put(marketData.getSymbol(), marketData);
    }
}
