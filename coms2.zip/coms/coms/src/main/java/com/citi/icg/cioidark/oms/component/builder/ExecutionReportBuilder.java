package com.citi.icg.cioidark.oms.component.builder;

import java.util.Objects;
import java.util.Set;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.enumeration.ExternalSystem;
import com.citi.icg.cioidark.idgen.IDGenerator;
import com.citi.icg.cioidark.oms.component.dto.OrderState;
import com.citi.icg.cioidark.oms.component.order.Order;
import com.citi.icg.cioidark.util.BooleanUtil;
import com.citi.icg.cioidark.util.FixTagUtil;
import com.google.common.collect.Sets;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.fields.Account;
import software.chronicle.fix.codegen.fields.ActReport;
import software.chronicle.fix.codegen.fields.AvgPriceAcct;
import software.chronicle.fix.codegen.fields.BidPx;
import software.chronicle.fix.codegen.fields.BidSize;
import software.chronicle.fix.codegen.fields.ClOrdID;
import software.chronicle.fix.codegen.fields.ClearingInstruction;
import software.chronicle.fix.codegen.fields.ContraOrderCapacity;
import software.chronicle.fix.codegen.fields.CorellationClOrdID;
import software.chronicle.fix.codegen.fields.CrossInstruction;
import software.chronicle.fix.codegen.fields.CrossRestrictionClientID;
import software.chronicle.fix.codegen.fields.CustomerSlang;
import software.chronicle.fix.codegen.fields.CxlRejResponseTo;
import software.chronicle.fix.codegen.fields.ExecInst;
import software.chronicle.fix.codegen.fields.ExecType;
import software.chronicle.fix.codegen.fields.IDSource;
import software.chronicle.fix.codegen.fields.LegalEntity;
import software.chronicle.fix.codegen.fields.LocateBroker;
import software.chronicle.fix.codegen.fields.LocateIdentifier;
import software.chronicle.fix.codegen.fields.LocateReqd;
import software.chronicle.fix.codegen.fields.MinQty;
import software.chronicle.fix.codegen.fields.OfferPx;
import software.chronicle.fix.codegen.fields.OfferSize;
import software.chronicle.fix.codegen.fields.OnBehalfOfCompID;
import software.chronicle.fix.codegen.fields.OnBehalfOfSubID;
import software.chronicle.fix.codegen.fields.OrdStatus;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.OrderCapacity;
import software.chronicle.fix.codegen.fields.OrderFlowClass;
import software.chronicle.fix.codegen.fields.OrderFlowEntry;
import software.chronicle.fix.codegen.fields.OrderID;
import software.chronicle.fix.codegen.fields.OrderQty;
import software.chronicle.fix.codegen.fields.PreviousLinkOrderID;
import software.chronicle.fix.codegen.fields.PreviousLinkSrcSystemID;
import software.chronicle.fix.codegen.fields.Price;
import software.chronicle.fix.codegen.fields.QuoteTime;
import software.chronicle.fix.codegen.fields.ReceiveTime;
import software.chronicle.fix.codegen.fields.RootOrderID;
import software.chronicle.fix.codegen.fields.RootSrcSystemID;
import software.chronicle.fix.codegen.fields.SecurityAltID;
import software.chronicle.fix.codegen.fields.SecurityAltIDSource;
import software.chronicle.fix.codegen.fields.SecurityID;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.fields.SrcTargetCompId;
import software.chronicle.fix.codegen.fields.StrategyParameterValue;
import software.chronicle.fix.codegen.fields.Symbol;
import software.chronicle.fix.codegen.fields.SymbolSfx;
import software.chronicle.fix.codegen.fields.TickSizePilotGroup;
import software.chronicle.fix.codegen.fields.TimeInForce;
import software.chronicle.fix.codegen.fields.TraderID;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReject;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReject;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;
import software.chronicle.fix.datamodel.AbstractDataModel;
import software.chronicle.fix.sessioncode.fields.SenderCompID;
import software.chronicle.fix.sessioncode.fields.SenderSubID;
import software.chronicle.fix.sessioncode.fields.TargetCompID;
import software.chronicle.fix.sessioncode.fields.TargetSubID;
import software.chronicle.fix.staticcode.messages.FixConstants;

public class ExecutionReportBuilder {

    private final static Logger logger = LoggerFactory.getLogger(ExecutionReportBuilder.class);

    private static final Set<String> execInst_Not_Held = Sets.newHashSet("M 1", "1 M", "1");

    private void enrichExecutionReport(final DefaultExecutionReport executionReport, final Order order, final AbstractDataModel sourceMessage) {
        DateTime now = DateTime.now();
        executionReport.execID(IDGenerator.newID());
        executionReport.sendingTime(now.getMillis());
        executionReport.transactTime(now.getMillis());
        //Was being set as "H" in Citibloc code, so inherited from there
        executionReport.sourceFeed("H");

        copyAllTags(sourceMessage, executionReport);

        if (Objects.nonNull(order)) {

            executionReport.senderCompID(order.getOrderState().senderCompId());
            executionReport.senderSubID(order.getOrderState().senderSubID());
            executionReport.orderQty(order.getOrderState().getOrderQty());
            executionReport.orderID(order.getOrderState().getOrderID());
            executionReport.price(order.getOrderState().getPrice());
            executionReport.orderVersion(order.getOrderState().orderVersion());
            executionReport.targetCompID(order.getOrderState().targetCompId());
            executionReport.targetSubID(order.getOrderState().targetSubID());
            if (sourceMessage instanceof OrderCancelRequest && Objects.nonNull(order))
                executionReport.setChar(OrdType.FIELD, order.getOrderState().ordType());
        }

        BooleanUtil.ifPresentSetFixTag(sourceMessage.getDouble(OrderQty.FIELD), executionReport::leavesQty);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(CorellationClOrdID.FIELD), executionReport::corellationClOrdID);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(PreviousLinkOrderID.FIELD), executionReport::previousLinkOrderID);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(RootOrderID.FIELD), executionReport::rootOrderID);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(CustomerSlang.FIELD), executionReport::customerSlang);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(IDSource.FIELD), executionReport::idSource);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getChar(TimeInForce.FIELD), executionReport::timeInForce);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(StrategyParameterValue.FIELD), executionReport::strategyParameterValue);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ReceiveTime.FIELD), executionReport::receiveTime);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(CrossRestrictionClientID.FIELD), executionReport::crossRestrictionClientID);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(TickSizePilotGroup.FIELD), executionReport::tickSizePilotGroup);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ClearingInstruction.FIELD), executionReport::clearingInstruction);

        if (FixTagUtil.isValueSet(sourceMessage.getString(OnBehalfOfSubID.FIELD))) {
            executionReport.deliverToSubID(sourceMessage.getString(OnBehalfOfSubID.FIELD));
            executionReport.onBehalfOfSubID(sourceMessage.getString(OnBehalfOfSubID.FIELD));
        }

        if (FixTagUtil.isValueSet(sourceMessage.getString(OnBehalfOfCompID.FIELD))) {
            executionReport.deliverToCompID(sourceMessage.getString(OnBehalfOfCompID.FIELD));
            executionReport.onBehalfOfCompID(sourceMessage.getString(OnBehalfOfCompID.FIELD));
        }

        mapExecInst(executionReport, sourceMessage);
    }

    private void mapExecInst(final DefaultExecutionReport executionReport,
                             final AbstractDataModel sourceMessage) {
        String execInst = "5 M";
        if (FixTagUtil.isValueSet(sourceMessage.getString(ExecInst.FIELD))) {
            if (execInst_Not_Held.contains(sourceMessage.getString(ExecInst.FIELD))) {
                execInst = "1 M";
            }
        }
        //append u65 for DNCS
        if (FixTagUtil.isValueSet(sourceMessage.getString(CrossInstruction.FIELD))
                && sourceMessage.getString(CrossInstruction.FIELD).contains("NS")) {
            execInst = execInst + " u65";
        }

        executionReport.execInst(execInst);
    }

    public void enrichOrderCancelReject(final DefaultOrderCancelReject orderCancelReject, final Order order, final AbstractDataModel sourceMessage) {

        if (!(sourceMessage instanceof OrderCancelRequest || sourceMessage instanceof OrderCancelReplaceRequest)
                && Objects.nonNull(order)) {
            orderCancelReject.setChar(OrdType.FIELD, order.getOrderState().ordType());
        }

        DateTime now = DateTime.now();
        orderCancelReject.senderCompID(sourceMessage.getString(SenderCompID.FIELD));
        orderCancelReject.senderSubID(sourceMessage.getString(SenderSubID.FIELD));
        orderCancelReject.sendingTime(now.getMillis());
        orderCancelReject.transactTime(now.getMillis());
        orderCancelReject.targetCompID(sourceMessage.getString(TargetCompID.FIELD));
        orderCancelReject.targetSubID(sourceMessage.getString(TargetSubID.FIELD));
        copyAllTags(sourceMessage, orderCancelReject);
        if (FixTagUtil.isValueSet(sourceMessage.getString(OnBehalfOfSubID.FIELD))) {
            orderCancelReject.deliverToSubID(sourceMessage.getString(OnBehalfOfSubID.FIELD));
            orderCancelReject.onBehalfOfSubID(sourceMessage.getString(OnBehalfOfSubID.FIELD));
        }

        if (FixTagUtil.isValueSet(sourceMessage.getString(OnBehalfOfCompID.FIELD))) {
            orderCancelReject.deliverToCompID(sourceMessage.getString(OnBehalfOfCompID.FIELD));
            orderCancelReject.onBehalfOfCompID(sourceMessage.getString(OnBehalfOfCompID.FIELD));
        }

        BooleanUtil.ifPresentSetFixTag(sourceMessage.getChar(Side.FIELD), orderCancelReject::side);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getDouble(Price.FIELD), orderCancelReject::price);

        orderCancelReject.sourceFeed("H");
    }

    public void enrichExecutionReport(final DefaultExecutionReport executionReport, final NewOrderSingle newOrderSingle) {
        DateTime now = DateTime.now();
        executionReport.clOrdID(newOrderSingle.clOrdID());
        executionReport.execID(IDGenerator.newID());
        executionReport.sendingTime(now.getMillis());
        executionReport.transactTime(now.getMillis());
    }

    public DefaultExecutionReport newReject(NewOrderSingle newOrderSingle, String text, int rejReason) {
        DefaultExecutionReport executionReport = null;

        try {
            executionReport = OMSApplicationContextProvider.getExecutionReportObjectPool().borrowObject();
            enrichExecutionReport(executionReport, newOrderSingle);

            executionReport.execType(ExecType.REJECTED);
            executionReport.ordStatus(OrdStatus.REJECTED);
            executionReport.ordRejReason(rejReason);
            executionReport.text(text);
            if (FixConstants.isUnset(executionReport.orderID()))
                executionReport.orderID(IDGenerator.newID());
            executionReport.avgPx(0);
            executionReport.cumQty(0);
            executionReport.leavesQty(0);
            BooleanUtil.ifPresentSetFixTag(newOrderSingle.clearingInstruction(), executionReport::clearingInstruction);
        } catch (Exception ex) {
            logger.error("ITRSALERT| Error creating ExecutionReport for newReject {}", newOrderSingle);
        } finally {
            OMSApplicationContextProvider.getExecutionReportObjectPool().returnObject(executionReport);
        }
        return executionReport;

    }

    public DefaultOrderCancelReject modReject(final Order order, final OrderCancelReplaceRequest sourceMessage,
                                              final String text, final String orderId, final int rejReason) {
        DefaultOrderCancelReject orderCancelReject = null;

        try {
            orderCancelReject = OMSApplicationContextProvider.getOrderCancelRejectObjectPool().borrowObject();
            enrichOrderCancelReject(orderCancelReject, order, (DefaultOrderCancelReplaceRequest) sourceMessage);
            orderCancelReject.ordStatus(OrdStatus.CANCELED);
            orderCancelReject.clOrdID(sourceMessage.clOrdID());
            orderCancelReject.orderQty(sourceMessage.orderQty());
            orderCancelReject.origClOrdID(sourceMessage.origClOrdID());
            orderCancelReject.execType(ExecType.REJECTED);
            orderCancelReject.cxlRejResponseTo(CxlRejResponseTo.ORDER_CANCEL_REPLACE_REQUEST);
            orderCancelReject.cxlRejReason(rejReason);
            orderCancelReject.text(text);
            orderCancelReject.orderID(orderId);
        } catch (Exception ex) {
            logger.error("ITRSALERT| Error creating OrderCancelReject for modReject {}", sourceMessage);
        } finally {
            OMSApplicationContextProvider.getOrderCancelRejectObjectPool().returnObject(orderCancelReject);
        }


        return orderCancelReject;
    }

    public DefaultOrderCancelReject cancelReject(final Order order, final OrderCancelRequest sourceMessage,
                                                 final String text, final String orderId, final int rejReason) {
        DefaultOrderCancelReject orderCancelReject = null;

        try {
            orderCancelReject = OMSApplicationContextProvider.getOrderCancelRejectObjectPool().borrowObject();
            enrichOrderCancelReject(orderCancelReject, order, (DefaultOrderCancelRequest) sourceMessage);
            orderCancelReject.ordStatus(OrdStatus.CANCELED);
            orderCancelReject.clOrdID(sourceMessage.clOrdID());
            orderCancelReject.orderQty(sourceMessage.orderQty());
            orderCancelReject.origClOrdID(sourceMessage.origClOrdID());
            orderCancelReject.execType(ExecType.REJECTED);
            orderCancelReject.cxlRejResponseTo(CxlRejResponseTo.ORDER_CANCEL_REQUEST);
            orderCancelReject.cxlRejReason(rejReason);
            orderCancelReject.text(text);
            orderCancelReject.orderID(orderId);
        } catch (Exception ex) {
            logger.error("ITRSALERT| Error creating OrderCancelReject for cancelReject {}", sourceMessage);
        } finally {
            OMSApplicationContextProvider.getOrderCancelRejectObjectPool().returnObject(orderCancelReject);
        }

        return orderCancelReject;
    }

    public DefaultExecutionReport newAck(Order order, NewOrderSingle newOrderSingle) {
        DefaultExecutionReport executionReport = null;

        try {
            executionReport = OMSApplicationContextProvider.getExecutionReportObjectPool().borrowObject();
            enrichExecutionReport(executionReport, order, (DefaultNewOrderSingle) newOrderSingle);
            executionReport.ordStatus(OrdStatus.NEW);
            executionReport.execType(ExecType.NEW);
            executionReport.avgPriceAcctIDSource(newOrderSingle.avgPriceAcctIDSource());
            executionReport.bidPx(newOrderSingle.bidPx());
            executionReport.offerPx(newOrderSingle.offerPx());
            BooleanUtil.ifPresentSetFixTag(newOrderSingle.clearingInstruction(), executionReport::clearingInstruction);
            BooleanUtil.ifPresentSetFixTag(newOrderSingle.tickSizePilotGroup(), executionReport::tickSizePilotGroup);
            executionReport.avgPx(0);
            executionReport.cumQty(0);
        } catch (Exception ex) {
            logger.error("ITRSALERT| Error creating ExecutionReport for newAck {}", newOrderSingle);
        } finally {
            OMSApplicationContextProvider.getExecutionReportObjectPool().returnObject(executionReport);
        }

        return executionReport;
    }

    private void newCanModCommon(DefaultExecutionReport executionReport, Order order, AbstractDataModel sourceMessage) {
        executionReport.avgPx(0);
        executionReport.cumQty(0);
        executionReport.leavesQty(0);

        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ClearingInstruction.FIELD), executionReport::clearingInstruction);
        BooleanUtil.ifTrueExecute(order != null, () -> executionReport.orderVersion(order.getOrderState().orderVersion()));
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getDouble(Price.FIELD), executionReport::price);
    }

    public DefaultExecutionReport modAck(final Order order, final OrderCancelReplaceRequest sourceMessage) {
        DefaultExecutionReport executionReport = null;

        try {
            executionReport = OMSApplicationContextProvider.getExecutionReportObjectPool().borrowObject();
            enrichExecutionReport(executionReport, order, (DefaultOrderCancelReplaceRequest) sourceMessage);
            newCanModCommon(executionReport, order, (DefaultOrderCancelReplaceRequest) sourceMessage);
            executionReport.ordStatus(OrdStatus.REPLACED);
            executionReport.execType(ExecType.REPLACE);
            executionReport.origClOrdID(sourceMessage.clOrdID());
            executionReport.leavesQty(executionReport.orderQty() - executionReport.cumQty());
            BooleanUtil.ifPresentSetFixTag(sourceMessage.clearingInstruction(), executionReport::clearingInstruction);

            return executionReport;

        } catch (Exception ex) {
            logger.error("ITRSALERT| Error creating ExecutionReport for modAck {}", sourceMessage);
        } finally {
            OMSApplicationContextProvider.getExecutionReportObjectPool().returnObject(executionReport);
        }

        return executionReport;

    }

    public DefaultExecutionReport cxlAck(final Order order, final OrderCancelRequest sourceMessage) {
        DefaultExecutionReport executionReport = null;

        try {
            executionReport = OMSApplicationContextProvider.getExecutionReportObjectPool().borrowObject();
            enrichExecutionReport(executionReport, order, (DefaultOrderCancelRequest) sourceMessage);

            BooleanUtil.ifPresentSetFixTag(sourceMessage.origClOrdID(), executionReport::origClOrdID);
            executionReport.ordStatus(OrdStatus.CANCELED);
            executionReport.execType(ExecType.CANCELED);
            newCanModCommon(executionReport, order, (DefaultOrderCancelRequest) sourceMessage);
            executionReport.account(null);
            BooleanUtil.ifPresentSetFixTag(sourceMessage.clearingInstruction(), executionReport::clearingInstruction);

        } catch (Exception ex) {
            logger.error("ITRSALERT| Error creating ExecutionReport for cxlAck {}", sourceMessage);
        } finally {
            OMSApplicationContextProvider.getExecutionReportObjectPool().returnObject(executionReport);
        }

        return executionReport;
    }

    public DefaultExecutionReport unsolCxl(Order order, DefaultExecutionReport sourceMessage) {
        DefaultExecutionReport executionReport = null;

        try {
            executionReport = OMSApplicationContextProvider.getExecutionReportObjectPool().borrowObject();
            enrichExecutionReport(executionReport, order, sourceMessage);
            executionReport.ordStatus(OrdStatus.CANCELED);
            executionReport.execType(ExecType.CANCELED);

            newCanModCommon(executionReport, order, sourceMessage);

        } catch (Exception ex) {
            logger.error("ITRSALERT| Error creating ExecutionReport for unsolCxl {}", sourceMessage);
        } finally {
            OMSApplicationContextProvider.getExecutionReportObjectPool().returnObject(executionReport);
        }

        return sourceMessage;
    }

    public DefaultExecutionReport crossFill(final Order order) {
        DefaultExecutionReport executionReport = null;

        try {
            executionReport = OMSApplicationContextProvider.getExecutionReportObjectPool().borrowObject();
            OrderState orderState = order.getOrderState();
            executionReport.execType(ExecType.TRADE);
            executionReport.lastPx(orderState.getLastPx());
            executionReport.lastShares(orderState.getLastShares());
            executionReport.side(Side.CROSS);
            executionReport.price(FixConstants.UNSET_DOUBLE);
            executionReport.clOrdID(null);
            executionReport.minQty(FixConstants.UNSET_DOUBLE);
            executionReport.orderQty(FixConstants.UNSET_DOUBLE);
            executionReport.orderCapacity(FixConstants.UNSET_CHAR);
            executionReport.quoteTime(FixConstants.UNSET_LONG);
            executionReport.bidPx(FixConstants.UNSET_DOUBLE);
            executionReport.offerPx(FixConstants.UNSET_DOUBLE);
            executionReport.avgPriceAcct(null);
            executionReport.legalEntity(null);
            executionReport.firmId(null);
            executionReport.crossID(orderState.getCrossID());
            executionReport.zExecID(orderState.getCrossID() + ":0");
            executionReport.actReport(ActReport.PARTYMUSTRPT);
            executionReport.targetCompID(ExternalSystem.CTRS.value());
            executionReport.targetSubID(ExternalSystem.CTRS.value());
            executionReport.srcTargetCompId(ExternalSystem.CTRS.value());
            //executionReport.avgPriceAcctIDSource(sourceMessage.getString(AvgPriceAcctIDSource.FIELD));
            //BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(TickSizePilotGroup.FIELD), executionReport::tickSizePilotGroup);
        } catch (Exception ex) {
            logger.error("ITRSALERT| Error creating ExecutionReport for crossfill order {}", order);
        } finally {
            OMSApplicationContextProvider.getExecutionReportObjectPool().returnObject(executionReport);
        }

        return executionReport;
    }

    public DefaultExecutionReport fill(final Order order) {
        DefaultExecutionReport executionReport = null;

        try {
            executionReport = OMSApplicationContextProvider.getExecutionReportObjectPool().borrowObject();
            enrichExecutionReport(executionReport, order, order.getOrderState().getCurrentMsg());
            executionReport.execType(ExecType.TRADE);
            executionReport.lastPx(order.getOrderState().getLastPx());
            executionReport.lastShares(order.getOrderState().getLastShares());
        } catch (Exception ex) {
            logger.error("ITRSALERT| Error creating ExecutionReport for fill order {}", order);
        } finally {
            OMSApplicationContextProvider.getExecutionReportObjectPool().returnObject(executionReport);
        }
        return executionReport;
    }

    public void copyAllTags(final AbstractDataModel sourceMessage, AbstractDataModel executionReport) {

        executionReport.setString(Account.FIELD, sourceMessage.getString(Account.FIELD));
        executionReport.setString(SrcTargetCompId.FIELD, sourceMessage.getString(SrcTargetCompId.FIELD));
        executionReport.setString(ClOrdID.FIELD, sourceMessage.getString(ClOrdID.FIELD));
        executionReport.setString(OrderID.FIELD, sourceMessage.getString(OrderID.FIELD));
        executionReport.setString(Symbol.FIELD, sourceMessage.getString(Symbol.FIELD));
        executionReport.setString(SymbolSfx.FIELD, sourceMessage.getString(SymbolSfx.FIELD));
        executionReport.setChar(Side.FIELD, sourceMessage.getChar(Side.FIELD));
        executionReport.setDouble(Price.FIELD, sourceMessage.getDouble(Price.FIELD));
        executionReport.setDouble(OrderQty.FIELD, sourceMessage.getDouble(OrderQty.FIELD));
        executionReport.setDouble(BidPx.FIELD, sourceMessage.getDouble(BidPx.FIELD));
        executionReport.setDouble(OfferPx.FIELD, sourceMessage.getDouble(OfferPx.FIELD));

        if (sourceMessage instanceof DefaultNewOrderSingle) {
            executionReport.setDouble(BidSize.FIELD, sourceMessage.getDouble(BidSize.FIELD));
            executionReport.setDouble(OfferSize.FIELD, sourceMessage.getDouble(OfferSize.FIELD));
            executionReport.setLong(RootSrcSystemID.FIELD, sourceMessage.getLong(RootSrcSystemID.FIELD));
            executionReport.setLong(PreviousLinkSrcSystemID.FIELD, sourceMessage.getLong(PreviousLinkSrcSystemID.FIELD));
            executionReport.setChar(ContraOrderCapacity.FIELD, sourceMessage.getChar(ContraOrderCapacity.FIELD));
            executionReport.setString(OrderFlowEntry.FIELD, sourceMessage.getString(OrderFlowEntry.FIELD));
            executionReport.setString(OrderFlowClass.FIELD, sourceMessage.getString(OrderFlowClass.FIELD));
            executionReport.setString(TraderID.FIELD, sourceMessage.getString(TraderID.FIELD));
            executionReport.setString(AvgPriceAcct.FIELD, sourceMessage.getString(AvgPriceAcct.FIELD));
            executionReport.setString(LegalEntity.FIELD, sourceMessage.getString(LegalEntity.FIELD));
            executionReport.setString(LocateBroker.FIELD, sourceMessage.getString(LocateBroker.FIELD));
            executionReport.setString(LocateIdentifier.FIELD, sourceMessage.getString(LocateIdentifier.FIELD));
        }
        if (!(executionReport instanceof OrderCancelReject)) {
            executionReport.setChar(OrdType.FIELD, sourceMessage.getChar(OrdType.FIELD));
            executionReport.setDouble(MinQty.FIELD, sourceMessage.getDouble(MinQty.FIELD));
            executionReport.setChar(LocateReqd.FIELD, sourceMessage.getChar(LocateReqd.FIELD));
            executionReport.setChar(OrderCapacity.FIELD, sourceMessage.getChar(OrderCapacity.FIELD));
            executionReport.setString(SecurityAltID.FIELD, sourceMessage.getString(SecurityAltID.FIELD));
            executionReport.setString(SecurityAltIDSource.FIELD, sourceMessage.getString(SecurityAltIDSource.FIELD));
            executionReport.setString(SecurityID.FIELD, sourceMessage.getString(SecurityID.FIELD));
            executionReport.setString(CrossInstruction.FIELD, sourceMessage.getString(CrossInstruction.FIELD));
            executionReport.setLong(QuoteTime.FIELD, sourceMessage.getLong(QuoteTime.FIELD));
        }

    }
}
