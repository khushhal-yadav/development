package com.citi.icg.cioidark.oms.component.publisher;

import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;

public class AckPublisher extends Publisher {

    public void executionReport(final DefaultExecutionReport executionReport) {
        omsOut.clientExecutionReport(executionReport);
    }
}
