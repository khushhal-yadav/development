package com.citi.icg.cioidark.oms.component.dto;

import com.citi.icg.cioidark.enumeration.EventType;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.ints.IntSet;
import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.bytes.BytesIn;
import net.openhft.chronicle.bytes.BytesOut;
import net.openhft.chronicle.wire.AbstractBytesMarshallable;
import net.openhft.chronicle.wire.BinaryWire;
import net.openhft.chronicle.wire.WireIn;
import net.openhft.chronicle.wire.WireOut;
import net.openhft.chronicle.wire.Wires;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.datamodel.AbstractDataModel;
import software.chronicle.fix.staticcode.messages.FixMessage;

public class OrderState extends AbstractBytesMarshallable {

    private String orderID = null;
    private String clOrdID = null;
    private String crossID = null;
    private String account = null;
    private String symbol = null;
    private String securityID = null;
    private String idSource = null;
    private String securityAltID = null;
    private char side = FixMessage.UNSET_CHAR;
    private char timeInForce;
    private char ordType = FixMessage.UNSET_CHAR;
    private char ordStatus;
    private double orderQty = FixMessage.UNSET_DOUBLE;
    private double price = FixMessage.UNSET_DOUBLE;
    private double cumQty = FixMessage.UNSET_DOUBLE;
    private double avgPx = FixMessage.UNSET_DOUBLE;
    private double leavesQty = FixMessage.UNSET_DOUBLE;
    private String pendingClOrdID = null;
    private double newPrice = FixMessage.UNSET_DOUBLE;
    private double newOrderQty = FixMessage.UNSET_DOUBLE;
    private EventType eventType = null;
    private char orderCapacity = FixMessage.UNSET_CHAR;
    private String senderSubID = null;
    private String targetSubID = null;
    private String currency = null;
    private String exDestination = null;
    private String orderLinkID = null;

    private double lastTraded = 0;
    private double newLastTraded = 0;

    private String senderCompId = null;
    private String targetCompId = null;

    private String tradingAcct = null;

    private int pendingCancelCounter = 0;
    private char newTimeInForce = FixMessage.UNSET_CHAR;
    private char newOrdType = FixMessage.UNSET_CHAR;

    private Bytes venueExecIDBuffer = Bytes.allocateElasticDirect();
    private Bytes venueExecID = Bytes.fromString("");

    private Bytes clientExecIDBuffer = Bytes.allocateElasticDirect();
    private Bytes clientExecID = Bytes.fromString("");

    private double lastPx = FixMessage.UNSET_DOUBLE;
    private double lastShares = FixMessage.UNSET_DOUBLE;

    private char locateReqd = FixMessage.UNSET_CHAR;

    private int orderVersion = 0;
    private AbstractDataModel currentMsg = null;
    private transient Int2ObjectMap<CharSequence> customFieldMap = null;

    public OrderState orderVersion(int orderVersion) {
        this.orderVersion = orderVersion;
        return this;
    }

    public OrderState incrementOrderVersion() {
        this.orderVersion += 1;
        return this;
    }

    public int orderVersion() {
        return orderVersion;
    }

    public char locateReqd() {
        return locateReqd;
    }

    public OrderState locateReqd(char locateReqd) {
        this.locateReqd = locateReqd;
        return this;
    }

    public double getLastPx() {
        return lastPx;
    }

    public OrderState setLastPx(double lastPx) {
        this.lastPx = lastPx;
        return this;
    }

    public double getLastShares() {
        return lastShares;
    }

    public OrderState setLastShares(double lastShares) {
        this.lastShares = lastShares;
        return this;
    }

    public OrderState setCurrentMsg(AbstractDataModel msg) {
        this.currentMsg = msg;
        return this;
    }

    public AbstractDataModel getCurrentMsg() {
        return currentMsg;
    }

    public OrderState() {

    }

    /**
     * OrderState is created with required fields.
     * All other fields could potentially be defaulted. for example: TIF
     */
    public OrderState(String orderID,
                      String symbol,
                      char side,
                      char ordType,
                      double orderQty,
                      double price) {
        this.orderID = orderID;
        this.symbol = symbol;
        this.side = side;
        this.ordType = ordType;
        this.orderQty = orderQty;
        this.price = price;
    }

    public CharSequence getCustomField(int field) {
        return customFieldMap != null ? customFieldMap.get(field) : null;
    }

    public IntSet getCustomFieldMapKeys() {
        return customFieldMap != null ? customFieldMap.keySet() : null;
    }

    public void setCustomField(int field, CharSequence fieldValue) {
        if (customFieldMap == null)
            customFieldMap = new Int2ObjectOpenHashMap();  //Review this if need use some other implementation?
        customFieldMap.put(field, fieldValue);
    }

    public String getOrderID() {
        return orderID;
    }

    public String getClOrdID() {
        return clOrdID;
    }

    public OrderState setClOrdID(String clOrdID) {
        this.clOrdID = clOrdID;
        return this;
    }

    public String getCrossID() {
        return crossID;
    }

    public OrderState setCrossID(String crossID) {
        this.crossID = crossID;
        return this;
    }

    public String getAccount() {
        return account;
    }

    public OrderState setAccount(String account) {
        this.account = account;
        return this;
    }

    public String getSymbol() {
        return symbol;
    }

    public char getSide() {
        return side;
    }

    public char getTimeInForce() {
        return timeInForce;
    }

    public OrderState setTimeInForce(char timeInForce) {
        this.timeInForce = timeInForce;
        return this;
    }

    public char getOrdType() {
        return ordType;
    }

    public char getOrdStatus() {
        return ordStatus;
    }

    public OrderState setOrdStatus(char ordStatus) {
        this.ordStatus = ordStatus;
        return this;
    }

    public double getOrderQty() {
        return orderQty;
    }

    public OrderState setOrderQty(double orderQty) {
        this.orderQty = orderQty;
        return this;
    }

    public double getPrice() {
        return price;
    }

    public OrderState setPrice(double price) {
        this.price = price;
        return this;
    }

    public double getCumQty() {
        return cumQty;
    }

    public OrderState setCumQty(double cumQty) {
        this.cumQty = cumQty;
        return this;
    }

    public double getAvgPx() {
        return avgPx;
    }

    public OrderState setAvgPx(double avgPx) {
        this.avgPx = avgPx;
        return this;
    }

    public double getLeavesQty() {
        return leavesQty;
    }

    public OrderState setLeavesQty(double leavesQty) {
        this.leavesQty = leavesQty;
        return this;
    }

    public String getPendingClOrdID() {
        return pendingClOrdID;
    }

    public OrderState setPendingClOrdID(String pendingClOrdID) {
        this.pendingClOrdID = pendingClOrdID;
        return this;
    }

    public EventType getEventType() {
        return eventType;
    }

    public OrderState setEventType(EventType eventType) {
        this.eventType = eventType;
        return this;
    }

    public char getOrderCapacity() {
        return orderCapacity;
    }

    public OrderState setOrderCapacity(char orderCapacity) {
        this.orderCapacity = orderCapacity;
        return this;
    }

    public String senderSubID() {
        return senderSubID;
    }

    public OrderState senderSubID(String senderSubID) {
        this.senderSubID = senderSubID;
        return this;
    }

    public String targetSubID() {
        return targetSubID;
    }

    public OrderState targetSubID(String targetSubID) {
        this.targetSubID = targetSubID;
        return this;
    }

    public String getCurrency() {
        return this.currency;
    }

    public OrderState setCurrency(String curr) {
        this.currency = curr;
        return this;
    }

    public String getExDestination() {
        return this.exDestination;
    }

    public OrderState setExDestination(String exDestination) {
        this.exDestination = exDestination;
        return this;
    }

    public String getOrderLinkID() {
        return this.orderLinkID;
    }

    public OrderState setOrderLinkID(String orderLinkID) {
        this.orderLinkID = orderLinkID;
        return this;
    }

    public double getLastTraded() {
        return lastTraded;
    }

    public void setLastTraded(double lastTraded) {
        this.lastTraded = lastTraded;
    }

    public double getNewLastTraded() {
        return newLastTraded;
    }

    public OrderState setNewLastTraded(double newLastTraded) {
        this.newLastTraded = newLastTraded;
        return this;
    }

    public double getNewPrice() {
        return newPrice;
    }

    public OrderState setNewPrice(double newPrice) {
        this.newPrice = newPrice;
        return this;
    }

    public double getNewOrderQty() {
        return newOrderQty;
    }

    public OrderState setNewOrderQty(double newOrderQty) {
        this.newOrderQty = newOrderQty;
        return this;
    }

    public String getSecurityID() {
        return securityID;
    }

    public OrderState setSecurityID(String securityID) {
        this.securityID = securityID;
        return this;
    }

    public String getIdSource() {
        return idSource;
    }

    public OrderState setIdSource(String idSource) {
        this.idSource = idSource;
        return this;
    }

    public String getSecurityAltID() {
        return securityAltID;
    }

    public OrderState setSecurityAltID(String securityAltID) {
        this.securityAltID = securityAltID;
        return this;
    }

    public String senderCompId() {
        return senderCompId;
    }

    public OrderState senderCompId(String senderCompId) {
        this.senderCompId = senderCompId;
        return this;
    }

    public String targetCompId() {
        return targetCompId;
    }

    public OrderState targetCompId(String targetCompId) {
        this.targetCompId = targetCompId;
        return this;
    }

    public String tradingAcct() {
        return tradingAcct;
    }

    public OrderState tradingAcct(String tradingAcct) {
        this.tradingAcct = tradingAcct;
        return this;
    }

    public int pendingCancelCounter() {
        return pendingCancelCounter;
    }

    public int incrementAndGetPendingCancelCounter() {
        return ++pendingCancelCounter;
    }

    public int decrementAndGetPendingCancelCounter() {
        return --pendingCancelCounter;
    }

    public OrderState pendingCancelCounter(int pendingCancelCounter) {
        this.pendingCancelCounter = pendingCancelCounter;
        return this;
    }

    public char newTimeInForce() {
        return newTimeInForce;
    }

    public OrderState newTimeInForce(char newTimeInForce) {
        this.newTimeInForce = newTimeInForce;
        return this;
    }

    public char newOrdType() {
        return newOrdType;
    }

    public OrderState newOrdType(char newOrdType) {
        this.newOrdType = newOrdType;
        return this;
    }

    public char ordType() {
        return ordType;
    }

    public OrderState ordType(char ordType) {
        this.ordType = ordType;
        return this;
    }

    public Bytes getVenueExecID() {
        return venueExecID;
    }

    public OrderState setVenueExecID(Bytes venueExecID) {
        this.venueExecID = venueExecID;
        return this;
    }

    public Bytes getClientExecID() {
        return clientExecID;
    }

    public OrderState setClientExecID(Bytes clientExecID) {
        this.clientExecID = clientExecID;
        return this;
    }

    public Bytes venueExecIDBuffer() {
        venueExecIDBuffer.clear();
        return venueExecIDBuffer;
    }

    public Bytes clientExecIDBuffer() {
        clientExecIDBuffer.clear();
        return clientExecIDBuffer;
    }

    @Override
    public void readMarshallable(@NotNull WireIn wire) {
        if (wire instanceof BinaryWire) {
            readMarshallable(((BinaryWire) wire).bytes());
        } else {
            Wires.readMarshallable(this, wire, false);
        }
    }

    @Override
    public void writeMarshallable(@NotNull WireOut wire) {
        if (wire instanceof BinaryWire) {
            writeMarshallable(((BinaryWire) wire).bytes());
        } else {
            Wires.writeMarshallable(this, wire, false);
        }
    }

    @Override
    public void readMarshallable(BytesIn bytes) {

        orderID = bytes.read8bit();
        clOrdID = bytes.read8bit();
        account = bytes.read8bit();
        symbol = bytes.read8bit();
        pendingClOrdID = bytes.read8bit();
        senderSubID = bytes.read8bit();
        currency = bytes.read8bit();
        exDestination = bytes.read8bit();

        securityID = bytes.read8bit();
        idSource = bytes.read8bit();
        securityAltID = bytes.read8bit();

        orderLinkID = bytes.read8bit();
        senderCompId = bytes.read8bit();
        targetCompId = bytes.read8bit();
        tradingAcct = bytes.read8bit();

        byte et = bytes.readByte();
        eventType = et == -1 ? null : EventType.values()[et]; //Allow for null.

        side = (char) bytes.readStopBit();
        timeInForce = (char) bytes.readStopBit();
        ordType = (char) bytes.readStopBit();
        ordStatus = (char) bytes.readStopBit();
        orderCapacity = (char) bytes.readStopBit();
        newTimeInForce = (char) bytes.readStopBit();
        newOrdType = (char) bytes.readStopBit();
        locateReqd = (char) bytes.readStopBit();


        orderQty = bytes.readDouble(); //TODO _dp?
        price = bytes.readDouble();
        cumQty = bytes.readDouble();
        avgPx = bytes.readDouble();
        leavesQty = bytes.readDouble();
        newPrice = bytes.readDouble();
        newOrderQty = bytes.readDouble();
        lastTraded = bytes.readDouble();
        newLastTraded = bytes.readDouble();

        pendingCancelCounter = bytes.readInt();

        venueExecID = venueExecIDBuffer;
        bytes.read8bit(this.venueExecID);

        clientExecID = clientExecIDBuffer;
        bytes.read8bit(this.clientExecID);

        lastShares = bytes.readDouble();
        lastPx = bytes.readDouble();

        int sizeOfCustomMap = bytes.readInt();
        for (int i = 0; i < sizeOfCustomMap; i++) {
            setCustomField(bytes.readInt(), bytes.read8bit());
        }
    }

    @Override
    public void writeMarshallable(BytesOut bytes) {
        bytes.write8bit(orderID);
        bytes.write8bit(clOrdID);
        bytes.write8bit(account);
        bytes.write8bit(symbol);
        bytes.write8bit(pendingClOrdID);
        bytes.write8bit(senderSubID);
        bytes.write8bit(currency);
        bytes.write8bit(exDestination);

        bytes.write8bit(securityID);
        bytes.write8bit(idSource);
        bytes.write8bit(securityAltID);

        bytes.write8bit(orderLinkID);
        bytes.write8bit(senderCompId);
        bytes.write8bit(targetCompId);
        bytes.write8bit(tradingAcct);
        bytes.writeByte(eventType == null ? -1 : (byte) eventType.ordinal()); //writeEnum() doesn't handle null.

        bytes.writeStopBit(side);
        bytes.writeStopBit(timeInForce);
        bytes.writeStopBit(ordType);
        bytes.writeStopBit(ordStatus);
        bytes.writeStopBit(orderCapacity);
        bytes.writeStopBit(newTimeInForce);
        bytes.writeStopBit(newOrdType);
        bytes.writeStopBit(locateReqd);

        bytes.writeDouble(orderQty);
        bytes.writeDouble(price);
        bytes.writeDouble(cumQty);
        bytes.writeDouble(avgPx);
        bytes.writeDouble(leavesQty);
        bytes.writeDouble(newPrice);
        bytes.writeDouble(newOrderQty);
        bytes.writeDouble(lastTraded);
        bytes.writeDouble(newLastTraded);

        bytes.writeInt(pendingCancelCounter);

        bytes.write8bit(venueExecID);
        bytes.write8bit(clientExecID);

        bytes.writeDouble(lastShares);
        bytes.writeDouble(lastPx);


        if (customFieldMap != null) {
            bytes.writeInt(customFieldMap.size());

            customFieldMap.forEach((key, value) -> {
                bytes.writeInt(key);
                bytes.write8bit(value);
            });
        } else {
            bytes.writeInt(0);
        }


    }

    @Override
    public boolean equals(Object o) {
        return super.equals(o);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
