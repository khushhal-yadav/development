package com.citi.icg.cioidark.oms.component.order;

import java.util.LinkedList;
import java.util.List;

import com.citi.icg.cioidark.idgen.IDGenerator;
import com.citi.icg.cioidark.oms.component.dto.OrderState;
import software.chronicle.fix.codegen.fields.OrdStatus;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;

public class Order {

    private OrderState orderState;
    private List<OrderState> prevOrderStates;

    public Order(DefaultNewOrderSingle nos) {
        orderState = new OrderState(
                IDGenerator.newID(), nos.symbol(), nos.side(), nos.ordType(), nos.orderQty(), nos.price())
                .setClOrdID(nos.clOrdID())
                .setTimeInForce(nos.timeInForce())
                .setOrdStatus(OrdStatus.NEW)
                .setAccount(nos.account())
                .setCumQty(0.0)
                .setAvgPx(0.0)
                .setLeavesQty(nos.orderQty())
                .setOrderCapacity(nos.orderCapacity())
                .senderSubID(nos.senderSubID())
                .tradingAcct(nos.tradingAcct())
                .locateReqd(nos.locateReqd())
                .orderVersion(1).setCurrentMsg(nos);

        setRoutingTags(nos);
    }

    private void setRoutingTags(NewOrderSingle newOrderSingle) {
        orderState.targetCompId(newOrderSingle.targetCompID()).senderCompId(newOrderSingle.senderCompID()).senderSubID(newOrderSingle.senderSubID());
    }

    public OrderState getOrderState() {
        return orderState;
    }

    public void addOrderToStates(OrderState orderState) {
        if (prevOrderStates == null) {
            prevOrderStates = new LinkedList<>();
        }
        prevOrderStates.add(orderState);
    }

    public boolean isOut() {
        switch (getOrderState().getOrdStatus()) {
            case OrdStatus.REJECTED:
            case OrdStatus.CANCELED:
            case OrdStatus.EXPIRED:
            case OrdStatus.FILLED:
            case OrdStatus.DONE_FOR_DAY:
                return true;
            default:
                return false;
        }
    }

    public boolean isPending() {
        switch (getOrderState().getOrdStatus()) {
            case OrdStatus.PENDING_NEW:
            case OrdStatus.PENDING_REPLACE:
            case OrdStatus.PENDING_CANCEL:
                return true;
            default:
                return false;
        }
    }

    public boolean isOpen() {
        return !isOut() && getOrderState().getLeavesQty() > 0;
    }

}
