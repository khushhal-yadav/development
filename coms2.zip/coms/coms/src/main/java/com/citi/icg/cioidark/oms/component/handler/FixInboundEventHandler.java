package com.citi.icg.cioidark.oms.component.handler;

import java.util.Objects;
import java.util.Optional;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.util.threadpool.event.DispatchableEvent;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;
import software.chronicle.fix.datamodel.AbstractDataModel;

//InboundDispEvent
public class FixInboundEventHandler extends DispatchableEvent<AbstractDataModel> {

    FixInboundEventHandler(AbstractDataModel message) {
        this.setPayload(message);
    }

    @Override
    public void run() {

        AbstractDataModel message = getPayload();

        assert message != null;

        if (message instanceof DefaultNewOrderSingle) {
            OMSApplicationContextProvider.getFixInboundProcessor()
                    .onMessage((DefaultNewOrderSingle) message);
        } else if (message instanceof DefaultOrderCancelRequest) {
            OMSApplicationContextProvider.getFixInboundProcessor()
                    .onMessage((DefaultOrderCancelRequest) message);
        } else if (message instanceof DefaultOrderCancelReplaceRequest) {
            OMSApplicationContextProvider.getFixInboundProcessor()
                    .onMessage((DefaultOrderCancelReplaceRequest) message);
        }
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getPayload());
    }

    @Override
    public boolean equals(Object obj) {
        return Optional.ofNullable(obj)
                .filter(FixInboundEventHandler.class::isInstance)
                .map(FixInboundEventHandler.class::cast)
                .filter(o -> Objects.equals(this.getPayload(), o.getPayload()))
                .isPresent();
    }
}
