package com.citi.icg.cioidark;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.OMSOut;
import com.citi.icg.cioidark.oms.component.builder.ExecutionReportBuilder;
import com.citi.icg.cioidark.oms.component.enricher.CioiDarkOrderEnricher;
import com.citi.icg.cioidark.oms.component.handler.InboundHandler;
import com.citi.icg.cioidark.oms.component.marketData.SubscribeToMarketDataService;
import com.citi.icg.cioidark.oms.component.order.OrderCache;
import com.citi.icg.cioidark.oms.component.order.OrderManager;
import com.citi.icg.cioidark.oms.component.processor.EngineInboundProcessor;
import com.citi.icg.cioidark.oms.component.processor.FixInboundProcessor;
import com.citi.icg.cioidark.oms.component.publisher.AckPublisher;
import com.citi.icg.cioidark.oms.component.publisher.OutboundPublisher;
import com.citi.icg.cioidark.oms.component.publisher.RejectPublisher;
import com.citi.icg.cioidark.oms.component.validator.CioiDarkOrderValidator;
import com.citi.icg.cioidark.util.objectPool.ObjectPool;
import com.citi.icg.cioidark.util.objectPool.PooledObjectFactory;
import com.citi.icg.cioidark.util.threadpool.CioiDarkThreadPool;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReject;
import software.chronicle.fix.datamodel.AbstractDataModel;

public class OMSApplicationContextProvider {

    private static final Logger logger = LoggerFactory.getLogger(OMSApplicationContextProvider.class);

    static final OMSApplicationContextProvider instance = new OMSApplicationContextProvider();

    private static OMSSystemProperty omsSystemProperty;
    private static Map<String, MarketDataMessage> marketDataMessageMap;
    private static OrderManager orderManager = new OrderManager();
    private static OrderCache orderCache = new OrderCache();

    private static CioiDarkThreadPool<AbstractDataModel> inboundFixThreadPool;
    private static CioiDarkThreadPool<ExecutionReport> crossingEngineThreadPool;

    private static ObjectPool<DefaultExecutionReport> executionReportObjectPool;
    private static ObjectPool<DefaultOrderCancelReject> orderCancelRejectObjectPool;


    private OMSApplicationContextProvider() {
    }

    public static synchronized void initialize(final OMSOut omsOut) throws ConfigurationException {

        if (Objects.isNull(omsSystemProperty)) {
            try {
                omsSystemProperty = new OMSSystemProperty(omsOut);
            } catch (ConfigurationException e) {
                logger.error("ITRSALERT| System property file not found, exiting, {} ", e);
                throw e;
            }
        }

        if (Objects.isNull(orderManager))
            orderManager = new OrderManager();

        if (Objects.isNull(orderCache))
            orderCache = new OrderCache();

        if (Objects.isNull(inboundFixThreadPool))
            inboundFixThreadPool = new CioiDarkThreadPool<>("INBOUND_THREAD_POOL",
                    7, 7, 1000, 2147483647, 100000,
                    5000, 10);

        if (Objects.isNull(crossingEngineThreadPool))
            crossingEngineThreadPool = new CioiDarkThreadPool<>("CROSSING_ENGINE_THREAD_POOL",
                    7, 7, 1000, 2147483647, 100000,
                    5000, 10);

        if (Objects.isNull(marketDataMessageMap))
            marketDataMessageMap = new ConcurrentHashMap<>();

        GenericObjectPoolConfig objectPoolConfig = new GenericObjectPoolConfig();
        objectPoolConfig.setMaxIdle(5);
        objectPoolConfig.setMaxTotal(20);
        objectPoolConfig.setMaxWaitMillis(2000);
        objectPoolConfig.setMinEvictableIdleTimeMillis(3000);

        if (Objects.isNull(executionReportObjectPool))
            executionReportObjectPool = new ObjectPool<>(new PooledObjectFactory<>(DefaultExecutionReport.class), objectPoolConfig);

        if (Objects.isNull(orderCancelRejectObjectPool))
            orderCancelRejectObjectPool = new ObjectPool<>(new PooledObjectFactory<>(DefaultOrderCancelReject.class), objectPoolConfig);

        logger.info("OMS Context Initialized!");
    }


    public static OMSSystemProperty getOmsSystemProperty() {
        return omsSystemProperty;
    }

    public static OrderManager getOrderManager() {
        return orderManager;
    }

    public static OrderCache getOrderCache() {
        return orderCache;
    }

    public static Map<String, MarketDataMessage> marketDataMessageMap() {
        return marketDataMessageMap;
    }

    public static ExecutionReportBuilder getExecutionReportBuilder() {
        return new ExecutionReportBuilder();
    }

    public static InboundHandler getInboundHandler() {
        return new InboundHandler();
    }

    public static FixInboundProcessor getFixInboundProcessor() {
        return new FixInboundProcessor();
    }

    public static EngineInboundProcessor getEngineInboundProcessor() {
        return new EngineInboundProcessor();
    }

    public static SubscribeToMarketDataService getSubscribeToMarketDataService() {
        return new SubscribeToMarketDataService();
    }

    public static CioiDarkOrderValidator getCioiDarkOrderValidator() {
        return new CioiDarkOrderValidator();
    }

    public static CioiDarkOrderEnricher getCioiDarkOrderEnricher() {
        return new CioiDarkOrderEnricher();
    }

    public static AckPublisher getAckPublisher() {
        return new AckPublisher();
    }

    public static RejectPublisher getRejectPublisher() {
        return new RejectPublisher();
    }

    public static OutboundPublisher getOutboundPublisher() {
        return new OutboundPublisher();
    }

    public static CioiDarkThreadPool<AbstractDataModel> getInboundFixThreadPool() {
        return inboundFixThreadPool;
    }

    public static CioiDarkThreadPool<ExecutionReport> getCrossingEngineThreadPool() {
        return crossingEngineThreadPool;
    }

    public static ObjectPool<DefaultExecutionReport> getExecutionReportObjectPool() {
        return executionReportObjectPool;
    }

    public static ObjectPool<DefaultOrderCancelReject> getOrderCancelRejectObjectPool() {
        return orderCancelRejectObjectPool;
    }
}
