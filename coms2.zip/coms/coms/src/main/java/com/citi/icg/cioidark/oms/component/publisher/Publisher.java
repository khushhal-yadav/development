package com.citi.icg.cioidark.oms.component.publisher;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.queue.OMSOut;

public abstract class Publisher {

    protected final OMSOut omsOut;

    public Publisher() {
        this.omsOut = OMSApplicationContextProvider.getOmsSystemProperty().getOmsOut();
    }
}
