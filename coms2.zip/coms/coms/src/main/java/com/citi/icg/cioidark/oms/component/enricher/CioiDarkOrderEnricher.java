package com.citi.icg.cioidark.oms.component.enricher;

import java.util.Objects;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.util.FixTagUtil;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.fields.BidPx;
import software.chronicle.fix.codegen.fields.CrossInstruction;
import software.chronicle.fix.codegen.fields.CrossRestrictionClientID;
import software.chronicle.fix.codegen.fields.OfferPx;
import software.chronicle.fix.codegen.fields.QuoteTime;
import software.chronicle.fix.codegen.fields.ReceiveTime;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;
import software.chronicle.fix.datamodel.AbstractDataModel;

public class CioiDarkOrderEnricher {

    private final static Logger logger = LoggerFactory.getLogger(CioiDarkOrderEnricher.class);

    public void enrich(AbstractDataModel abstractDataModel, String symbol) {
        abstractDataModel.setLong(ReceiveTime.FIELD, DateTime.now(DateTimeZone.UTC).getMillis());// use time received as set by the engine for cross order sorting
        stampMarketDataOnOrder(abstractDataModel, symbol);

        if (!(abstractDataModel instanceof DefaultOrderCancelRequest))
            enrich(abstractDataModel);

    }

    private void enrich(AbstractDataModel abstractDataModel) {
        if (FixTagUtil.isValueSet(abstractDataModel.getString(CrossRestrictionClientID.FIELD))) {
            if (FixTagUtil.isValueSet(abstractDataModel.getString(CrossInstruction.FIELD))
                    && !abstractDataModel.getString(CrossInstruction.FIELD).contains("NS"))
                abstractDataModel.setString(CrossInstruction.FIELD, abstractDataModel.getString(CrossInstruction.FIELD) + " NS");
            else
                abstractDataModel.setString(CrossInstruction.FIELD, "NS");
        }
    }

    private void stampMarketDataOnOrder(final AbstractDataModel abstractDataModel, final String symbol) {

        final MarketDataMessage marketData = OMSApplicationContextProvider.marketDataMessageMap().get(symbol);

        if (Objects.isNull(marketData)) {
            logger.warn("ITRSALERT| Marketdata absent for symbol {}, so market data enrichment skipped", symbol);
            return;
        }

        if (marketData.getBidPx() > 0)
            abstractDataModel.setDouble(BidPx.FIELD, marketData.getBidPx());
        else
            abstractDataModel.setDouble(BidPx.FIELD, 0.0);

        if (marketData.getAskPx() > 0)
            abstractDataModel.setDouble(OfferPx.FIELD, marketData.getAskPx());
        else
            abstractDataModel.setDouble(OfferPx.FIELD, 0.0);

        abstractDataModel.setLong(QuoteTime.FIELD, abstractDataModel.getLong(ReceiveTime.FIELD));
    }

}
