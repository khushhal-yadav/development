package com.citi.icg.cioidark.oms.component.validator.exception;

import java.text.MessageFormat;

public class ValidationException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	private int rejectReason = 99;
	
	public ValidationException(String message) {
		super(message, null);
	}
	
	public ValidationException(String message, int rejectReason) {
		super(message, null);
		this.rejectReason=rejectReason;
	}
	
	public ValidationException(String message, Object... args) {
		super(MessageFormat.format(message, args));
	}

	public int getRejectReason() {
		return rejectReason;
	}
}
