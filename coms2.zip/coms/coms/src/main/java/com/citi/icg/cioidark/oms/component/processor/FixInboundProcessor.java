package com.citi.icg.cioidark.oms.component.processor;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.oms.component.order.Order;
import com.citi.icg.cioidark.oms.component.order.OrderManager;
import com.citi.icg.cioidark.oms.component.validator.CioiDarkOrderValidator;
import com.citi.icg.cioidark.oms.component.validator.exception.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

public class FixInboundProcessor {

    private static final Logger logger = LoggerFactory.getLogger(FixInboundProcessor.class);
    private final OrderManager orderManager;

    public FixInboundProcessor() {
        this.orderManager = OMSApplicationContextProvider.getOrderManager();
    }

    public void onMessage(final DefaultNewOrderSingle newOrderSingle) {
        try {
            OMSApplicationContextProvider.getCioiDarkOrderValidator().validate(newOrderSingle);
            OMSApplicationContextProvider.getCioiDarkOrderValidator().validateNewOrderSingle(newOrderSingle, newOrderSingle.ordType() == OrdType.LIMIT);

            if (orderManager.getOrderCache().containsClOrdId(newOrderSingle.clOrdID()))
                throw new ValidationException(CioiDarkOrderValidator.DUPLICATE_CLORDID, 6);

            OMSApplicationContextProvider.getCioiDarkOrderEnricher().enrich(newOrderSingle, newOrderSingle.symbol());

            Order newOrder = orderManager.newOrderSingle(newOrderSingle);
            newOrderSingle.orderID(newOrder.getOrderState().getOrderID());

            OMSApplicationContextProvider.getOutboundPublisher().sendForCrossing(newOrderSingle);
        } catch (ValidationException e) {
            OMSApplicationContextProvider.getRejectPublisher().rejectNewOrderSingle(newOrderSingle, e.getMessage(), e.getRejectReason());
        } catch (Exception e) {
            logger.error("ITRSALERT|Application error: " + e.getMessage(), e);
        }
    }

    public void onMessage(final DefaultOrderCancelRequest orderCancelRequest) {
        try {
            OMSApplicationContextProvider.getCioiDarkOrderValidator().validate(orderCancelRequest);
            OMSApplicationContextProvider.getCioiDarkOrderValidator().validateOrderCancelRequest(orderCancelRequest);

            OMSApplicationContextProvider.getCioiDarkOrderEnricher().enrich(orderCancelRequest, orderCancelRequest.symbol());

            orderManager.cancelRequest(orderCancelRequest);
            OMSApplicationContextProvider.getOutboundPublisher().sendForCrossing(orderCancelRequest);
        } catch (ValidationException ex) {
            OMSApplicationContextProvider.getRejectPublisher().rejectCancelRequest(orderCancelRequest, ex.getMessage(), ex.getRejectReason());
        } catch (Exception e) {
            logger.error("ITRSALERT|Application error: " + e.getMessage(), e);
        }
    }

    public void onMessage(final DefaultOrderCancelReplaceRequest orderCancelReplaceRequest) {
        try {
            OMSApplicationContextProvider.getCioiDarkOrderValidator().validate(orderCancelReplaceRequest);
            OMSApplicationContextProvider.getCioiDarkOrderValidator().validateOrderCancelReplaceRequest(orderCancelReplaceRequest, orderCancelReplaceRequest.ordType() == OrdType.LIMIT);

            OMSApplicationContextProvider.getCioiDarkOrderEnricher().enrich(orderCancelReplaceRequest, orderCancelReplaceRequest.symbol());

            orderManager.cancelReplaceRequest(orderCancelReplaceRequest);
            OMSApplicationContextProvider.getOutboundPublisher().sendForCrossing(orderCancelReplaceRequest);
        } catch (ValidationException ex) {
            OMSApplicationContextProvider.getRejectPublisher().rejectCancelReplaceRequest(orderCancelReplaceRequest, ex.getMessage(), ex.getRejectReason());
        } catch (Exception e) {
            logger.error("ITRSALERT|Application error: " + e.getMessage(), e);
        }
    }
}