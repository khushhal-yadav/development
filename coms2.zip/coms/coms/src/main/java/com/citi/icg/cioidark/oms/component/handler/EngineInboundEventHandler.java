package com.citi.icg.cioidark.oms.component.handler;

import java.util.Objects;
import java.util.Optional;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.util.threadpool.event.DispatchableEvent;
import software.chronicle.fix.codegen.messages.ExecutionReport;

public class EngineInboundEventHandler extends DispatchableEvent<ExecutionReport> {

    EngineInboundEventHandler(ExecutionReport executionReport) {
        setPayload(executionReport);
    }

    @Override
    public void run() {
        assert getPayload() != null;
        OMSApplicationContextProvider.getEngineInboundProcessor().onMessage(getPayload());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getPayload());
    }

    @Override
    public boolean equals(Object obj) {
        return Optional.ofNullable(obj)
                .filter(EngineInboundEventHandler.class::isInstance)
                .map(EngineInboundEventHandler.class::cast)
                .filter(o -> Objects.equals(this.getPayload(), o.getPayload()))
                .isPresent();
    }
}
