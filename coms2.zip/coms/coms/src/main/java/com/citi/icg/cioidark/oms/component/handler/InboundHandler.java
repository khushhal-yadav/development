package com.citi.icg.cioidark.oms.component.handler;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.util.threadpool.CioiDarkThreadPool;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;
import software.chronicle.fix.datamodel.AbstractDataModel;

public class InboundHandler {

    private final CioiDarkThreadPool<AbstractDataModel> inboundThreadPool;
    private final CioiDarkThreadPool<ExecutionReport> crossingEngineThreadPool;

    public InboundHandler() {
        inboundThreadPool = OMSApplicationContextProvider.getInboundFixThreadPool();
        crossingEngineThreadPool = OMSApplicationContextProvider.getCrossingEngineThreadPool();
    }

    public void fixInbound(final DefaultNewOrderSingle newOrderSingle) {
        FixInboundEventHandler fixInboundEventHandler = new FixInboundEventHandler(newOrderSingle);
        inboundThreadPool.submit(fixInboundEventHandler, newOrderSingle.symbol());
    }

    public void fixInbound(final DefaultOrderCancelRequest orderCancelRequest) {
        FixInboundEventHandler fixInboundEventHandler = new FixInboundEventHandler(orderCancelRequest);
        inboundThreadPool.submit(fixInboundEventHandler, orderCancelRequest.symbol());
    }

    public void fixInbound(final DefaultOrderCancelReplaceRequest orderCancelReplaceRequest) {
        FixInboundEventHandler fixInboundEventHandler = new FixInboundEventHandler(orderCancelReplaceRequest);
        inboundThreadPool.submit(fixInboundEventHandler, orderCancelReplaceRequest.symbol());
    }

    public void engineInbound(final DefaultExecutionReport executionReport) {
        EngineInboundEventHandler engineInboundEventHandler = new EngineInboundEventHandler(executionReport);
        crossingEngineThreadPool.submit(engineInboundEventHandler, executionReport.symbol());
    }
}
