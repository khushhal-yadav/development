package com.citi.icg.cioidark.oms.component.order;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.StampedLock;

import com.citi.icg.cioidark.oms.component.dto.OrderState;

public class OrderCache {
    private final Map<String, Order> orderIdMap;
    private final Map<String, String> clOrdIdOrderIdMap;
    private final StampedLock lock;

    public OrderCache() {
        this.orderIdMap = new ConcurrentHashMap<>();
        this.clOrdIdOrderIdMap = new ConcurrentHashMap<>();
        this.lock = new StampedLock();
    }

    public void add(Order order) {
        long stamp = 0;
        try {
            stamp = lock.writeLock();
            OrderState orderState = order.getOrderState();
            this.orderIdMap.put(orderState.getOrderID(), order);
            this.clOrdIdOrderIdMap.put(orderState.getClOrdID(), orderState.getOrderID());

        } finally {
            lock.unlockWrite(stamp);
        }

    }

    public boolean containsClOrdId(String clOrdId) {
        return clOrdIdOrderIdMap.containsKey(clOrdId);
    }

    public Order get(String clOrdId, String origClOrdId) {
        long stamp = 0;

        try {
            stamp = lock.readLock();
            String orderId = getOrderId(clOrdId, origClOrdId);
            if (Objects.nonNull(orderId))
                return orderIdMap.get(orderId);
        } finally {
            lock.unlockRead(stamp);
        }
        return null;
    }

    public Order remove(String clOrdId, String origClOrdId) {
        Order order = null;
        long stamp = 0;

        try {
            stamp = lock.writeLock();
            String orderId = getOrderId(clOrdId, origClOrdId);
            if (Objects.nonNull(orderId))
                order = orderIdMap.remove(orderId);
            clOrdIdOrderIdMap.remove(clOrdId);
            clOrdIdOrderIdMap.remove(origClOrdId);
        } finally {
            lock.unlockWrite(stamp);
        }

        return order;
    }

    public void clearAll() {
        long stamp = 0;
        try {
            stamp = lock.readLock();
            this.orderIdMap.clear();
            this.clOrdIdOrderIdMap.clear();
        } finally {
            lock.unlockRead(stamp);
        }
    }

    private String getOrderId(String clOrdId, String origClOrdId) {
        return clOrdIdOrderIdMap.get((origClOrdId == null) ? clOrdId : origClOrdId);
    }
}
