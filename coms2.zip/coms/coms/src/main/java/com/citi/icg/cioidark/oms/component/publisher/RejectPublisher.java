package com.citi.icg.cioidark.oms.component.publisher;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.oms.component.order.Order;
import com.citi.icg.cioidark.oms.component.order.OrderCache;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReject;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

public class RejectPublisher extends Publisher {
    private final OrderCache orderCache;

    public RejectPublisher() {
        this.orderCache = OMSApplicationContextProvider.getOrderCache();
    }

    public DefaultExecutionReport rejectNewOrderSingle(final DefaultNewOrderSingle newOrderSingle, final String message, final Integer rejectReason) {
        DefaultExecutionReport executionReport = OMSApplicationContextProvider.getExecutionReportBuilder()
                .newReject(newOrderSingle, message, rejectReason);
        omsOut.clientExecutionReport(executionReport);

        return executionReport;
    }

    public DefaultOrderCancelReject rejectCancelRequest(final DefaultOrderCancelRequest orderCancelRequest, final String message, final Integer rejectReason) {
        Order order = orderCache.get(orderCancelRequest.clOrdID(), orderCancelRequest.origClOrdID());
        final String orderId = order != null ? order.getOrderState().getOrderID() : "NOT_FOUND";
        DefaultOrderCancelReject orderCancelReject = OMSApplicationContextProvider.getExecutionReportBuilder()
                .cancelReject(order, orderCancelRequest, message, orderId, rejectReason);
        omsOut.clientOrderCancelReject(orderCancelReject);

        return orderCancelReject;
    }

    public DefaultOrderCancelReject rejectCancelReplaceRequest(final DefaultOrderCancelReplaceRequest orderCancelReplaceRequest, final String message, final Integer rejectReason) {
        Order order = orderCache.get(orderCancelReplaceRequest.clOrdID(), orderCancelReplaceRequest.origClOrdID());
        final String orderId = order != null ? order.getOrderState().getOrderID() : "NOT_FOUND";
        DefaultOrderCancelReject orderCancelReplaceReject = OMSApplicationContextProvider.getExecutionReportBuilder()
                .modReject(order, orderCancelReplaceRequest, message, orderId, rejectReason);
        omsOut.clientOrderCancelReject(orderCancelReplaceReject);

        return orderCancelReplaceReject;
    }

}
