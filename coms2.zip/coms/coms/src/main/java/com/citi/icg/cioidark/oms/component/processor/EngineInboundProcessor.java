package com.citi.icg.cioidark.oms.component.processor;

import java.util.Objects;

import com.citi.icg.cioidark.OMSApplicationContextProvider;
import com.citi.icg.cioidark.oms.component.order.OrderManager;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;

public class EngineInboundProcessor {
    private final OrderManager orderManager;

    public EngineInboundProcessor() {
        this.orderManager = OMSApplicationContextProvider.getOrderManager();
    }

    public void onMessage(final ExecutionReport executionReport) {
        final DefaultExecutionReport execReport = orderManager.ackOrFill(executionReport);
        if (Objects.nonNull(execReport))
            OMSApplicationContextProvider.getAckPublisher().executionReport(execReport);
    }
}
