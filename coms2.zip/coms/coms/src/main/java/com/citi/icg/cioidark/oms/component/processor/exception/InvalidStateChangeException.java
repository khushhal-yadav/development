package com.citi.icg.cioidark.oms.component.processor.exception;

public class InvalidStateChangeException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public InvalidStateChangeException() {
        super();
    }

    public InvalidStateChangeException(String message) {
        super(message);
    }
}
