package com.citi.icg.cioidark.crossing.engine.component.book;

import static com.citi.icg.cioidark.enumeration.Rank.A;
import static com.citi.icg.cioidark.enumeration.Rank.B;
import static com.citi.icg.cioidark.enumeration.Rank.C;
import static com.citi.icg.cioidark.enumeration.Rank.D;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import com.citi.icg.cioidark.crossing.engine.component.exception.OverFillException;
import com.citi.icg.cioidark.enumeration.Rank;
import com.citi.icg.cioidark.util.BooleanUtil;
import com.citi.icg.cioidark.util.FixTagUtil;
import software.chronicle.fix.codegen.fields.OrdStatus;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.OrderVersion;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.staticcode.messages.FixConstants;

public class CioiDarkBookOrder implements OrderVersion {

    private char side;
    private String symbol;
    private String symbolSfx;
    private String clOrderId;
    private String orderId;
    private String ioiId;
    private double price;
    private String strategyParameterValue;
    private long seqNo;
    private char orderType;
    private String account;
    /**
     * Crossing instruction from the client.  Supports multiple values delimited with space.
     */
    private String crossInstruction;
    private char orderCapacity;
    private double orderQty;
    private double minQty;
    private String crossRestrictionClientId;
    private double sumOfStopExecQty;
    private char ordStatus;
    private long orderVersion;
    private String senderSubId;
    private double cxlQty;

    private final CioiDarkTradeBook tradeBook = new CioiDarkTradeBook();

    public CioiDarkBookOrder() {
        // empty/default constructor
    }

    @Override
    public String toString() {
        return "CioiDarkBookOrder [side=" + side + ", symbol=" + symbol + ", clOrderId=" + clOrderId + ", orderId="
                + orderId + ", price=" + price + ", strategyParameterValue=" + strategyParameterValue + ", seqNo=" + seqNo + ", orderType=" + orderType
                + ", crossInstruction=" + crossInstruction + ", orderQty=" + orderQty + "]";
    }

    public char side() {
        return side;
    }

    public void side(char side) {
        this.side = side;
    }

    public String clOrderId() {
        return clOrderId;
    }

    public void clOrderId(String clOrderId) {
        this.clOrderId = clOrderId;
    }

    public String orderId() {
        return orderId;
    }

    public void orderId(String orderId) {
        this.orderId = orderId;
    }

    public String ioiId() {
        return ioiId;
    }

    public void ioiId(String ioiId) {
        this.ioiId = ioiId;
    }

    public double price() {
        return price;
    }

    public void price(double price) {
        this.price = price;
    }

    public int rank() {
        int rankval = Rank.DEFAULT.intValue();
        String rank = Optional.ofNullable(strategyParameterValue()).orElse("");
        switch (Rank.valueOf(rank)) {
            case A:
                rankval = A.intValue();
                break;
            case B:
                rankval = B.intValue();
                break;
            case C:
                rankval = C.intValue();
                break;
            case D:
                rankval = D.intValue();
                break;
        }

        return rankval;
    }

    public String strategyParameterValue() {
        return strategyParameterValue;
    }

    public long seqNo() {
        return seqNo;
    }

    public void seqNo(final long seqNo) {
        this.seqNo = seqNo;
    }

    public char orderType() {
        return orderType;
    }

    public void orderType(char orderType) {
        this.orderType = orderType;
    }

    public boolean isMarketOrder() {
        return this.orderType == OrdType.MARKET;
    }

    public boolean isNotMarketOrder() {
        return !isMarketOrder();
    }

    public String crossInstruction() {
        return crossInstruction;
    }

    public void crossInstruction(String crossInstruction) {
        this.crossInstruction = crossInstruction;
    }

    public Set<String> getCrossInstruction() {
        return crossInstruction() != null ?
                new HashSet<>(Arrays.asList(crossInstruction().split(" "))) :
                new HashSet<>();
    }

    public char orderCapacity() {
        return orderCapacity;
    }

    public void orderCapacity(char orderCapacity) {
        this.orderCapacity = orderCapacity;
    }

    public String crossRestrictionClientId() {
        return crossRestrictionClientId;
    }

    public void crossRestrictionClientId(String crossRestrictionClientId) {
        this.crossRestrictionClientId = crossRestrictionClientId;
    }

    public double sumOfStopExecQty() {
        return sumOfStopExecQty;
    }

    public void sumOfStopExecQty(double sumOfStopExecQty) {
        this.sumOfStopExecQty = sumOfStopExecQty;
    }

    public double orderQty() {
        return orderQty;
    }

    public void orderQty(double orderQty) {
        this.orderQty = orderQty;
    }

    public double minQty() {
        return minQty;
    }

    public void minQty(double minQty) {
        this.minQty = minQty;
    }

    public char ordStatus() {
        return ordStatus;
    }

    public void ordStatus(char ordStatus) {
        this.ordStatus = ordStatus;
    }

    public String symbol() {
        return symbol;
    }

    public void symbol(String symbol) {
        this.symbol = symbol;
    }

    public String account() {
        return account;
    }

    public void account(String account) {
        this.account = account;
    }

    public String symbolSfx() {
        return symbolSfx;
    }

    public void symbolSfx(String symbolSfx) {
        this.symbolSfx = symbolSfx;
    }

    public String senderSubId() {
        return senderSubId;
    }

    public void senderSubId(String senderSubId) {
        this.senderSubId = senderSubId;
    }

    public void cxlQty(double cxlQty) {
        this.cxlQty = cxlQty;
    }

    public double cxlQty() {
        return cxlQty;
    }

    public double getLeavesQty() {
        return orderQty() - getCumQty();
    }

    public double getCumQty() {
        return tradeBook.cumQty();
    }

    public double getAvgPx() {
        return tradeBook.avgPx();
    }

    public boolean isOpen() {
        return getLeavesQty() > 0;
    }


    @Override
    public long orderVersion() {
        return this.orderVersion;
    }

    @Override
    public void orderVersion(long orderVersion) {
        this.orderVersion = orderVersion;

    }

    public void incOrderVersion() {
        orderVersion(orderVersion() + 1);
    }

    public double getCrossableQuantity() {
        double sumOfStopExecQtyVal = FixConstants.isUnset(sumOfStopExecQty()) ?
                0.0 : sumOfStopExecQty();
        return BooleanUtil.ifTrueEvaluateOrElse(
                (!FixTagUtil.isValueSet(minQty())),
                () -> orderQty() - sumOfStopExecQtyVal,
                () -> minQty() - sumOfStopExecQtyVal);
    }

    public boolean isShortSaleSide() {
        return Side.SELL_SHORT == side() || Side.SELL_SHORT_EXEMPT == side();
    }

    public DefaultExecutionReport applyTrade(DefaultExecutionReport fill) {
        if (getLeavesQty() < +fill.lastShares())
            throw new OverFillException(fill.lastShares(), getLeavesQty());
        tradeBook.put(fill);
        incOrderVersion();
        fill.orderVersion(orderVersion);
        return fill;
    }

    public CioiDarkBookOrder newOrderSingle(final DefaultNewOrderSingle newOrderSingle) {
        orderVersion(0);
        orderQty(newOrderSingle.orderQty());
        orderType(newOrderSingle.ordType());
        orderId(newOrderSingle.orderID());
        clOrderId(newOrderSingle.clOrdID());
        side(newOrderSingle.side());
        minQty(newOrderSingle.minQty());

        return this;

    }

    public void cancel() {
        cxlQty(getLeavesQty());
        ordStatus(OrdStatus.CANCELED);
        incOrderVersion();
    }
}
