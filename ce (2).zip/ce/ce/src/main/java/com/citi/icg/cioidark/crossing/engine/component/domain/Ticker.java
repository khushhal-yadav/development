package com.citi.icg.cioidark.crossing.engine.component.domain;

public class Ticker {

    private final String root;
    private final String suffix;

    public Ticker(String root, String suffix) {
        this.root = root;
        this.suffix = suffix;
    }

    public Ticker(String root) {
        this(root, "");
    }

    public String getRoot() {
        return root;
    }

    public String getSuffix() {
        return suffix;
    }

    @Override
    public String toString() {
        return "Ticker{" +
                "root='" + root + '\'' +
                ", suffix='" + suffix + '\'' +
                '}';
    }
}
