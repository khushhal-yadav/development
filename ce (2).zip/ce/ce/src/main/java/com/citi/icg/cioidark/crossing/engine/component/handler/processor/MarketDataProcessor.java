package com.citi.icg.cioidark.crossing.engine.component.handler.processor;

import java.util.Optional;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.message.alert.Alert;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.CrossingEngineOut;
import com.citi.icg.cioidark.crossing.engine.component.book.BookAttributes;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBook;
import com.citi.icg.cioidark.crossing.engine.component.domain.CioiDarkMarketData;
import com.citi.icg.cioidark.enumeration.MarketDataStatus;
import com.citi.icg.cioidark.enumeration.ShortSaleRestriction;
import com.citi.icg.cioidark.enumeration.alert.AlertCategory;
import com.citi.icg.cioidark.enumeration.alert.AlertLevel;
import com.citi.icg.cioidark.enumeration.alert.AlertStatus;
import org.slf4j.Logger;
import software.chronicle.fix.codegen.fields.CxlReason;

//GMDTickMessageHelper
public class MarketDataProcessor {

    public void assignSequenceId(final MarketDataMessage marketDataMessage) {
        CioiDarkBook cioiDarkBook = CrossingEngineApplicationContextProvider.getCioiDarkBookManager()
                .createIfAbsent(marketDataMessage.getSymbol());

        marketDataMessage.setSequenceId(cioiDarkBook.getNextMarketDataSeq());
    }

    public boolean processMarketData(final CioiDarkMarketData cioiDarkMarketData, final Logger logger) {

        return Optional.ofNullable(cioiDarkMarketData.getStatus())
                .map(marketDataMessage -> processMarketData(marketDataMessage, logger, cioiDarkMarketData)).orElse(false) ||
                Optional.ofNullable(cioiDarkMarketData.getNbbo())
                        .map(marketDataMessage -> processMarketData(marketDataMessage, logger, cioiDarkMarketData)).orElse(false);

    }

    private boolean processMarketData(final MarketDataMessage marketDataMessage, final Logger logger,
                                      final CioiDarkMarketData cioiDarkMarketData) {
        if (!marketDataMessage.isStatusEvent() || marketDataMessage.isUpdateBook())
            refreshMarketDataOnCioiDarkBook(marketDataMessage, logger);

        if (marketDataMessage.isStatusEvent() && !marketDataMessage.isCrossAttempt())
            return false;

        CioiDarkBook cioiDarkBook = CrossingEngineApplicationContextProvider
                .getCioiDarkBookManager().createIfAbsent(marketDataMessage.getSymbol());

        if (CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().isLogMarketData())
            cioiDarkBook.getLogger().info(marketDataMessage.toString());

        //do not attempt to cross with old makrket data if crossing was attempted with latest marketdata
        cioiDarkMarketData.setCioiDarkBook(cioiDarkBook);
        return cioiDarkBook.getLastCrossAttemptMDSeqId() < marketDataMessage.getSequenceId() || marketDataMessage.getSequenceId() == 1;

    }

    private void refreshMarketDataOnCioiDarkBook(final MarketDataMessage marketDataMessage, final Logger logger) {
        final String symbol = marketDataMessage.getSymbol();

        CioiDarkBook cioiDarkBook = CrossingEngineApplicationContextProvider.getCioiDarkBookManager()
                .createIfAbsent(symbol);

        checkStale(cioiDarkBook, marketDataMessage, logger);

        if (marketDataMessage.isStatusEvent())
            processTickUpdateOnBook(cioiDarkBook, marketDataMessage, logger);
        else
            postTickOnBook(cioiDarkBook, marketDataMessage);
    }

    private void postTickOnBook(CioiDarkBook cioiDarkBook, MarketDataMessage marketDataMessage) {
        cioiDarkBook.updateMarketData(marketDataMessage);
    }

    private void processTickUpdateOnBook(final CioiDarkBook cioiDarkBook, final MarketDataMessage marketDataMessage, Logger logger) {
        final BookAttributes bookAttributes = cioiDarkBook.bookAttributes();
        processRegSHOActivatedUpdate(marketDataMessage, logger, bookAttributes);
        processMarketStatusUpdate(cioiDarkBook, marketDataMessage, logger, bookAttributes);
    }

    private void processMarketStatusUpdate(CioiDarkBook cioiDarkBook, MarketDataMessage marketDataMessage, Logger logger, BookAttributes bookAttributes) {
        switch (MarketDataStatus.valueOf(marketDataMessage.getStatus())) {
            case HALTED:
                bookAttributes.setHalted(true);
                bookAttributes.setQuoteOnly(false);
                cioiDarkBook.getLogger().info("{}|STATUS TICK|MARKET HALTED", bookAttributes.getBookSymbol());
                sendAlert(bookAttributes.getBookSymbol(), AlertCategory.HALTMARKET, AlertLevel.LVL1, AlertStatus.OPEN,
                        "Market is halted for symbol " + bookAttributes.getBookSymbol());
                cancelAllOpenOrders(cioiDarkBook);
                break;
            case QUOTEONLY:
                bookAttributes.setQuoteOnly(true);
                bookAttributes.setHalted(false);
                sendAlert(bookAttributes.getBookSymbol(), AlertCategory.HALTMARKET, AlertLevel.LVL1, AlertStatus.OPEN,
                        "Market is Quote only for symbol " + bookAttributes.getBookSymbol());
                logger.info("{}|STATUS TICK|MARKET QUOTE ONLY", bookAttributes.getBookSymbol());
                break;
            case OPENED_OR_TRADE_RESUME:
                boolean shouldAlert = false;
                if (bookAttributes.isHalted() || bookAttributes.isQuoteOnly() || bookAttributes.isTradePaused())
                    shouldAlert = true;

                bookAttributes.setHalted(false);
                bookAttributes.setQuoteOnly(false);
                bookAttributes.setTradePaused(false);

                if (bookAttributes.isMarketOpen()) {
                    bookAttributes.setMarketOpen(true);
                    logger.info("{}|STATUS TICK|MARKET OPENED", bookAttributes.getBookSymbol());
                }
                if (shouldAlert) {
                    logger.info("{}|STATUS TICK|TRADE RESUMED", bookAttributes.getBookSymbol());
                    sendAlert(bookAttributes.getBookSymbol(), AlertCategory.HALTMARKET, AlertLevel.LVL0, AlertStatus.OPEN,
                            "Market resumed trading for symbol " + bookAttributes.getBookSymbol());
                }

                break;
            case CLOSED:
                if (bookAttributes.isMarketOpen()) {
                    bookAttributes.setMarketOpen(false);
                    logger.info("{}|STATUS TICK|MARKET CLOSED", bookAttributes.getBookSymbol());
                }
                break;
            case PAUSED:
                if (bookAttributes.isTradePaused()) {
                    bookAttributes.setTradePaused(true);
                    logger.info("{}|STATUS TICK|TRADE PAUSED", bookAttributes.getBookSymbol());
                    sendAlert(bookAttributes.getBookSymbol(), AlertCategory.TRADEPAUSED, AlertLevel.LVL1, AlertStatus.OPEN,
                            "Trading is paused for symbol " + bookAttributes.getBookSymbol());
                }
                break;
            default:
                break;
        }
    }

    private void processRegSHOActivatedUpdate(MarketDataMessage marketDataMessage, Logger logger, BookAttributes bookAttributes) {
        if (marketDataMessage.getShortSaleRestricted() == ShortSaleRestriction.SHORT_SALE_RESTRICTION_ACTIVATED.value()
                && !bookAttributes.isRegSHOActivated()) {
            bookAttributes.setRegSHOActivated(true);
            logger.info("{}|STATUS TICK|RegSHO Short Sale Restriction Activated", bookAttributes.getBookSymbol());
            CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishBookAttributes(bookAttributes);

            final String alertMessage = "RegSHO Short Sale Restriction Activated for symbol " + bookAttributes.getBookSymbol();
            sendAlert(bookAttributes.getBookSymbol(), AlertCategory.SHORTSELLACTIVE, AlertLevel.LVL0, AlertStatus.OPEN, alertMessage);
        } else if (marketDataMessage.getShortSaleRestricted() == ShortSaleRestriction.SHORT_SALE_RESTRICTION_REMOVED.value()
                && bookAttributes.isRegSHOActivated()) {
            bookAttributes.setRegSHOActivated(false);
            logger.info("{}|STATUS TICK|RegSHO Short Sale Restriction Removed", bookAttributes.getBookSymbol());

            final String alertMessage = "RegSHO Short Sale Restriction Removed for symbol " + bookAttributes.getBookSymbol();
            sendAlert(bookAttributes.getBookSymbol(), AlertCategory.SHORTSELLREMOVE, AlertLevel.LVL0, AlertStatus.OPEN, alertMessage);
        }
    }

    private void sendAlert(String symbol, AlertCategory alertCategory, AlertLevel alertLevel, AlertStatus alertStatus, String alertMessage) {
        Alert alert = new Alert(symbol, alertCategory);
        alert.setLevel(alertLevel);
        alert.setStatus(alertStatus);
        alert.setMsg(alertMessage);
        CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishAlert(alert);
    }

    private void checkStale(final CioiDarkBook cioiDarkBook, final MarketDataMessage marketDataMessage, final Logger logger) {
        final BookAttributes bookAttributes = cioiDarkBook.bookAttributes();
        if (marketDataMessage.isSourceStale() && !bookAttributes.isMarketDataStale()) {
            bookAttributes.setMarketDataStale(true);
            CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishBookAttributes(bookAttributes);

            logger.info("ITRSALERT|Market data for [{}] is stale", bookAttributes.getBookSymbol());
            sendAlert(bookAttributes.getBookSymbol(), AlertCategory.CROSSPAUSE, AlertLevel.LVL0, AlertStatus.CLOSE,
                    "MarketData Stale for symbol " + bookAttributes.getBookSymbol());
        } else if (bookAttributes.isMarketDataStale()) {
            logger.info("ITRSALERT|Market data for [{}] is no longer stale", bookAttributes.getBookSymbol());
            cioiDarkBook.bookAttributes().setMarketDataStale(false);
            CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishBookAttributes(bookAttributes);
        }
    }

    private void cancelAllOpenOrders(final CioiDarkBook cioiDarkBook) {
        final CrossingEngineOut crossingEngineOut = CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getCrossingEngineOut();
        cioiDarkBook.allOpenOrders().stream()
                .map(cioiDarkBookOrder ->
                        cioiDarkBook.unSolCxlOrder(cioiDarkBookOrder, CxlReason.UNSOL_CXL_MARKET_CLOSED, null))
                .forEach(crossingEngineOut::executionReport);
    }
}
