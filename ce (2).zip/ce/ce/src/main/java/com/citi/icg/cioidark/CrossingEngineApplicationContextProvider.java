package com.citi.icg.cioidark;

import com.citi.icg.cioidark.chronicle.messaging.message.admin.AdminMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.CrossingEngineOut;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBook;
import com.citi.icg.cioidark.crossing.engine.component.book.manager.CioiDarkBookManager;
import com.citi.icg.cioidark.crossing.engine.component.book.manager.GMDSymbologyManager;
import com.citi.icg.cioidark.crossing.engine.component.builder.CioiDarkExecutionReportBuilder;
import com.citi.icg.cioidark.crossing.engine.component.handler.AdminMessageEvent;
import com.citi.icg.cioidark.crossing.engine.component.handler.processor.MarketDataProcessor;
import com.citi.icg.cioidark.crossing.engine.component.publisher.CfgMgrDataPublisher;
import com.citi.icg.cioidark.crossing.engine.component.domain.CioiDarkMarketData;
import com.citi.icg.cioidark.crossing.engine.component.handler.InboundHandler;
import com.citi.icg.cioidark.crossing.engine.component.marketdata.SubscribeToMarketDataService;
import com.citi.icg.cioidark.crossing.engine.component.handler.processor.FixOrderProcessor;
import com.citi.icg.cioidark.qmf.TimerTask;
import com.citi.icg.cioidark.util.threadpool.CioiDarkThreadPool;
import org.apache.commons.configuration.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.datamodel.AbstractDataModel;

public class CrossingEngineApplicationContextProvider {

    private static final Logger logger = LoggerFactory.getLogger(CrossingEngineApplicationContextProvider.class);
    static final CrossingEngineApplicationContextProvider instance = new CrossingEngineApplicationContextProvider();

    private static volatile CrossingEngineSystemProperty crossingEngineSystemProperty;

    private static volatile GMDSymbologyManager symbologyManager;
    private final static CioiDarkBookManager cioiDarkBookManager = new CioiDarkBookManager();

    private static volatile CioiDarkThreadPool<AbstractDataModel> inboundFixThreadPool;
    private static volatile CioiDarkThreadPool<CioiDarkMarketData> inboundMarketDataThreadPool;
    private static volatile CioiDarkThreadPool<CioiDarkBook> cioiDarkBookCrossingThreadPool;
    private static volatile CioiDarkThreadPool<?> cfgMgrThreadPool;
    private static volatile CioiDarkThreadPool<AdminMessage> adminMessageThreadPool;
    private static volatile CioiDarkThreadPool<TimerTask> timerTaskThreadPool;

    private CrossingEngineApplicationContextProvider() {
    }

    public static synchronized CrossingEngineSystemProperty getCrossingEngineSystemProperty(CrossingEngineOut crossingEngineOut) throws ConfigurationException {
        if (crossingEngineSystemProperty == null) {
            try {
                crossingEngineSystemProperty = new CrossingEngineSystemProperty(crossingEngineOut);
            } catch (ConfigurationException e) {
                logger.error("ITRSALERT| System property file not found, exiting, {} ", e);
                throw e;
            }
        }

        return crossingEngineSystemProperty;
    }

    public static CrossingEngineSystemProperty getCrossingEngineSystemProperty(){
        if (crossingEngineSystemProperty == null) {
            logger.error("ITRSALERT| Crossing Engine System properties haven't been loaded");
        }

        return crossingEngineSystemProperty;
    }

    public static CioiDarkBookManager getCioiDarkBookManager(){
        return cioiDarkBookManager;
    }

    public static GMDSymbologyManager getGmdSymbologyManager() {
        if (symbologyManager == null) {
                symbologyManager = new GMDSymbologyManager();
        }
        return symbologyManager;
    }

    public static SubscribeToMarketDataService getSubscribeToMarketDataService() {
        return new SubscribeToMarketDataService();
    }

    public static CioiDarkExecutionReportBuilder getCioiDarkExecutionReportBuilder() {
        return new CioiDarkExecutionReportBuilder();
    }

    public static synchronized CioiDarkThreadPool<AbstractDataModel> getInboundFixThreadPool() {
        if (inboundFixThreadPool == null) {
            inboundFixThreadPool = new CioiDarkThreadPool<>("INBOUND_THREAD_POOL",
                        10, 10, 1000, 2147483647, 100000,
                        5000, 10);
        }
        return inboundFixThreadPool;
    }

    public static synchronized CioiDarkThreadPool<CioiDarkMarketData> getInboundMarketDataThreadPool() {
        if (inboundMarketDataThreadPool == null) {
            inboundMarketDataThreadPool = new CioiDarkThreadPool<>("MARKETDATA_THREAD_POOL",
                    30, 30, 100000, 2147483647, 100000,
                    5000, 5);
        }
        return inboundMarketDataThreadPool;
    }

    public static synchronized CioiDarkThreadPool<CioiDarkBook> getCioiDarkBookCrossingThreadPool() {
        if (cioiDarkBookCrossingThreadPool == null) {
            cioiDarkBookCrossingThreadPool = new CioiDarkThreadPool<>("CIOIDARK_CROSS_THREAD_POOL",
                    30, 30, 100000, 2147483647, 100000,
                    5000, 5);

        }
        return cioiDarkBookCrossingThreadPool;
    }

    public static synchronized CioiDarkThreadPool<?> getCfgMgrThreadPool() {
        if (cfgMgrThreadPool == null) {
            cfgMgrThreadPool = new CioiDarkThreadPool<>("CFGMGR_THREAD_POOL",
                    10, 10, 10000, 2147483647, 100000,
                    5000, 5);

        }
        return cfgMgrThreadPool;
    }

    public static synchronized CioiDarkThreadPool<AdminMessage> getAdminMessageThreadPool() {
        if (adminMessageThreadPool == null) {
            adminMessageThreadPool = new CioiDarkThreadPool<>("ADMINMESSAGE_THREAD_POOL",
                    10, 10, 1000, 2147483647, 100000,
                    5000, 5);
        }
        return adminMessageThreadPool;
    }

    public static synchronized CioiDarkThreadPool<TimerTask> getTimerTaskThreadPool() {
        if (timerTaskThreadPool == null) {
            timerTaskThreadPool = new CioiDarkThreadPool<>("TIMERTASK_THREAD_POOL",
                    10, 10, 100000, 2147483647, 100000,
                    5000, 5);
        }
        return timerTaskThreadPool;
    }

    public static InboundHandler getInboundHandler() {
        return  new InboundHandler();
    }

    public static FixOrderProcessor getFixOrderProcessor() {
        return  new FixOrderProcessor();
    }

    public static MarketDataProcessor getMarketDataProcessor() {
        return  new MarketDataProcessor();
    }

    public static CfgMgrDataPublisher getCfgMgrDataHandler() {
        return new CfgMgrDataPublisher();
    }

    public static AdminMessageEvent getAdminMessageEvent() {
        return new AdminMessageEvent();
    }

}
