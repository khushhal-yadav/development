package com.citi.icg.cioidark.crossing.engine.component.domain;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBook;

public class CioiDarkMarketData {

    private final MarketDataMessage nbbo;
    private final MarketDataMessage status;
    private CioiDarkBook cioiDarkBook;

    public CioiDarkMarketData(final MarketDataMessage nbbo, final MarketDataMessage status) {
        this.nbbo = nbbo;
        this.status = status;
    }

    public MarketDataMessage getNbbo() {
        return nbbo;
    }

    public MarketDataMessage getStatus() {
        return status;
    }

    public CioiDarkBook getCioiDarkBook() {
        return cioiDarkBook;
    }

    public void setCioiDarkBook(CioiDarkBook cioiDarkBook) {
        this.cioiDarkBook = cioiDarkBook;
    }
}
