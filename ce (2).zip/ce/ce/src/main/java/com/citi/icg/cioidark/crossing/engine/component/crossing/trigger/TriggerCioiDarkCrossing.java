package com.citi.icg.cioidark.crossing.engine.component.crossing.trigger;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBook;
import com.citi.icg.cioidark.crossing.engine.component.crossing.handler.CioiDarkCrossingEvent;

public class TriggerCioiDarkCrossing {

	private TriggerCioiDarkCrossing () {
	    throw new IllegalStateException("Utility class");		
	}

    public static void trigger(final CioiDarkBook cioiDarkBook) {
        CrossingEngineApplicationContextProvider.getCioiDarkBookCrossingThreadPool()
                .submit(new CioiDarkCrossingEvent(cioiDarkBook, cioiDarkBook.rootSymbol()), cioiDarkBook.rootSymbol());
    }
}
