package com.citi.icg.cioidark.crossing.engine.component.marketdata;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

public class SubscribeToMarketDataService {

    public boolean subscribe(final String bookSymbol, final String marketDataSymbol,
                          final boolean subscribe, final Logger logger) {

        if (StringUtils.isEmpty(bookSymbol)) {
            logger.warn("Booksymbol: {} is empty and marketDataSymbol: {}, so didn't subscribe : subcribeValue {} ", bookSymbol, marketDataSymbol, subscribe);
            return false;
        }

        CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty()
                .getCrossingEngineOut().subscribeTick(getGmdTickSubscriptionMsg(bookSymbol, marketDataSymbol, subscribe, logger));

        logger.info("Subscribed to MDSubscriptionChronicleQ for Booksymbol: {} and marketDataSymbol: {}", bookSymbol, marketDataSymbol);

        return true;

    }

    private GMDTickSubscriptionMsg getGmdTickSubscriptionMsg(String bookSymbol, String marketDataSymbol, boolean subscribe, final Logger logger) {
        logger.info("SubscribeMessage for values: {} to MDSubscriptionChronicleQ for Booksymbol: {} and marketDataSymbol: {}", subscribe, bookSymbol, marketDataSymbol);

        return new GMDTickSubscriptionMsg(bookSymbol, marketDataSymbol, subscribe);
    }
}
