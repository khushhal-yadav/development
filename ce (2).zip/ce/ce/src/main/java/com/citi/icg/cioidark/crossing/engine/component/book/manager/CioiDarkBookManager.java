package com.citi.icg.cioidark.crossing.engine.component.book.manager;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBook;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBookOrderRepo;

public class CioiDarkBookManager {

    private final Map<String, CioiDarkBook> cioiDarkBooks = new ConcurrentHashMap<>();

    public CioiDarkBook getCioiDarkBook(final String symbol) {
        return cioiDarkBooks.get(symbol);
    }

    public Collection<CioiDarkBook> getCioiDarkBooks() {
        return cioiDarkBooks.values();
    }

    public CioiDarkBook createIfAbsent(final String key) {
        return createIfAbsent(key, key, null);
    }

    public CioiDarkBook createIfAbsent(final String key, final String symbol, final String symbolSuffix) {
        return cioiDarkBooks.computeIfAbsent(key, k -> createBook(key, symbol, symbolSuffix));
    }

    private CioiDarkBook createBook(final String key, final String symbol, final String symbolSuffix) {
        CioiDarkBook cioiDarkBook = getNewBook(key, symbol, symbolSuffix);
        cioiDarkBook.init();

        return cioiDarkBook;
    }

    private CioiDarkBook getNewBook(String key, String symbol , String symbolSfx) {
        return new CioiDarkBook(key, symbol ,symbolSfx, new CioiDarkBookOrderRepo());
    }
}
