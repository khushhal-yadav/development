package com.citi.icg.cioidark.crossing.engine.component.handler.processor;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBook;
import com.citi.icg.cioidark.crossing.engine.component.book.manager.CioiDarkBookManager;
import com.citi.icg.cioidark.crossing.engine.component.crossing.trigger.TriggerCioiDarkCrossing;
import software.chronicle.fix.codegen.fields.Symbol;
import software.chronicle.fix.codegen.fields.SymbolSfx;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

//CioiDarkInboundEventFramework
public class FixOrderProcessor {

    private final CioiDarkBookManager cioiDarkBookManager;

    public FixOrderProcessor() {
        cioiDarkBookManager = new CioiDarkBookManager();
    }

    public void onMessage(DefaultNewOrderSingle newOrderSingle) {
        final CioiDarkBook cioiDarkBook =
                getCioiDarkBook(newOrderSingle.getString(SymbolSfx.FIELD), newOrderSingle.getString(Symbol.FIELD));

        cioiDarkBook.newOrderSingle(newOrderSingle);
        CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty()
                .getCrossingEngineOut().executionReport(cioiDarkBook.newOrderSingle(newOrderSingle));

        TriggerCioiDarkCrossing.trigger(cioiDarkBook);
    }

    public void onMessage(DefaultOrderCancelRequest orderCancelRequest) {
        final CioiDarkBook cioiDarkBook =
                getCioiDarkBook(orderCancelRequest.getString(SymbolSfx.FIELD), orderCancelRequest.getString(Symbol.FIELD));

        CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty()
                .getCrossingEngineOut().executionReport(cioiDarkBook.orderCancelRequest(orderCancelRequest));
    }

    public void onMessage(DefaultOrderCancelReplaceRequest orderCancelReplaceRequest) {

        final CioiDarkBook cioiDarkBook =
                getCioiDarkBook(orderCancelReplaceRequest.getString(SymbolSfx.FIELD), orderCancelReplaceRequest.getString(Symbol.FIELD));

        CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty()
                .getCrossingEngineOut().executionReport(cioiDarkBook.orderCancelReplaceRequest(orderCancelReplaceRequest));

        TriggerCioiDarkCrossing.trigger(cioiDarkBook);

    }

    private CioiDarkBook getCioiDarkBook(String symbolSuffixField, String symbol) {
        String symbolSuffix = symbolSuffixField == null ? "" : symbolSuffixField;
        return cioiDarkBookManager.createIfAbsent(symbol + symbolSuffix,
                symbol, symbolSuffix);
    }
}
