package com.citi.icg.cioidark.crossing.engine.component.timertask;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.CrossingEngineSystemProperty;
import com.citi.icg.cioidark.crossing.engine.component.book.loader.LoadAtStartup;
import com.citi.icg.cioidark.enumeration.MarketPeriod;
import com.citi.icg.cioidark.qmf.Timer;
import com.citi.icg.cioidark.qmf.TimerTask;
import com.citi.icg.cioidark.qmf.TimerTaskType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ScheduleSystemTimerService {

    private final static Logger logger = LoggerFactory.getLogger(ScheduleSystemTimerService.class);

    private final static String SYSTEM = "SYSTEM";

    public ScheduleSystemTimerService() {}

    public static void setStartupAndTimerServices() {

        final CrossingEngineSystemProperty crossingEngineSystemProperty = CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty();

        final long now = System.currentTimeMillis();

        // Schedule warm up end time, client shouldn't send any order prior to warm up end time
        if (now < crossingEngineSystemProperty.getWarmupEndTime().getTime()) {
            logger.info("Schedule warm up end timer for " + crossingEngineSystemProperty.getWarmupEndTime());
            Timer.getInstance().schedule(new CrossingEngineTimerRunnable(), new TimerTask(SYSTEM, TimerTaskType.MARKET_PRE_OPEN),
                    crossingEngineSystemProperty.getWarmupEndTime(), 0);
        }

        // Schedule market open timer if current time is before market open time
        if (now < crossingEngineSystemProperty.getMarketOpenTime().getTime()) {
            logger.info("Schedule Market Open Timer for " + crossingEngineSystemProperty.getMarketOpenTime());
            Timer.getInstance().schedule(new CrossingEngineTimerRunnable(),
                    new TimerTask(SYSTEM, TimerTaskType.MARKET_OPEN),
                    crossingEngineSystemProperty.getMarketOpenTime(), 0);
        }

        // Schedule market close timer if current time is before market close time
        if (now < crossingEngineSystemProperty.getMarketCloseTime().getTime()) {
            logger.info("Schedule Market Close Timer for " + crossingEngineSystemProperty.getMarketCloseTime());
            Timer.getInstance().schedule(new CrossingEngineTimerRunnable(),
                    new TimerTask(SYSTEM, TimerTaskType.MARKET_CLOSE),
                    crossingEngineSystemProperty.getMarketCloseTime(), 0);
        }

        //Schedule Close unSolicited Cancel time
        if (now < crossingEngineSystemProperty.getMarketCloseUnsolicitedCxlTime().getTime()) {
            logger.info("Schedule Market Close Unsolicited Cancel Timer for " + crossingEngineSystemProperty.getMarketCloseUnsolicitedCxlTime());
            Timer.getInstance().schedule(new CrossingEngineTimerRunnable(),
                    new TimerTask(SYSTEM, TimerTaskType.GLOBAL_TASK),
                    crossingEngineSystemProperty.getMarketCloseUnsolicitedCxlTime(), 0);
        }

        setMarketPeriod(now, crossingEngineSystemProperty);

        Timer.getInstance().schedule(new PublishSystemPropertiesRunnable(),
                new TimerTask(SYSTEM, TimerTaskType.GLOBAL_TASK), 1000, 0);

        Timer.getInstance().schedule(new LoadAtStartup(),
                new TimerTask(SYSTEM, TimerTaskType.GLOBAL_TASK), 10000, 0);


    }

    private static void setMarketPeriod(final long now, final CrossingEngineSystemProperty crossingEngineSystemProperty) {

        if (now < crossingEngineSystemProperty.getWarmupEndTime().getTime())
            crossingEngineSystemProperty.setMarketPeriod(MarketPeriod.WARM_UP);
        else if (crossingEngineSystemProperty.getWarmupEndTime().getTime() < now && now < crossingEngineSystemProperty.getMarketOpenTime().getTime())
            crossingEngineSystemProperty.setMarketPeriod(MarketPeriod.PRE_OPEN);
        else if (now > crossingEngineSystemProperty.getMarketCloseTime().getTime())
            crossingEngineSystemProperty.setMarketPeriod(MarketPeriod.POST_CLOSE);
        else
            crossingEngineSystemProperty.setMarketPeriod(MarketPeriod.CONTINUOUS_TRADING);

    }
}
