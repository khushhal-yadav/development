package com.citi.icg.cioidark.crossing.engine.component.book;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.AbstractBookAttributes;
import com.citi.icg.cioidark.enumeration.MarketPeriod;
import com.citi.icg.cioidark.util.BooleanUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

public class BookAttributes extends AbstractBookAttributes {
    private boolean marketDataStale;
    private boolean regSHOActivated;
    private boolean bypassMode;
    private boolean halted;
    private boolean quoteOnly;
    private boolean marketOpen;
    private String bookSymbol;
    private String marketDataSymbol;
    private String symbol;
    private String symbolSfx;
    private boolean subscribeMarketData;
    private String securityExchange;
    private boolean tradePaused;
    private String primaryExchange;
    private String instance;
    private double maxNotional;

    public String getBookSymbol() {
        return bookSymbol;
    }

    public void setBookSymbol(String bookSymbol) {
        this.bookSymbol = bookSymbol;
    }

    public boolean isMarketDataStale() {
        return marketDataStale;
    }

    public void setMarketDataStale(boolean marketDataStale) {
        this.marketDataStale = marketDataStale;
    }

    public boolean isRegSHOActivated() {
        return regSHOActivated;
    }

    public void setRegSHOActivated(boolean regSHOActivated) {
        this.regSHOActivated = regSHOActivated;
    }

    public boolean isBypassMode() {
        return bypassMode;
    }

    public void setBypassMode(boolean bypassMode) {
        this.bypassMode = bypassMode;
    }

    public boolean isHalted() {
        return halted;
    }

    public void setHalted(boolean halted) {
        this.halted = halted;
    }

    public boolean isQuoteOnly() {
        return quoteOnly;
    }

    public void setQuoteOnly(boolean quoteOnly) {
        this.quoteOnly = quoteOnly;
    }

    public void setMarketOpen(boolean marketOpen) {
        this.marketOpen = marketOpen;
    }

    public boolean isMarketOpen() {
        return marketOpen;
    }

    public boolean setSubscribeMarketData(boolean subscribeMarketData) {
        this.subscribeMarketData = subscribeMarketData;
        return this.subscribeMarketData;
    }

    public boolean isSubscribeMarketData() {
        return subscribeMarketData;
    }

    public String getMarketDataSymbol() {
        return marketDataSymbol;
    }

    public void setMarketDataSymbol(String marketDataSymbol) {
        this.marketDataSymbol = marketDataSymbol;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getSymbolSfx() {
        return symbolSfx;
    }

    public void setSymbolSfx(String symbolSfx) {
        this.symbolSfx = symbolSfx;
    }

    public String getSecurityExchange() {
        return securityExchange;
    }

    public void setSecurityExchange(String securityExchange) {
        this.securityExchange = securityExchange;
    }

    public boolean isTradePaused() {
        return tradePaused;
    }

    public void setTradePaused(boolean tradePaused) {
        this.tradePaused = tradePaused;
    }

    public String getPrimaryExchange() {
        return primaryExchange;
    }

    public void setPrimaryExchange(String primaryExchange) {
        this.primaryExchange = primaryExchange;
    }

    public String getInstance() {
        return instance;
    }

    public void setInstance(String instance) {
        this.instance = instance;
    }

    public double getMaxNotional() {
        return maxNotional;
    }

    public void setMaxNotional(double maxnotional) {
        this.maxNotional = maxnotional;
    }

    @Override
    public String toString() {
        return "BookAttributes [marketDataStale=" + marketDataStale + ", regSHOActivated=" + regSHOActivated
                + ", bypassMode=" + bypassMode + ", halted=" + halted + ", quoteOnly=" + quoteOnly + ", marketOpen="
                + marketOpen + ", bookSymbol=" + bookSymbol + ", marketDataSymbol=" + marketDataSymbol + ", symbol="
                + symbol + ", symbolSfx=" + symbolSfx + ", subscribeMarketData="
                + subscribeMarketData + ", securityExchange=" + securityExchange + ", tradePaused=" + tradePaused
                + ", primaryExchange=" + primaryExchange + ", instance=" + instance + ", maxNotional=" + maxNotional
                + "]";
    }

    public void setMarketDataSymbol(final String symbolSuffix, final String rootSymbol, Logger logger) {
        BooleanUtil.ifTrueExecuteOrElse(
                StringUtils.isBlank(symbolSuffix),
                () -> this.setMarketDataSymbol(rootSymbol),
                () -> {
                    switch (CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getMarketDataSource()) {
                        case GMD:
                            final String symbologySfx = CrossingEngineApplicationContextProvider.getGmdSymbologyManager().getSymbologySuffix(symbolSuffix);
                            BooleanUtil.ifNotNullExecuteOrElse(
                                    symbologySfx,
                                    () -> this.setMarketDataSymbol(rootSymbol + symbologySfx),
                                    () -> logger.warn("Unable to lookup corresponding symbology suffix for symbolsfx {} ", symbologySfx)
                            );
                            break;

                        default:
                            logger.error("MARKET DATA SOURCE NOT SUPPORTED - {}",
                                    CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getMarketDataSource());
                    }
                }
        );
    }

    public final boolean subscribeMarketData(final Logger logger) {
        return BooleanUtil.ifTrueEvaluateOrElse(
                CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().isSubscribeMarketData(),
                () -> this.subscribeMarketDataOn(logger),
                () -> this.subscribeMarketDataOff(logger)
        );
    }

    private boolean subscribeMarketDataOn(final Logger logger) {
        logger.info("subscribeMarketData for symbol {} ", getSymbol());
        return BooleanUtil.ifTrueEvaluateOrElse(
                this.isSubscribeMarketData(),
                () -> {
                    logger.warn("Book for symbol {} is already subscribed to market data", getSymbol());
                    return false;
                },
                () -> this
                        .setSubscribeMarketData(CrossingEngineApplicationContextProvider.getSubscribeToMarketDataService()
                                .subscribe(getSymbol(), this.getMarketDataSymbol() == null
                                        ? ""
                                        : this.getMarketDataSymbol(), true, logger))
        );
    }

    private boolean subscribeMarketDataOff(final Logger logger) {
        this.setSubscribeMarketData(false);
        BooleanUtil.ifTrueExecute(
                CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getMarketPeriod() == MarketPeriod.CONTINUOUS_TRADING,
                () -> {
                    this.setMarketOpen(true);
                    logger.info("{}|MARKET OPENED|INIT", symbol);
                }
        );
        return false;
    }

}
