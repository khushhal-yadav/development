package com.citi.icg.cioidark.crossing.engine.component.book.loader;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.crossing.engine.component.domain.Ticker;
import com.citi.icg.cioidark.qmf.TimerRunnable;
import com.citi.icg.cioidark.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoadAtStartup extends TimerRunnable {

    private static final Logger logger = LoggerFactory.getLogger(LoadAtStartup.class);

    @Override
    public void run() {
        loadBook();
    }

    private void loadBook() {

        List<Ticker> symbols = loadSymbolsForSymbolRange(CrossingEngineApplicationContextProvider
                .getCrossingEngineSystemProperty().getSymbolRange());

        symbols.parallelStream().forEach(ticker ->
                CrossingEngineApplicationContextProvider.getCioiDarkBookManager()
                        .createIfAbsent(ticker.getRoot() + ticker.getSuffix(), ticker.getRoot(), ticker.getSuffix()));

        logger.info("{} Symbols loaded", symbols.size());
    }

    private List<Ticker> loadSymbolsForSymbolRange(final String symbolRange) {

        return loadSymbolUniverse().stream()
                .filter(ticker -> ticker != null && SymbolRangeCheck.isInRange(ticker.getRoot(), symbolRange))
                .collect(Collectors.toCollection(ArrayList::new));
    }

    private List<Ticker> loadSymbolUniverse() {
        final String filePath = getMostRecentFileLocation();

        return Optional.ofNullable(filePath)
                .map(file -> {
                    logger.info("Loading symbol universe from file {}", filePath);
                    try {
                        return loadSymbolUniverse(filePath);
                    } catch (IOException e) {
                        logger.error("Error in loading symbols from file {}", file);
                        return null;
                    }
                }).filter(tickers -> tickers != null && !tickers.isEmpty()).orElse(Collections.emptyList());
    }

    private List<Ticker> loadSymbolUniverse(final String filePath) throws IOException {
        return Files.lines(Paths.get(filePath))
                .filter(lineOfFile -> !StringUtils.containsWhitespace(lineOfFile) && StringUtils.isNotEmpty(lineOfFile))
                .map(lineOfFile -> {
                    String[] symbol = lineOfFile.split(",");
                    if (symbol.length == 2) {
                        return new Ticker(symbol[0], symbol[1]);
                    } else {
                        return new Ticker(symbol[0]);
                    }
                }).collect(Collectors.toCollection(LinkedList::new));
    }


    private String getMostRecentFileLocation() {
        LocalDate today = LocalDate.now();
        final Optional<String> filePath = IntStream.rangeClosed(0, CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getNumPreviousDaysToSearchForSymbolFile())
                .mapToObj(day -> createFilePath(DateUtil.localDateToDigitString(today.minusDays(day))))
                .filter(fileLocation -> (new File(fileLocation)).exists())
                .findFirst();

        if (!filePath.isPresent())
            logger.warn("File not found at {}", filePath);

        return filePath.orElse(null);
    }

    private String createFilePath(String subDirectory) {
        return String.format("%s%s%s%s%s", CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getSymbolsFileLocation()
                , System.getProperty("file.separator"), subDirectory, System.getProperty("file.separator")
                , CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getSymbolFileFileName());
    }
}
