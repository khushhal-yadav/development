package com.citi.icg.cioidark.crossing.engine.component.publisher;

import java.util.Optional;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.DisableClient;
import com.citi.icg.cioidark.chronicle.messaging.message.alert.Alert;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.crossing.engine.component.book.BookAttributes;
import com.citi.icg.cioidark.util.threadpool.CioiDarkThreadPool;

public class CfgMgrDataPublisher {

    private final CioiDarkThreadPool<?> cfgMgrThreadPool;

    public CfgMgrDataPublisher() {
        this.cfgMgrThreadPool = CrossingEngineApplicationContextProvider.getCfgMgrThreadPool();
    }

    public void publishBookAttributes(final BookAttributes bookAttributes) {
        final CfgMgrDataEvent cfgMgrDataEvent = new CfgMgrDataEvent(bookAttributes);
        cfgMgrThreadPool.submit(cfgMgrDataEvent, bookAttributes.getSymbol());
    }

    public void publishSystemProperties() {
        final CfgMgrDataEvent cfgMgrDataEvent =
                new CfgMgrDataEvent(CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty());
        cfgMgrThreadPool.submit(cfgMgrDataEvent, "");
    }

    public void publishAlert(final Alert alert) {
        CfgMgrDataEvent cfgMgrDataEvent = new CfgMgrDataEvent(alert);
        cfgMgrThreadPool.submit(cfgMgrDataEvent, Optional.ofNullable(alert.getSymbol()).orElse(""));
    }

    public void publishDisableClient(final DisableClient disableClient) {
        CfgMgrDataEvent cfgMgrDataEvent = new CfgMgrDataEvent(disableClient);
        cfgMgrThreadPool.submit(cfgMgrDataEvent, Optional.ofNullable(disableClient.getSymbol()).orElse(""));
    }

    public void publishMarketDataMessage(final MarketDataMessage marketDataMessage) {
        CfgMgrDataEvent cfgMgrDataEvent = new CfgMgrDataEvent(marketDataMessage);
        cfgMgrThreadPool.submit(cfgMgrDataEvent, Optional.ofNullable(marketDataMessage.getSymbol()).orElse(""));
    }







}
