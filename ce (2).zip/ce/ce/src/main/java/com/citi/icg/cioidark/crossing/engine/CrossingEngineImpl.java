package com.citi.icg.cioidark.crossing.engine;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.CrossingEngineDirector;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.AdminMessage;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.CrossingEngineIn;
import com.citi.icg.cioidark.chronicle.messaging.queue.CrossingEngineOut;
import com.citi.icg.cioidark.chronicle.service.AbstractChronicleService;
import org.apache.commons.configuration.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;

/**
 * Implementation class for chronicle market data service
 * @author ky54595
 */
@SuppressWarnings({"WeakerAccess", "unused"})
public class CrossingEngineImpl extends AbstractChronicleService implements CrossingEngineIn {

    private static final Logger logger = LoggerFactory.getLogger(CrossingEngineImpl.class);

    public CrossingEngineImpl(CrossingEngineOut crossingEngineOut) throws ConfigurationException {
        CrossingEngineDirector.getInstance().initialize(crossingEngineOut);
    }

    @Override
    public void newOrderSingle(final NewOrderSingle newOrderSingle) {
        logger.info("FIX Inbound Message: NewOrderSingle |{}", newOrderSingle.toString());
        CrossingEngineApplicationContextProvider.getInboundHandler()
                .fixInbound(newOrderSingle);
    }

    @Override
    public void orderCancelRequest(final OrderCancelRequest orderCancelRequest) {
        logger.info("FIX Inbound Message: OrderCancelRequest |{}", orderCancelRequest.toString());
        CrossingEngineApplicationContextProvider.getInboundHandler()
                .fixInbound(orderCancelRequest);
    }

    @Override
    public void orderCancelReplaceRequest(final OrderCancelReplaceRequest orderCancelReplaceRequest) {
        logger.info("FIX Inbound Message: OrderCancelReplaceRequest |{}", orderCancelReplaceRequest.toString());
        CrossingEngineApplicationContextProvider.getInboundHandler()
                .fixInbound(orderCancelReplaceRequest);
    }

    @Override
    public void marketData(final MarketDataMessage marketDataMessage) {
        logger.info("MarketData Inbound Message: MarketDataMessage |{}", marketDataMessage.toString());
        CrossingEngineApplicationContextProvider.getInboundHandler()
                .marketDataInbound(marketDataMessage);
    }

    @Override
    public void adminMessage(final AdminMessage adminMessage) {
        logger.info("Admin Inbound Message: AdminMessage |{}", adminMessage.toString());
        CrossingEngineApplicationContextProvider.getInboundHandler()
                .adminMessage(adminMessage);

    }
}
