package com.citi.icg.cioidark.crossing.engine.component.timertask;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.qmf.TimerRunnable;

public class PublishSystemPropertiesRunnable extends TimerRunnable {

    @Override
    public void run() {
        CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishSystemProperties();
    }
}
