package com.citi.icg.cioidark.crossing.engine.component.crossing.handler;


import java.util.List;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.queue.CrossingEngineOut;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBook;
import com.citi.icg.cioidark.util.threadpool.event.DispatchableEvent;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;

public class CioiDarkCrossingEvent extends DispatchableEvent<CioiDarkBook>{

    private final CrossingEngineOut crossingEngineOut;

    public CioiDarkCrossingEvent(final CioiDarkBook cioiDarkBook, final String symbol) {
        setPayload(cioiDarkBook);
        setSynchKey(symbol);
        crossingEngineOut = CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty()
                .getCrossingEngineOut();
    }

    @Override
    public void run() {
        cross().forEach(crossingEngineOut::executionReport);
    }

    private List<DefaultExecutionReport> cross() {
        return getPayload().checkLiquidityAndCross();
    }
}
