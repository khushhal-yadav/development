package com.citi.icg.cioidark.crossing.engine.component.book;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.citi.icg.cioidark.crossing.engine.component.exception.DuplicateTradeException;
import com.citi.icg.cioidark.crossing.engine.component.exception.UnknownTradeException;
import software.chronicle.fix.codegen.messages.ExecutionReport;

public class CioiDarkTradeBook {

    private final Map<String, ExecutionReport> trades = new ConcurrentHashMap<>();
    private double cumQty = 0;
    private double avgPx = 0;

    public double cumQty() {
        return cumQty;
    }

    public double avgPx() {
        return avgPx;
    }

    public boolean contains(final String execID) {
        return trades.containsKey(execID);
    }

    public ExecutionReport get(final String execID) {
        if (!trades.containsKey(execID))
            throw new UnknownTradeException();

        return trades.get(execID);
    }

    public ExecutionReport put(final ExecutionReport cioiDarkTrade) {
        if (trades.containsKey(cioiDarkTrade.execID()))
            throw new DuplicateTradeException();

        addTrade(cioiDarkTrade.lastShares(), cioiDarkTrade.lastPx());
        return trades.put(cioiDarkTrade.execID(), cioiDarkTrade);
    }

    public ExecutionReport remove(final String execID) {
        if (!trades.containsKey(execID))
            throw new UnknownTradeException();

        final ExecutionReport removedTrade = trades.remove(execID);
        subtractTrade(removedTrade.lastShares(), removedTrade.lastPx());
        return removedTrade;
    }

    private void addTrade(final double lastShares, final double lastPx) {
        if (cumQty + lastShares > 0) {
            avgPx = (avgPx * cumQty + lastPx * lastShares) / (cumQty + lastShares);
        } else {
            avgPx = 0;
        }
        cumQty += lastShares;
    }

    private void subtractTrade(final double lastShares, final double lastPx) {
        addTrade(-lastShares, lastPx);
    }

}
