package com.citi.icg.cd.template;

//Kept it for reference
public class CioiDarkExecutionReportBuilder {

   /* private DefaultExecutionReport executionReport = new DefaultExecutionReport();
    private DefaultOrderCancelReject orderCancelReject = new DefaultOrderCancelReject();
    private int[] tagsToCopy = new int[]{SrcTargetCompId.FIELD, ClOrdID.FIELD, OrderID.FIELD, Symbol.FIELD, SymbolSfx.FIELD,
            Side.FIELD, Price.FIELD, OrdType.FIELD, OrderQty.FIELD, BidPx.FIELD, OfferPx.FIELD, QuoteTime.FIELD, BidSize.FIELD,
            OfferSize.FIELD, MinQty.FIELD, LocateReqd.FIELD, LocateBroker.FIELD, LocateIdentifier.FIELD, RootSrcSystemID.FIELD,
            PreviousLinkSrcSystemID.FIELD, OrderCapacity.FIELD, SecurityAltID.FIELD, SecurityAltIDSource.FIELD, SecurityID.FIELD,
            SecurityExchange.FIELD, CrossInstruction.FIELD, ContraOrderCapacity.FIELD, OrderFlowEntry.FIELD, OrderFlowClass.FIELD,
            TraderID.FIELD, AvgPriceAcct.FIELD, LegalEntity.FIELD, Account.FIELD};

    private static final Set<String> execInst_Not_Held = Sets.newHashSet("M 1", "1 M", "1");

    private AbstractDataModel sourceMessage;
    private CioiDarkOrder order;


    public CioiDarkExecutionReportBuilder from(AbstractDataModel msg, CioiDarkOrder order) {
        sourceMessage = msg;
        this.order = order;
        return this;
    }

    public CioiDarkExecutionReportBuilder from(AbstractDataModel msg) {
        sourceMessage = msg;
        return this;
    }

    @Override
    public CioiDarkOrderResponse executionReport() {
        return this;
    }

    public DefaultExecutionReport createExecutionReport() {
        executionReport.reset();
        DateTime now = DateTime.now();
        executionReport.execID(IDGenerator.newID());
        executionReport.senderCompID(sourceMessage.getString(SenderCompID.FIELD));
        executionReport.senderSubID(sourceMessage.getString(SenderSubID.FIELD));
        executionReport.sendingTime(now.getMillis());
        executionReport.transactTime(now.getMillis());
        executionReport.targetCompID(sourceMessage.getString(TargetCompID.FIELD));
        executionReport.targetSubID(sourceMessage.getString(TargetSubID.FIELD));
        copyAllTags(executionReport);

        if (order != null) {
            executionReport.orderQty(order.orderQty());
            executionReport.orderID(order.orderID());
            executionReport.price(order.price());
        }

        BooleanUtil.ifPresentSetFixTag(sourceMessage.getDouble(OrderQty.FIELD), executionReport::leavesQty);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(CorellationClOrdID.FIELD), executionReport::corellationClOrdID);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(PreviousLinkOrderID.FIELD), executionReport::previousLinkOrderID);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(RootOrderID.FIELD), executionReport::rootOrderID);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(CustomerSlang.FIELD), executionReport::customerSlang);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(IDSource.FIELD), executionReport::idSource);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getChar(TimeInForce.FIELD), executionReport::timeInForce);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(StrategyParameterValue.FIELD), executionReport::strategyParameterValue);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ReceiveTime.FIELD), executionReport::receiveTime);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(CrossRestrictionClientID.FIELD), executionReport::crossRestrictionClientID);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getDouble(Price.FIELD), executionReport::price);

        BooleanUtil.ifTrueExecute(order != null, () -> executionReport.orderVersion(order.orderVersion()));

        if (FixTagUtil.isValueSet(sourceMessage.getString(CustomPrice1.FIELD))
                && sourceMessage.getString(CustomPrice1.FIELD).equals(OrderType.CONDITIONAL_ORDER)) {
            executionReport.conditionalOrderQty(executionReport.orderQty());
            executionReport.customPrice1(sourceMessage.getString(CustomPrice1.FIELD));
        } else if (FixTagUtil.isValueSet(sourceMessage.getString(CustomPrice1.FIELD))) {
            executionReport.customPrice1(sourceMessage.getString(CustomPrice1.FIELD));
        }

        if (FixTagUtil.isValueSet(sourceMessage.getString(OnBehalfOfSubID.FIELD))) {
            executionReport.deliverToSubID(sourceMessage.getString(OnBehalfOfSubID.FIELD));
            executionReport.onBehalfOfSubID(sourceMessage.getString(OnBehalfOfSubID.FIELD));
        }

        if (FixTagUtil.isValueSet(sourceMessage.getString(OnBehalfOfCompID.FIELD))) {
            executionReport.deliverToCompID(sourceMessage.getString(OnBehalfOfCompID.FIELD));
            executionReport.onBehalfOfCompID(sourceMessage.getString(OnBehalfOfCompID.FIELD));
        }

        //Was being set as "H" in Citibloc code, so inherited from there
        executionReport.sourceFeed("H");

        mapExecInst();

        return this.executionReport;
    }

    private void mapExecInst() {
        String execInst = "5 M";
        if (FixTagUtil.isValueSet(sourceMessage.getString(ExecInst.FIELD))) {
            if (execInst_Not_Held.contains(sourceMessage.getString(ExecInst.FIELD))) {
                execInst = "1 M";
            }
        }
        //append u65 for DNCS
        if (FixTagUtil.isValueSet(sourceMessage.getString(CrossInstruction.FIELD))
                && sourceMessage.getString(CrossInstruction.FIELD).contains("NS")) {
            execInst = execInst + " u65";
        }

        executionReport.execInst(execInst);
    }

    public DefaultOrderCancelReject createOrderCancelReject() {
        orderCancelReject.reset();
        DateTime now = DateTime.now();
        orderCancelReject.senderCompID(sourceMessage.getString(SenderCompID.FIELD));
        orderCancelReject.senderSubID(sourceMessage.getString(SenderSubID.FIELD));
        orderCancelReject.sendingTime(now.getMillis());
        orderCancelReject.transactTime(now.getMillis());
        orderCancelReject.targetCompID(sourceMessage.getString(TargetCompID.FIELD));
        orderCancelReject.targetSubID(sourceMessage.getString(TargetSubID.FIELD));
        copyAllTags(orderCancelReject);
        if (FixTagUtil.isValueSet(sourceMessage.getString(OnBehalfOfSubID.FIELD))) {
            orderCancelReject.deliverToSubID(sourceMessage.getString(OnBehalfOfSubID.FIELD));
            orderCancelReject.onBehalfOfSubID(sourceMessage.getString(OnBehalfOfSubID.FIELD));
        }

        if (FixTagUtil.isValueSet(sourceMessage.getString(OnBehalfOfCompID.FIELD))) {
            orderCancelReject.deliverToCompID(sourceMessage.getString(OnBehalfOfCompID.FIELD));
            orderCancelReject.onBehalfOfCompID(sourceMessage.getString(OnBehalfOfCompID.FIELD));
        }

        BooleanUtil.ifPresentSetFixTag(sourceMessage.getChar(Side.FIELD), orderCancelReject::side);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getDouble(Price.FIELD), orderCancelReject::price);
        BooleanUtil.ifTrueExecute(order != null, () -> orderCancelReject.orderVersion(order.orderVersion()));

        orderCancelReject.sourceFeed("H");

        return orderCancelReject;
    }

    public DefaultExecutionReport createExecutionReport(NewOrderSingle newOrderSingle) {
        executionReport.reset();
        DateTime now = DateTime.now();
        executionReport.clOrdID(newOrderSingle.clOrdID());
        executionReport.execID(IDGenerator.newID());
        executionReport.sendingTime(now.getMillis());
        executionReport.transactTime(now.getMillis());
        return this.executionReport;
    }

    public DefaultExecutionReport invite(String clOrdId, String crossId) {
        this.executionReport = createExecutionReport();
        executionReport.cxlQty(sourceMessage.getDouble(CxlQty.FIELD));
        executionReport.ordStatus(OrdStatus.CANCELED);
        //executionReport.orderVersion(sourceMessage.getInt(OrderVersion.FIELD) + 1);
        executionReport.execType(ExecType.CANCELED);
        executionReport.avgPx(0);
        executionReport.cumQty(0);
        executionReport.leavesQty(0);
        executionReport.ioiID(clOrdId);
        executionReport.crossID(crossId);
        executionReport.text(clOrdId);
        executionReport.onBehalfOfSubID(sourceMessage.getString(OnBehalfOfSubID.FIELD));
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ClearingInstruction.FIELD), executionReport::clearingInstruction);
        return this.executionReport;
    }

    public DefaultExecutionReport newReject(String text, int rejReason) {
        this.executionReport = createExecutionReport();

        executionReport.execType(ExecType.REJECTED);
        executionReport.ordStatus(OrdStatus.REJECTED);
        executionReport.ordRejReason(rejReason);
        executionReport.text(text);
        if (FixConstants.isUnset(executionReport.orderID()))
            executionReport.orderID(IDGenerator.newID());
        executionReport.avgPx(0);
        executionReport.cumQty(0);
        executionReport.leavesQty(0);
        executionReport.ioiID(sourceMessage.getString(IOIID.FIELD));
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ClearingInstruction.FIELD), executionReport::clearingInstruction);
        executionReport.conditionalOrderQty(sourceMessage.getLong(OrderQty.FIELD));
        return this.executionReport;

    }

    public DefaultOrderCancelReject modReject(String text, String orderId, int rejReason) {
        createOrderCancelReject();
        orderCancelReject.ordStatus(OrdStatus.CANCELED);
        orderCancelReject.clOrdID(sourceMessage.getString(ClOrdID.FIELD));
        orderCancelReject.orderQty(sourceMessage.getDouble(OrderQty.FIELD));
        orderCancelReject.origClOrdID(sourceMessage.getString(OrigClOrdID.FIELD));
        orderCancelReject.execType(ExecType.REJECTED);
        orderCancelReject.cxlRejResponseTo(CxlRejResponseTo.ORDER_CANCEL_REPLACE_REQUEST);
        orderCancelReject.cxlRejReason(rejReason);
        orderCancelReject.text(text);
        orderCancelReject.orderID(orderId);
        return orderCancelReject;
    }

    public DefaultOrderCancelReject cancelReject(String text, String orderId, int rejReason) {
        createOrderCancelReject();
        orderCancelReject.ordStatus(OrdStatus.CANCELED);
        orderCancelReject.clOrdID(sourceMessage.getString(ClOrdID.FIELD));
        orderCancelReject.orderQty(sourceMessage.getDouble(OrderQty.FIELD));
        orderCancelReject.origClOrdID(sourceMessage.getString(OrigClOrdID.FIELD));
        orderCancelReject.execType(ExecType.REJECTED);
        orderCancelReject.cxlRejResponseTo(CxlRejResponseTo.ORDER_CANCEL_REQUEST);
        orderCancelReject.cxlRejReason(rejReason);
        orderCancelReject.text(text);
        orderCancelReject.orderID(orderId);
        return orderCancelReject;
    }

    @Override
    public DefaultExecutionReport newAck() {
        this.executionReport = createExecutionReport();
        executionReport.ordStatus(OrdStatus.NEW);
        executionReport.execType(ExecType.NEW);
        executionReport.ioiID(sourceMessage.getString(IOIID.FIELD));
        executionReport.avgPriceAcctIDSource(sourceMessage.getString(AvgPriceAcctIDSource.FIELD));
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(TickSizePilotGroup.FIELD), executionReport::tickSizePilotGroup);
        executionReport.bidPx(sourceMessage.getDouble(BidPx.FIELD));
        executionReport.offerPx(sourceMessage.getDouble(OfferPx.FIELD));
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ClearingInstruction.FIELD), executionReport::clearingInstruction);
        executionReport.avgPx(0);
        executionReport.cumQty(0);

        return this.executionReport;
    }

    private void newCanModCommon() {
        executionReport.avgPx(0);
        executionReport.cumQty(0);
        executionReport.leavesQty(0);
        if (FixTagUtil.isValueSet(sourceMessage.getString(CustomPrice1.FIELD)) &&
                sourceMessage.getString(CustomPrice1.FIELD).equals(OrderType.CONDITIONAL_ORDER)) {
            executionReport.customPrice1(sourceMessage.getString(CustomPrice1.FIELD));
            executionReport.conditionalOrderQty(executionReport.orderQty());
        }

        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ClearingInstruction.FIELD), executionReport::clearingInstruction);
        BooleanUtil.ifTrueExecute(order != null, () -> executionReport.orderVersion(order.orderVersion()));
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getDouble(Price.FIELD), executionReport::price);
    }

    @Override
    public DefaultExecutionReport modAck() {
        this.executionReport = createExecutionReport();
        newCanModCommon();
        executionReport.ordStatus(OrdStatus.REPLACED);
        executionReport.execType(ExecType.REPLACE);
        executionReport.origClOrdID(sourceMessage.getString(OrigClOrdID.FIELD));
        executionReport.leavesQty(executionReport.orderQty() - executionReport.cumQty());
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ClearingInstruction.FIELD), executionReport::clearingInstruction);

        return this.executionReport;
    }

    @Override
    public DefaultExecutionReport cxlAck() {
        executionReport = createExecutionReport();

        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(OrigClOrdID.FIELD), executionReport::origClOrdID);
        executionReport.ordStatus(OrdStatus.CANCELED);
        executionReport.execType(ExecType.CANCELED);
        newCanModCommon();
        executionReport.account(null);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ClearingInstruction.FIELD), executionReport::clearingInstruction);

        return executionReport;
    }

    @Override
    public DefaultExecutionReport unsolCxl() {
        this.executionReport = createExecutionReport();
        executionReport.ordStatus(OrdStatus.CANCELED);
        executionReport.execType(ExecType.CANCELED);
        executionReport.avgPriceAcctIDSource(sourceMessage.getString(AvgPriceAcctIDSource.FIELD));
        executionReport.tickSizePilotGroup(sourceMessage.getString(TickSizePilotGroup.FIELD));
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(TickSizePilotGroup.FIELD), executionReport::tickSizePilotGroup);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ClearingInstruction.FIELD), executionReport::clearingInstruction);
        newCanModCommon();

        return this.executionReport;
    }

    @Override
    public DefaultExecutionReport crossfill(double lastPx, double lastQty, String crossid) {
        this.executionReport = fill(lastPx, lastQty);

        executionReport.side(Side.CROSS);
        executionReport.price(FixConstants.UNSET_DOUBLE);
        executionReport.clOrdID(null);
        executionReport.minQty(FixConstants.UNSET_DOUBLE);
        executionReport.orderQty(FixConstants.UNSET_DOUBLE);
        executionReport.orderCapacity(FixConstants.UNSET_CHAR);
        executionReport.quoteTime(FixConstants.UNSET_LONG);
        executionReport.bidPx(FixConstants.UNSET_DOUBLE);
        executionReport.offerPx(FixConstants.UNSET_DOUBLE);
        executionReport.avgPriceAcct(null);
        executionReport.legalEntity(null);
        executionReport.firmId(null);
        executionReport.ioiID(null);
        executionReport.crossID(crossid);
        executionReport.zExecID(crossid + ":0");
        executionReport.actReport(ActReport.PARTYMUSTRPT);
        executionReport.targetCompID(ExternalSystem.CTRS.value());
        executionReport.targetSubID(ExternalSystem.CTRS.value());
        executionReport.srcTargetCompId(ExternalSystem.CTRS.value());
        executionReport.avgPriceAcctIDSource(sourceMessage.getString(AvgPriceAcctIDSource.FIELD));
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(TickSizePilotGroup.FIELD), executionReport::tickSizePilotGroup);

        return this.executionReport;
    }

    @Override
    public DefaultExecutionReport fill(double lastPx, double lastShares) {
        startExecutionReport();
        executionReport.execType(ExecType.TRADE);
        executionReport.lastPx(lastPx);
        executionReport.lastShares(lastShares);
        executionReport.avgPriceAcctIDSource(sourceMessage.getString(AvgPriceAcctIDSource.FIELD));
        executionReport.tickSizePilotGroup(sourceMessage.getString(TickSizePilotGroup.FIELD));
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(TickSizePilotGroup.FIELD), executionReport::tickSizePilotGroup);
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ClearingInstruction.FIELD), executionReport::clearingInstruction);
        return this.executionReport;
    }

    public DefaultExecutionReport newCondAck() {
        startExecutionReport();
        executionReport.ordStatus(OrdStatus.NEW);
        executionReport.execType(ExecType.NEW);
        executionReport.ioiID(sourceMessage.getString(IOIID.FIELD));
        executionReport.avgPriceAcctIDSource(sourceMessage.getString(AvgPriceAcctIDSource.FIELD));
        executionReport.tickSizePilotGroup(sourceMessage.getString(TickSizePilotGroup.FIELD));
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getString(SourceFeed.FIELD), executionReport::sourceFeed);
        executionReport.bidPx(sourceMessage.getDouble(BidPx.FIELD));
        executionReport.offerPx(sourceMessage.getDouble(OfferPx.FIELD));
        newCanModCommon();
        executionReport.leavesQty(executionReport.orderQty());
        BooleanUtil.ifPresentSetFixTag(sourceMessage.getLong(ClearingInstruction.FIELD), executionReport::clearingInstruction);

        return this.executionReport;
    }

    public void startExecutionReport() {
        this.executionReport = createExecutionReport();
        // TODO: These need to come from the order  obj
        executionReport.cumQty();
        executionReport.leavesQty();
        executionReport.avgPx();
    }

    public void copyAllTags(AbstractDataModel msg) {

        msg.setString(Account.FIELD, sourceMessage.getString(Account.FIELD));
        msg.setString(SrcTargetCompId.FIELD, sourceMessage.getString(SrcTargetCompId.FIELD));
        msg.setString(ClOrdID.FIELD, sourceMessage.getString(ClOrdID.FIELD));
        msg.setString(OrderID.FIELD, sourceMessage.getString(OrderID.FIELD));
        msg.setString(Symbol.FIELD, sourceMessage.getString(Symbol.FIELD));
        msg.setString(SymbolSfx.FIELD, sourceMessage.getString(SymbolSfx.FIELD));
        msg.setChar(Side.FIELD, sourceMessage.getChar(Side.FIELD));
        msg.setDouble(Price.FIELD, sourceMessage.getDouble(Price.FIELD));
        msg.setDouble(OrderQty.FIELD, sourceMessage.getDouble(OrderQty.FIELD));
        msg.setDouble(BidPx.FIELD, sourceMessage.getDouble(BidPx.FIELD));
        msg.setDouble(OfferPx.FIELD, sourceMessage.getDouble(OfferPx.FIELD));

        if (sourceMessage instanceof DefaultNewOrderSingle) {
            msg.setDouble(BidSize.FIELD, sourceMessage.getDouble(BidSize.FIELD));
            msg.setDouble(OfferSize.FIELD, sourceMessage.getDouble(OfferSize.FIELD));
            msg.setLong(RootSrcSystemID.FIELD, sourceMessage.getLong(RootSrcSystemID.FIELD));
            msg.setLong(PreviousLinkSrcSystemID.FIELD, sourceMessage.getLong(PreviousLinkSrcSystemID.FIELD));
            msg.setChar(ContraOrderCapacity.FIELD, sourceMessage.getChar(ContraOrderCapacity.FIELD));
            msg.setString(OrderFlowEntry.FIELD, sourceMessage.getString(OrderFlowEntry.FIELD));
            msg.setString(OrderFlowClass.FIELD, sourceMessage.getString(OrderFlowClass.FIELD));
            msg.setString(TraderID.FIELD, sourceMessage.getString(TraderID.FIELD));
            msg.setString(AvgPriceAcct.FIELD, sourceMessage.getString(AvgPriceAcct.FIELD));
            msg.setString(LegalEntity.FIELD, sourceMessage.getString(LegalEntity.FIELD));
            msg.setString(LocateBroker.FIELD, sourceMessage.getString(LocateBroker.FIELD));
            msg.setString(LocateIdentifier.FIELD, sourceMessage.getString(LocateIdentifier.FIELD));
        }
        if (!(msg instanceof OrderCancelReject)) {
            if (sourceMessage instanceof OrderCancelRequest) {
                msg.setChar(OrdType.FIELD, order.ordType());
            } else {
                msg.setChar(OrdType.FIELD, sourceMessage.getChar(OrdType.FIELD));
                msg.setDouble(MinQty.FIELD, sourceMessage.getDouble(MinQty.FIELD));
                msg.setChar(LocateReqd.FIELD, sourceMessage.getChar(LocateReqd.FIELD));
                msg.setChar(OrderCapacity.FIELD, sourceMessage.getChar(OrderCapacity.FIELD));
                msg.setString(SecurityAltID.FIELD, sourceMessage.getString(SecurityAltID.FIELD));
                msg.setString(SecurityAltIDSource.FIELD, sourceMessage.getString(SecurityAltIDSource.FIELD));
                msg.setString(SecurityID.FIELD, sourceMessage.getString(SecurityID.FIELD));
                msg.setString(CrossInstruction.FIELD, sourceMessage.getString(CrossInstruction.FIELD));
            }
            msg.setLong(QuoteTime.FIELD, sourceMessage.getLong(QuoteTime.FIELD));
        }
*//*
        List<Integer> sourceFields = Arrays.stream(sourceMessage.getFieldNumbers()).boxed().collect(Collectors.toList());
        List<Integer> destinationFields = Arrays.stream(msg.getFieldNumbers()).boxed().collect(Collectors.toList());

        // This is to ensure that the fields are defined in both the source and destination object

        IntStream.of(tagsToCopy)
                .filter(x -> (sourceFields.contains(x) && destinationFields.contains(x)
                        && FixTagUtil.isValueSet(sourceMessage.getString(x))))
                .forEach(tag -> msg.setString(tag, sourceMessage.getString(tag)));

*//*

    }*/
}
