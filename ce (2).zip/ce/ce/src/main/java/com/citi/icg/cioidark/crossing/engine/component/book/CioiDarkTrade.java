package com.citi.icg.cioidark.crossing.engine.component.book;

import software.chronicle.fix.codegen.fields.OrderVersion;
import software.chronicle.fix.staticcode.messages.FixMessage;

public class CioiDarkTrade implements OrderVersion {

    private final String tradeId;
    private final double lastShares;
    private final double lastPx;
    private long orderVersion = FixMessage.UNSET_LONG;

    CioiDarkTrade(String tradeId, double lastShares, double lastPx) {
        this.tradeId = tradeId;
        this.lastShares = lastShares;
        this.lastPx = lastPx;
    }

    public String tradeId() {
        return tradeId;
    }

    public double lastShares() {
        return lastShares;
    }

    public double lastPx() {
        return lastPx;
    }

    @Override
    public long orderVersion() {
        return this.orderVersion;
    }

    @Override
    public void orderVersion(final long orderVersion) {
        this.orderVersion = orderVersion;
    }
}
