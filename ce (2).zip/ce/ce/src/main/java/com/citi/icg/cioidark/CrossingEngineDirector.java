package com.citi.icg.cioidark;

import com.citi.icg.cioidark.chronicle.messaging.queue.CrossingEngineOut;
import com.citi.icg.cioidark.crossing.engine.component.timertask.ScheduleSystemTimerService;
import org.apache.commons.configuration.ConfigurationException;

public class CrossingEngineDirector {

    private static final CrossingEngineDirector director = new CrossingEngineDirector();

    private CrossingEngineDirector() {}

    public static CrossingEngineDirector getInstance() {
        return director;
    }

    public void initialize(final CrossingEngineOut crossingEngineOut) throws ConfigurationException {
        CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty(crossingEngineOut);
        ScheduleSystemTimerService.setStartupAndTimerServices();
    }
}
