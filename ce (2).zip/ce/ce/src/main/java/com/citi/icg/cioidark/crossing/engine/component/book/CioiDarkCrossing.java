package com.citi.icg.cioidark.crossing.engine.component.book;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.util.BooleanUtil;
import com.citi.icg.cioidark.util.FixTagUtil;
import com.citi.icg.cioidark.util.PriceUtil;
import software.chronicle.fix.codegen.fields.CrossInstruction;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.OrderCapacity;

public class CioiDarkCrossing {

	private CioiDarkCrossing() {
	    throw new IllegalStateException("Utility class");
	}

    public static boolean areOrdersCrossable(CioiDarkBook cioiDarkBook, final CioiDarkBookOrder buyOrder, final CioiDarkBookOrder sellOrder) {
        // DNCP Check
        if (buyOrder.crossInstruction() != null && buyOrder.getCrossInstruction().contains(CrossInstruction.NO_PRINCIPLE)
                && OrderCapacity.PRINCIPAL == sellOrder.orderCapacity()
                || sellOrder.crossInstruction() != null
                && sellOrder.getCrossInstruction().contains(CrossInstruction.NO_PRINCIPLE)
                && OrderCapacity.PRINCIPAL == buyOrder.orderCapacity()) {
            cioiDarkBook.getLogger().info(
                    "oid:{}|oid:{}order excluded from cross due to DNCP flag on one order, and principal capacity on the other",
                    buyOrder.orderId(), sellOrder.orderId());
            return false;
        }
        // DNCS Check
        if (FixTagUtil.isValueSet(buyOrder.crossInstruction()) &&
                FixTagUtil.isValueSet(sellOrder.crossInstruction()) &&
                buyOrder.getCrossInstruction().contains(CrossInstruction.DO_NOT_CROSS_SELF) &&
                sellOrder.getCrossInstruction().contains(CrossInstruction.DO_NOT_CROSS_SELF) &&
                FixTagUtil.isValueSet(buyOrder.crossRestrictionClientId()) &&
                FixTagUtil.isValueSet(sellOrder.crossRestrictionClientId()) &&
                buyOrder.crossRestrictionClientId().equals(sellOrder.crossRestrictionClientId())) {
            cioiDarkBook.getLogger().info("oid:{}|oid:{}|buyOrder excluded from cross due to DNCS tag 10896={} on both orders",
                    buyOrder.orderId(), sellOrder.orderId(), buyOrder.crossRestrictionClientId());
            return false;
        }

        double crossPrice = getCrossPrice(cioiDarkBook, buyOrder, sellOrder);

        // Order Limit Price Check
        if (crossPrice <= 0) {
            cioiDarkBook.getLogger().info("oid:{}|oid:{}|orders excluded from cross due to incompatible limit prices",
                    buyOrder.orderId(), sellOrder.orderId());
            return false;
        }

        // RegSHO-201 Short-sale-restriction Bid-test
        if (cioiDarkBook.crossingRegSHOActivated() &&
                (buyOrder.isShortSaleSide() || sellOrder.isShortSaleSide())) {
            double onePennyAboveTheBid = cioiDarkBook.crossingMarketData().getBidPx() + 0.01d;
            if (crossPrice < onePennyAboveTheBid) {
                cioiDarkBook.getLogger().info(
                        "oid:{}|oid:{}|buyOrder excluded from cross due to RegSHO-201: short-sale orders cannot execute for less than one penny above the bid when short-sale-restriction is active",
                        buyOrder.orderId(), sellOrder.orderId());
                return false;
            }
        }

        return true;
    }

    public static double getCrossPrice(CioiDarkBook cioiDarkBook, CioiDarkBookOrder buyOrder, CioiDarkBookOrder sellOrder) {
        final MarketDataMessage crossingMarketData = cioiDarkBook.crossingMarketData();
        final double crossPrice = PriceUtil.priceRoundingCustom((crossingMarketData.getBidPx() + crossingMarketData.getAskPx()) / 2.0d);

        return BooleanUtil.ifTrueEvaluateOtherwiseReturnDefault(
                (buyOrder.orderType() == OrdType.MARKET || buyOrder.price() >= crossPrice) &&
                        (sellOrder.orderType() == OrdType.MARKET || sellOrder.price() <= crossPrice),
                () -> crossPrice,
                -1.0d
        );

    }

    public static double getCrossQuantity(CioiDarkBookOrder buyOrder, CioiDarkBookOrder sellOrder) {
        return Math.min(buyOrder.getCrossableQuantity(), sellOrder.getCrossableQuantity());
    }

    public static boolean isCrossPriceWithInLowerUpperBand(double crossPrice, CioiDarkBook cioiDarkBook) {
        return BooleanUtil.ifTrueEvaluateOrElse(
                (cioiDarkBook.crossingLULDData().getLowerLimit() == 0.0 && cioiDarkBook.crossingLULDData().getUpperLimit() == 0.0) ||
                        crossPrice >= cioiDarkBook.crossingLULDData().getLowerLimit() && crossPrice <= cioiDarkBook.crossingLULDData().getUpperLimit(),
                () -> true,
                () -> {
                    cioiDarkBook.getLogger().info("cross price [{}] is outside lower band [{}] and upper band [{}]", crossPrice,
                            cioiDarkBook.crossingLULDData().getLowerLimit(), cioiDarkBook.crossingLULDData().getUpperLimit());
                    return false;
                }
        );
    }
}
