package com.citi.icg.cioidark.crossing.engine.component.util;

import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBookOrder;
import com.citi.icg.cioidark.util.BooleanUtil;
import software.chronicle.fix.codegen.fields.Side;

public class ParticipationLimitPriceCalculator {

	private ParticipationLimitPriceCalculator () {
	    throw new IllegalStateException("Utility class");		
	}

    public static double price(CioiDarkBookOrder order) {
        return BooleanUtil.ifTrueOrElse(
                order.isMarketOrder(),
                BooleanUtil.ifTrueOrElse(
                        order.side() == Side.BUY,
                        Double.MAX_VALUE,
                        Double.MIN_VALUE),
                order.price());
    }

}
