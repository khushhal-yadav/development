package com.citi.icg.cioidark.crossing.engine.component.exception;

public class InvalidStateChangeException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public InvalidStateChangeException(String message) {
        super(message);
    }
}
