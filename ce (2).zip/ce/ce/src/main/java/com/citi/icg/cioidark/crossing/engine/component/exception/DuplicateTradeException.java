package com.citi.icg.cioidark.crossing.engine.component.exception;

public class DuplicateTradeException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
}
