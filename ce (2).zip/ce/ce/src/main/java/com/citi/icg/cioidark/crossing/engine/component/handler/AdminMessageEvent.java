package com.citi.icg.cioidark.crossing.engine.component.handler;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.AdminCommand;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.AdminMessage;
import com.citi.icg.cioidark.chronicle.messaging.message.alert.Alert;
import com.citi.icg.cioidark.crossing.engine.component.book.loader.SymbolRangeCheck;
import com.citi.icg.cioidark.crossing.engine.component.book.manager.CioiDarkBookManager;
import com.citi.icg.cioidark.crossing.engine.component.handler.processor.AdminMessageProcessorEvent;
import com.citi.icg.cioidark.enumeration.alert.AlertCategory;
import com.citi.icg.cioidark.enumeration.alert.AlertStatus;
import com.citi.icg.cioidark.util.threadpool.CioiDarkThreadPool;
import com.citi.icg.cioidark.util.threadpool.event.DispatchableEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AdminMessageEvent {

    private final static Logger logger = LoggerFactory.getLogger(AdminMessageEvent.class);
    private final CioiDarkBookManager cioiDarkBookManager;
    private final CioiDarkThreadPool<AdminMessage> adminMsgThreadPool;


    public AdminMessageEvent() {
        this.cioiDarkBookManager = CrossingEngineApplicationContextProvider.getCioiDarkBookManager();
        this.adminMsgThreadPool = CrossingEngineApplicationContextProvider.getAdminMessageThreadPool();
    }

    public void adminMessage(final AdminMessage adminMessage) {

        assert adminMessage != null;
        switch (adminMessage.getCommand()) {
            case CXLORDERS:
                cancelOrders(adminMessage);
                break;
            case PAUSECROSSINGBYINSTANCEID:
                pauseResumeCrossingByInstance(adminMessage);
                break;
            case RESUMECROSSINGBYINSTANCEID:
                pauseResumeCrossingByInstance(adminMessage);
                break;
            case CXLORDERSBYINSTANCEID:
                cxlOrdersInstanceId(adminMessage);
                break;
            case PAUSECROSSINGBYSYMBOL:
                pauseResumeCrossingBySymbol(adminMessage);
                break;
            case RESUMECROSSINGBYSYMBOL:
                pauseResumeCrossingBySymbol(adminMessage);
                break;
            case CXLORDERSBYSYMBOL:
            case DELETEBOOK:
                cxlBySymbol(adminMessage);
                break;
            case MASSCXL:
                massCxl(adminMessage);
                break;
            case MASSCXL_MPID:
                massCxlMpid(adminMessage);
                break;
            case MASSCXL_MPID_SYMBOL:
                massCxlMpidSymbol(adminMessage);
                break;
            case SETMARKETDATA:
            case RESUBSCRIBEMARKETDATA:
                marketData(adminMessage);
            case REENABLE_CLIENT:
                dispatchAdminMessage(adminMessage.getSymbol(), adminMessage);
                break;
            case CXLORDERSBYSESSIONID:
                cancelBySessionID(adminMessage);
                break;
            case ENGINESNAPSHOT:
                engineSnapshot();
                break;
            case DISABLEPERFMONITORING:
                disablePerfMonitoring();
                break;
            case ENABLEPERFMONITORING:
                enablePerfMonitoring();
                break;
            default:
                break;
        }
    }

    private void enablePerfMonitoring() {
        CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().setPerfMonitorStatus(true);
        publishCrossingEngineSystemProperties();
        logger.info("performance monitoring enabled");
    }

    private void disablePerfMonitoring() {
        CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().setPerfMonitorStatus(false);
        publishCrossingEngineSystemProperties();
        logger.info("performance monitoring disabled");
    }

    private void engineSnapshot() {
        cioiDarkBookManager.getCioiDarkBooks().forEach(cioiDarkBook -> CrossingEngineApplicationContextProvider
                .getCfgMgrDataHandler().publishBookAttributes(cioiDarkBook.bookAttributes()));
        publishCrossingEngineSystemProperties();

    }

    private void publishCrossingEngineSystemProperties() {
        CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishSystemProperties();
    }

    private void cancelBySessionID(AdminMessage adminMessage) {
        if (Objects.isNull(adminMessage.getSessionID()))
            return;

        cioiDarkBookManager.getCioiDarkBooks().forEach(cioiDarkBook -> {
            AdminMessage bookAdminMessage = new AdminMessage(adminMessage.getCommand());
            bookAdminMessage.setSymbol(cioiDarkBook.symbol());
            bookAdminMessage.setSessionID(adminMessage.getSessionID());
            bookAdminMessage.setSoeId(adminMessage.getSoeId());
            adminMsgThreadPool.submit(new AdminMessageProcessorEvent(bookAdminMessage, cioiDarkBookManager), bookAdminMessage.getSymbol());
        });

        sendAlert("", AlertCategory.CXLORDERS, AlertStatus.OPEN,
                "Admin Cancel orders ," + adminMessage.getCommand(), adminMessage.getSoeId(), null);
    }

    private void marketData(AdminMessage adminMessage) {
        adminMsgThreadPool.submit(new AdminMessageProcessorEvent(adminMessage, cioiDarkBookManager), adminMessage.getSymbol());
    }

    private void massCxlMpidSymbol(AdminMessage adminMessage) {
        final String symbol = adminMessage.getSymbol();
        final String mpid = adminMessage.getMpid();
        final String symbolRange = CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getSymbolRange();

        if (Objects.isNull(symbolRange) || !SymbolRangeCheck.isInRange(symbol, symbolRange))
            return;

        AdminMessage bookAdminMessage = new AdminMessage(adminMessage.getCommand());
        bookAdminMessage.setSymbol(symbol);
        bookAdminMessage.setAccount(mpid);
        adminMsgThreadPool.submit(new AdminMessageProcessorEvent(bookAdminMessage, cioiDarkBookManager), bookAdminMessage.getSymbol());

        sendAlert(symbol, AlertCategory.MASSCXLBYMPIDBYSYMBOL, AlertStatus.OPEN,
                "Admin Mass Cancel by MPID Symbol , " + adminMessage.getCommand(), adminMessage.getSoeId(), mpid);
    }

    private void massCxlMpid(AdminMessage adminMessage) {
        final String mpid = adminMessage.getMpid();
        cioiDarkBookManager.getCioiDarkBooks().forEach(cioiDarkBook -> {
            AdminMessage bookAdminMessage = new AdminMessage(adminMessage.getCommand());
            bookAdminMessage.setSymbol(cioiDarkBook.symbol());
            bookAdminMessage.setAccount(mpid);
            adminMsgThreadPool.submit(new AdminMessageProcessorEvent(bookAdminMessage, cioiDarkBookManager), bookAdminMessage.getSymbol());
        });

        sendAlert("", AlertCategory.MASSCXLBYMPID, AlertStatus.OPEN,
                "Admin Mass Cancel by MPID , " + adminMessage.getCommand(), adminMessage.getSoeId(), mpid);
    }

    private void cxlBySymbol(AdminMessage adminMessage) {
        adminMsgThreadPool.submit(new AdminMessageProcessorEvent(adminMessage, cioiDarkBookManager), adminMessage.getSymbol());
        sendAlert(adminMessage.getSymbol(), AlertCategory.MASSCANCELS, AlertStatus.OPEN,
                "Admin mass cancel , " + adminMessage.getCommand(), adminMessage.getSoeId(), null);
    }

    private void pauseResumeCrossingBySymbol(AdminMessage adminMessage) {
        dispatchAdminMessage(adminMessage.getSymbol(), adminMessage);

        if (adminMessage.getCommand() == AdminCommand.RESUMECROSSINGBYSYMBOL)
            sendAlert(adminMessage.getSymbol(), AlertCategory.CROSSRESUME, AlertStatus.OPEN,
                    "Admin Cross Resume by symbol ," + adminMessage.getCommand(), adminMessage.getSoeId(), null);
        else
            sendAlert(adminMessage.getSymbol(), AlertCategory.CROSSPAUSE, AlertStatus.OPEN,
                    "Admin Cross Resume by symbol ," + adminMessage.getCommand(), adminMessage.getSoeId(), null);

    }

    private void cxlOrdersInstanceId(AdminMessage adminMessage) {
        if (!isValidInstanceId(adminMessage)) {
            logger.warn("Admin Message does not have valid instance id {}", adminMessage);
            return;
        }
        adminMessage = new AdminMessage(AdminCommand.MASSCXL);
        massCxl(adminMessage);
    }

    private void massCxl(final AdminMessage adminMessage) {
        final String symbolRange = CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getSymbolRange();
        final String sessionID = adminMessage.getSessionID();

        cioiDarkBookManager.getCioiDarkBooks().forEach(cioiDarkBook -> {
            AdminMessage bookAdminMessage = new AdminMessage(adminMessage.getCommand());
            bookAdminMessage.setSymbol(cioiDarkBook.symbol());
            bookAdminMessage.setSymbolRange(symbolRange);
            bookAdminMessage.setSessionID(sessionID);
            adminMsgThreadPool.submit(new AdminMessageProcessorEvent(bookAdminMessage, cioiDarkBookManager), bookAdminMessage.getSymbol());
        });

        sendAlert("", AlertCategory.MASSCANCELS, AlertStatus.OPEN,
                "Admin mass cancel , " + adminMessage.getCommand(), adminMessage.getSoeId(), null);
    }

    private void pauseResumeCrossingByInstance(AdminMessage adminMessage) {
        if (!isValidInstanceId(adminMessage)) {
            logger.warn("Admin Message does not have valid instance id {}", adminMessage);
            return;
        }
        cioiDarkBookManager.getCioiDarkBooks().forEach(cioiDarkBook -> dispatchAdminMessage(cioiDarkBook.symbol(), adminMessage));

        if (adminMessage.getCommand() == AdminCommand.PAUSECROSSINGBYINSTANCEID)
            sendAlert("", AlertCategory.CROSSPAUSE, AlertStatus.OPEN,
                    "Admin Cross Pausing by InstanceID, " + adminMessage.getCommand(), adminMessage.getSoeId(), null);
        else
            sendAlert("", AlertCategory.CROSSRESUME, AlertStatus.OPEN,
                    "Admin Cross Resume by InstanceID, " + adminMessage.getCommand(), adminMessage.getSoeId(), null);

        publishCrossingEngineSystemProperties();
    }

    private void dispatchAdminMessage(String symbol, AdminMessage adminMessage) {
        AdminMessage bookAdminMessage = new AdminMessage(adminMessage.getCommand());
        bookAdminMessage.setSymbol(symbol);
        bookAdminMessage.setAccount(adminMessage.getAccount());
        adminMsgThreadPool.submit(new AdminMessageProcessorEvent(bookAdminMessage, cioiDarkBookManager), bookAdminMessage.getSymbol());
    }

    private boolean isValidInstanceId(AdminMessage adminMsg) {
        return (System.getProperty("app.instance").equals(adminMsg.getInstance()));
    }


    private void cancelOrders(AdminMessage adminMessage) {
        List<String> items = Arrays.asList(adminMessage.getDelimitedCxlOrdId().split("\\s*,\\s*"));
        adminMessage.setCxlOrdIdMap(items.stream().collect(HashMap::new, (m, cxlOrdId) -> m.put(cxlOrdId, cxlOrdId), Map::putAll));

        adminMsgThreadPool.submit(new AdminMessageProcessorEvent(adminMessage, cioiDarkBookManager), adminMessage.getSymbol());

        final String alertMessage = "Admin Cancel orders ," + adminMessage.getCommand();
        sendAlert(adminMessage.getSymbol(), AlertCategory.CXLORDERS, AlertStatus.OPEN, alertMessage, adminMessage.getSoeId(), null);

    }

    private void sendAlert(final String symbol, final AlertCategory alertCategory, final AlertStatus alertStatus,
                           final String message, final String updatedBy, final String slang) {
        Alert alert = new Alert(symbol, alertCategory);
        alert.setMsg(message);
        alert.setStatus(alertStatus);
        alert.setUpdatedBy(updatedBy);
        alert.setNewalerttime(String.valueOf(System.currentTimeMillis()));
        if (Objects.nonNull(slang))
            alert.setSlang(slang);
        CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishAlert(alert);
    }

}
