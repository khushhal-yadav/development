package com.citi.icg.cioidark.crossing.engine.component.handler;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.util.threadpool.event.DispatchableEvent;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;
import software.chronicle.fix.datamodel.AbstractDataModel;

//InboundDispEvent
public class FixInboundEvent extends DispatchableEvent<AbstractDataModel> {

    private final AbstractDataModel message;

    public FixInboundEvent(AbstractDataModel message) {
        this.message = message;
    }

    @Override
    public void run() {

        assert message != null;

        if(message instanceof DefaultNewOrderSingle) {
            CrossingEngineApplicationContextProvider.getFixOrderProcessor()
                    .onMessage((DefaultNewOrderSingle) message);
        }
        else if (message instanceof DefaultOrderCancelRequest){
            CrossingEngineApplicationContextProvider.getFixOrderProcessor()
                    .onMessage((DefaultOrderCancelRequest) message);
        }
        else if (message instanceof DefaultOrderCancelReplaceRequest){
            CrossingEngineApplicationContextProvider.getFixOrderProcessor()
                    .onMessage((DefaultOrderCancelReplaceRequest) message);
        }
    }
}
