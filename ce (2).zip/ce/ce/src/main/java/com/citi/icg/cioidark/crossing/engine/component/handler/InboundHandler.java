package com.citi.icg.cioidark.crossing.engine.component.handler;

import java.util.Optional;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.AdminMessage;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.crossing.engine.component.domain.CioiDarkMarketData;
import com.citi.icg.cioidark.util.threadpool.CioiDarkThreadPool;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;
import software.chronicle.fix.datamodel.AbstractDataModel;

public class InboundHandler {

    private static final Logger logger = LoggerFactory.getLogger(InboundHandler.class);

    private final CioiDarkThreadPool<AbstractDataModel> inboundThreadPool;
    private final CioiDarkThreadPool<CioiDarkMarketData> marketDataThreadPool;

    public InboundHandler() {
        this.inboundThreadPool = CrossingEngineApplicationContextProvider.getInboundFixThreadPool();
        this.marketDataThreadPool = CrossingEngineApplicationContextProvider.getInboundMarketDataThreadPool();
    }

    public void fixInbound(final NewOrderSingle inboundMessage) {
        final String symbol = inboundMessage.symbol();
        if (StringUtils.isEmpty(symbol)) {
            logger.warn("ITRSALERT|NewOrderSingle received with symbol={}, dropping message", symbol);
            return;
        }

        DefaultNewOrderSingle newOrderSingle = new DefaultNewOrderSingle();
        inboundMessage.copyTo(newOrderSingle);
        logger.info("Sending NewOrderSingle to FixInboundEvent for Symbol {}", symbol);
        FixInboundEvent fixInboundEvent = new FixInboundEvent(newOrderSingle);
        inboundThreadPool.submit(fixInboundEvent, symbol);
    }

    public void fixInbound(final OrderCancelRequest inboundMessage) {
        final String symbol = inboundMessage.symbol();
        if (StringUtils.isEmpty(symbol)) {
            logger.warn("ITRSALERT|OrderCancelRequest received with getSymbol={}, dropping message", symbol);
            return;
        }

        DefaultOrderCancelRequest orderCancelRequest = new DefaultOrderCancelRequest();
        inboundMessage.copyTo(orderCancelRequest);
        logger.info("Sending OrderCancelRequest to FixInboundEvent for Symbol {}", symbol);
        FixInboundEvent fixInboundEvent = new FixInboundEvent(orderCancelRequest);
        inboundThreadPool.submit(fixInboundEvent, symbol);
    }

    public void fixInbound(final OrderCancelReplaceRequest inboundMessage) {
        final String symbol = inboundMessage.symbol();
        if (StringUtils.isEmpty(symbol)) {
            logger.warn("ITRSALERT|OrderCancelReplaceRequest received with symbol={}, dropping message", symbol);
            return;
        }

        DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = new DefaultOrderCancelReplaceRequest();
        inboundMessage.copyTo(orderCancelReplaceRequest);
        logger.info("Sending OrderCancelReplaceRequest to FixInboundEvent for Symbol {}", symbol);
        FixInboundEvent fixInboundEvent = new FixInboundEvent(orderCancelReplaceRequest);
        inboundThreadPool.submit(fixInboundEvent, symbol);
    }


    public void marketDataInbound(MarketDataMessage marketDataMessage) {
        final String symbol = marketDataMessage.getSymbol();
        if (StringUtils.isEmpty(symbol)) {
            logger.warn("ITRSALERT|Market data tick received with symbol={}, dropping tick, markdetdata getSymbol", symbol);
            return;
        }

        logger.info("Sending MarketDataMessage to MarketDataEvent for Symbol {}", symbol);
        MarketDataEvent marketDataEvent = new MarketDataEvent(marketDataMessage);
        marketDataThreadPool.submit(marketDataEvent, symbol);
    }


    public void adminMessage(final AdminMessage adminMessage) {
        CrossingEngineApplicationContextProvider.getAdminMessageEvent().adminMessage(adminMessage);
    }
}
