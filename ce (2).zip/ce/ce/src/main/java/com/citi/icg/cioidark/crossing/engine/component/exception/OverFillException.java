package com.citi.icg.cioidark.crossing.engine.component.exception;

public class OverFillException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public OverFillException(double lastQty, double leavesQty) {
        super("OVERFILL|lastQty:" + lastQty + " < leavesQty:" + leavesQty);
    }
}
