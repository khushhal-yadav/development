package com.citi.icg.cioidark.crossing.engine.component.handler;

import java.util.Objects;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBook;
import com.citi.icg.cioidark.crossing.engine.component.crossing.trigger.TriggerCioiDarkCrossing;
import com.citi.icg.cioidark.crossing.engine.component.domain.CioiDarkMarketData;
import com.citi.icg.cioidark.util.BooleanUtil;
import com.citi.icg.cioidark.util.threadpool.event.DispatchableEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//MarketDataComboDispatchableEvent
public class MarketDataEvent extends DispatchableEvent<CioiDarkMarketData> {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataEvent.class);

    public MarketDataEvent(MarketDataMessage marketDataMessage) {
        CrossingEngineApplicationContextProvider.getMarketDataProcessor().assignSequenceId(marketDataMessage);
        BooleanUtil.ifTrueExecuteOrElse(
                marketDataMessage.isStatusEvent(),
                () -> setPayload(new CioiDarkMarketData(null, marketDataMessage)),
                () -> setPayload(new CioiDarkMarketData(marketDataMessage, null))
        );
    }

    @Override
    public void run() {
        final boolean triggerCross = CrossingEngineApplicationContextProvider.getMarketDataProcessor().processMarketData(getPayload(), logger);
        final CioiDarkBook cioiDarkBook = getPayload().getCioiDarkBook();

        BooleanUtil.ifTrueExecute(
                Objects.nonNull(cioiDarkBook) && triggerCross,
                () -> TriggerCioiDarkCrossing.trigger(cioiDarkBook)
        );


    }
}
