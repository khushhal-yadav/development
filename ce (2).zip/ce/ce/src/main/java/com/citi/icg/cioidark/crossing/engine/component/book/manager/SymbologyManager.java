package com.citi.icg.cioidark.crossing.engine.component.book.manager;

import java.util.Map;

public class SymbologyManager {

    private final Map<String, String> symbology;

    public SymbologyManager(Map<String, String> symbology) {
        this.symbology = symbology;
    }

    public Map<String, String> getSymbology() {
        return symbology;
    }
}
