package com.citi.icg.cioidark.crossing.engine.component.handler.processor;

import java.util.Collection;
import java.util.Objects;
import java.util.function.Predicate;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.AdminCommand;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.AdminMessage;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.IgnoreMDTick;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.CrossingEngineOut;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBook;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBookOrder;
import com.citi.icg.cioidark.crossing.engine.component.book.manager.CioiDarkBookManager;
import com.citi.icg.cioidark.enumeration.MarketPeriod;
import com.citi.icg.cioidark.util.BooleanUtil;
import com.citi.icg.cioidark.util.threadpool.event.DispatchableEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.fields.CxlReason;

public class AdminMessageProcessorEvent extends DispatchableEvent<AdminMessage> {

    private final static Logger logger = LoggerFactory.getLogger(AdminMessageProcessorEvent.class);

    private final CioiDarkBookManager cioiDarkBookManager;
    private final CrossingEngineOut crossingEngineOut;

    public AdminMessageProcessorEvent(final AdminMessage adminMessage, final CioiDarkBookManager cioiDarkBookManager) {
        setPayload(adminMessage);
        this.cioiDarkBookManager = cioiDarkBookManager;
        this.crossingEngineOut = CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getCrossingEngineOut();
    }

    @Override
    public void run() {

        final AdminMessage adminMessage = getPayload();
        assert adminMessage != null;

        CioiDarkBook cioiDarkBook;

        switch (adminMessage.getCommand()) {
            case SETMARKETDATA:
                cioiDarkBook = cioiDarkBookManager.createIfAbsent(adminMessage.getSymbol());
                BooleanUtil.ifNotNullExecuteOrElse(
                        cioiDarkBook,
                        () -> {
                            crossingEngineOut.ignoreMDTick(new IgnoreMDTick(adminMessage.getSymbol(), true));
                            MarketDataMessage marketDataMessage = new MarketDataMessage(adminMessage.getMarketData().getBid(),
                                    adminMessage.getMarketData().getOffer(), adminMessage.getSymbol(), System.currentTimeMillis());
                            cioiDarkBook.updateMarketData(marketDataMessage);
                            CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishMarketDataMessage(marketDataMessage);
                            logger.info("Admin overridden market data for symbol {}, Bid: {}, Ask: {}",
                                    adminMessage.getSymbol(), adminMessage.getMarketData().getBid(), adminMessage.getMarketData().getOffer());

                            if (!CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getTestSymbols().contains(adminMessage.getSymbol()))
                                return;

                            if (System.currentTimeMillis() > CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getMarketCloseTime().getTime()) {
                                CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().setMarketPeriod(MarketPeriod.POST_CLOSE_CHKOUT);
                                CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishSystemProperties();
                                logger.info("Post-market checkout period enabled for test symbol {}", adminMessage.getSymbol());
                            } else {
                                CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().setMarketPeriod(MarketPeriod.WARM_UP);
                                CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishSystemProperties();
                                logger.info("Pre-market (WARUP_UP) checkout period enabled for test symbol {}", adminMessage.getSymbol());
                            }


                        },
                        () -> logger.warn("Book Not Found for set market data/ignore MD Tick command - {}", adminMessage.getSymbol())
                );
                break;
            case RESUBSCRIBEMARKETDATA:
                cioiDarkBook = cioiDarkBookManager.createIfAbsent(adminMessage.getSymbol());
                BooleanUtil.ifNotNullExecuteOrElse(
                        cioiDarkBook,
                        () -> {
                            crossingEngineOut.ignoreMDTick(new IgnoreMDTick(adminMessage.getSymbol(), false));
                            logger.info("Admin resume marketdata symbol {}", adminMessage.getSymbol());

                            if (!CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getTestSymbols().contains(adminMessage.getSymbol()))
                                return;

                            if (System.currentTimeMillis() > CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getMarketCloseTime().getTime()
                                    && CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getMarketPeriod() == MarketPeriod.POST_CLOSE_CHKOUT) {
                                CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().setMarketPeriod(MarketPeriod.POST_CLOSE);
                                CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishSystemProperties();
                                logger.info("Market period set to POST_CLOSE for test symbol {}", adminMessage.getSymbol());
                            } else if (CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getMarketPeriod() == MarketPeriod.WARM_UP) {
                                CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().setMarketPeriod(MarketPeriod.PRE_OPEN);
                                CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishSystemProperties();
                                logger.info("arket period set to PRE_OPEN for test symbol {} ", adminMessage.getSymbol());
                            }
                        },
                        () -> logger.warn("Book Not Found for resume market data command - {}", adminMessage.getSymbol())
                );
                break;
            case PAUSECROSSINGBYINSTANCEID: // request would be submitted for all symbols
            case PAUSECROSSINGBYSYMBOL:
                cioiDarkBook = cioiDarkBookManager.createIfAbsent(adminMessage.getSymbol());
                BooleanUtil.ifNotNullExecuteOrElse(
                        cioiDarkBook,
                        book -> {
                            logger.info("Paused crossing for symbol {}", adminMessage.getSymbol());
                            book.setPausedCrossing(true);
                            CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishBookAttributes(book.bookAttributes());
                        },
                        () -> logger.warn("Book Not Found for pause crossing command - {}", adminMessage.getSymbol())
                );
                break;
            case RESUMECROSSINGBYINSTANCEID: // request would be submitted for all symbols
            case RESUMECROSSINGBYSYMBOL:
                cioiDarkBook = cioiDarkBookManager.createIfAbsent(adminMessage.getSymbol());
                BooleanUtil.ifNotNullExecuteOrElse(
                        cioiDarkBook,
                        bk -> {
                            logger.info("Resume crossing for symbol {}", adminMessage.getSymbol());
                            bk.setPausedCrossing(false);
                            CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishBookAttributes(bk.bookAttributes());
                            bk.checkLiquidityAndCross().forEach(crossingEngineOut::executionReport);
                        },
                        () -> logger.warn("Book Not Found for resume crossing command - {}", adminMessage.getSymbol())
                );
                break;
            case UNSOLCITEDCXLORDER:
                cioiDarkBook = cioiDarkBookManager.createIfAbsent(adminMessage.getSymbol());
                final CioiDarkBookOrder cioiDarkBookByOrdID = cioiDarkBook.findByOrdID(adminMessage.getOrderID());
                if (Objects.nonNull(cioiDarkBookByOrdID))
                    crossingEngineOut.executionReport(cioiDarkBook.unSolCxlOrder(cioiDarkBookByOrdID, CxlReason.ADMINISTRATIVE_CXL, null));
                break;
            case CXLORDERSBYSYMBOL:
            case MASSCXL:
                String cxlReason = BooleanUtil.ifTrueEvaluateOrElse(
                        adminMessage.getCommand() == AdminCommand.CXLORDERSBYSYMBOL,
                        () -> CxlReason.ADMINISTRATIVE_CXL,
                        () -> CxlReason.MASS_CXL);
                cioiDarkBook = cioiDarkBookManager.createIfAbsent(adminMessage.getSymbol());
                BooleanUtil.ifNotNullExecuteOrElse(
                        cioiDarkBook,
                        bk -> cancelBook(bk, adminMessage, cxlReason, ord -> true),
                        () -> logger.warn("Book Not Found on MassCxl Command - {}", adminMessage.getSymbol())
                );
                break;
            case CXLORDERS:
                cioiDarkBook = cioiDarkBookManager.getCioiDarkBook(adminMessage.getSymbol());
                BooleanUtil.ifNotNullExecuteOrElse(
                        cioiDarkBook,
                        bk -> cancelBook(bk, adminMessage, CxlReason.ADMINISTRATIVE_CXL, ord -> adminMessage.getCxlOrdIdMap().containsKey(ord.orderId())),
                        () -> logger.warn("Book Not Found on cxlOrders Command - {}", adminMessage.getSymbol())
                );
                break;
            case MASSCXL_MPID: // request would be submitted for all cioiDarkBooks
            case MASSCXL_MPID_SYMBOL:  // request would be submitted only for one symbol
                cioiDarkBook = cioiDarkBookManager.getCioiDarkBook(adminMessage.getSymbol());
                BooleanUtil.ifNotNullExecuteOrElse(
                        cioiDarkBook,
                        bk -> cancelBook(bk, adminMessage, CxlReason.MASS_CXL, ord -> ord.account().equals(adminMessage.getAccount())),
                        () -> logger.warn("Book Not Found on MassCxl Command - {}", adminMessage.getSymbol())
                );
                break;
            case CXLORDERSBYSESSIONID:
                cioiDarkBook = cioiDarkBookManager.getCioiDarkBook(adminMessage.getSymbol());
                BooleanUtil.ifNotNullExecuteOrElse(
                        cioiDarkBook,
                        bk -> cancelBook(bk, adminMessage, CxlReason.ADMINISTRATIVE_CXL, ord -> (adminMessage.getSessionID().equals(ord.senderSubId()))),
                        () -> logger.warn("Book Not Found on cxlOrders Command - {}", adminMessage.getSymbol())
                );
                break;
            default:
                break;

        }

    }

    private void cancelBook(CioiDarkBook cioiDarkBook, AdminMessage adminMsg, String reason, Predicate<CioiDarkBookOrder> p) {
        boolean symbolRangeSet = adminMsg.getSymbolRange() != null;
        boolean sessionIDSet = adminMsg.getSessionID() != null;
        Collection<CioiDarkBookOrder> orders = (sessionIDSet && !symbolRangeSet) ?
                cioiDarkBook.allOpenOrdersForSessionId(adminMsg.getSessionID()) :
                cioiDarkBook.allOpenOrders();

        orders.stream().filter(p).map(cioiDarkBookOrder -> cioiDarkBook.unSolCxlOrder(cioiDarkBookOrder, reason, null))
                .forEach(crossingEngineOut::executionReport);
    }
}
