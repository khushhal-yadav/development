package com.citi.icg.cioidark.crossing.engine.component.domain;

import java.util.Date;

public class LULDData {
	private double lowerLimit;
	private double upperLimit;
	private Date arrivedTime;

	public LULDData(double lower, double upper, Date date) {
		this.lowerLimit = lower;
		this.upperLimit = upper;
		this.arrivedTime = date;
	}

	public double getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(double lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public double getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(double upperLimit) {
		this.upperLimit = upperLimit;
	}

	public Date getArrivedTime() {
		return arrivedTime;
	}

	public void setArrivedTime(Date arrivedTime) {
		this.arrivedTime = arrivedTime;
	}

}
