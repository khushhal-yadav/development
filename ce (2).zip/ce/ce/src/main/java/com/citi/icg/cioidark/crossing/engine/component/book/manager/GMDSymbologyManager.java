package com.citi.icg.cioidark.crossing.engine.component.book.manager;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.crossing.engine.component.book.loader.LoadGMDSymbology;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GMDSymbologyManager extends SymbologyManager {

    private static final Logger logger = LoggerFactory.getLogger(GMDSymbologyManager.class);

    private static Map<String, String> symbology;

    static {
        try {
            symbology = LoadGMDSymbology.loadGMDSymbology();
        } catch (IOException | URISyntaxException e) {
            logger.error("ITRSALERT| Error in loading GMD Symboloy file {}", CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getGmdSymbologyFileName());
            symbology = new HashMap<>();
        }
    }

    public GMDSymbologyManager() {
        super(symbology);
    }

    public String getSymbologySuffix(final String symbolSuffix) {
        return symbology.get(symbolSuffix);
    }
}
