package com.citi.icg.cioidark.crossing.engine.component.book;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.CrossingEngineSystemProperty;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.crossing.engine.component.domain.LULDData;
import com.citi.icg.cioidark.idgen.IDGenerator;
import com.citi.icg.cioidark.util.BooleanUtil;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.fields.CxlReason;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

public class CioiDarkBook {

    private final Logger logger;

    private static final long CFG_MGR_PUBLISH_DELAY = 200L;

    private final String symbol;
    private final String symbolSuffix;
    private final String rootSymbol;
    private final CioiDarkBookOrderRepo cioiDarkBookOrderRepo;
    private final CrossingEngineSystemProperty crossingEngineSystemProperty;
    private boolean crossingRegSHOActivated;

    private final BookAttributes bookAttributes = new BookAttributes();
    private MarketDataMessage marketData = new MarketDataMessage();
    private MarketDataMessage crossingMarketData;
    private LULDData luldData;
    private LULDData crossingLULDData;
    private final AtomicLong marketDataSeq = new AtomicLong(0);

    public CioiDarkBook(String key, String symbolSuffix, String rootSymbol, CioiDarkBookOrderRepo cioiDarkBookOrderRepo) {
        this.symbol = key;
        this.symbolSuffix = symbolSuffix;
        this.rootSymbol = rootSymbol;
        this.cioiDarkBookOrderRepo = cioiDarkBookOrderRepo;
        this.crossingEngineSystemProperty = CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty();
        logger = LoggerFactory.getLogger(getClass().getName() + "|" + this.symbol);
    }

    public void init() {

        logger.info("Initializing book for ticker {},suffix {}, rootSymbol {} ", this.symbol, this.symbolSuffix, this.rootSymbol);

        bookAttributes.setBookSymbol(this.symbol);
        bookAttributes.setSymbol(this.symbol);
        bookAttributes.setSymbolSfx(this.symbolSuffix);
        bookAttributes.setMarketOpen(false);
        bookAttributes.setInstance(this.crossingEngineSystemProperty.getServiceInstance());
        bookAttributes.setMaxNotional(this.crossingEngineSystemProperty.getMaxNotional());
        bookAttributes.setMarketDataSymbol(symbolSuffix, rootSymbol, logger);
        final boolean subscribed = bookAttributes.subscribeMarketData(logger);

        if (subscribed)
            CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishBookAttributes(bookAttributes);

        luldData = new LULDData(0.0, 0.0, crossingEngineSystemProperty.getMarketOpenTime());
    }

    public List<DefaultExecutionReport> checkLiquidityAndCross() {

        if (cioiDarkBookOrderRepo.isSideEmpty())
            return Collections.emptyList();

        setCrossingMarketDataAndLULDData();
        crossingRegSHOActivated = bookAttributes.isRegSHOActivated();

        if (!isBookCrossable())
            return Collections.emptyList();

        final List<DefaultExecutionReport> crosses = new LinkedList<>();

        synchronized (this) {
            final List<CioiDarkBookOrder> buyOrders = cioiDarkBookOrderRepo.findBuyOrders(crossingMarketData.getBidPx());

            if (buyOrders.isEmpty())
                return crosses;

            final List<CioiDarkBookOrder> sellOrders = cioiDarkBookOrderRepo.findSellOrders(crossingMarketData.getAskPx());

            if (sellOrders.isEmpty())
                return crosses;

            buyOrders.forEach(buyOrder -> {
                final Optional<Map<CioiDarkBookOrder, List<DefaultExecutionReport>>> crossableOrderTradesOptional =
                        sellOrders.stream()
                                .map(sellOrder -> crossableOrderTrades(buyOrder, sellOrder)).filter(cioiDarkBookOrderListMap -> !cioiDarkBookOrderListMap.isEmpty()).findFirst();
                crossableOrderTradesOptional.ifPresent(crossableOrderTrades -> {
                    sellOrders.remove(crossableOrderTrades.keySet().iterator().next());
                    crosses.addAll(crossableOrderTrades.values().iterator().next());
                });
            });
        }

        return crosses;
    }

    private boolean isBookCrossable() {

        waitIfCrossingPaused();

        // Global pause check
        if (CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().isCrossingPaused()) {
            logger.info("PAUSED|crossing is paused across the engine");
            return false;
        }

        if (this.isHalted()) {
            logger.info("HALT|trading is halted for this getSymbol, no crossing until trading resumes");
            return false;
        }
        if (this.isQuoteOnly()) {
            logger.info("QUOTEONLY|this getSymbol is in a trading-halt quotation-period, no crossing until trading resumes");
            return false;
        }
        if (this.isMarketDataStale()) {
            logger.info("STALE|Market is stale for this getSymbol");
            return false;
        }
        if (this.isLockedMarket()) {
            logger.info("LOCKED|Market is locked for this getSymbol");
            return false;
        }

        if (this.isPausedCrossing()) {
            logger.info("PAUSED|crossing is paused for this getSymbol");
            return false;
        }
        if (this.isCrossedMarket()) {
            logger.info("CROSSED|Market crossed, bid {}, ask {}, would not be able to cross",
                    this.crossingMarketData().getBidPx(),
                    this.crossingMarketData().getAskPx());
            return false;
        }
        return true;

    }

    private void waitIfCrossingPaused() {
        BooleanUtil.ifTrueExecute(
                CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().isCrossingPaused() &&
                        !this.isPausedCrossing(),
                () -> {
                    // before attempting the first cross,
                    // wait for the market data to be published in System Property Manager
                    logger.info("Wait for the market data to be published in System Property Manager");
                    try {
                        Thread.sleep(CFG_MGR_PUBLISH_DELAY);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
        );
    }

    private Map<CioiDarkBookOrder, List<DefaultExecutionReport>> crossableOrderTrades(CioiDarkBookOrder buyOrder, CioiDarkBookOrder sellOrder) {

        if (!CioiDarkCrossing.areOrdersCrossable(this, buyOrder, sellOrder))
            return Collections.emptyMap();

        double crossPrice = CioiDarkCrossing.getCrossPrice(this, buyOrder, sellOrder);
        double crossQuantity = CioiDarkCrossing.getCrossQuantity(buyOrder, sellOrder);

        if (!(crossPrice > 0 && crossQuantity > 0 && CioiDarkCrossing.isCrossPriceWithInLowerUpperBand(crossPrice, this)))
            return Collections.emptyMap();

        final List<DefaultExecutionReport> cioiDarkExecutions = new LinkedList<>();
        final String crossId = IDGenerator.newID();

        final DefaultExecutionReport buyExecutionReport = this.applyTrade(buyOrder, CrossingEngineApplicationContextProvider.getCioiDarkExecutionReportBuilder().fill(crossPrice, crossQuantity));
        final DefaultExecutionReport sellExecutionReport = this.applyTrade(sellOrder, CrossingEngineApplicationContextProvider.getCioiDarkExecutionReportBuilder().fill(crossPrice, crossQuantity));
        final long transactTime = buyExecutionReport.transactTime();

        long lULDPriceBandTimestamp = new DateTime(luldData.getArrivedTime().getTime(),
                DateTimeZone.UTC).getMillis();

        fillExecutionReport(buyOrder, buyExecutionReport, crossId, transactTime, lULDPriceBandTimestamp);
        fillExecutionReport(sellOrder, sellExecutionReport, crossId, transactTime, lULDPriceBandTimestamp);

        cioiDarkExecutions.add(buyExecutionReport);
        cioiDarkExecutions.add(sellExecutionReport);

        DefaultExecutionReport crossExecutionReport
                = getCrossExecutionReport(sellOrder, crossPrice, crossQuantity, crossId, transactTime);

        cioiDarkExecutions.add(crossExecutionReport);

        if (buyOrder.isOpen()) {
            DefaultExecutionReport buyUnSolCxlExecutionReport = unSolCxlOrder(buyOrder, CxlReason.CLIENT_CXL, null);
            buyUnSolCxlExecutionReport.crossID(crossId);
            cioiDarkExecutions.add(buyUnSolCxlExecutionReport);
        }
        if (sellOrder.isOpen()) {
            DefaultExecutionReport sellUnSolCxlExecutionReport = unSolCxlOrder(sellOrder, CxlReason.CLIENT_CXL, null);
            sellUnSolCxlExecutionReport.crossID(crossId);
            cioiDarkExecutions.add(sellUnSolCxlExecutionReport);
        }

        return Collections.singletonMap(sellOrder, cioiDarkExecutions);
    }

    private DefaultExecutionReport getCrossExecutionReport(final CioiDarkBookOrder sellOrder, final double crossPrice, final double crossQuantity,
                                                           final String crossId, final long transactTime) {
        DefaultExecutionReport crossExecutionReport = CrossingEngineApplicationContextProvider.getCioiDarkExecutionReportBuilder()
                .crossFill(crossId, crossQuantity, crossPrice);
        crossExecutionReport.avgPx(sellOrder.getAvgPx());
        crossExecutionReport.transactTime(transactTime);
        crossExecutionReport.bidPx(marketData.getBidPx());
        crossExecutionReport.offerPx(marketData.getAskPx());
        crossExecutionReport.quoteTime(marketData.getMarketDataArrivedTime());

        return crossExecutionReport;

    }

    private void fillExecutionReport(CioiDarkBookOrder cioiDarkBookOrder, DefaultExecutionReport executionReport,
                                     String crossId, final long transactTime, final long lULDPriceBandTimestamp) {

        executionReport.crossID(crossId);
        executionReport.cumQty(cioiDarkBookOrder.getCumQty());
        executionReport.leavesQty(cioiDarkBookOrder.getLeavesQty());
        executionReport.avgPx(cioiDarkBookOrder.getAvgPx());
        executionReport.ordStatus(cioiDarkBookOrder.ordStatus());
        executionReport.bidPx(marketData.getBidPx());
        executionReport.offerPx(marketData.getAskPx());
        executionReport.quoteTime(marketData.getMarketDataArrivedTime());
        executionReport.transactTime(transactTime);

        updateLuld(executionReport, lULDPriceBandTimestamp);

    }

    private void updateLuld(DefaultExecutionReport executionReport, long lULDPriceBandTimestamp) {
        if (isLowerAndUpperBandZero(luldData))
            return;

        executionReport.lULDLowerPriceBand(luldData.getLowerLimit());
        executionReport.lULDUpperPriceBand(luldData.getUpperLimit());
        executionReport.lULDPriceBandTimestamp(lULDPriceBandTimestamp);
    }

    private boolean isLowerAndUpperBandZero(LULDData luld) {
        return luld.getLowerLimit() == 0.0 && luld.getUpperLimit() == 0.0;
    }

    private DefaultExecutionReport applyTrade(final CioiDarkBookOrder cioiDarkBookOrder, final DefaultExecutionReport fill) {
        cioiDarkBookOrder.applyTrade(fill);
        this.saveOrder(cioiDarkBookOrder);
        return fill;

    }

    public void saveOrder(final CioiDarkBookOrder cioiDarkBookOrder) {
        saveOrder(cioiDarkBookOrder, cioiDarkBookOrder.side(), cioiDarkBookOrder.price());
    }

    public void saveOrder(final CioiDarkBookOrder cioiDarkBookOrder, final char side, final double price) {
        cioiDarkBookOrderRepo.save(cioiDarkBookOrder, side, price);
    }

    public void deleteOrder(final CioiDarkBookOrder cioiDarkBookOrder) {
        cioiDarkBookOrderRepo.delete(cioiDarkBookOrder);
    }

    public void evictIfPossible(final CioiDarkBookOrder cioiDarkBookOrder) {
        if (cioiDarkBookOrder.isOpen())
            return;
        this.deleteOrder(cioiDarkBookOrder);
        logger.info("Order {} evicted from cache.", cioiDarkBookOrder.orderId());
    }

    private void setCrossingMarketDataAndLULDData() {
        setCrossingMarketData();
        setCrossingLULDData();
    }

    public MarketDataMessage crossingMarketData() {
        return crossingMarketData;
    }

    public void setCrossingMarketData() {
        this.crossingMarketData = currentMarketData();
    }

    public MarketDataMessage currentMarketData() {
        return marketData;
    }

    public LULDData crossingLULDData() {
        return crossingLULDData;
    }

    private void setCrossingLULDData() {
        this.crossingLULDData = LULDData();
    }

    public LULDData LULDData() {
        return luldData;
    }

    public boolean crossingRegSHOActivated() {
        return crossingRegSHOActivated;
    }

    public void crossingRegSHOActivated(boolean crossingRegSHOActivated) {
        this.crossingRegSHOActivated = crossingRegSHOActivated;
    }

    public boolean isLockedMarket() {
        return crossingMarketData() == null ||
                crossingMarketData().getBidPx() == crossingMarketData().getAskPx();
    }

    public boolean isCrossedMarket() {
        return crossingMarketData() == null ||
                crossingMarketData().getBidPx() > crossingMarketData().getAskPx();
    }

    public boolean isHalted() {
        return bookAttributes.isHalted();
    }

    public boolean isQuoteOnly() {
        return bookAttributes.isQuoteOnly();
    }

    public boolean isMarketDataStale() {
        return bookAttributes.isMarketDataStale();
    }

    public boolean isPausedCrossing() {
        return bookAttributes.isTradePaused();
    }

    public long getNextMarketDataSeq() {
        return marketDataSeq.incrementAndGet();
    }

    public long getLastCrossAttemptMDSeqId() {
        return BooleanUtil.ifNotNullEvaluateOrElse(
                crossingMarketData,
                () -> crossingMarketData.getSequenceId(),
                () -> currentMarketData().getSequenceId()
        );
    }

    public String rootSymbol() {
        return this.rootSymbol;
    }

    public String symbol() {
        return this.symbol;
    }

    public BookAttributes bookAttributes() {
        return bookAttributes;
    }

    public List<CioiDarkBookOrder> allOpenOrders() {
        return this.cioiDarkBookOrderRepo.getAll().stream()
                .filter(CioiDarkBookOrder::isOpen)
                .collect(Collectors.toCollection(ArrayList::new));
    }

    public Collection<CioiDarkBookOrder> allOpenOrdersForSessionId(String sessionID) {
        return this.cioiDarkBookOrderRepo.getAll().stream()
                .filter(order -> order.isOpen() && sessionID.equals(order.senderSubId()))
                .collect(Collectors.toCollection(ArrayList::new));
    }

    public void updateMarketData(final MarketDataMessage marketDataMessage) {
        if (marketDataMessage.getLULDTime() != null &&
                (marketData.getLowerLimit() != marketDataMessage.getLowerLimit() ||
                        marketData.getUpperLimit() != marketDataMessage.getUpperLimit())) {
            luldData = new LULDData(marketDataMessage.getLowerLimit(), marketDataMessage.getUpperLimit(), marketDataMessage.getLULDTime());

        }
        marketData = marketDataMessage;
    }

    public Logger getLogger() {
        return logger;
    }

    public DefaultExecutionReport newOrderSingle(final DefaultNewOrderSingle newOrderSingle) {
        CioiDarkBookOrder cioiDarkBookOrder = new CioiDarkBookOrder();
        cioiDarkBookOrder.newOrderSingle(newOrderSingle);
        this.saveNewOrderSingle(cioiDarkBookOrder);
        return CrossingEngineApplicationContextProvider.getCioiDarkExecutionReportBuilder().newAck(newOrderSingle);
    }

    private void saveNewOrderSingle(final CioiDarkBookOrder cioiDarkBookOrder) {
        cioiDarkBookOrderRepo.save(cioiDarkBookOrder);
    }

    public CioiDarkBookOrder findByClOrdID(String clOrdID) {
        return cioiDarkBookOrderRepo.findByClOrdID(clOrdID);
    }

    public DefaultExecutionReport orderCancelRequest(DefaultOrderCancelRequest orderCancelRequest) {
        CioiDarkBookOrder cioiDarkBookOrder;

        synchronized (this) {
            cioiDarkBookOrder = this.findByClOrdID(orderCancelRequest.clOrdID());

            if (Objects.isNull(cioiDarkBookOrder))
                logger.warn("No order found to cancel clOrdID {}, origClOrdID: {}", orderCancelRequest.clOrdID(), orderCancelRequest.origClOrdID());


            cioiDarkBookOrder.incOrderVersion();
            this.saveOrder(cioiDarkBookOrder);
            this.evictIfPossible(cioiDarkBookOrder);
        }

        return CrossingEngineApplicationContextProvider.getCioiDarkExecutionReportBuilder().cxlAck(orderCancelRequest);
    }

    public DefaultExecutionReport orderCancelReplaceRequest(DefaultOrderCancelReplaceRequest orderCancelReplaceRequest) {
        CioiDarkBookOrder cioiDarkBookOrder;

        synchronized (this) {
            final Optional<CioiDarkBookOrder> origOrderByClOrdID = this.findOrigOrderByClOrdID(orderCancelReplaceRequest.origClOrdID(), orderCancelReplaceRequest.side());

            if (!origOrderByClOrdID.isPresent())
                logger.warn("No order found to replace clOrdID {}, origClOrdID: {}", orderCancelReplaceRequest.clOrdID(), orderCancelReplaceRequest.origClOrdID());


            cioiDarkBookOrder = origOrderByClOrdID.get();
            cioiDarkBookOrder.incOrderVersion();
            this.saveOrder(cioiDarkBookOrder, orderCancelReplaceRequest.side(), orderCancelReplaceRequest.price());

        }

        return CrossingEngineApplicationContextProvider.getCioiDarkExecutionReportBuilder().replaceAck(orderCancelReplaceRequest);
    }

    public Optional<CioiDarkBookOrder> findOrigOrderByClOrdID(String clOrdID, char side) {
        return cioiDarkBookOrderRepo.findOrigOrderByClOrdID(clOrdID, side);
    }

    public CioiDarkBookOrder findByOrdID(String orderId) {
        return cioiDarkBookOrderRepo.findByOrdID(orderId);
    }

    public DefaultExecutionReport unSolCxlOrder(CioiDarkBookOrder cioiDarkBookOrder, final String cxlReason, final String text) {
        synchronized (this) {
            cioiDarkBookOrder.cancel();
            this.saveOrder(cioiDarkBookOrder);
            this.evictIfPossible(cioiDarkBookOrder);
        }

        return CrossingEngineApplicationContextProvider.getCioiDarkExecutionReportBuilder().unSolCxlOrder(cioiDarkBookOrder, cxlReason, text);
    }

    public boolean isNotEmpty() {
        return !cioiDarkBookOrderRepo.isEmpty();
    }


    public void setPausedCrossing(final boolean pausedCrossing) {
        bookAttributes.setTradePaused(pausedCrossing);
    }
}
