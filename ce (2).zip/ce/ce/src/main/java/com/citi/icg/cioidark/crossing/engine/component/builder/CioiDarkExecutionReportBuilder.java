package com.citi.icg.cioidark.crossing.engine.component.builder;

import java.util.Optional;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBookOrder;
import com.citi.icg.cioidark.idgen.IDGenerator;
import org.joda.time.DateTime;
import software.chronicle.fix.codegen.fields.ExecType;
import software.chronicle.fix.codegen.fields.OrdStatus;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

public final class CioiDarkExecutionReportBuilder {

    public DefaultExecutionReport newAck(DefaultNewOrderSingle newOrderSingle) {
        final DefaultExecutionReport newAckExecutionReport = new DefaultExecutionReport();
        Optional.ofNullable(newOrderSingle.clOrdID()).ifPresent(newOrderSingle::clOrdID);
        newAckExecutionReport.ordStatus(OrdStatus.NEW);
        newAckExecutionReport.execType(ExecType.NEW);
        return newAckExecutionReport;
    }

    public DefaultExecutionReport fill(final double lastPx, final double lastShares) {
        final DefaultExecutionReport fillExecutionReport = new DefaultExecutionReport();
        fillExecutionReport.transactTime(DateTime.now().getMillis());
        fillExecutionReport.execID(IDGenerator.newID());
        fillExecutionReport.execType(ExecType.TRADE);
        fillExecutionReport.lastPx(lastPx);
        fillExecutionReport.lastShares(lastShares);

        return fillExecutionReport;
    }

    public DefaultExecutionReport crossFill(final String crossId, final double crossQuantity, final double crossPrice) {
        DefaultExecutionReport executionReport = fill(crossPrice, crossQuantity);
        executionReport.side(Side.CROSS);
        executionReport.crossID(crossId);
        return executionReport;
    }

    public DefaultExecutionReport cxlAck(DefaultOrderCancelRequest orderCancelRequest) {
        final DefaultExecutionReport cxlAckExecutionReport = new DefaultExecutionReport();
        Optional.ofNullable(orderCancelRequest.origClOrdID()).ifPresent(cxlAckExecutionReport::origClOrdID);
        cxlAckExecutionReport.ordStatus(OrdStatus.CANCELED);
        cxlAckExecutionReport.execType(ExecType.CANCELED);
        return  cxlAckExecutionReport;
    }

    public DefaultExecutionReport replaceAck(final DefaultOrderCancelReplaceRequest orderCancelReplaceRequest) {
        final DefaultExecutionReport replaceAckExecutionReport = new DefaultExecutionReport();
        replaceAckExecutionReport.ordStatus(OrdStatus.REPLACED);
        replaceAckExecutionReport.execType(ExecType.REPLACE);
        Optional.ofNullable(orderCancelReplaceRequest.origClOrdID()).ifPresent(replaceAckExecutionReport::origClOrdID);
        return replaceAckExecutionReport;
    }

    public DefaultExecutionReport unSolCxlOrder(final CioiDarkBookOrder cioiDarkBookOrder,
                                                final String cxlReason, final String text) {

        final DefaultExecutionReport unSolCxlExecutionReport = new DefaultExecutionReport();
        unSolCxlExecutionReport.cumQty(cioiDarkBookOrder.getCumQty());
        unSolCxlExecutionReport.leavesQty(0.0);

        Optional.ofNullable(text).ifPresent(unSolCxlExecutionReport::text);

        if (CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().isPopulateCancelReason())
            unSolCxlExecutionReport.cxlReason(cxlReason);

        return unSolCxlExecutionReport;
    }


}
