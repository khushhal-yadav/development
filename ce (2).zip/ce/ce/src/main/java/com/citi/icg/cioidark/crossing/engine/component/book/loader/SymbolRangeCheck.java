package com.citi.icg.cioidark.crossing.engine.component.book.loader;

public class SymbolRangeCheck{

    public static boolean isInRange(String symbol, String symbolRange) {
        String[] tokens = symbolRange.split("-");
        switch (tokens.length) {
            case 2:
                return isInRange(symbol, tokens[0], tokens[1]);
            case 1:
                return isInRange(symbol, tokens[0], tokens[0]);
            default:
                return false;
        }
    }

    private static boolean isInRange(String symbol, String rangeStart, String rangeEnd) {
        int endLen = symbol.length();

        if (symbol.length() > rangeEnd.length()) {
            endLen = rangeEnd.length();
        }

        boolean greaterOrEqualToStart = symbol.compareTo(rangeStart) >= 0;
        boolean lessOrEqualToEnd =  symbol.substring(0, endLen).compareTo(rangeEnd) <= 0;

        return greaterOrEqualToStart && lessOrEqualToEnd;
    }

}
