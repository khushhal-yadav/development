package com.citi.icg.cioidark.crossing.engine.component.publisher;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.CrossingEngineSystemProperty;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.DisableClient;
import com.citi.icg.cioidark.chronicle.messaging.message.alert.Alert;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.CrossingEngineOut;
import com.citi.icg.cioidark.crossing.engine.component.book.BookAttributes;
import com.citi.icg.cioidark.util.threadpool.event.DispatchableEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CfgMgrDataEvent extends DispatchableEvent {

    private static final Logger logger = LoggerFactory.getLogger(CfgMgrDataEvent.class);
    private final CrossingEngineOut crossingEngineOut;

    public CfgMgrDataEvent(Object cfgMgrData) {
        setPayload(cfgMgrData);
        this.crossingEngineOut = CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getCrossingEngineOut();
    }

    @Override
    public void run() {

        final Object payload = getPayload();
        assert payload != null;

        if (payload instanceof BookAttributes) {
            final BookAttributes bookAttributes = (BookAttributes) payload;
            logger.info("CFG OUT: publishing bookAttributes: {}", bookAttributes);
            crossingEngineOut.bookAttributes(bookAttributes);
        }
        else if (payload instanceof CrossingEngineSystemProperty) {
            final CrossingEngineSystemProperty crossingEngineSystemProperty = (CrossingEngineSystemProperty) payload;
            logger.info("CFG OUT: publishing crossingEngineSystemProperty: {}", crossingEngineSystemProperty);
            crossingEngineOut.systemProperties(crossingEngineSystemProperty);
        }
        else if (payload instanceof Alert) {
            final Alert alert = (Alert) payload;
            logger.info("CFG OUT: publishing alert: {}", alert);
            crossingEngineOut.alert(alert);
        }
        else if (payload instanceof DisableClient) {
            final DisableClient disableClient = (DisableClient) payload;
            logger.info("CFG OUT: publishing disableClient: {}", disableClient);
            crossingEngineOut.disableClient(disableClient);
        }
        else if (payload instanceof MarketDataMessage) {
            final MarketDataMessage marketData = (MarketDataMessage) payload;
            logger.info("CFG OUT: publishing marketData: {}", marketData);
            crossingEngineOut.marketDataMessage(marketData);
        }

    }
}
