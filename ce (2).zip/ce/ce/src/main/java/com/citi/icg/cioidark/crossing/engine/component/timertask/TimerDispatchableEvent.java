package com.citi.icg.cioidark.crossing.engine.component.timertask;

import java.util.Collection;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.crossing.engine.component.book.BookAttributes;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBook;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBookOrder;
import com.citi.icg.cioidark.qmf.TimerTask;
import com.citi.icg.cioidark.util.threadpool.event.DispatchableEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.fields.CxlReason;

public class TimerDispatchableEvent extends DispatchableEvent<TimerTask> {

    private static final Logger logger = LoggerFactory.getLogger(TimerDispatchableEvent.class.getName());

    public TimerDispatchableEvent(TimerTask task) {
        setPayload(task);
    }

    @Override
    public void run() {

        final TimerTask timerTask = getPayload();
        assert timerTask != null;
        BookAttributes bookAttributes;

        switch (timerTask.getTaskType()) {
            case MARKET_OPEN:
                bookAttributes = CrossingEngineApplicationContextProvider.getCioiDarkBookManager().createIfAbsent(timerTask.getTaskId()).bookAttributes();
                bookAttributes.setMarketOpen(true);
                CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishBookAttributes(bookAttributes);
                logger.info("{}|MARKET OPENED|TIMER", timerTask.getTaskId());
                break;

            case MARKET_CLOSE:
                final CioiDarkBook bookToClose = CrossingEngineApplicationContextProvider.getCioiDarkBookManager().createIfAbsent(timerTask.getTaskId());
                bookAttributes = bookToClose.bookAttributes();
                bookAttributes.setMarketOpen(false);
                doUnsolicitedCancel(bookToClose.allOpenOrders(), bookToClose, CxlReason.UNSOL_CXL_MARKET_CLOSED);
                CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishBookAttributes(bookAttributes);
                logger.info("{}|MARKET CLOSED|TIMER", timerTask.getTaskId());
                break;
            case CXL_ON_DC:
                CioiDarkBook book = CrossingEngineApplicationContextProvider.getCioiDarkBookManager().createIfAbsent(timerTask.getTaskId());
                logger.info("{}|{}|CANCEL ON DISCONNECT", timerTask.getTaskId(), timerTask.getTaskSubId());
                doUnsolicitedCancel(book.allOpenOrdersForSessionId(timerTask.getTaskSubId()), book, CxlReason.CXL_ON_DISCONNECT);
                break;
            case EXPIRE_TASK:
                break;
            default:
                break;
        }
    }

    private void doUnsolicitedCancel(final Collection<CioiDarkBookOrder> orders, final CioiDarkBook book, final String reason) {
        orders.forEach(order
                -> CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty()
                .getCrossingEngineOut().executionReport(book.unSolCxlOrder(order, reason, null)));

    }
}
