package com.citi.icg.cd.messaging;

import java.util.HashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import com.tibco.tibjms.Tibjms;
import com.tibco.tibjms.TibjmsConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EMSPublisher {
    private static final Logger logger = LoggerFactory.getLogger(EMSPublisher.class.getSimpleName());
    private Connection connection;
    private Session session;
    private MessageProducer producer;
    private final AckMode ackMode = AckMode.ClientAcknowledge;
    private long sleepTimeBetweenErrors = 6000;
    private int numberOfRetry = 5;
    private String url;
    private String userName;
    private String password;
    private final HashMap<String, Destination> destinationMap = new HashMap<>(); //thread safe
    private final AtomicBoolean isInitialized = new AtomicBoolean(false);
    private final AtomicBoolean isClosed = new AtomicBoolean(true);


    private EMSPublisher() {

    }

    private String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    private String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    private String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    private long getSleepTimeBetweenErrors() {
        return sleepTimeBetweenErrors;
    }

    public void setSleepTimeBetweenErrors(long sleepTimeBetweenErrors) {
        this.sleepTimeBetweenErrors = sleepTimeBetweenErrors;
    }

    private int getNumberOfRetry() {
        return numberOfRetry;
    }

    public void setNumberOfRetry(int numberOfRetry) {
        this.numberOfRetry = numberOfRetry;
    }

    public enum AckMode {
        AutoAcknowledge,
        ClientAcknowledge,
        ExplicitClientAcknowledge,
    }

    private void init() throws Exception {
        ConnectionFactory factory;
        factory = new TibjmsConnectionFactory(getUrl());

        if (connection != null) {
            try {
                connection.close();
                connection = null;
            } catch (Exception e) {
                logger.error("error closing connection ", e);
            }
        }
        //String login = new String(TTCryptoManagerFactory.getInstance().getDefaultCryptoManager().decryptFromBase64Encoded(getUserName()));
        //String passwd = new String(TTCryptoManagerFactory.getInstance().getDefaultCryptoManager().decryptFromBase64Encoded(getPassword()));

        //to-do 
        String login = getUserName();
        String passwd = getPassword();

        connection = factory.createConnection(login, passwd);
        connection.start();

        switch (ackMode) {
            case AutoAcknowledge:
                session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                break;

            case ClientAcknowledge:
                session = connection.createSession(false, Session.CLIENT_ACKNOWLEDGE);
                break;
            case ExplicitClientAcknowledge:
                session = connection.createSession(false, Tibjms.EXPLICIT_CLIENT_ACKNOWLEDGE);
                break;
        }

        producer = session.createProducer(null);
        producer.setDeliveryMode(DeliveryMode.PERSISTENT);
    }

    private synchronized void open() throws Exception {
        logger.info("opeing connection with url: {} , username:{} ", getUrl(), getUserName());
        int count = 0;
        while (count < getNumberOfRetry() && !isInitialized.get() && isClosed.get()) {
            try {
                init();
                isInitialized.set(true);
                isClosed.set(false);
                logger.info("sucessfully connected .");
                break;
            } catch (javax.jms.JMSSecurityException s) {
                logger.error("unable to connect ..", s);
                throw s;
            } catch (JMSException e) {
                logger.error("Failed To Open A JMS Connection will retry in [{}] sec ", getSleepTimeBetweenErrors() / 1000, e);
                count++;
                try {
                    Thread.sleep(getSleepTimeBetweenErrors());
                } catch (InterruptedException e1) {
                }
            }
        }
    }

    private synchronized void close() {
        isClosed.set(true);
        if (connection != null) {
            try {
                //logger.info("opeing connection with url: {} , username:{} pwd:{}",getUrl(),getUserName(),getPassword());
                logger.info("opeing connection with url: {} , username:{}", getUrl(), getUserName());
                connection.close();
                connection = null;
            } catch (JMSException e) {
                logger.warn("exception closing connection ", e);
            }
        }
        notifyAll();
    }

    private Destination getDestination(String destinationName) throws Exception {
        Destination destination = destinationMap.get(destinationName);
        if (destination == null) {
            destination = session.createTopic(destinationName);
            destinationMap.put(destinationName, destination);
        }
        return destination;

    }


    public boolean doService() {
        try {
            open();
        } catch (Exception e) {
            logger.error("unable to start service ", e);
            isInitialized.set(false);
        }
        return isInitialized.get();
    }


    public void publish(String msg, String topic) throws Exception {
        TextMessage textMsg = session.createTextMessage(msg);
        try {
            producer.send(getDestination(topic), textMsg);
        } catch (JMSException e) {
            if (isClosed.get()) {
                logger.error("failed to send message trying to reconnect ", e);
                close();
                destinationMap.clear(); //clean zombi sessions
                open();
            }
            logger.error("re-trying to publish ");
            try {
                producer.send(getDestination(topic), textMsg);
            } catch (Exception e1) {
                logger.error("re-try to send message {} failed...gave up ", msg, e);
            }
        }

    }
}
