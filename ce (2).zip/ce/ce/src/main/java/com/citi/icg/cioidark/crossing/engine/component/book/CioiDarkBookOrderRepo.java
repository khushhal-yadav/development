package com.citi.icg.cioidark.crossing.engine.component.book;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.StampedLock;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.citi.icg.cioidark.crossing.engine.component.util.ParticipationLimitPriceCalculator;
import com.citi.icg.cioidark.util.BooleanUtil;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.Side;

public final class CioiDarkBookOrderRepo {

    private final TreeMap<Double, ConcurrentMap<String, CioiDarkBookOrder>> buyOrders = new TreeMap<>();
    private final TreeMap<Double, ConcurrentMap<String, CioiDarkBookOrder>> sellOrders = new TreeMap<>();
    private final ConcurrentMap<String, String> clOrdIDs = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, CioiDarkBookOrder> ordIDs = new ConcurrentHashMap<>();
    private final StampedLock lock = new StampedLock();

    public int size() {
        return ordIDs.size();
    }

    public List<CioiDarkBookOrder> getAll() {
        return new ArrayList<>(ordIDs.values());
    }

    public void delete(CioiDarkBookOrder cioiDarkBookOrder) {
        long stamp = 0;
        try {
            stamp = lock.writeLock();
            deleteOrder(cioiDarkBookOrder.clOrderId(), cioiDarkBookOrder.orderId(),
                    cioiDarkBookOrder.side(), cioiDarkBookOrder.price());
        } finally {
            lock.unlockWrite(stamp);
        }
    }

    public void deleteAll() {
        long stamp = 0;
        try {
            stamp = lock.writeLock();
            buyOrders.clear();
            sellOrders.clear();
            ordIDs.clear();
            clOrdIDs.clear();
        } finally {
            lock.unlockWrite(stamp);
        }
    }

    public void save(final CioiDarkBookOrder cioiDarkBookOrder) {
        long stamp = 0;
        try {
            stamp = lock.writeLock();
            saveOrder(cioiDarkBookOrder);
        } finally {
            lock.unlockWrite(stamp);
        }
    }

    public void save(final CioiDarkBookOrder cioiDarkBookOrder, final char side, final double price) {
        long stamp = 0;
        try {
            stamp = lock.writeLock();
            //if side is different from order side or it's a LIMIT order with price being different from order price,
            // remove the already exiting OrderId
            clearAlreadyExisitngOrder(cioiDarkBookOrder, side, price);

            saveOrder(cioiDarkBookOrder);
        } finally {
            lock.unlockWrite(stamp);
        }
    }

    public CioiDarkBookOrder findByOrdID(final String ordID) {
        return ordIDs.get(ordID);
    }

    public CioiDarkBookOrder findByClOrdID(final String clOrdID) {
        return ordIDs.get(Optional.ofNullable(clOrdIDs.get(clOrdID)).orElse(""));
    }

    public Optional<CioiDarkBookOrder> findOrigOrderByClOrdID(final String clOrdID, char side) {
        return getOrderRepo(side).values().stream()
                .flatMap(orders -> orders.values().stream())
                .filter(order -> order.clOrderId().equals(clOrdID))
                .findFirst();
    }

    public List<CioiDarkBookOrder> findBuyOrders(double bidPrice) {
        long stamp = 0;

        try {
            stamp = lock.readLock();

            return buyOrders.tailMap(bidPrice, true).values().stream()
                    .flatMap(orders -> orders.values().stream())
                    .sorted(Comparator.comparing(CioiDarkBookOrder::isNotMarketOrder).
                            thenComparing(CioiDarkBookOrder::rank).
                            thenComparing((Function<CioiDarkBookOrder, Long>) CioiDarkBookOrder::seqNo))
                    .collect(Collectors.toCollection(ArrayList::new));
        } finally {
            lock.unlockRead(stamp);
        }
    }

    public List<CioiDarkBookOrder> findSellOrders(double askPrice) {
        long stamp = 0;

        try {
            stamp = lock.readLock();

            return sellOrders.headMap(askPrice, true).values().stream()
                    .flatMap(orders -> orders.values().stream())
                    .sorted(Comparator.comparing(CioiDarkBookOrder::isNotMarketOrder).
                            thenComparing(CioiDarkBookOrder::rank).
                            thenComparing((Function<CioiDarkBookOrder, Long>) CioiDarkBookOrder::seqNo))
                    .collect(Collectors.toCollection(ArrayList::new));
        } finally {
            lock.unlockRead(stamp);
        }
    }

    private void saveOrder(final CioiDarkBookOrder cioiDarkBookOrder) {
        final double participationLimitPrice = ParticipationLimitPriceCalculator.price(cioiDarkBookOrder);
        final TreeMap<Double, ConcurrentMap<String, CioiDarkBookOrder>> orderRepo = getOrderRepo(cioiDarkBookOrder.side());
        final ConcurrentMap<String, CioiDarkBookOrder> orders = orderRepo.computeIfAbsent(participationLimitPrice, key -> new ConcurrentHashMap<>());
        orders.put(cioiDarkBookOrder.orderId(), cioiDarkBookOrder);

        clOrdIDs.put(cioiDarkBookOrder.clOrderId(), cioiDarkBookOrder.orderId());
        ordIDs.put(cioiDarkBookOrder.orderId(), cioiDarkBookOrder);
    }

    private void clearAlreadyExisitngOrder(final CioiDarkBookOrder cioiDarkBookOrder, final char side, final double price) {
        BooleanUtil.ifTrueExecute(
                (side != cioiDarkBookOrder.side())
                        || (cioiDarkBookOrder.orderType() == OrdType.LIMIT && price != cioiDarkBookOrder.price()),
                () -> deleteOrder(cioiDarkBookOrder.clOrderId(), cioiDarkBookOrder.orderId(), side, price)
        );
    }

    private void deleteOrder(final String clOrderId, final String orderId, final char side, final double price) {
        final TreeMap<Double, ConcurrentMap<String, CioiDarkBookOrder>> orderRepo = getOrderRepo(side);
        final ConcurrentMap<String, CioiDarkBookOrder> orders = orderRepo.get(price);
        orders.remove(orderId);
        BooleanUtil.ifTrueExecute(
                orders.isEmpty(),
                () -> orderRepo.remove(price)
        );
        ordIDs.remove(orderId);
        clOrdIDs.remove(clOrderId);
    }

    private TreeMap<Double, ConcurrentMap<String, CioiDarkBookOrder>> getOrderRepo(final char side) {
        return BooleanUtil.ifTrueEvaluateOrElse(
                Side.BUY == side,
                () -> buyOrders,
                () -> sellOrders
        );
    }
    
	public boolean isSideEmpty() {
		return buyOrders.isEmpty() || sellOrders.isEmpty();
	}

	public boolean isEmpty() {
        return ordIDs.isEmpty();
    }


}
