package com.citi.icg.cioidark.crossing.engine.component.book.loader;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.stream.Collectors;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import org.apache.commons.lang3.StringUtils;

public class LoadGMDSymbology {

    public static Map<String, String> loadGMDSymbology() throws IOException, URISyntaxException {
        return Files.lines(Paths.get(ClassLoader
                .getSystemResource(CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().getGmdSymbologyFileName()).toURI()))
                .filter(lineOfFile -> !StringUtils.containsWhitespace(lineOfFile) && StringUtils.isNotEmpty(lineOfFile))
                .map(lineOfFile ->
                        lineOfFile.split(",")
                ).collect(Collectors.toMap(line -> line[0],
                        line -> line[1]));
    }
}
