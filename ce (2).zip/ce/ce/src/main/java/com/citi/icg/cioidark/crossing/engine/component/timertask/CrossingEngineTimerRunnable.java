package com.citi.icg.cioidark.crossing.engine.component.timertask;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBook;
import com.citi.icg.cioidark.enumeration.MarketPeriod;
import com.citi.icg.cioidark.qmf.TimerRunnable;
import com.citi.icg.cioidark.qmf.TimerTask;
import com.citi.icg.cioidark.qmf.TimerTaskType;

//DefaultTimerRunnable
public class CrossingEngineTimerRunnable extends TimerRunnable {

    @Override
    public void run() {

        logger.info("Triggering timer task {} for key {} ", getTimerTask().getTaskType(), getTimerTask().getTaskId());

        switch (getTimerTask().getTaskType()) {

            case MARKET_PRE_OPEN:
                CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().setMarketPeriod(MarketPeriod.PRE_OPEN);
                CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishSystemProperties();
                break;
            case MANNING_OPEN:
                CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().setMarketPeriod(MarketPeriod.CONTINUOUS_TRADING);
                CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishSystemProperties();
                break;
            case MANNING_CLOSE:
                CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().setMarketPeriod(MarketPeriod.POST_CLOSE);
                CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishSystemProperties();
                break;
            case GLOBAL_TASK:
                CrossingEngineApplicationContextProvider.getCioiDarkBookManager().getCioiDarkBooks().stream()
                        .filter(CioiDarkBook::isNotEmpty)
                        .forEach(cioiDarkBook -> submitBookTimerTask(cioiDarkBook, TimerTaskType.MARKET_CLOSE));
                break;
            case FORCE_MARKET_OPEN:
                CrossingEngineApplicationContextProvider.getCioiDarkBookManager().getCioiDarkBooks()
                        .forEach(cioiDarkBook -> submitBookTimerTask(cioiDarkBook, TimerTaskType.MARKET_OPEN));
                if (CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty()
                        .getMarketPeriod() != MarketPeriod.CONTINUOUS_TRADING) {
                    CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty().setMarketPeriod(MarketPeriod.CONTINUOUS_TRADING);
                    CrossingEngineApplicationContextProvider.getCfgMgrDataHandler().publishSystemProperties();
                }
                break;
            case EXPIRE_TASK:
                CrossingEngineApplicationContextProvider
                        .getTimerTaskThreadPool().submit(new TimerDispatchableEvent(getTimerTask()), getTimerTask().getTaskId());
                break;
            default:
                break;
        }
    }

    private void submitBookTimerTask(final CioiDarkBook cioiDarkBook, final TimerTaskType marketCloseTask) {
        TimerTask bookTimerTask = new TimerTask(cioiDarkBook.symbol(), marketCloseTask);
        CrossingEngineApplicationContextProvider.getTimerTaskThreadPool().submit(new TimerDispatchableEvent(bookTimerTask), bookTimerTask.getTaskId());
    }
}
