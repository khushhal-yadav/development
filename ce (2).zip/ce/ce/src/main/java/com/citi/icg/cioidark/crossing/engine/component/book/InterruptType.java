package com.citi.icg.cioidark.crossing.engine.component.book;

public enum InterruptType {
    /** Cross Attempt Succeeded **/
    SUCCESSFUL,
    /** Cross Attempt Failed Due to Other Side Filled **/
    FILL,
    /** Cross Attempt Failed Due to Other Side Rejected **/
    REJECT,
    /** Cross Attempt Failed Due to Market Data Movement **/
    MARKETDATA,
    /** Cross Attempt Failed Due to Cross Timeout**/
    TIMEOUT,
    /** Cross Attempt Failed Due to Order Expired **/
    ORDEREXPIRED,
    /** Cross Attempt Failed Due to Order Canceled **/
    ORDERCANCELED,
    /** Cross Attempt Failed Due to Market Halted **/
    HALTED,
    /** Cross Attempt Failed Due min qty not satisfied **/
    MINQTY
}
