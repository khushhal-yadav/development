package com.citi.icg.cioidark.crossing.engine.component.book;

import static org.junit.Assert.*;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.citi.icg.cioidark.crossing.CioiDarkBookOrderUtil;
import com.citi.icg.cioidark.crossing.FieldAccess;
import com.citi.icg.cioidark.crossing.engine.component.domain.LULDData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.CrossingEngineSystemProperty;

import software.chronicle.fix.codegen.fields.CrossInstruction;
import software.chronicle.fix.codegen.fields.OrdStatus;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.OrderCapacity;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultOrderCancelRequest;

import com.citi.icg.cioidark.util.DateUtil;
import com.citi.icg.fix44min.fields.ExecType;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.crossing.engine.component.builder.CioiDarkExecutionReportBuilder;



@RunWith(PowerMockRunner.class)
@PrepareForTest({CrossingEngineApplicationContextProvider.class, CioiDarkBookOrderRepo.class})
public class CioiDarkBookTest {

	private static final String SYMBOL = "SYMBOL";
	private static final String SUFFIX = "SUFFIX";
	private static final String ROOT = "ROOT";
	private static final String APP_INSTANCE = "1";
	private static final String MARKET_OPEN = "09:30:00";
	private static final String CROSS_RESTRICTION_CLIENT_ID = "CRCID";
	private static final String CXL_REASON = "CXL_REASON";
	private static final String CXL_TEXT = "CXL_TEXT";
	private static final double BID = 9.0;
	private static final double ASK = 10.0;
	private static final double MID_POINT = (BID + ASK) / 2;
	private static final double PENNY = 0.01;
	private static final double BUY_QTY = 5000.0;
	private static final double SELL_QTY = 6000.0;
	private static final double DELTA = 0.0001;

    @Mock
	private CioiDarkBookOrderRepo cioiDarkBookOrderRepo;


	private final static Logger logger = LoggerFactory.getLogger(CioiDarkBookTest.class);
	
	@Test
	public void testCioiDarkBook() {
		CioiDarkBook cioiDarkBook = createCioiDarkBook();
		assertNotNull("CioiDarkBook created", cioiDarkBook);
	}

	@Test
	public void testInit()  {
		boolean thrown =  false;
		try {
			initCioiDarkBook();
		} catch (Exception e) {
			thrown = true;
		}
		assertFalse("initialize CioiDarkBook", thrown);
	}
	
	@Test
	public void testCrossSideOrdersEmpty() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		List<DefaultExecutionReport> er;
		
		// side orders empty
        PowerMockito.when(cioiDarkBookOrderRepo.isSideEmpty()).thenReturn(true);
		er = cioiDarkBook.checkLiquidityAndCross();
		assertTrue("Side empty", er.isEmpty());
	}

	@Test
	public void testCrossIsOkToCross() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		List<DefaultExecutionReport> er;

		// orders on either side
        PowerMockito.when(cioiDarkBookOrderRepo.isSideEmpty()).thenReturn(false);
        
        // trading halted
		cioiDarkBook.bookAttributes().setHalted(true);
		er = cioiDarkBook.checkLiquidityAndCross();
		cioiDarkBook.bookAttributes().setHalted(false);
		assertTrue("Trading halted", er.isEmpty());
        
        // quote only
		cioiDarkBook.bookAttributes().setQuoteOnly(true);
		er = cioiDarkBook.checkLiquidityAndCross();
		cioiDarkBook.bookAttributes().setQuoteOnly(false);
		assertTrue("Quote only", er.isEmpty());
        
        // market stale
		cioiDarkBook.bookAttributes().setMarketDataStale(true);
		er = cioiDarkBook.checkLiquidityAndCross();
		cioiDarkBook.bookAttributes().setMarketDataStale(false);
		assertTrue("Market stale", er.isEmpty());
        
        // market locked
		cioiDarkBook.updateMarketData(new MarketDataMessage(BID, BID, SYMBOL, System.currentTimeMillis()));
		er = cioiDarkBook.checkLiquidityAndCross();
		cioiDarkBook.updateMarketData(new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis()));
		assertTrue("Market locked", er.isEmpty());
        
        // trading is paused
		cioiDarkBook.bookAttributes().setTradePaused(true);
		er = cioiDarkBook.checkLiquidityAndCross();
		cioiDarkBook.bookAttributes().setTradePaused(false);
		assertTrue("Trading is paused", er.isEmpty());

		// market crossed
		cioiDarkBook.updateMarketData(new MarketDataMessage(ASK, BID, SYMBOL, System.currentTimeMillis()));
		er = cioiDarkBook.checkLiquidityAndCross();
		cioiDarkBook.updateMarketData(new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis()));
		assertTrue("Market crossed", er.isEmpty());
		
	}

	
	@Test
	public void testCrossNoMarketableOrders() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		List<DefaultExecutionReport> er;

		// orders on either side
        PowerMockito.when(cioiDarkBookOrderRepo.isSideEmpty()).thenReturn(false);
        // normal market
		cioiDarkBook.updateMarketData(new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis()));
		
		// buy and ask orders empty
        PowerMockito.when(cioiDarkBookOrderRepo.findBuyOrders(BID)).thenReturn(Collections.emptyList());
        PowerMockito.when(cioiDarkBookOrderRepo.findSellOrders(ASK)).thenReturn(Collections.emptyList());
		er = cioiDarkBook.checkLiquidityAndCross();
		assertTrue("No buy nor sell orders for the market bid/ask", er.isEmpty());
	}

	@Test
	public void testCrossPrincipal() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		List<DefaultExecutionReport> er;
		
		// orders on either side
		PowerMockito.when(cioiDarkBookOrderRepo.isSideEmpty()).thenReturn(false);
		// normal market
		cioiDarkBook.updateMarketData(new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis()));
		
		// buy orders
		int seqNo = 0;
		List<CioiDarkBookOrder> buyOrders = CioiDarkBookOrderUtil.generateOrders(
			Side.BUY, OrdType.MARKET, BUY_QTY, Double.NaN, seqNo);
		// sell orders
		List<CioiDarkBookOrder> sellOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.SELL, OrdType.MARKET, SELL_QTY, Double.NaN, seqNo + buyOrders.size());

		// buy and ask market orders not empty
		PowerMockito.when(cioiDarkBookOrderRepo.findBuyOrders(BID)).thenReturn(buyOrders);
		PowerMockito.when(cioiDarkBookOrderRepo.findSellOrders(ASK)).thenReturn(sellOrders);
		
		// buy orders cross instruction do not cross with principal capacity
		buyOrders.forEach(o -> o.crossInstruction(CrossInstruction.NO_PRINCIPLE));
		// sell orders principal capacity
		sellOrders.forEach(o -> o.orderCapacity(OrderCapacity.PRINCIPAL));
		er = cioiDarkBook.checkLiquidityAndCross();
		buyOrders.forEach(o -> o.crossInstruction(null));
		assertTrue("Buy orders do not cross with principal capacity, sell orders principal capacity", er.isEmpty());
		
		// buy orders principal capacity
		buyOrders.forEach(o -> o.orderCapacity(OrderCapacity.PRINCIPAL));
		// sell orders cross instruction do not cross with principal capacity
		sellOrders.forEach(o -> o.crossInstruction(CrossInstruction.NO_PRINCIPLE));
		er = cioiDarkBook.checkLiquidityAndCross();
		sellOrders.forEach(o -> o.crossInstruction(null));
		assertTrue("Buy orders principal capacity, sell orders do not cross with principal capacity", er.isEmpty());
	}
	
	@Test
	public void testCrossDoNotCrossSelf() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		List<DefaultExecutionReport> er;
		
		// orders on either side
		PowerMockito.when(cioiDarkBookOrderRepo.isSideEmpty()).thenReturn(false);
		// normal market
		cioiDarkBook.updateMarketData(new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis()));
		
		// buy orders
		int seqNo = 0;
		List<CioiDarkBookOrder> buyOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.BUY, OrdType.MARKET, BUY_QTY, Double.NaN, seqNo);
		// sell orders
		List<CioiDarkBookOrder> sellOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.SELL, OrdType.MARKET, SELL_QTY, Double.NaN, seqNo + buyOrders.size());

		// buy and ask market orders not empty
		PowerMockito.when(cioiDarkBookOrderRepo.findBuyOrders(BID)).thenReturn(buyOrders);
		PowerMockito.when(cioiDarkBookOrderRepo.findSellOrders(ASK)).thenReturn(sellOrders);
		
		// buy orders do not cross self instruction, with cross restriction client id set
		buyOrders.forEach(o -> o.crossInstruction(CrossInstruction.DO_NOT_CROSS_SELF));
		buyOrders.forEach(o -> o.crossRestrictionClientId(CROSS_RESTRICTION_CLIENT_ID));
		// sell orders do not cross self instruction, with cross restriction client id set
		sellOrders.forEach(o -> o.crossInstruction(CrossInstruction.DO_NOT_CROSS_SELF));
		sellOrders.forEach(o -> o.crossRestrictionClientId(CROSS_RESTRICTION_CLIENT_ID));
		er = cioiDarkBook.checkLiquidityAndCross();
		buyOrders.forEach(o -> o.crossInstruction(null));
		buyOrders.forEach(o -> o.crossRestrictionClientId(null));
		sellOrders.forEach(o -> o.crossInstruction(null));
		sellOrders.forEach(o -> o.crossRestrictionClientId(null));
		assertTrue("Buy and sell orders do not cross with self, with cross restriction client id set", er.isEmpty());

	}
	
	@Test
	public void testCrossRegShoActivatedTightMarket() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		List<DefaultExecutionReport> er;
		
		// orders on either side
		PowerMockito.when(cioiDarkBookOrderRepo.isSideEmpty()).thenReturn(false);
		// tight market: mid-point less than one penny above the bid
		cioiDarkBook.updateMarketData(new MarketDataMessage(BID, BID + PENNY, SYMBOL, System.currentTimeMillis()));
		
		// buy orders
		int seqNo = 0;
		List<CioiDarkBookOrder> buyOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.BUY, OrdType.MARKET, BUY_QTY, Double.NaN, seqNo);
		// sell orders
		List<CioiDarkBookOrder> sellOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.SELL_SHORT, OrdType.LIMIT, SELL_QTY, BID, seqNo + buyOrders.size());

		// buy and ask market orders not empty
		PowerMockito.when(cioiDarkBookOrderRepo.findBuyOrders(BID)).thenReturn(buyOrders);
		PowerMockito.when(cioiDarkBookOrderRepo.findSellOrders(BID + PENNY)).thenReturn(sellOrders);
		
		// Reg SHO activated
		cioiDarkBook.bookAttributes().setRegSHOActivated(true);
		// short sell orders
		er = cioiDarkBook.checkLiquidityAndCross();
		cioiDarkBook.bookAttributes().setRegSHOActivated(false);
		assertTrue("Short sell orders, Reg SHO activated, tight market", er.isEmpty());
		
		// Reg SHO activated
		cioiDarkBook.bookAttributes().setRegSHOActivated(true);
		// short sell exempt orders
		sellOrders.forEach(o -> o.orderType(Side.SELL_SHORT_EXEMPT));
		er = cioiDarkBook.checkLiquidityAndCross();
		cioiDarkBook.bookAttributes().setRegSHOActivated(false);
		assertTrue("Short sell exempt orders, Reg SHO activated, tight market", er.isEmpty());

	}

	@Test
	public void testCrossTwoMarketOrders() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		List<DefaultExecutionReport> er;

		// orders on either side
		PowerMockito.when(cioiDarkBookOrderRepo.isSideEmpty()).thenReturn(false);
		// normal market
		cioiDarkBook.updateMarketData(new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis()));

		// buy orders
		int seqNo = 0;
		List<CioiDarkBookOrder> buyOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.BUY, OrdType.MARKET,  BUY_QTY, Double.NaN, seqNo);
		// sell orders
		List<CioiDarkBookOrder> sellOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.SELL, OrdType.MARKET, SELL_QTY, Double.NaN, seqNo + buyOrders.size());

		// buy and ask market orders not empty
		PowerMockito.when(cioiDarkBookOrderRepo.findBuyOrders(BID)).thenReturn(buyOrders);
		PowerMockito.when(cioiDarkBookOrderRepo.findSellOrders(ASK)).thenReturn(sellOrders);
		er = cioiDarkBook.checkLiquidityAndCross();
		logger.info("Normal crossing market orders: {}", er);
		assertEquals("Normal crossing market orders", 2, er.size());

	}

	@Test
	public void testCrossTwoLimitOrders() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		List<DefaultExecutionReport> er;

		// orders on either side
		PowerMockito.when(cioiDarkBookOrderRepo.isSideEmpty()).thenReturn(false);
		// normal market
		cioiDarkBook.updateMarketData(new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis()));

		// buy orders
		int seqNo = 0;
		List<CioiDarkBookOrder> buyOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.BUY, OrdType.LIMIT, BUY_QTY, ASK, seqNo);
		// sell orders
		List<CioiDarkBookOrder> sellOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.SELL, OrdType.LIMIT, SELL_QTY, BID, seqNo + buyOrders.size());

		// buy and ask market orders not empty
		PowerMockito.when(cioiDarkBookOrderRepo.findBuyOrders(BID)).thenReturn(buyOrders);
		PowerMockito.when(cioiDarkBookOrderRepo.findSellOrders(ASK)).thenReturn(sellOrders);
		er = cioiDarkBook.checkLiquidityAndCross();
		logger.info("Normal crossing limit orders: {}", er);
		assertEquals("Normal crossing limit orders", 2, er.size());

	}

	@Test
	public void testCrossOrderLimitPriceCheck() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		List<DefaultExecutionReport> er;

		// orders on either side
		PowerMockito.when(cioiDarkBookOrderRepo.isSideEmpty()).thenReturn(false);
		// normal market
		cioiDarkBook.updateMarketData(new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis()));

		// buy orders below midpoint 
		int seqNo = 0;
		List<CioiDarkBookOrder> buyOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.BUY, OrdType.LIMIT, BUY_QTY, MID_POINT - PENNY, seqNo);
		// sell orders
		List<CioiDarkBookOrder> sellOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.SELL, OrdType.LIMIT,  SELL_QTY, BID, seqNo + buyOrders.size());

		// buy and ask market orders not empty
		PowerMockito.when(cioiDarkBookOrderRepo.findBuyOrders(BID)).thenReturn(buyOrders);
		PowerMockito.when(cioiDarkBookOrderRepo.findSellOrders(ASK)).thenReturn(sellOrders);
		er = cioiDarkBook.checkLiquidityAndCross();
		assertTrue("Limit orders buy below midpoint", er.isEmpty());

		// buy orders
		seqNo = 0;
		buyOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.BUY, OrdType.LIMIT, BUY_QTY, ASK, seqNo);
		// sell orders above midpoint
		sellOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.SELL,  OrdType.LIMIT, SELL_QTY, MID_POINT + PENNY, seqNo + buyOrders.size());
		
		// buy and ask market orders not empty
		PowerMockito.when(cioiDarkBookOrderRepo.findBuyOrders(BID)).thenReturn(buyOrders);
		PowerMockito.when(cioiDarkBookOrderRepo.findSellOrders(ASK)).thenReturn(sellOrders);
		er = cioiDarkBook.checkLiquidityAndCross();
		assertTrue("Limit orders sell above midpoint", er.isEmpty());

		// buy orders below midpoint 
		seqNo = 0;
		buyOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.BUY, OrdType.LIMIT, BUY_QTY, MID_POINT - PENNY, seqNo);
		sellOrders = CioiDarkBookOrderUtil.generateOrders(Side.SELL, OrdType.LIMIT, 
				SELL_QTY, MID_POINT + PENNY, seqNo + buyOrders.size());
		
		// buy and ask market orders not empty
		PowerMockito.when(cioiDarkBookOrderRepo.findBuyOrders(BID)).thenReturn(buyOrders);
		PowerMockito.when(cioiDarkBookOrderRepo.findSellOrders(ASK)).thenReturn(sellOrders);
		er = cioiDarkBook.checkLiquidityAndCross();
		assertTrue("Limit orders buy below midpoint, sell above midpoint", er.isEmpty());

	}

	@Test
	public void testCrossLuldLimits() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		List<DefaultExecutionReport> er;

		// orders on either side
		PowerMockito.when(cioiDarkBookOrderRepo.isSideEmpty()).thenReturn(false);
		
		// normal market
		MarketDataMessage md = new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis());
		cioiDarkBook.updateMarketData(md);

		generateOneSetOfMarketOrders();
		
		// normal market without LULD
		er = cioiDarkBook.checkLiquidityAndCross();
		logger.info("Midpoint no LULD: {}", er);
		assertEquals("Midpoint no LULD", 2, er.size());
		
		generateOneSetOfMarketOrders();
		
		// normal market with LULD
		MarketDataMessage md1 = new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis());
		md1.setLowerLimit(BID);
		md1.setUpperLimit(ASK);
		md1.setLULDTime(new Date(System.currentTimeMillis()));
		cioiDarkBook.updateMarketData(md1);
		er = cioiDarkBook.checkLiquidityAndCross();
		logger.info("Midpoint inside LULD orders: {}", er);
		assertEquals("Midpoint inside LULD", 2, er.size());

		generateOneSetOfMarketOrders();

		// Midpoint below LULD
		MarketDataMessage md2 = new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis());
		md2.setLowerLimit(MID_POINT + PENNY);
		md2.setUpperLimit(ASK);
		md2.setLULDTime(new Date(System.currentTimeMillis()));
		cioiDarkBook.updateMarketData(md2);
		er = cioiDarkBook.checkLiquidityAndCross();
		assertTrue("Midpoint below LULD", er.isEmpty());
		
		// Midpoint above LULD
		MarketDataMessage md3 = new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis());
		md3.setLowerLimit(BID);
		md3.setUpperLimit(MID_POINT - PENNY);
		md3.setLULDTime(new Date(System.currentTimeMillis()));
		cioiDarkBook.updateMarketData(md3);
		er = cioiDarkBook.checkLiquidityAndCross();
		assertTrue("Midpoint below LULD", er.isEmpty());
		
	}

	@Test
	public void testSaveOrderCioiDarkBookOrder() {
		boolean thrown = false;
		try {
			CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
			int seqNo = 0;
			cioiDarkBook.saveOrder(CioiDarkBookOrderUtil.generateOrder(OrdType.MARKET, Side.BUY, BUY_QTY, Double.NaN, seqNo++));
			cioiDarkBook.saveOrder(CioiDarkBookOrderUtil.generateOrder(OrdType.LIMIT, Side.BUY, BUY_QTY, ASK, seqNo++));
			cioiDarkBook.saveOrder(CioiDarkBookOrderUtil.generateOrder(OrdType.MARKET, Side.SELL, SELL_QTY, Double.NaN, seqNo++));
			cioiDarkBook.saveOrder(CioiDarkBookOrderUtil.generateOrder(OrdType.LIMIT, Side.SELL, SELL_QTY, BID, seqNo++));
		} catch (Exception e) {
			thrown = true;
		}
		assertFalse("SaveOrderCioiDarkBookOrder", thrown);
	}

	@Test
	public void testSaveOrderCioiDarkBookOrderCharDouble() {
		boolean thrown = false;
		try {
			CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
			int seqNo = 0;
			cioiDarkBook.saveOrder(CioiDarkBookOrderUtil.generateOrder(OrdType.MARKET, Side.BUY, BUY_QTY, Double.NaN, seqNo++),
					Side.BUY, Double.NaN);
			cioiDarkBook.saveOrder(CioiDarkBookOrderUtil.generateOrder(OrdType.LIMIT, Side.BUY, BUY_QTY, ASK, seqNo++),
					Side.BUY, ASK);
			cioiDarkBook.saveOrder(CioiDarkBookOrderUtil.generateOrder(OrdType.MARKET, Side.SELL, SELL_QTY, Double.NaN, seqNo++),
					Side.SELL, Double.NaN);
			cioiDarkBook.saveOrder(CioiDarkBookOrderUtil.generateOrder(OrdType.LIMIT, Side.SELL, SELL_QTY, BID, seqNo++),
					Side.SELL, BID);
		} catch (Exception e) {
			thrown = true;
		}
		assertFalse("SaveOrderCioiDarkBookOrderCharDouble", thrown);
	}

	@Test
	public void testDeleteOrder() {
		boolean thrown = false;
		try {
			CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
			final CioiDarkBookOrder cioiDarkBookOrder = CioiDarkBookOrderUtil.generateOrder(OrdType.MARKET, Side.BUY, BUY_QTY, 
					Double.NaN, 0);
			cioiDarkBook.deleteOrder(cioiDarkBookOrder);
		} catch (Exception e) {
			thrown = true;
		}
		assertFalse("DeleteOrder", thrown);
	}

	@Test
	public void testEvictIfPossible() {
		boolean thrown = false;
		try {
			CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
			final CioiDarkBookOrder cioiDarkBookOrder = CioiDarkBookOrderUtil.generateOrder(OrdType.MARKET, Side.BUY, BUY_QTY, 
					Double.NaN, 0);
			cioiDarkBook.evictIfPossible(cioiDarkBookOrder);
			cioiDarkBookOrder.ordStatus(OrdStatus.REJECTED);
			cioiDarkBook.evictIfPossible(cioiDarkBookOrder);
		} catch (Exception e) {
			thrown = true;
		}
		assertFalse("EvictIfPossible", thrown);
	}

	@Test
	public void testCrossingMarketData() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        MarketDataMessage crossingMarketData = new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis());
        FieldAccess.setField(cioiDarkBook, "crossingMarketData", crossingMarketData);
        assertEquals("Get CrossingMarketData", crossingMarketData, cioiDarkBook.crossingMarketData());
	}

	@Test
	public void testSetCrossingMarketData() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        MarketDataMessage marketData = (MarketDataMessage) FieldAccess.getField(cioiDarkBook, "marketData");
        cioiDarkBook.setCrossingMarketData();
        assertEquals("Set CrossingMarketData", marketData, cioiDarkBook.crossingMarketData());
	}

	@Test
	public void testCurrentMarketData() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        MarketDataMessage marketData = new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis());
        FieldAccess.setField(cioiDarkBook, "marketData", marketData);
        assertEquals("Get MarketData", marketData, cioiDarkBook.currentMarketData());
	}

	@Test
	public void testCrossingLULDData() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        LULDData crossingLULDData = new LULDData(BID, BID, new Date(System.currentTimeMillis()));
        FieldAccess.setField(cioiDarkBook, "crossingLULDData", crossingLULDData);
        assertEquals("Get CrossingLULDData", crossingLULDData, cioiDarkBook.crossingLULDData());
	}

	@Test
	public void testLULDData() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        LULDData luldData = new LULDData(BID, BID, new Date(System.currentTimeMillis()));
        FieldAccess.setField(cioiDarkBook, "luldData", luldData);
        assertEquals("Get CrossingLULDData", luldData, cioiDarkBook.LULDData());
	}

	@Test
	public void testCrossingRegSHOActivated() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        boolean crossingRegSHOActivated = true;
        FieldAccess.setField(cioiDarkBook, "crossingRegSHOActivated", crossingRegSHOActivated);
        assertEquals("Get CrossingRegSHOActivated", crossingRegSHOActivated, cioiDarkBook.crossingRegSHOActivated());
	}

	@Test
	public void testCrossingRegSHOActivatedBoolean() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();	
	    cioiDarkBook.crossingRegSHOActivated(true);
		boolean crossingRegSHOActivated = (boolean) FieldAccess.getField(cioiDarkBook, "crossingRegSHOActivated");
	    assertEquals("Get CrossingRegSHOActivated", true, crossingRegSHOActivated);
	}

	@Test
	public void testIsLockedMarket() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        MarketDataMessage crossingMarketData = new MarketDataMessage(BID, BID, SYMBOL, System.currentTimeMillis());
        FieldAccess.setField(cioiDarkBook, "crossingMarketData", crossingMarketData);
        assertTrue("IsLockedMarket", cioiDarkBook.isLockedMarket());
        crossingMarketData = new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis());
        FieldAccess.setField(cioiDarkBook, "crossingMarketData", crossingMarketData);
        assertFalse("IsLockedMarket", cioiDarkBook.isLockedMarket());
	}

	@Test
	public void testIsCrossedMarket() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        MarketDataMessage crossingMarketData = new MarketDataMessage(ASK, BID, SYMBOL, System.currentTimeMillis());
        FieldAccess.setField(cioiDarkBook, "crossingMarketData", crossingMarketData);
        assertTrue("IsCrossedMarket", cioiDarkBook.isCrossedMarket());
        crossingMarketData = new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis());
        FieldAccess.setField(cioiDarkBook, "crossingMarketData", crossingMarketData);
        assertFalse("IsCrossedMarket", cioiDarkBook.isCrossedMarket());
	}

	@Test
	public void testIsHalted() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        BookAttributes bookAttributes = (BookAttributes) FieldAccess.getField(cioiDarkBook, "bookAttributes");
        bookAttributes.setHalted(true);
        assertTrue("IsMarketHalted", cioiDarkBook.isHalted());
        bookAttributes.setHalted(false);
        assertFalse("IsMarketHalted", cioiDarkBook.isHalted());
	}

	@Test
	public void IsQuoteOnly() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        BookAttributes bookAttributes = (BookAttributes) FieldAccess.getField(cioiDarkBook, "bookAttributes");
        bookAttributes.setQuoteOnly(true);
        assertTrue("IsQuoteOnly", cioiDarkBook.isQuoteOnly());
        bookAttributes.setQuoteOnly(false);
        assertFalse("IsQuoteOnly", cioiDarkBook.isQuoteOnly());
	}

	@Test
	public void testIsMarketDataStale() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        BookAttributes bookAttributes = (BookAttributes) FieldAccess.getField(cioiDarkBook, "bookAttributes");
        bookAttributes.setMarketDataStale(true);
        assertTrue("IsMarketDataStale", cioiDarkBook.isMarketDataStale());
        bookAttributes.setMarketDataStale(false);
        assertFalse("IsMarketDataStale", cioiDarkBook.isMarketDataStale());
	}

	@Test
	public void testIsPausedCrossing() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        BookAttributes bookAttributes = (BookAttributes) FieldAccess.getField(cioiDarkBook, "bookAttributes");
        bookAttributes.setTradePaused(true);
        assertTrue("IsPausedCrossing", cioiDarkBook.isPausedCrossing());
        bookAttributes.setTradePaused(false);
        assertFalse("IsPausedCrossing", cioiDarkBook.isPausedCrossing());
	}

	@Test
	public void testGetNextMarketDataSeq() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		long seq1 = cioiDarkBook.getNextMarketDataSeq();
		long seq2 = cioiDarkBook.getNextMarketDataSeq();
		assertEquals("GetNextMarketDataSeq", seq1 + 1, seq2);
	}

	@Test
	public void testGetLastCrossAttemptMDSeqId() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		MarketDataMessage marketData = (MarketDataMessage) FieldAccess.getField(cioiDarkBook, "marketData");
        long sequenceId = 1234;
        FieldAccess.setField(marketData, "sequenceId", sequenceId);
		assertEquals("GetLastCrossAttemptMDSeqId", sequenceId, cioiDarkBook.getLastCrossAttemptMDSeqId());
	    MarketDataMessage crossingMarketData = new MarketDataMessage(ASK, BID, SYMBOL, System.currentTimeMillis());
	    FieldAccess.setField(cioiDarkBook, "crossingMarketData", crossingMarketData);
        long crossingSequenceId = 9876;
        FieldAccess.setField(crossingMarketData, "sequenceId", crossingSequenceId);
		assertEquals("GetLastCrossAttemptMDSeqId", crossingSequenceId, cioiDarkBook.getLastCrossAttemptMDSeqId());
	}

	@Test
	public void testRootSymbol() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
        String rootSymbol = "ROOT_SYMBOL";
        FieldAccess.setField(cioiDarkBook, "rootSymbol", rootSymbol);
        assertEquals("Get RootSymbol", rootSymbol, cioiDarkBook.rootSymbol());
	}

	@Test
	public void testBookAttributes() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		BookAttributes bookAttributes = new BookAttributes();
		FieldAccess.setField(cioiDarkBook, "bookAttributes", bookAttributes);
        assertEquals("Get RootSymbol", bookAttributes, cioiDarkBook.bookAttributes());
	}

	@Test
	public void testAllOpenOrders() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		// generate ten buy orders
		List<CioiDarkBookOrder> orders = CioiDarkBookOrderUtil.generateOrders(
				Side.BUY, OrdType.LIMIT, BUY_QTY, ASK, 0, 10);
        PowerMockito.when(cioiDarkBookOrderRepo.getAll()).thenReturn(orders);
        assertEquals("Get AllOpenOrders", orders, cioiDarkBook.allOpenOrders());
	}

	@Test
	public void testUpdateMarketData() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		MarketDataMessage md = new MarketDataMessage(BID, ASK, SYMBOL, System.currentTimeMillis());
		cioiDarkBook.updateMarketData(md);
        MarketDataMessage prvMd = (MarketDataMessage) FieldAccess.getField(cioiDarkBook, "marketData");
        assertEquals("UpdateMarketData", md, prvMd);
	}

	@Test
	public void testGetLogger() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		Logger cdLogger = cioiDarkBook.getLogger();
		Logger prvLogger = (Logger) FieldAccess.getField(cioiDarkBook, "logger");
	    assertEquals("GetLogger", cdLogger, prvLogger);
	    FieldAccess.setField(cioiDarkBook, "logger", logger);
		Logger updLogger = (Logger) FieldAccess.getField(cioiDarkBook, "logger");
	    assertEquals("GetLogger", logger, updLogger);
	}

	@Test
	public void testNewOrderSingle() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		DefaultNewOrderSingle newOrderSingle = new DefaultNewOrderSingle();
		DefaultExecutionReport er = cioiDarkBook.newOrderSingle(newOrderSingle);
		assertEquals("NewOrderSingle execType", ExecType.NEW, er.execType());
		assertEquals("NewOrderSingle ordStatus", OrdStatus.NEW, er.ordStatus());
	}

	@Test
	public void testFindByClOrdID() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		final CioiDarkBookOrder cioiDarkBookOrder = CioiDarkBookOrderUtil.generateOrder(OrdType.MARKET, Side.BUY, BUY_QTY, 
				Double.NaN, 0);
        PowerMockito.when(cioiDarkBookOrderRepo.findByClOrdID(cioiDarkBookOrder.clOrderId())).thenReturn(cioiDarkBookOrder);
		final CioiDarkBookOrder retCioiDarkBookOrder = cioiDarkBook.findByClOrdID(cioiDarkBookOrder.clOrderId());
		assertEquals("FindByClOrdID",cioiDarkBookOrder, retCioiDarkBookOrder);
	}

	@Test
	public void testOrderCancelRequest() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		final CioiDarkBookOrder cioiDarkBookOrder = CioiDarkBookOrderUtil.generateOrder(OrdType.MARKET, Side.BUY, BUY_QTY, 
				Double.NaN, 0);
        PowerMockito.when(cioiDarkBookOrderRepo.findByClOrdID(cioiDarkBookOrder.clOrderId())).thenReturn(cioiDarkBookOrder);
		DefaultOrderCancelRequest orderCancelRequest = new DefaultOrderCancelRequest();
		orderCancelRequest.clOrdID(cioiDarkBookOrder.clOrderId());
		DefaultExecutionReport er = cioiDarkBook.orderCancelRequest(orderCancelRequest);
		assertEquals("OrderCancelRequest execType", ExecType.CANCELED, er.execType());
		assertEquals("OrderCancelRequest ordStatus", OrdStatus.CANCELED, er.ordStatus());
	}

	@Test
	public void testOrderCancelReplaceRequest() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		final CioiDarkBookOrder cioiDarkBookOrder = CioiDarkBookOrderUtil.generateOrder(OrdType.MARKET, Side.BUY, BUY_QTY, 
				Double.NaN, 0);
        PowerMockito.when(cioiDarkBookOrderRepo.findOrigOrderByClOrdID(cioiDarkBookOrder.clOrderId(), cioiDarkBookOrder.side()))
         	.thenReturn(Optional.of(cioiDarkBookOrder));
        DefaultOrderCancelReplaceRequest orderCancelReplaceRequest = new DefaultOrderCancelReplaceRequest();
        orderCancelReplaceRequest.origClOrdID(cioiDarkBookOrder.clOrderId());
        orderCancelReplaceRequest.side(cioiDarkBookOrder.side());
		DefaultExecutionReport er = cioiDarkBook.orderCancelReplaceRequest(orderCancelReplaceRequest);
		assertEquals("OrderCancelReplaceRequest origClOrdID", cioiDarkBookOrder.clOrderId(), er.origClOrdID());
		assertEquals("OrderCancelReplaceRequest execType", ExecType.REPLACE, er.execType());
		assertEquals("OrderCancelReplaceRequest ordStatus", OrdStatus.REPLACED, er.ordStatus());
	}

	@Test
	public void testFindOrigOrderByClOrdID() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		final CioiDarkBookOrder cioiDarkBookOrder = CioiDarkBookOrderUtil.generateOrder(OrdType.MARKET, Side.BUY, BUY_QTY, 
				Double.NaN, 0);
        PowerMockito.when(cioiDarkBookOrderRepo.findOrigOrderByClOrdID(cioiDarkBookOrder.clOrderId(), cioiDarkBookOrder.side()))
         	.thenReturn(Optional.of(cioiDarkBookOrder));
        Optional<CioiDarkBookOrder> retCioiDarkBookOrder = cioiDarkBook.findOrigOrderByClOrdID(cioiDarkBookOrder.clOrderId(), cioiDarkBookOrder.side());
		assertEquals("FindOrigOrderByClOrdID", Optional.of(cioiDarkBookOrder), retCioiDarkBookOrder);
	}

	@Test
	public void testUnSolCxlOrder() {
		CioiDarkBook cioiDarkBook = initCioiDarkBookNoExceptions();
		final CioiDarkBookOrder cioiDarkBookOrder = CioiDarkBookOrderUtil.generateOrder(OrdType.MARKET, Side.BUY, BUY_QTY, 
				Double.NaN, 0);
		DefaultExecutionReport er = cioiDarkBook.unSolCxlOrder(cioiDarkBookOrder, CXL_REASON, CXL_TEXT);
		assertEquals("UnSolCxlOrder text", CXL_TEXT, er.text());
		assertEquals("UnSolCxlOrder leavesQty", 0.0, er.leavesQty(), DELTA);
		assertEquals("UnSolCxlOrder cumQty", 0.0, er.cumQty(), DELTA);
	}

	private CioiDarkBook initCioiDarkBookNoExceptions () {
		CioiDarkBook cioiDarkBook = null;
		try {
			cioiDarkBook = initCioiDarkBook();
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return cioiDarkBook;
	}

	private CioiDarkBook initCioiDarkBook () throws Exception {
		final CrossingEngineSystemProperty crossingEngineSystemProperty = Mockito.mock(CrossingEngineSystemProperty.class);
        PowerMockito.when(crossingEngineSystemProperty.getServiceInstance()).thenReturn(APP_INSTANCE);
        PowerMockito.when(crossingEngineSystemProperty.getMarketOpenTime()).thenReturn(DateUtil.getDateFromTime(MARKET_OPEN));
		
        PowerMockito.mockStatic(CrossingEngineApplicationContextProvider.class);
        PowerMockito.doReturn(crossingEngineSystemProperty)
                    .when(CrossingEngineApplicationContextProvider.class, 
                    	  "getCrossingEngineSystemProperty");
        
		final CrossingEngineSystemProperty systemPropertyManager = Mockito.mock(CrossingEngineSystemProperty.class);
        PowerMockito.when(systemPropertyManager.getMarketDataSource()).thenReturn(com.citi.icg.cioidark.enumeration.MarketDataSource.GMD);

        final CioiDarkExecutionReportBuilder cioiDarkExecutionReportBuilder = new CioiDarkExecutionReportBuilder();
        PowerMockito.doReturn(cioiDarkExecutionReportBuilder)
                    .when(CrossingEngineApplicationContextProvider.class, 
        	              "getCioiDarkExecutionReportBuilder");

		CioiDarkBook cioiDarkBook = createCioiDarkBook();
		cioiDarkBook.init();
		return cioiDarkBook;
	}

	private CioiDarkBook createCioiDarkBook () {
		cioiDarkBookOrderRepo = Mockito.mock(CioiDarkBookOrderRepo.class);

		return new CioiDarkBook(SYMBOL, SUFFIX, ROOT, cioiDarkBookOrderRepo);
	}
		
	private void generateOneSetOfMarketOrders() {
		// buy orders  
		int seqNo = 0;
		List<CioiDarkBookOrder> buyOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.BUY, OrdType.MARKET, BUY_QTY, Double.NaN, seqNo);
		// sell orders
		List<CioiDarkBookOrder> sellOrders = CioiDarkBookOrderUtil.generateOrders(
				Side.SELL, OrdType.MARKET, BUY_QTY, Double.NaN, seqNo + buyOrders.size());
	
		// buy and ask market orders not empty
		PowerMockito.when(cioiDarkBookOrderRepo.findBuyOrders(BID)).thenReturn(buyOrders);
		PowerMockito.when(cioiDarkBookOrderRepo.findSellOrders(ASK)).thenReturn(sellOrders);
	}
	
}
