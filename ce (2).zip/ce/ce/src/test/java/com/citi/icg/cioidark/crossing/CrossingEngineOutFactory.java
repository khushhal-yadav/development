package com.citi.icg.cioidark.crossing;

import com.citi.icg.cioidark.chronicle.messaging.message.admin.AbstractBookAttributes;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.AbstractSystemProperty;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.DisableClient;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.IgnoreMDTick;
import com.citi.icg.cioidark.chronicle.messaging.message.alert.Alert;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.CrossingEngineOut;
import software.chronicle.fix.codegen.messages.ExecutionReport;

public class CrossingEngineOutFactory {

    private final static CrossingEngineOut crossingEngineOut = new CrossingEngineOut() {
        @Override
        public void executionReport(ExecutionReport executionReport) {}

        @Override
        public void bookAttributes(AbstractBookAttributes bookAttributes) {}

        @Override
        public void systemProperties(AbstractSystemProperty systemProperties) {}

        @Override
        public void alert(Alert alert) {}

        @Override
        public void disableClient(DisableClient disableClient) {}

        @Override
        public void marketDataMessage(MarketDataMessage marketDataMessage) {}

        @Override
        public void ignoreMDTick(IgnoreMDTick ignoreMDTick) {}

        @Override
        public void subscribeTick(GMDTickSubscriptionMsg gmdTickSubscriptionMsg) {}
    };

    public static CrossingEngineOut get() {
        return crossingEngineOut;
    }

}
