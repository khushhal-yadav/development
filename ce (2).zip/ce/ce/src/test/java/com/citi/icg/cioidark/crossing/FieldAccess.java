package com.citi.icg.cioidark.crossing;

import java.lang.reflect.Field;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class FieldAccess {

    private final static Logger logger = LoggerFactory.getLogger(FieldAccess.class);


    private FieldAccess () {
        throw new IllegalStateException("Utility class");
    }

    public static Object getField(Object parentObj, String fieldName) {
        Object obj = null;
        try {
            Field field = parentObj.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            obj = field.get(parentObj);
        } catch (Exception e) {
            logger.error("{}", e);
        }
        return obj;
    }


    public static void setField (Object parentObj, String fieldName, Object obj) {
        try {
            Field field = parentObj.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(parentObj, obj);
        } catch (Exception e) {
            logger.error("{}", e);
        }
    }

}
