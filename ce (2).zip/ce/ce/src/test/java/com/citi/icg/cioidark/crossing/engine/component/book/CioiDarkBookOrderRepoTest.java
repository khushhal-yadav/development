package com.citi.icg.cioidark.crossing.engine.component.book;

import static org.junit.Assert.*;

import org.junit.Test;

public class CioiDarkBookOrderRepoTest {

	@Test
	public void testSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAll() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDelete() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDeleteAll() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSaveCioiDarkBookOrder() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSaveCioiDarkBookOrderCharDouble() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFindByOrdID() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFindByClOrdID() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFindOrigOrderByClOrdID() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFindBuyOrders() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFindSellOrders() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsSideEmpty() {
		fail("Not yet implemented"); // TODO
	}

}
