package com.citi.icg.cioidark.crossing.engine.component.util;

import static org.junit.Assert.assertEquals;

import com.citi.icg.cioidark.crossing.CioiDarkBookOrderUtil;
import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBookOrder;
import org.junit.Test;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.Side;

public class ParticipationLimitPriceCalculatorTest {

    private static final double DELTA = 0.0001;
    private static final double PRICE = 123.45;

    @Test
    public void testPriceBuyMarket() {
        CioiDarkBookOrder cioiDarkBookOrder = CioiDarkBookOrderUtil.generateOrder(
                Side.BUY, OrdType.MARKET, 0, Double.NaN, 0);
        double price = ParticipationLimitPriceCalculator.price(cioiDarkBookOrder);
        assertEquals("Buy Market Order", Double.MAX_VALUE, price, DELTA);
    }

    @Test
    public void testPriceSellMarket() {
        CioiDarkBookOrder cioiDarkBookOrder = CioiDarkBookOrderUtil.generateOrder(
                Side.SELL, OrdType.MARKET, 0, Double.NaN, 0);
        double price = ParticipationLimitPriceCalculator.price(cioiDarkBookOrder);
        assertEquals("Sell Market Order", Double.MIN_VALUE, price, DELTA);
    }

    @Test
    public void testPriceBuyLimit() {
        CioiDarkBookOrder cioiDarkBookOrder = CioiDarkBookOrderUtil.generateOrder(
                Side.BUY, OrdType.LIMIT, 0, PRICE, 0);
        double price = ParticipationLimitPriceCalculator.price(cioiDarkBookOrder);
        assertEquals("Buy Limit Order", PRICE, price, DELTA);
    }

    @Test
    public void testPriceSellLimit() {
        CioiDarkBookOrder cioiDarkBookOrder = CioiDarkBookOrderUtil.generateOrder(
                Side.SELL, OrdType.LIMIT, 0, PRICE, 0);
        double price = ParticipationLimitPriceCalculator.price(cioiDarkBookOrder);
        assertEquals("Sell Limit Order", PRICE, price, DELTA);
    }

}
