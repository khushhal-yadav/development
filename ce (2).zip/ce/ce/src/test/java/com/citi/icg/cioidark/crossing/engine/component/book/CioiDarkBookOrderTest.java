package com.citi.icg.cioidark.crossing.engine.component.book;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import com.citi.icg.cioidark.crossing.FieldAccess;
import com.citi.icg.cioidark.crossing.engine.component.exception.OverFillException;
import com.citi.icg.fix44min.fields.OrdStatus;
import com.citi.icg.fix44min.fields.OrderCapacity;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.messages.datamodel.DefaultNewOrderSingle;

public class CioiDarkBookOrderTest {

    private static CioiDarkBookOrder cioiDarkBookOrder;
    private static final double PRICE = 123.45;
    private static final double DELTA = 0.0001;
    private static final double SUM_OF_STOP_EXEC_QTY = 1000.0;
    private static final double ORDER_QTY = 5500.0;
    private static final double MIN_QTY = 5000.0;
    private static final double CXL_QTY = 3000.0;
    private static final double CUM_QTY = 1500.0;
    private static final double AVG_PX = 35.678;
    private static final int RANK = 2;
    private static final long SEQ_NO = 345L;
    private static final long ORDER_VERSION = 3L;
    private static final String CL_ORDER_ID = "CL_ORDER_ID";
    private static final String ORDER_ID = "ORDER_ID";
    private static final String IOI_ID = "IOI_ID";
    private static final String CROSS_INSTRUCTION = "CROSS_INSTRUCTION";
    private static final String CROSS_INSTRUCTION_1 = "A";
    private static final String CROSS_INSTRUCTION_2 = "A NS";
    private static final String CROSS_RESTRICTION_CLIENT_ID = "CROSS_RESTRICTION_CLIENT_ID";
    private static final String SYMBOL = "SYMBOL";
    private static final String SYMBOL_SFX = "SYMBOL_SFX";
    private static final String SENDER_SUB_ID = "SENDER_SUB_ID";
    private static final String EXEC_ID = "EXEC_ID";

    private final static Logger logger = LoggerFactory.getLogger(CioiDarkBookOrderTest.class);


    @Before
    public void init() {
        cioiDarkBookOrder = new CioiDarkBookOrder();
    }

    @Test
    public void testCioiDarkBookOrder() {
        assertNotNull("Create CioiDarkBookOrder", cioiDarkBookOrder);
    }

    @Test
    public void testToString() {
        String res = cioiDarkBookOrder.toString();
        assertNotNull("CioiDarkBookOrder toString", res);
    }

    @Test
    public void testSide() {
        char side = Side.BUY;
        FieldAccess.setField(cioiDarkBookOrder, "side", side);
        assertEquals("Get side", side, cioiDarkBookOrder.side());
    }

    @Test
    public void testSideChar() {
        cioiDarkBookOrder.side(Side.SELL);
        char side = (char) FieldAccess.getField(cioiDarkBookOrder, "side");
        assertEquals("Set side", Side.SELL, side);
    }

    @Test
    public void testClOrderId() {
        String clOrderId = CL_ORDER_ID;
        FieldAccess.setField(cioiDarkBookOrder, "clOrderId", clOrderId);
        assertEquals("Get clOrderId", clOrderId, cioiDarkBookOrder.clOrderId());
    }

    @Test
    public void testClOrderIdString() {
        cioiDarkBookOrder.clOrderId(CL_ORDER_ID);
        String clOrderId = (String) FieldAccess.getField(cioiDarkBookOrder, "clOrderId");
        assertEquals("Set clOrderId", CL_ORDER_ID, clOrderId);
    }

    @Test
    public void testOrderId() {
        String orderId = ORDER_ID;
        FieldAccess.setField(cioiDarkBookOrder, "orderId", orderId);
        assertEquals("Get testOrderId", orderId, cioiDarkBookOrder.orderId());
    }

    @Test
    public void testOrderIdString() {
        cioiDarkBookOrder.orderId(ORDER_ID);
        String orderId = (String) FieldAccess.getField(cioiDarkBookOrder, "orderId");
        assertEquals("Set orderId", ORDER_ID, orderId);
    }

    @Test
    public void testIoiId() {
        String ioiId = IOI_ID;
        FieldAccess.setField(cioiDarkBookOrder, "ioiId", ioiId);
        assertEquals("Get ioiId", ioiId, cioiDarkBookOrder.ioiId());
    }

    @Test
    public void testIoiIdString() {
        cioiDarkBookOrder.ioiId(IOI_ID);
        String ioiId = (String) FieldAccess.getField(cioiDarkBookOrder, "ioiId");
        assertEquals("Set ioiId", IOI_ID, ioiId);
    }

    @Test
    public void testPrice() {
        double price = PRICE;
        FieldAccess.setField(cioiDarkBookOrder, "price", price);
        assertEquals("Get price", price, cioiDarkBookOrder.price(), DELTA);
    }

    @Test
    public void testPriceDouble() {
        cioiDarkBookOrder.price(PRICE);
        double price = (double) FieldAccess.getField(cioiDarkBookOrder, "price");
        assertEquals("Set price", PRICE, price, DELTA);
    }

    @Test
    public void testRank() {
        int rank = RANK;
        FieldAccess.setField(cioiDarkBookOrder, "rank", rank);
        assertEquals("Get price", RANK, cioiDarkBookOrder.rank());
    }

    @Test
    public void testSeqNo() {
        long seqNo = SEQ_NO;
        FieldAccess.setField(cioiDarkBookOrder, "seqNo", seqNo);
        assertEquals("Get seqNo", seqNo, cioiDarkBookOrder.seqNo());
    }

    @Test
    public void testSeqNoLong() {
        cioiDarkBookOrder.seqNo(SEQ_NO);
        long seqNo = (long) FieldAccess.getField(cioiDarkBookOrder, "seqNo");
        assertEquals("Set seqNo", SEQ_NO, seqNo);
    }

    @Test
    public void testOrderType() {
        char orderType = OrdType.LIMIT;
        FieldAccess.setField(cioiDarkBookOrder, "orderType", orderType);
        assertEquals("Get orderType", orderType, cioiDarkBookOrder.orderType());
    }

    @Test
    public void testOrderTypeChar() {
        cioiDarkBookOrder.orderType(OrdType.LIMIT);
        char orderType = (char) FieldAccess.getField(cioiDarkBookOrder, "orderType");
        assertEquals("Set orderType", OrdType.LIMIT, orderType);
    }

    @Test
    public void testIsMarketOrder() {
        char orderType;
        boolean marketOrder;

        orderType = OrdType.LIMIT;
        FieldAccess.setField(cioiDarkBookOrder, "orderType", orderType);
        marketOrder = cioiDarkBookOrder.isMarketOrder();
        assertFalse("Limit order isMarketOrder", marketOrder);

        orderType = OrdType.MARKET;
        FieldAccess.setField(cioiDarkBookOrder, "orderType", orderType);
        marketOrder = cioiDarkBookOrder.isMarketOrder();
        assertTrue("Market order isMarketOrder", marketOrder);
    }

    @Test
    public void testIsNotMarketOrder() {
        char orderType;
        boolean notMarketOrder;

        orderType = OrdType.LIMIT;
        FieldAccess.setField(cioiDarkBookOrder, "orderType", orderType);
        notMarketOrder = cioiDarkBookOrder.isNotMarketOrder();
        assertTrue("Limit order isNotMarketOrder", notMarketOrder);

        orderType = OrdType.MARKET;
        FieldAccess.setField(cioiDarkBookOrder, "orderType", orderType);
        notMarketOrder = cioiDarkBookOrder.isNotMarketOrder();
        assertFalse("Market order isNotMarketOrder", notMarketOrder);
    }

    @Test
    public void testCrossInstruction() {
        String crossInstruction = CROSS_INSTRUCTION;
        FieldAccess.setField(cioiDarkBookOrder, "crossInstruction", crossInstruction);
        assertEquals("Get crossInstruction", crossInstruction, cioiDarkBookOrder.crossInstruction());
    }

    @Test
    public void testCrossInstructionString() {
        cioiDarkBookOrder.crossInstruction(CROSS_INSTRUCTION);
        String crossInstruction = (String) FieldAccess.getField(cioiDarkBookOrder, "crossInstruction");
        assertEquals("Set crossInstruction", CROSS_INSTRUCTION, crossInstruction);
    }

    @Test
    public void testGetCrossInstruction() {
        String crossInstruction;
        Set<String> crossInstructions;

        crossInstruction = null;
        FieldAccess.setField(cioiDarkBookOrder, "crossInstruction", crossInstruction);
        crossInstructions = cioiDarkBookOrder.getCrossInstruction();
        assertTrue("crossInstruction null", crossInstructions.isEmpty());

        crossInstruction = CROSS_INSTRUCTION_1;
        FieldAccess.setField(cioiDarkBookOrder, "crossInstruction", crossInstruction);
        crossInstructions = cioiDarkBookOrder.getCrossInstruction();
        assertEquals("crossInstruction null", 1, crossInstructions.size());

        crossInstruction = CROSS_INSTRUCTION_2;
        FieldAccess.setField(cioiDarkBookOrder, "crossInstruction", crossInstruction);
        crossInstructions = cioiDarkBookOrder.getCrossInstruction();
        logger.info("crossInstructions: {}", crossInstructions);
        assertEquals("crossInstruction null", 2, crossInstructions.size());
    }

    @Test
    public void testOrderCapacity() {
        char orderCapacity = OrderCapacity.AGENCY;
        FieldAccess.setField(cioiDarkBookOrder, "orderCapacity", orderCapacity);
        assertEquals("Get orderCapacity", orderCapacity, cioiDarkBookOrder.orderCapacity());
    }

    @Test
    public void testOrderCapacityChar() {
        cioiDarkBookOrder.orderCapacity(OrderCapacity.AGENCY);
        char orderCapacity = (char) FieldAccess.getField(cioiDarkBookOrder, "orderCapacity");
        assertEquals("Set orderCapacity", OrderCapacity.AGENCY, orderCapacity);
    }

    @Test
    public void testCrossRestrictionClientId() {
        String crossRestrictionClientId = CROSS_RESTRICTION_CLIENT_ID;
        FieldAccess.setField(cioiDarkBookOrder, "crossRestrictionClientId", crossRestrictionClientId);
        assertEquals("Get rossRestrictionClientId", crossRestrictionClientId, cioiDarkBookOrder.crossRestrictionClientId());
    }

    @Test
    public void testCrossRestrictionClientIdString() {
        cioiDarkBookOrder.crossRestrictionClientId(CROSS_RESTRICTION_CLIENT_ID);
        String crossRestrictionClientId = (String) FieldAccess.getField(cioiDarkBookOrder, "crossRestrictionClientId");
        assertEquals("Set crossRestrictionClientId", CROSS_RESTRICTION_CLIENT_ID, crossRestrictionClientId);
    }

    @Test
    public void testSumOfStopExecQty() {
        double sumOfStopExecQty = SUM_OF_STOP_EXEC_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "sumOfStopExecQty", sumOfStopExecQty);
        assertEquals("Get sumOfStopExecQty", sumOfStopExecQty, cioiDarkBookOrder.sumOfStopExecQty(), DELTA);
    }

    @Test
    public void testSumOfStopExecQtyDouble() {
        cioiDarkBookOrder.sumOfStopExecQty(SUM_OF_STOP_EXEC_QTY);
        double sumOfStopExecQty = (double) FieldAccess.getField(cioiDarkBookOrder, "sumOfStopExecQty");
        assertEquals("Set sumOfStopExecQty", SUM_OF_STOP_EXEC_QTY, sumOfStopExecQty, DELTA);
    }

    @Test
    public void testOrderQty() {
        double orderQty = ORDER_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "orderQty", orderQty);
        assertEquals("Get orderQty", orderQty, cioiDarkBookOrder.orderQty(), DELTA);
    }

    @Test
    public void testOrderQtyDouble() {
        cioiDarkBookOrder.orderQty(ORDER_QTY);
        double orderQty = (double) FieldAccess.getField(cioiDarkBookOrder, "orderQty");
        assertEquals("Set orderQty", ORDER_QTY, orderQty, DELTA);
    }

    @Test
    public void testMinQty() {
        double minQty = MIN_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "minQty", minQty);
        assertEquals("Get minQty", minQty, cioiDarkBookOrder.minQty(), DELTA);
    }

    @Test
    public void testMinQtyDouble() {
        cioiDarkBookOrder.minQty(MIN_QTY);
        double minQty = (double) FieldAccess.getField(cioiDarkBookOrder, "minQty");
        assertEquals("Set minQty", MIN_QTY, minQty, DELTA);
    }

    @Test
    public void testOrdStatus() {
        char ordStatus = OrdStatus.FILLED;
        FieldAccess.setField(cioiDarkBookOrder, "ordStatus", ordStatus);
        assertEquals("Get ordStatus", ordStatus, cioiDarkBookOrder.ordStatus());
    }

    @Test
    public void testOrdStatusChar() {
        cioiDarkBookOrder.ordStatus(OrdStatus.FILLED);
        char ordStatus = (char) FieldAccess.getField(cioiDarkBookOrder, "ordStatus");
        assertEquals("Set ordStatus", OrdStatus.FILLED, ordStatus);
    }

    @Test
    public void testSymbol() {
        String symbol = SYMBOL;
        FieldAccess.setField(cioiDarkBookOrder, "symbol", symbol);
        assertEquals("Get rossRestrictionClientId", symbol, cioiDarkBookOrder.symbol());
    }

    @Test
    public void testSymbolString() {
        cioiDarkBookOrder.symbol(SYMBOL);
        String symbol = (String) FieldAccess.getField(cioiDarkBookOrder, "symbol");
        assertEquals("Set symbol", SYMBOL, symbol);
    }

    @Test
    public void testSymbolSfx() {
        String symbolSfx = SYMBOL_SFX;
        FieldAccess.setField(cioiDarkBookOrder, "symbolSfx", symbolSfx);
        assertEquals("Get symbolSfx", symbolSfx, cioiDarkBookOrder.symbolSfx());
    }

    @Test
    public void testSymbolSfxString() {
        cioiDarkBookOrder.symbolSfx(SYMBOL_SFX);
        String symbolSfx = (String) FieldAccess.getField(cioiDarkBookOrder, "symbolSfx");
        assertEquals("Set symbolSfx", SYMBOL_SFX, symbolSfx);
    }

    @Test
    public void testSenderSubId() {
        String senderSubId = SENDER_SUB_ID;
        FieldAccess.setField(cioiDarkBookOrder, "senderSubId", senderSubId);
        assertEquals("Get senderSubId", senderSubId, cioiDarkBookOrder.senderSubId());
    }

    @Test
    public void testSenderSubIdString() {
        cioiDarkBookOrder.senderSubId(SENDER_SUB_ID);
        String senderSubId = (String) FieldAccess.getField(cioiDarkBookOrder, "senderSubId");
        assertEquals("Set senderSubId", SENDER_SUB_ID, senderSubId);
    }

    @Test
    public void testCxlQtyDouble() {
        cioiDarkBookOrder.cxlQty(CXL_QTY);
        double cxlQty = (double) FieldAccess.getField(cioiDarkBookOrder, "cxlQty");
        assertEquals("Set cxlQty", CXL_QTY, cxlQty, DELTA);
    }

    @Test
    public void testCxlQty() {
        double cxlQty = CXL_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "cxlQty", cxlQty);
        assertEquals("Get cxlQty", cxlQty, cioiDarkBookOrder.cxlQty(), DELTA);
    }

    @Test
    public void testGetLeavesQty() {
        double orderQty = ORDER_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "orderQty", orderQty);
        CioiDarkTradeBook tradeBook = (CioiDarkTradeBook) FieldAccess.getField(cioiDarkBookOrder, "tradeBook");
        double cumQty = CUM_QTY;
        FieldAccess.setField(tradeBook, "cumQty", cumQty);
        assertEquals("Get leavesQty", orderQty - cumQty, cioiDarkBookOrder.getLeavesQty(), DELTA);
    }

    @Test
    public void testGetCumQty() {
        CioiDarkTradeBook tradeBook = (CioiDarkTradeBook) FieldAccess.getField(cioiDarkBookOrder, "tradeBook");
        double cumQty = CUM_QTY;
        FieldAccess.setField(tradeBook, "cumQty", cumQty);
        assertEquals("Get cumQty", cumQty, cioiDarkBookOrder.getCumQty(), DELTA);
    }

    @Test
    public void testGetAvgPx() {
        CioiDarkTradeBook tradeBook = (CioiDarkTradeBook) FieldAccess.getField(cioiDarkBookOrder, "tradeBook");
        double avgPx = AVG_PX;
        FieldAccess.setField(tradeBook, "avgPx", avgPx);
        assertEquals("Get avgPx", avgPx, cioiDarkBookOrder.getAvgPx(), DELTA);
    }

    @Test
    public void testIsOpen() {
        double orderQty = ORDER_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "orderQty", orderQty);
        CioiDarkTradeBook tradeBook = (CioiDarkTradeBook) FieldAccess.getField(cioiDarkBookOrder, "tradeBook");
        double cumQty;

        cumQty = CUM_QTY;
        FieldAccess.setField(tradeBook, "cumQty", cumQty);
        assertTrue("Get isOpenleavesQty positive", cioiDarkBookOrder.isOpen());

        cumQty = ORDER_QTY;
        FieldAccess.setField(tradeBook, "cumQty", cumQty);
        assertFalse("Get isOpenleavesQty zero", cioiDarkBookOrder.isOpen());
    }

    @Test
    public void testOrderVersion() {
        long orderVersion = ORDER_VERSION;
        FieldAccess.setField(cioiDarkBookOrder, "orderVersion", orderVersion);
        assertEquals("Get orderVersion", orderVersion, cioiDarkBookOrder.orderVersion());
    }

    @Test
    public void testOrderVersionLong() {
        cioiDarkBookOrder.orderVersion(ORDER_VERSION);
        long orderVersion = (long) FieldAccess.getField(cioiDarkBookOrder, "orderVersion");
        assertEquals("Set orderVersion", ORDER_VERSION, orderVersion);
    }

    @Test
    public void testIncOrderVersion() {
        long orderVersion = ORDER_VERSION;
        FieldAccess.setField(cioiDarkBookOrder, "orderVersion", orderVersion);
        cioiDarkBookOrder.incOrderVersion();
        orderVersion = (long) FieldAccess.getField(cioiDarkBookOrder, "orderVersion");
        assertEquals("Set orderVersion", ORDER_VERSION + 1, orderVersion);
    }

    @Test
    public void testGetCrossableQuantity() {
        double crossableQuantity;

        crossableQuantity = cioiDarkBookOrder.getCrossableQuantity();
        assertEquals("Get crossableQuantity nothing set", 0.0, crossableQuantity, DELTA);

        double orderQty = ORDER_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "orderQty", orderQty);
        crossableQuantity = cioiDarkBookOrder.getCrossableQuantity();
        logger.info("crossableQuantity: {}", crossableQuantity);
        assertEquals("Get crossableQuantity orderQty set", ORDER_QTY, crossableQuantity, DELTA);

        double sumOfStopExecQty = SUM_OF_STOP_EXEC_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "sumOfStopExecQty", sumOfStopExecQty);
        crossableQuantity = cioiDarkBookOrder.getCrossableQuantity();
        sumOfStopExecQty = 0;
        FieldAccess.setField(cioiDarkBookOrder, "sumOfStopExecQty", sumOfStopExecQty);
        logger.info("crossableQuantity: {}", crossableQuantity);
        assertEquals("Get crossableQuantity orderQty and sumOfStopExecQty set", ORDER_QTY - SUM_OF_STOP_EXEC_QTY, crossableQuantity, DELTA);

        double minQty = MIN_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "minQty", minQty);
        crossableQuantity = cioiDarkBookOrder.getCrossableQuantity();
        logger.info("crossableQuantity: {}", crossableQuantity);
        assertEquals("Get crossableQuantity orderQty and minQty set", MIN_QTY, crossableQuantity, DELTA);

        sumOfStopExecQty = SUM_OF_STOP_EXEC_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "sumOfStopExecQty", sumOfStopExecQty);
        crossableQuantity = cioiDarkBookOrder.getCrossableQuantity();
        logger.info("crossableQuantity: {}", crossableQuantity);
        assertEquals("Get crossableQuantity minQty and sumOfStopExecQtyset", MIN_QTY - SUM_OF_STOP_EXEC_QTY, crossableQuantity, DELTA);
    }

    @Test
    public void testIsShortSaleSide() {
        char side;

        side = Side.SELL;
        FieldAccess.setField(cioiDarkBookOrder, "side", side);
        assertFalse("IsShortSaleSide SELL", cioiDarkBookOrder.isShortSaleSide());

        side = Side.SELL_SHORT;
        FieldAccess.setField(cioiDarkBookOrder, "side", side);
        assertTrue("IsShortSaleSide SELL_SHORT", cioiDarkBookOrder.isShortSaleSide());

        side = Side.SELL_SHORT_EXEMPT;
        FieldAccess.setField(cioiDarkBookOrder, "side", side);
        assertTrue("IsShortSaleSide SELL_SHORT_EXEMPT", cioiDarkBookOrder.isShortSaleSide());
    }

    @Test
    public void testApplyTrade() {
        DefaultExecutionReport er;
        DefaultExecutionReport fill = new DefaultExecutionReport();
        fill.execID(EXEC_ID);

        double orderQty = ORDER_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "orderQty", orderQty);

        fill.lastShares(ORDER_QTY + 1);
        logger.info("fill: {}", fill);
        boolean overfillException = false;
        try {
            er = cioiDarkBookOrder.applyTrade(fill);
        } catch (OverFillException e) {
            overfillException = true;
        }
        assertTrue("OverFillException", overfillException);

        fill.lastShares(ORDER_QTY);
        logger.info("fill: {}", fill);
        er = cioiDarkBookOrder.applyTrade(fill);
        logger.info("er: {}", er);
        assertEquals("execID", fill.execID(), er.execID());
        assertEquals("lastShares", fill.lastShares(), er.lastShares(), DELTA);
        assertEquals("orderVersion", 1, er.orderVersion());


    }

    @Test
    public void testNewOrderSingle() {
        DefaultNewOrderSingle newOrderSingle = new DefaultNewOrderSingle();
        newOrderSingle.orderQty(ORDER_QTY);
        newOrderSingle.ordType(OrdType.LIMIT);
        newOrderSingle.orderID(ORDER_ID);
        newOrderSingle.clOrdID(CL_ORDER_ID);
        newOrderSingle.side(Side.BUY);
        newOrderSingle.minQty(MIN_QTY);
        logger.info("newOrderSingle: {}", newOrderSingle);
        CioiDarkBookOrder orderSingle = cioiDarkBookOrder.newOrderSingle(newOrderSingle);
        assertEquals("orderVersion", 0, orderSingle.orderVersion());
        assertEquals("orderQty", newOrderSingle.orderQty(), orderSingle.orderQty(), DELTA);
        assertEquals("orderType", newOrderSingle.ordType(), orderSingle.orderType());
        assertEquals("clOrderId", newOrderSingle.clOrdID(), orderSingle.clOrderId());
        assertEquals("side", newOrderSingle.side(), orderSingle.side());
        assertEquals("minQty", newOrderSingle.minQty(), orderSingle.minQty(), DELTA);
        logger.info("orderSingle: {}", orderSingle);
    }

    @Test
    public void testCancel() {
        double orderQty = ORDER_QTY;
        FieldAccess.setField(cioiDarkBookOrder, "orderQty", orderQty);
        CioiDarkTradeBook tradeBook = (CioiDarkTradeBook) FieldAccess.getField(cioiDarkBookOrder, "tradeBook");
        double cumQty = CUM_QTY;
        FieldAccess.setField(tradeBook, "cumQty", cumQty);

        cioiDarkBookOrder.cancel();

        char ordStatus = (char) FieldAccess.getField(cioiDarkBookOrder, "ordStatus");
        assertEquals("Cancel Verify ordStatus", OrdStatus.CANCELED, ordStatus);

        long orderVersion = (long) FieldAccess.getField(cioiDarkBookOrder, "orderVersion");
        assertEquals("Cancel Verify orderVersion", 1, orderVersion);

        double cxlQty = (double) FieldAccess.getField(cioiDarkBookOrder, "cxlQty");
        assertEquals("Cancel Verify cxlQty", ORDER_QTY - CUM_QTY, cxlQty, DELTA);
    }

}
