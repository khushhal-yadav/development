package com.citi.icg.cioidark.crossing.engine.component.book.loader;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Map;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.crossing.CrossingEngineOutFactory;
import org.apache.commons.configuration.ConfigurationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class LoadGMDSymbologyTest {

    @Before
    public void init() throws ConfigurationException {
        CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty(CrossingEngineOutFactory.get());
    }

    @Test
    public void loadGMDSymbology() throws IOException, URISyntaxException {
        Assert.assertNotNull(CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty());
        final Map<String, String> gmdSymbology = LoadGMDSymbology.loadGMDSymbology();

        Assert.assertEquals(172, gmdSymbology.size());
    }

}