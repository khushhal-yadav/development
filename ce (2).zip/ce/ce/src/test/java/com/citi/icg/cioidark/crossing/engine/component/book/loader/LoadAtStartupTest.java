package com.citi.icg.cioidark.crossing.engine.component.book.loader;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Map;

import com.citi.icg.cioidark.CrossingEngineApplicationContextProvider;
import com.citi.icg.cioidark.crossing.CrossingEngineOutFactory;
import org.apache.commons.configuration.ConfigurationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class LoadAtStartupTest {

    private LoadAtStartup loadAtStartup;

    @Before
    public void init() throws ConfigurationException {
        CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty(CrossingEngineOutFactory.get());
        loadAtStartup = new LoadAtStartup();
    }

    @Test
    public void loadBook() {

        Assert.assertNotNull(CrossingEngineApplicationContextProvider.getCrossingEngineSystemProperty());
        loadAtStartup.run();

        //Assert.assertEquals(8168, CrossingEngineApplicationContextProvider.getCioiDarkBookManager().getCioiDarkBooks().size());
    }

}