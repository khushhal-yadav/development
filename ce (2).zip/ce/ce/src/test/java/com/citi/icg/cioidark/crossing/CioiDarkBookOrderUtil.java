package com.citi.icg.cioidark.crossing;

import java.util.LinkedList;
import java.util.List;

import com.citi.icg.cioidark.crossing.engine.component.book.CioiDarkBookOrder;

public class CioiDarkBookOrderUtil {

    private static final String SYMBOL = "SYMBOL";

    private CioiDarkBookOrderUtil () {
        throw new IllegalStateException("Utility class");
    }

    public static List<CioiDarkBookOrder> generateOrders(char side, char ordType,
                                                         double qty, double price, int seqNoStart) {
        return generateOrders(side, ordType, qty, price,  seqNoStart, 1);
    }

    public static List<CioiDarkBookOrder> generateOrders(char side, char ordType,
                                                         double qty, double price, int seqNoStart, int ordNo) {
        return generateOrders(side, SYMBOL, ordType, qty, price,  seqNoStart, ordNo);
    }

    public static List<CioiDarkBookOrder> generateOrders(char side, String symbol, char ordType,
                                                         double qty, double price,  int seqNoStart, int ordNo) {
        List<CioiDarkBookOrder> orders = new LinkedList<>();
        for (int i = 0; i < ordNo; i ++) {
            CioiDarkBookOrder cioiDarkBookOrder = generateOrder(side, symbol, ordType,
                    qty, price, i + seqNoStart);
            orders.add(cioiDarkBookOrder);
        }
        return orders;
    }

    public static  CioiDarkBookOrder generateOrder(char side, char ordType,
                                                   double qty, double price, int seqNo) {
        return generateOrder(side, SYMBOL, ordType, qty, price, seqNo);
    }

    public static  CioiDarkBookOrder generateOrder(char side, String symbol, char ordType,
                                                   double qty, double price, int seqNo) {
        CioiDarkBookOrder cioiDarkBookOrder = new CioiDarkBookOrder();
        cioiDarkBookOrder.side(side);
        cioiDarkBookOrder.symbol(symbol);
        cioiDarkBookOrder.orderType(ordType);
        cioiDarkBookOrder.orderQty(qty);
        cioiDarkBookOrder.price(price);
        cioiDarkBookOrder.seqNo(seqNo);
        cioiDarkBookOrder.clOrderId(cioiDarkBookOrder.orderId());
        return cioiDarkBookOrder;
    }

}
