package com.citi.icg.cioidark.fixengine.client;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAccumulator;
import java.util.concurrent.atomic.LongAdder;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.StampedLock;
import java.util.function.LongBinaryOperator;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderIn;
import com.citi.icg.cioidark.fixengine.FixEngineDirector;
import com.citi.icg.cioidark.fixengine.FixEngineInitializer;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.OrderCancelReject;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.FixSessionHandler;

@RunWith(PowerMockRunner.class)
@PrepareForTest({FixEngineDirector.class, FixEngineInitializer.class})
public class ClientImplTest {

    private final static Logger logger = LoggerFactory.getLogger(ClientImplTest.class);

    @Mock
    private ClientOrderIn clientOrderIn;
    @Mock
    private FixEngineDirector fixEngineDirector;
    @Mock
    private ChronicleFixEngine chronicleFixEngine;
    @Mock
    private FixSessionHandler<ClientMessageNotifier> fixSessionHandler;

    private ClientImpl client;

    @Before
    public void init() throws Exception {
        PowerMockito.mockStatic(FixEngineDirector.class);
        PowerMockito.mockStatic(FixEngineInitializer.class);
        PowerMockito.when(FixEngineDirector.getInstance()).thenReturn(fixEngineDirector);
        PowerMockito.doNothing().when(fixEngineDirector, "initialize", clientOrderIn);
        PowerMockito.doReturn(chronicleFixEngine).when(FixEngineInitializer.class, "getChronicleFixEngine");

        PowerMockito.doNothing().when(fixSessionHandler, "sendMessage", ArgumentMatchers.any());
        PowerMockito.when(chronicleFixEngine.sessions()).thenReturn(Arrays.asList(fixSessionHandler));

        client = new ClientImpl(clientOrderIn);
    }


    @Test
    public void clientExecutionReport() {
        final ExecutionReport executionReport = Mockito.mock(ExecutionReport.class);
        client.clientExecutionReport(executionReport);

        Mockito.verify(chronicleFixEngine, Mockito.times(1)).sessions();
        Mockito.verify(fixSessionHandler, Mockito.times(1)).sendMessage(executionReport);
        Mockito.verify(executionReport, Mockito.times(1)).reset();
    }

    @Test
    public void clientOrderCancelReject() {
        final OrderCancelReject orderCancelReject = Mockito.mock(OrderCancelReject.class);
        client.clientOrderCancelReject(orderCancelReject);

        Mockito.verify(chronicleFixEngine, Mockito.times(1)).sessions();
        Mockito.verify(fixSessionHandler, Mockito.times(1)).sendMessage(orderCancelReject);
        Mockito.verify(orderCancelReject, Mockito.times(1)).reset();

    }

    private ReentrantLock lock = new ReentrantLock();
    int count = 0;

    void increment() {
        lock.lock();
        try {
            count = count + 1;
            sleep(2);
        } finally {
            lock.unlock();
        }
    }

    Map<String, String> map = new HashMap<>();
    ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
    StampedLock stampedLock = new StampedLock();
    Semaphore semaphore = new Semaphore(5);

    @Test
    //-Djava.util.concurrent.ForkJoinPool.common.parallelism=5
    public void testSynchronization() {
        ExecutorService executor = Executors.newFixedThreadPool(10);

        Runnable longRunningTask = () -> {
            boolean permit = false;
            try {
                permit = semaphore.tryAcquire(1, TimeUnit.SECONDS);
                if (permit) {
                    logger.info("Semaphor Acquired");
                    sleep(3);
                } else {
                    logger.info("Could not acquire semaphore");
                }

            } catch (InterruptedException e) {
                throw new IllegalStateException();
            } finally {
                if (permit) {
                    semaphore.release();
                }
            }
        };

        IntStream.range(0, 10).forEach(i -> executor.submit(longRunningTask));

        AtomicInteger atomicInteger = new AtomicInteger(0);

        IntStream.range(0, 1000)
                .forEach(i -> executor.submit(() -> atomicInteger.updateAndGet(n -> n + 3)));

        AtomicInteger accAtomicInteger = new AtomicInteger(0);

        IntStream.range(0, 1000)
                .forEach(i -> executor.submit(() -> accAtomicInteger.accumulateAndGet(i, (n, m) -> n + m)));

        LongAdder longAdder = new LongAdder();
        IntStream.range(0, 1000)
                .forEach(i -> executor.submit(longAdder::decrement));

        LongBinaryOperator op = (x, y) -> 2 * x + y;
        LongAccumulator longAccumulator = new LongAccumulator(op, 1L);

        IntStream.range(0, 10)
                .forEach(i -> executor.submit(() -> longAccumulator.accumulate(i)));

        stop(executor);
        logger.info("atomicInteger {}", atomicInteger.get());
        logger.info("accAtomicInteger {}", accAtomicInteger.get());
        logger.info("longAdder {}", longAdder.sumThenReset());


        ConcurrentHashMap<String, String> map = new ConcurrentHashMap<>();
        map.put("foo", "bar");
        map.put("han", "solo");
        map.put("r2", "d2");
        map.put("c3", "p0");

        map.putIfAbsent("c3", "p2");

        System.out.println(map.get("c3"));
        System.out.println(map.getOrDefault("hi", "there"));

        map.replaceAll((key, value) -> "r2".equals(key) ? "d3" : value);
        System.out.println(map.get("r2"));

        map.compute("foo", (key, value) -> value + value);
        System.out.println(map.get("foo"));

        map.merge("foo", "boo", (oldVal, newVal) -> newVal + " was " + oldVal);
        System.out.println(map.get("foo"));

        map.forEach(1, (key, value) ->
                System.out.printf("key: %s; value: %s; thread: %s\n",
                        key, value, Thread.currentThread().getName())
        );

        String result = map.search(1, (key, value) -> {
            System.out.println(Thread.currentThread().getName());
            if ("foo".equals(key))
                return value;

            return null;
            }
        );

        System.out.println("Result : " + result);

        final String searchValue = map.searchValues(1, value -> {
            System.out.println(Thread.currentThread().getName());
            if (value.length() == 2)
                return value;
            return null;
        });

        System.out.println("searchValue : " + searchValue);

        int[][] intArray = new int[][]{{1,2,3},{1, 2, 3}};

        Stream.of(intArray).flatMapToInt(IntStream::of).forEach(System.out::println);




    }

    public static void stop(ExecutorService executor) {
        try {
            executor.shutdown();
            executor.awaitTermination(60, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            logger.error("termination interrupted");
        } finally {
            if (!executor.isTerminated()) {
                logger.error("killing non-finished tasks");
            }
            executor.shutdownNow();
        }
    }

    public static void sleep(int seconds) {
        try {
            TimeUnit.SECONDS.sleep(seconds);
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
    }

}