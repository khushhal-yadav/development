package com.citi.icg.cioidark.fixengine;

import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderIn;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import software.chronicle.fix.staticcode.ChronicleFixEngine;

@RunWith(PowerMockRunner.class)
@PrepareForTest({FixEngineApplicationContextProvider.class, FixEngineInitializer.class})
public class FixEngineDirectorTest {

    @Test
    public void getInstance() {
        Assert.assertEquals(FixEngineDirector.getInstance(), FixEngineDirector.getInstance());
    }

    @Test
    public void initialize() throws Exception {
        final ClientOrderIn clientOrderIn = Mockito.mock(ClientOrderIn.class);
        PowerMockito.mockStatic(FixEngineApplicationContextProvider.class);
        PowerMockito.mockStatic(FixEngineInitializer.class);
        PowerMockito.doReturn(Mockito.mock(FixEngineSystemProperty.class)).when(FixEngineApplicationContextProvider.class, "getFixEngineSystemProperty");
        PowerMockito.doReturn(Mockito.mock(ChronicleFixEngine.class)).when(FixEngineInitializer.class, "initialize", clientOrderIn);

        FixEngineDirector.getInstance().initialize(clientOrderIn);

    }
}