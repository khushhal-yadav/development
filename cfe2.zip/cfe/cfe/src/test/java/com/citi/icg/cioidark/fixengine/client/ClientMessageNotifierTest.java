package com.citi.icg.cioidark.fixengine.client;

import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderIn;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.staticcode.FixSessionHandler;

@RunWith(PowerMockRunner.class)
public class ClientMessageNotifierTest {

    @Mock
    private FixSessionHandler<ClientMessageNotifier> fixSessionHandler;
    @Mock
    private ClientOrderIn clientOrderIn;

    private ClientMessageNotifier clientMessageNotifier;

    @Before
    public void init() {
        clientMessageNotifier = new ClientMessageNotifier();
        clientMessageNotifier.clientOut(clientOrderIn);
    }

    @Test
    public void onNewOrderSingle() {
        final NewOrderSingle newOrderSingle = Mockito.mock(NewOrderSingle.class);
        clientMessageNotifier.onNewOrderSingle(fixSessionHandler, newOrderSingle);

        Mockito.verify(clientOrderIn, Mockito.times(1)).clientNewOrderSingle(newOrderSingle);
    }

    @Test
    public void onOrderCancelReplaceRequest() {
        final OrderCancelReplaceRequest orderCancelReplaceRequest = Mockito.mock(OrderCancelReplaceRequest.class);
        clientMessageNotifier.onOrderCancelReplaceRequest(fixSessionHandler, orderCancelReplaceRequest);

        Mockito.verify(clientOrderIn, Mockito.times(1)).clientOrderCancelReplaceRequest(orderCancelReplaceRequest);
    }

    @Test
    public void onOrderCancelRequest() {
        final OrderCancelRequest orderCancelRequest = Mockito.mock(OrderCancelRequest.class);
        clientMessageNotifier.onOrderCancelRequest(fixSessionHandler, orderCancelRequest);

        Mockito.verify(clientOrderIn, Mockito.times(1)).clientOrderCancelRequest(orderCancelRequest);
    }
}