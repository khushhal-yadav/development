package com.citi.icg.cioidark.fixengine;

import java.io.IOException;
import java.net.BindException;
import java.util.Optional;

import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderIn;
import org.apache.commons.configuration.ConfigurationException;
import org.junit.Assert;
import org.junit.Test;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.staticcode.ChronicleFixEngine;

public class FixEngineInitializerTest {

    @Test
    public void initialize() throws IOException, ConfigurationException {

        final ClientOrderIn clientOrderIn = new ClientOrderIn() {
            @Override
            public void clientNewOrderSingle(NewOrderSingle newOrderSingle) {
            }

            @Override
            public void clientOrderCancelRequest(OrderCancelRequest orderCancelRequest) {
            }

            @Override
            public void clientOrderCancelReplaceRequest(OrderCancelReplaceRequest orderCancelReplaceRequest) {
            }

            @Override
            public void executionReport(ExecutionReport executionReport) {

            }
        };

        try {
            FixEngineInitializer.initialize(clientOrderIn);
        } catch (BindException e) {
            Optional.ofNullable(FixEngineInitializer.getChronicleFixEngine()).ifPresent(ChronicleFixEngine::close);
        }

        //To test already initialized engine, so shouldn't initialize again
        FixEngineInitializer.initialize(clientOrderIn);

        Assert.assertNotNull(FixEngineInitializer.getChronicleFixEngine());
        Assert.assertFalse(FixEngineInitializer.getChronicleFixEngine().isClosed());

        FixEngineInitializer.getChronicleFixEngine().close();
        Assert.assertTrue(FixEngineInitializer.getChronicleFixEngine().isClosed());
    }
}