package com.citi.icg.cioidark.fixengine;

import org.apache.commons.configuration.ConfigurationException;
import org.junit.Assert;
import org.junit.Test;

public class FixEngineSystemPropertyTest {

    private FixEngineSystemProperty fixEngineSystemProperty;

    public FixEngineSystemPropertyTest() throws ConfigurationException {
        fixEngineSystemProperty = FixEngineApplicationContextProvider.getFixEngineSystemProperty();
    }

    @Test
    public void testFixEngineSystemProperties() {
        Assert.assertEquals("client-connector.yaml", fixEngineSystemProperty.getClientConnectorFile());
        Assert.assertEquals(Integer.parseInt(System.getProperty("app.instance")), fixEngineSystemProperty.getAppInstance());
    }

}