package com.citi.icg.cioidark.fixengine;

import org.apache.commons.configuration.ConfigurationException;
import org.junit.Assert;
import org.junit.Test;

public class FixEngineApplicationContextProviderWithoutMockTest{

        @Test
        public void getFixEngineSystemProperty() throws ConfigurationException {
            Assert.assertNotNull(FixEngineApplicationContextProvider.getFixEngineSystemProperty());
        }

}