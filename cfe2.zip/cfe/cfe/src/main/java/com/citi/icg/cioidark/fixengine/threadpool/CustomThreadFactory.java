package com.citi.icg.cioidark.fixengine.threadpool;

import java.util.concurrent.ThreadFactory;

import org.jetbrains.annotations.NotNull;

public class CustomThreadFactory implements ThreadFactory {

    private final ThreadGroup threadGroup;
    private final int threadPriority;
    private int threadSuffix;

    public CustomThreadFactory(final String name, int threadPriority) {
        this.threadGroup = new ThreadGroup(name);
        if (threadPriority > Thread.MAX_PRIORITY ||
                threadPriority < Thread.MIN_PRIORITY)
            this.threadPriority = Thread.currentThread().getPriority();
        else
            this.threadPriority = threadPriority;
    }


    @Override
    public Thread newThread(@NotNull Runnable runnable) {
        Thread thread =
                new Thread(threadGroup, runnable, threadGroup.getName() + "-" + threadSuffix);
        thread.setPriority(threadPriority);
        return thread;
    }
}
