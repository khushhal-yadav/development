package com.citi.icg.cioidark.fixengine.client;

import java.io.IOException;

import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderIn;
import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderOut;
import com.citi.icg.cioidark.chronicle.service.AbstractChronicleService;
import com.citi.icg.cioidark.fixengine.FixEngineDirector;
import com.citi.icg.cioidark.fixengine.FixEngineInitializer;
import org.apache.commons.configuration.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.OrderCancelReject;
import software.chronicle.fix.staticcode.ChronicleFixEngine;

@SuppressWarnings({"WeakerAccess", "unused"})
//Suppressed warnings as this class is being used as chronicle service impl class
public class ClientImpl extends AbstractChronicleService implements ClientOrderOut {

    private static final Logger logger = LoggerFactory.getLogger(ClientImpl.class);

    private FixEngineCfg cfg;
    private ChronicleFixEngine fixEngine;

    public ClientImpl(ClientOrderIn clientOrderIn) throws IOException, ConfigurationException {
        FixEngineDirector.getInstance().initialize(clientOrderIn);
        fixEngine = FixEngineInitializer.getChronicleFixEngine();
    }

    @Override
    public void clientExecutionReport(ExecutionReport executionReport) {
        logger.debug(executionReport.toString());
        fixEngine.sessions().forEach(s -> s.sendMessage(executionReport));
        executionReport.reset();
    }

    @Override
    public void clientOrderCancelReject(OrderCancelReject orderCancelReject) {
        logger.debug(orderCancelReject.toString());
        fixEngine.sessions().forEach(s -> s.sendMessage(orderCancelReject));
        orderCancelReject.reset();
    }
}
