package com.citi.icg.cioidark.fixengine.threadpool;

import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.google.common.collect.Interner;
import com.google.common.collect.Interners;

public class CustomThreadPool<T> {

    private final ThreadPoolExecutor tpe;
    private final int concurrencyQueueCapacity;
    public final Interner<String> interner;

    public final Map<String, String> submittedTaskMap = new ConcurrentHashMap<>();
    public final Map<String, BlockingQueue<Event<T>>> concurrencyMap = new ConcurrentHashMap<>();

    public CustomThreadPool(final String name, final int coreSize, final int maxSize, final int frameworkTaskQueueCapacity,
                            final int concurrencyQueueCapacity, final int priority) {
        ThreadFactory threadFactory = new CustomThreadFactory(name, priority);
        tpe = new ThreadPoolExecutor(coreSize, maxSize, 0, TimeUnit.SECONDS, new ArrayBlockingQueue<>(frameworkTaskQueueCapacity), threadFactory);
        tpe.setCorePoolSize(coreSize);
        tpe.setMaximumPoolSize(maxSize);
        tpe.prestartAllCoreThreads();
        if (concurrencyQueueCapacity <= 0)
            this.concurrencyQueueCapacity = Integer.MAX_VALUE;
        else
            this.concurrencyQueueCapacity = concurrencyQueueCapacity;

        this.interner = Interners.newStrongInterner();
    }

    public void submit(final Event<T> event, final String synchronizer) {
        event.setSynchKey(synchronizer);
        if (checkForExecution(event, synchronizer)) {
            CustomThreadPoolRunnable<T> customThreadPoolRunnable =
                    new CustomThreadPoolRunnable<>(this, synchronizer);
            tpe.submit(customThreadPoolRunnable);
        }
    }


    public boolean checkForExecution(final Event<T> event, final String synchronizer) {

        synchronized (interner.intern(synchronizer)) {
            try {
                putEventInQueue(event, synchronizer);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            boolean isSubmitted = submittedTaskMap.containsKey(synchronizer);
            if (!isSubmitted)
                submittedTaskMap.put(synchronizer, synchronizer);

            return !isSubmitted;

        }
    }

    private void putEventInQueue(final Event<T> event, final String synchronizer) throws InterruptedException {
        if (!concurrencyMap.containsKey(synchronizer)) {
            BlockingQueue<Event<T>> blockingQueue = new LinkedBlockingQueue<>(this.concurrencyQueueCapacity);
            blockingQueue.put(event);
            concurrencyMap.put(synchronizer, blockingQueue);
        } else
            concurrencyMap.get(synchronizer).put(event);
    }

}
