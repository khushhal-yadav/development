package com.citi.icg.cioidark.fixengine;

import org.apache.commons.configuration.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Application context holder for the application
 *
 * @author ky54595
 */
public class FixEngineApplicationContextProvider {

    private static final Logger logger = LoggerFactory.getLogger(FixEngineApplicationContextProvider.class.getName());

    private static volatile FixEngineSystemProperty fixEngineSystemProperty;

    private FixEngineApplicationContextProvider() {
    }

    public static synchronized FixEngineSystemProperty getFixEngineSystemProperty() throws ConfigurationException {
        if (fixEngineSystemProperty == null) {
            try {
                fixEngineSystemProperty = new FixEngineSystemProperty();
            } catch (ConfigurationException e) {
                logger.error("ITRSALERT| System property file not found, exiting, {} ", e);
                throw e;
            }
        }

        return fixEngineSystemProperty;
    }
}
