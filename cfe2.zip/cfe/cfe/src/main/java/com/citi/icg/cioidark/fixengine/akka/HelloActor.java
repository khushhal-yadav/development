package com.citi.icg.cioidark.fixengine.akka;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.actor.UntypedActor;

public class HelloActor extends UntypedActor {

    @Override
    public void onReceive(Object message) throws Exception {

        if (message instanceof  HelloMessage) {
            System.out.println("My message is: " + ((HelloMessage)message).getMessage());
        }
    }

    public static void main( String[] args) {

        ActorSystem actorSystem = ActorSystem.create("actorSystem");
        final ActorRef actorRef = actorSystem.actorOf(new Props(HelloActor.class), "helloActor");
        actorRef.tell(new HelloMessage("Hello, Akka!"));

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        actorSystem.stop(actorRef);
        actorSystem.shutdown();


    }
}
