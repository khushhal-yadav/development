package com.citi.icg.cioidark.fixengine;

import java.io.IOException;

import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderIn;
import org.apache.commons.configuration.ConfigurationException;

public class FixEngineDirector {

    private static final FixEngineDirector director = new FixEngineDirector();

    private FixEngineDirector() {
    }

    public static FixEngineDirector getInstance() {
        return director;
    }

    public void initialize(ClientOrderIn clientOrderIn) throws ConfigurationException, IOException {
        FixEngineApplicationContextProvider.getFixEngineSystemProperty();
        FixEngineInitializer.initialize(clientOrderIn);
    }
}
