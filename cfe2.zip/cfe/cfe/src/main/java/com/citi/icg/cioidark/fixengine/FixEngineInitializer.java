package com.citi.icg.cioidark.fixengine;

import java.io.IOException;

import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderIn;
import com.citi.icg.cioidark.fixengine.client.ClientMessageNotifier;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.threads.EventGroup;
import net.openhft.chronicle.threads.Pauser;
import net.openhft.chronicle.wire.Marshallable;
import org.apache.commons.configuration.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.fix.staticcode.msgseq.QueueMsgSequenceHandler;

public class FixEngineInitializer {

    private static final Logger logger = LoggerFactory.getLogger(FixEngineInitializer.class);
    private static ChronicleFixEngine chronicleFixEngine;

    static {
        ClassAliasPool.CLASS_ALIASES.addAlias(FixEngineCfg.class);
        ClassAliasPool.CLASS_ALIASES.addAlias(QueueMsgSequenceHandler.class);
        ClassAliasPool.CLASS_ALIASES.addAlias(LoggingMode.class);
    }

    public static synchronized ChronicleFixEngine initialize(ClientOrderIn clientOrderIn) throws IOException, ConfigurationException {

        if (chronicleFixEngine == null) {
            final String clientConnectorFile = FixEngineApplicationContextProvider
                    .getFixEngineSystemProperty().getClientConnectorFile();
            logger.info("Loading file {}", clientConnectorFile);

            final FixEngineCfg fixEngineCfg = Marshallable.fromFile(FixEngineCfg.class, clientConnectorFile);
            assert fixEngineCfg != null;
            logger.info("Loaded Config file: {}", fixEngineCfg.toString());

            assert fixEngineCfg.fixSessionCfgs() != null;
            fixEngineCfg.fixSessionCfgs().stream()
                    .map(FixSessionCfg::messageNotifier)
                    .filter(ClientMessageNotifier.class::isInstance)
                    .map(ClientMessageNotifier.class::cast)
                    .forEach(m -> m.clientOut(clientOrderIn));

            EventGroup eg = new EventGroup(true, Pauser.busy(), false);
            chronicleFixEngine = fixEngineCfg.createInstance(FixEngineApplicationContextProvider.getFixEngineSystemProperty().getAppInstance(), eg);
            logger.info("fix engine started successfully");
        }

        return chronicleFixEngine;

    }

    public static ChronicleFixEngine getChronicleFixEngine() {
        return chronicleFixEngine;
    }
}
