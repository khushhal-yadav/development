package com.citi.icg.cioidark.fixengine.threadpool;

public interface Event<T> extends Runnable {

    String getSynchKey();
    void setSynchKey(final String synchKey);
    T getPayload();
    void setPayload(final T payload);
    long getMsgSeq();
    void setMsgSeq(final long msgSeq);


}
