package com.citi.icg.cioidark.fixengine.akka;

import java.util.ArrayList;
import java.util.List;

public class Result {

    private List<Long> results = new ArrayList<>();

    public List<Long> getResults() {
        return results;
    }
}
