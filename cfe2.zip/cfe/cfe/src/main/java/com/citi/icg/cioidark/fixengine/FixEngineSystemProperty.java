package com.citi.icg.cioidark.fixengine;

import com.citi.icg.cioidark.chronicle.messaging.message.admin.AbstractSystemProperty;
import org.apache.commons.configuration.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FixEngineSystemProperty extends AbstractSystemProperty {

    private static final Logger logger = LoggerFactory.getLogger(FixEngineSystemProperty.class.getName());

    private final String clientConnectorFile;
    private final int appInstance;

    //only construction injection of properties, *ABSOLUTELY NO SETTERS
    public FixEngineSystemProperty() throws ConfigurationException {
        super("fixEngine.properties");

        clientConnectorFile = systemProperties.getString("chronicle.fix.client.connection.file");
        appInstance = Integer.parseInt(System.getProperty("app.instance"));

        logger.info("FixEngineSystemProperty loaded: {}", this.toString());
    }

    public String getClientConnectorFile() {
        return clientConnectorFile;
    }

    int getAppInstance() {
        return appInstance;
    }

    @Override
    public String toString() {
        return "FixEngineSystemProperty{" +
                "clientConnectorFile='" + clientConnectorFile + '\'' +
                ", appInstance=" + appInstance +
                '}';
    }
}
