package com.citi.icg.cioidark.fixengine.akka;

import java.io.Serializable;

public class NumberRangeMessage implements Serializable {

    private final long startNumber;
    private final long endNumber;

    public NumberRangeMessage(long startNumber, long endNumber) {
        this.startNumber = startNumber;
        this.endNumber = endNumber;
    }

    public long getStartNumber() {
        return startNumber;
    }

    public long getEndNumber() {
        return endNumber;
    }
}
