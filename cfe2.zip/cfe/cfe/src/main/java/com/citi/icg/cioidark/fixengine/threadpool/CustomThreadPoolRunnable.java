package com.citi.icg.cioidark.fixengine.threadpool;

import java.util.concurrent.BlockingQueue;

public class CustomThreadPoolRunnable<T> implements Runnable {

    private final CustomThreadPool<T> threadPool;
    private final String synchronizer;

    public CustomThreadPoolRunnable(CustomThreadPool<T> threadPool, String synchronizer) {
        this.threadPool = threadPool;
        this.synchronizer = synchronizer;
    }


    @Override
    public void run() {
        try {

            boolean queueNotEmpty = true;

            while(queueNotEmpty) {
                BlockingQueue<Event<T>> blockingQueue;
                synchronized (threadPool.interner.intern(synchronizer)) {
                    blockingQueue = threadPool.concurrencyMap.remove(synchronizer);
                }

                queueNotEmpty = blockingQueue != null && blockingQueue.size() > 0;

                if (queueNotEmpty) {
                    Event<T> event;
                    while ((event = blockingQueue.poll()) != null) {
                        event.run();
                    }
                }

                if (!queueNotEmpty) {
                   synchronized(threadPool.interner.intern(synchronizer)) {
                       if (threadPool.concurrencyMap.get(synchronizer) == null
                               || threadPool.concurrencyMap.get(synchronizer).size() == 0) {
                           threadPool.submittedTaskMap.remove(synchronizer);
                           queueNotEmpty = false;
                       }
                   }
                }
            }

        } catch (Throwable t) {

        }

    }
}
