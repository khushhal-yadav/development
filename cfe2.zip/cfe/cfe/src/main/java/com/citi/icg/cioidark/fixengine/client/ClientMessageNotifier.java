package com.citi.icg.cioidark.fixengine.client;

import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderIn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.messages.MessageNotifier;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.staticcode.FixSessionHandler;

public class ClientMessageNotifier implements MessageNotifier {

    private static final Logger logger = LoggerFactory.getLogger(ClientMessageNotifier.class);

    static {
        ClassLoader.getSystemClassLoader().setDefaultAssertionStatus(false);
    }

    private ClientOrderIn out;

    @Override
    public void onNewOrderSingle(FixSessionHandler session, NewOrderSingle newOrderSingle) {
        logger.info("newOrderSingle {}", newOrderSingle.toString());
        out.clientNewOrderSingle(newOrderSingle);
        newOrderSingle.reset();
    }

    @Override
    public void onOrderCancelReplaceRequest(FixSessionHandler session,
                                            OrderCancelReplaceRequest orderCancelReplaceRequest) {
        logger.info("orderCancelReplaceRequest {}", orderCancelReplaceRequest.toString());
        out.clientOrderCancelReplaceRequest(orderCancelReplaceRequest);
        orderCancelReplaceRequest.reset();
    }

    @Override
    public void onOrderCancelRequest(FixSessionHandler session,
                                     OrderCancelRequest orderCancelRequest) {
        logger.info("orderCancelRequest {}", orderCancelRequest.toString());
        out.clientOrderCancelRequest(orderCancelRequest);
        orderCancelRequest.reset();
    }

    public void clientOut(ClientOrderIn out) {
        this.out = out;
    }

}
