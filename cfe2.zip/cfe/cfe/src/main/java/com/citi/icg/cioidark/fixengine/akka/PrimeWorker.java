package com.citi.icg.cioidark.fixengine.akka;

import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

import akka.actor.UntypedActor;
import org.apache.commons.lang.math.IntRange;

public class PrimeWorker extends UntypedActor {

    @Override
    public void onReceive(Object message) throws Exception {

        if ( message instanceof NumberRangeMessage ) {
            NumberRangeMessage numberRangeMessage = (NumberRangeMessage)message;
            Result result = new Result();

            result.getResults().addAll(LongStream.rangeClosed(numberRangeMessage.getStartNumber(), numberRangeMessage.getEndNumber())
                    .filter(this::isPrime).boxed().collect(Collectors.toList()));

            getSender().tell(result, getSelf());
        } else {
            unhandled(message);
        }

    }

    private boolean isPrime(long number) {
        return LongStream.rangeClosed(2, number/2).noneMatch(i -> number%i == 0);
    }
}
