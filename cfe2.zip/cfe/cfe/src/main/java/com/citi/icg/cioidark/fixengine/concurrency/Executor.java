package com.citi.icg.cioidark.fixengine.concurrency;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Executor {

    private final static Logger logger = LoggerFactory.getLogger(Executor.class);

    public static void main(String... args) {

        ExecutorService executor = Executors.newWorkStealingPool();

        executor.submit(() -> {
            logger.info("Hello {}", Thread.currentThread().getName());
        });


        Callable<Integer> task = () -> {
            TimeUnit.SECONDS.sleep(10);
            return 123;
        };

        final Future<Integer> future = executor.submit(task);

        logger.info("Future done? {}", future.isDone());

        Integer result = null;

       /* try {
            result = future.get();
        } catch (InterruptedException e) {
            logger.error("Callable interrupted");
        } catch (ExecutionException e) {
            logger.error("Callable executionException");
        }

        logger.info("Future done? {}", future.isDone());
        logger.info("Result {}", result);

        List<Callable<String>> callables = Arrays.asList(
                callable("task1", 10),
                callable("task2", 5),
                callable("task3", 8)
        );

        try {
            final String any = executor.invokeAny(callables);
            logger.info("InvokeAny Result {}", any);
        } catch (InterruptedException e) {
            logger.error("Callable invokeAny InterruptedException");
        } catch (ExecutionException e) {
            logger.error("Callable invokeAny ExecutionException");
        }*/

        try {
            logger.info("Attempt to shutdown executor");
            executor.shutdown();
            executor.awaitTermination(1, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            logger.error("Tasks interrupted");
        } finally {
            if (!executor.isShutdown())
                logger.error("Cancelling non-finished tasks");
            executor.shutdownNow();
            logger.info("Shutdown finished");
        }

        ScheduledExecutorService scheduledExecutor = Executors.newScheduledThreadPool(4);
        Runnable scheduleTask = () -> logger.info("Scheduling.....: {}", System.nanoTime());

        ScheduledFuture<?> scheduledFuture = scheduledExecutor.schedule(scheduleTask, 3, TimeUnit.SECONDS);

        try {
            TimeUnit.MILLISECONDS.sleep(1337);
        } catch (InterruptedException e) {
            logger.error("Sleep Interrupted");
        }

        final long remainingDelay = scheduledFuture.getDelay(TimeUnit.MILLISECONDS);
        logger.info("Remaining Delay: {}", remainingDelay);

        int initialDelay = 0;
        int period = 1;

        scheduledExecutor.scheduleAtFixedRate(scheduleTask, initialDelay, period, TimeUnit.SECONDS);

        try {
            logger.info("Attempt to shutdown scheduledExecutor");
            scheduledExecutor.shutdown();
            scheduledExecutor.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            logger.error("Tasks scheduledExecutor interrupted");
        } finally {
            if (!scheduledExecutor.isShutdown())
                logger.error("Cancelling scheduledExecutor non-finished tasks");
            scheduledExecutor.shutdownNow();
            logger.info("Shutdown scheduledExecutor finished");
        }

        int[][] intArray = {{1, 2}, {3, 4}};

        Stream.of(intArray).flatMap(Stream::of).forEach(System.out::println);
    }

    static Callable<String> callable(String rslt, long sleepSeconds) {
        return () -> {
            TimeUnit.SECONDS.sleep(sleepSeconds);
            return rslt;
        };
    }

    ;
}
