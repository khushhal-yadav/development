#! /bin/sh

if [ $# -ne 3 ]
then
	echo "Error in $0 - Invalid Argument Count"
	echo "Syntax: $0 <chronicle_service_name> <env_name> <instance>"
	echo "Exiting ..."
	exit
fi

DATE=`date +%m%d%y_%H.%M.%S`

echo "${DATE}: Starting up...."

export CHRONICLE_SERVICE=$1
export ENV_NAME=$2
export INSTANCE=$3

export APP_NAME=cioidark-fix-engine-ms
export JAVA_HOME=/usr/java/latest
export APP_DIR=/opt/cioi/$APP_NAME/default
export CONFIG_HOME=$APP_DIR/config/

LOG_DIR=/opt/cioi/loghome/$APP_NAME
export LOG_CONSOLE_FILE=$LOG_DIR/console.$APP_NAME-instance${INSTANCE}_${DATE}.log

export CLASSPATH=$CONFIG_HOME/$ENV_NAME:$CONFIG_HOME/common:$APP_DIR/$APP_NAME-1.0.0-SNAPSHOT.jar:$APP_DIR/lib/*
echo $CLASSPATH

${JAVA_HOME}/bin/java -cp ${CLASSPATH} -Dpreferences.env=$ENV_NAME -Dapp.name=$APP_NAME -Dapp.instance=$INSTANCE com.citi.icg.cioidark.chronicle.StartService $CHRONICLE_SERVICE $INSTANCE >> $LOG_CONSOLE_FILE 2>&1 &