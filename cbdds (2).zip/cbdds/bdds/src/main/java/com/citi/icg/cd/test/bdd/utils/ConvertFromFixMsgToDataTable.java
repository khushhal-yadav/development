package com.citi.icg.cd.test.bdd.utils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.util.Assert;

import com.citi.icg.cioidark.citifix.TagConstants;

public class ConvertFromFixMsgToDataTable {
	public static void convertTo(String fixMsg, Map<Integer, String> tagInverseMap) {
		Assert.hasText(fixMsg, "fixMsg should have text");
		Map<String, String> naturalOrder = new TreeMap<>();
		Arrays.asList(fixMsg.split("")).forEach((k)->{
			String[] pairs = k.split("=");
			Assert.notNull(tagInverseMap.get(Integer.parseInt(pairs[0])), "The field can't be looked up " + pairs[0]);
			naturalOrder.put(tagInverseMap.get(Integer.parseInt(pairs[0])), pairs[1]);
		});
		
		printFix(naturalOrder);
		return;
	}

	private static void printFix(Map<String, String> naturalOrder) {
		StringBuffer header = new StringBuffer();
		StringBuffer values = new StringBuffer();
		naturalOrder.forEach((key,value)->{			
			header.append(key + "|");
			values.append(value + "|");
		});		
		System.out.println("|"+header.toString());
		System.out.println("|"+values.toString());
	}

	public static Map<Integer, String> getTagConstants(){
		Map<Integer, String> tagMapInverse = new HashMap<>();
		Arrays.asList(TagConstants.class.getFields()).forEach((field)->{
			try {
				tagMapInverse.put(field.getInt(TagConstants.class), field.getName());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		return tagMapInverse;
	}

	public static void main(String args[]) {
		String fixMsg = "8=FIX.4.49=24635=D34=35849=CFORE50=BLOCUAT52=20160407-19:19:28.91456=BLOCUAT115=SBSH1=CAD111={CLORDID4}38=6000.040=P54=255=IBM60=20160407-19:19:28.914207=NYSE455=7810820528=A10005=510148=1023={CLORDID2}10625=0.010626=1.0110=6000.044=9.010=000";
		Map<Integer, String> tagInverseMap = null;
		try {
			tagInverseMap = ConvertFromFixMsgToDataTable.getTagConstants();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ConvertFromFixMsgToDataTable.convertTo(fixMsg, tagInverseMap);
	}

}
