package com.citi.icg.cd.test.bdd.chronicle.publisher;

import com.citi.icg.cd.test.bdd.steps.cdark.NewFIXOrderProcessingSteps;
import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderIn;
import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderOut;
import com.citi.icg.cioidark.chronicle.service.AbstractService;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.OrderCancelReject;

public class FixInOrderPublisher extends AbstractService implements ClientOrderOut {

    private final ClientOrderIn clientOrderIn;

    public FixInOrderPublisher(ClientOrderIn clientOrderIn) {
        this.clientOrderIn = clientOrderIn;
        NewFIXOrderProcessingSteps.clientOrderIn = clientOrderIn;
    }


    @Override
    public void clientExecutionReport(ExecutionReport executionReport) {

    }

    @Override
    public void clientOrderCancelReject(OrderCancelReject orderCancelReject) {

    }
}
