package com.citi.icg.cd.test.bdd.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//holds all input and expected results information needed for result verification
public class ScenarioMetaDataHolder {

	//private Map<String,List<String>> expectedresult = new HashMap<String,List<String>>(15); //map from features expected result
	private List<List<String>> expectedresult = new ArrayList<List<String>>(15); //order of this list is important
	private List<Integer> tags = new ArrayList<Integer>();   //tag number that needs to be verified .important to maintain the order of tags
	private Map<String,String> templatesids = new HashMap<String,String>(); //all template ids which are replaced with actual id
	private Map<String,String>  crossids = new HashMap<String,String>(); //clordid as key and crossid as value
	
	//store expected result as key value pair. key is the first element in Gherkin expected result ex cl orderid , execid etc
	//value usually will be fix string
	public void setExpectedResult(List<List<String>> r){
		this.expectedresult = r;
	}
	
	public List<String> getExpectedResultByIndex(int idx){
		return expectedresult.get(idx);
	}
	public List<Integer> getTagList(){
		return tags;
	}
	public  void setTagList(List<Integer> t){
		this.tags = t;
	}
	public void putTemplateId(String replaced,String replacedwith){
		templatesids.put(replaced,replacedwith);
	}
	public String getTemplateId(String replaced){
		return templatesids.get(replaced);
	}
	public Map<String,String> getAllTemplateIds(){
		return templatesids;
	}
	public boolean hasTemplateId(String templateid){
		return templatesids.containsKey(templateid);
	}
	
	public List<List<String>> getExpectedresult() {
		return expectedresult;
	}
	public void putCrossId(String clOrdID,String crossID){
		crossids.put(clOrdID, crossID);
	}
	
	public String getCrossIDForClOrdID(String clOrdID){
		return crossids.get(clOrdID);
	}
}
