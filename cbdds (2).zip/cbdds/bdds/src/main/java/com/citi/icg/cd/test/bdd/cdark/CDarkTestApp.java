package com.citi.icg.cd.test.bdd.cdark;

import com.citi.icg.cd.bootstrap.services.CioiDarkDirector;
import com.citi.icg.cd.manager.SystemPropertyManager;
import com.citi.icg.cd.test.bdd.TestApp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class CDarkTestApp implements TestApp, ApplicationContextAware {

	private final static Logger logger = LoggerFactory.getLogger(CDarkTestApp.class);
	
	private boolean initialized = false;
	private ApplicationContext ctx;
	
	
	@Autowired
	SystemPropertyManager sysManager;
	
	
	private void initSysManager(){		
		sysManager.setCrossFailureClientTimeoutSecs(20);
		sysManager.setInviteTimeoutMillisec(2000);
	}
	
	@Override
	public void start() {

//		ConfigurableApplicationContext appCtx = new SpringApplication(Application.class).run(new String[0]);
//		appCtx.setParent(this.ctx);
		CioiDarkDirector.getInstance().init();
		initSysManager();
		
		while (! CioiDarkDirector.getInstance().isInitialized()) {
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				throw new RuntimeException(e);
			}
		}
		
		initialized = true;
	}

	@Override
	public void stop() {
		initialized = true;
	}

	@Override
	public boolean isInitialized() {
		return initialized;
	}

	@Override
	public void subscribeToAppLifecycleEvents(AppLifecycleListener listener) {

	}

	@Override
	public void setApplicationContext(ApplicationContext ctx) throws BeansException {
		this.ctx = ctx;

	}

}
