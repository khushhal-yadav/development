package com.citi.icg.cd.test.bdd.services;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import com.citi.icg.cd.messaging.SessionPublisher;
import com.citi.icg.gc.Service;

public class MockEMSPublisher extends Service implements SessionPublisher{

	private LinkedBlockingQueue<String> responseQueue = new LinkedBlockingQueue<String> (); 
	
	public MockEMSPublisher() {
		super(true);
	}
	
	@Override
	public boolean doService() {
		setInitialized(true);
		return true;
	}

	@Override
	public String getServiceName() {
		
		return MockEMSPublisher.class.getName();
	}

	public String getResponse() throws InterruptedException {
		return responseQueue.poll(10000,  TimeUnit.MILLISECONDS);
	}
	
	@Override
	public void publish(String msg, String topic) throws Exception {
		responseQueue.offer(msg);
	}
	public void purgeMessages(){
		responseQueue.clear();
	}

}
