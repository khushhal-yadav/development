package com.citi.icg.cd.test.bdd.cdark;

import com.citi.icg.cd.test.bdd.TestApp;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.citi.icg.cd.test.bdd.utils.ScenarioMetaDataHolder;

@Configuration
@ComponentScan("com.citi.icg.cd.test.bdd")
public class CDarkConfiguration {

	@Bean(name = "TestApp")
	public TestApp createTestApplication () {
		return new CDarkTestApp();
	}
	
	@Bean(name = "AppContextProvider")
	public AppContextProvider getAppContextProvider(){
		return new AppContextProvider();
	}
	
	@Bean(name= "scenarioMetaDataHolder")
	public ScenarioMetaDataHolder getScenarioMetaDataHolder(){
		return new ScenarioMetaDataHolder();
	}
}
