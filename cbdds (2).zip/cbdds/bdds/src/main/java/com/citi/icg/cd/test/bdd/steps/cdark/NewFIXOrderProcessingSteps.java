package com.citi.icg.cd.test.bdd.steps.cdark;

import static org.junit.Assert.fail;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.citi.icg.cd.data.util.AdminMessageHelper;
import com.citi.icg.cd.manager.SystemPropertyManager;
import com.citi.icg.cd.md.enumeration.MarketPeriod;
import com.citi.icg.cd.test.bdd.queue.OutTestQueues;
import com.citi.icg.cd.test.bdd.services.MockGMDMessageCallback;
import com.citi.icg.cd.test.bdd.threadpool.event.MockEventSession;
import com.citi.icg.cd.test.bdd.utils.LULDDataDTO;
import com.citi.icg.cd.test.bdd.utils.MarketDataDTO;
import com.citi.icg.cd.test.bdd.utils.MessageUtilities;
import com.citi.icg.cd.test.bdd.utils.ScenarioMetaDataHolder;
import com.citi.icg.cd.timer.DefaultTimerRunnable;
import com.citi.icg.cd.timer.qmf.Timer;
import com.citi.icg.cd.timer.qmf.TimerTask;
import com.citi.icg.cd.timer.qmf.TimerTaskType;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.AdminMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderIn;
import com.citi.icg.cioidark.citifix.constants.ExecType;
import com.citi.icg.cioidark.fix.CitiFixMessage;
import com.citi.icg.gc.Application;
import com.citi.icg.gc.ApplicationcontextProvider;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.annotation.NotNull;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import software.chronicle.fix.codegen.fields.ClOrdID;
import software.chronicle.fix.codegen.fields.CrossID;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.codegen.messages.MessageNotifier;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultExecutionReport;
import software.chronicle.fix.codegen.parsers.MessageParser;
import software.chronicle.fix.datamodel.AbstractDataModel;
import software.chronicle.fix.staticcode.parsers.MessageParserBase;

public class NewFIXOrderProcessingSteps {
    private final static Logger logger = LoggerFactory.getLogger(NewFIXOrderProcessingSteps.class);

    @Autowired
    private MockEventSession mockEventSession;

    @Autowired
    private AdminMessageHelper adminMessageHelper;

    public static ClientOrderIn clientOrderIn;

    final private MessageParserBase messageParser = new MessageParser();

    final private MessageNotifier messageNotifier = new MessageNotifier() {

        @Override
        public MessageGenerator onNewOrderSingle(NewOrderSingle newOrderSingle) {
            clientOrderIn.clientNewOrderSingle(newOrderSingle);
            return null;
        }

        @Override
        public MessageGenerator onOrderCancelReplaceRequest(OrderCancelReplaceRequest orderCancelReplaceRequest) {
            clientOrderIn.clientOrderCancelReplaceRequest(orderCancelReplaceRequest);
            return null;
        }

        @Override
        public MessageGenerator onOrderCancelRequest(OrderCancelRequest orderCancelRequest) {
            clientOrderIn.clientOrderCancelRequest(orderCancelRequest);
            return null;
        }
    };
    private Scenario scenario;

    @Autowired
    private ScenarioMetaDataHolder erh;

    @Autowired
    private MockGMDMessageCallback gmdMsgCallback;


    @Autowired
    SystemPropertyManager sysManager;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
        sysManager.setMarketPeriod(MarketPeriod.CONTINUOUS_TRADING);
        erh.getExpectedresult().clear();
        erh.getTagList().clear();
        erh.getAllTemplateIds().clear();
        Application.getCioiDarkBookManager().reset();

        logger.info("started running scenario name " + this.scenario.getName());

    }

    private void massCancelBook() {
        String message = "{\"attributes\":{\"action\":\"MASSCXL\",\"symbolrange\":\"A-A\"}}";
        AdminMessage adminMsg = ApplicationcontextProvider.getCfgMgrDataHandler().processInbound(message);
        adminMessageHelper.processAdminMessage(adminMsg);
    }

    @Given("^Engine is in State \"([^\"]*)\"$")
    public void engine_is_state(MarketPeriod period) throws Throwable {
        sysManager.setMarketPeriod(period);
    }

    @Given("^Timer Event of \"([^\"]*)\"$")
    public void timer_Event_of_in_milliseconds(TimerTaskType timerEvent) throws Throwable {

        Timer.getInstance().schedule(new DefaultTimerRunnable(), new TimerTask("SYSTEM", TimerTaskType.GLOBAL_TASK), Calendar.getInstance().getTime(), 0);
        a_delay_of_milliseconds(1000);
    }

    @Given("^New Order Received As <(.*?)>$")
    public void new_order(String desc, DataTable data) throws Throwable {
        int n = data.raw().size();
        for (int i = 1; i < n; i++) {
            String msg = MessageUtilities.populateCitiFixString(data.topCells(), data.raw().get(i));
            generateOnMessage(msg);
            //	a_delay_of_milliseconds(1);
        }
    }

    @Given("^New Order Received As <(.*?)> with delay of (\\d+) miliseconds$")
    public void new_Order_Received_As_Conditional_Buy_Order_with_delay_of_miliseconds(String desc, int delay, DataTable data) throws Throwable {
        int n = data.raw().size();
        for (int i = 1; i < n; i++) {
            String msg = MessageUtilities.populateCitiFixString(data.topCells(), data.raw().get(i));
            generateOnMessage(msg);
            a_delay_of_milliseconds(delay);

        }
    }

    @Given("^New Order Received As FIX Message$")
    public void new_Order_Received_As_FIX_Message(DataTable arg1) throws Throwable {
        int n = arg1.raw().size();
        for (int i = 1; i < n; i++) {
            generateOnMessage(arg1.raw().get(i).get(0) + '\u0001');
        }
    }

    private void generateOnMessage(String msg) {
        String message = MessageUtilities.replaceAndTrackTemplateIdsForFix(msg, erh);
        message = MessageUtilities.updateOrderFields(message);
        Bytes<ByteBuffer> byteBufferBytes = Bytes.elasticByteBuffer();
        @NotNull Bytes<ByteBuffer> byteMessage = byteBufferBytes.append(message);
        messageParser.parse(byteMessage, messageNotifier);
    }

    @Then("^Client Receives FIX Response (.*)$")
    public void client_Receives_FIX_Response(String desc, DataTable arg1) throws Throwable {
        MessageUtilities.populateExpectedResultsMap(arg1, erh);
        int n = arg1.raw().size() - 1;
        for (int i = 0; i < n; i++) {
            MessageUtilities.doAssertion(erh, OutTestQueues.outTestQueues.getFixOut(), i);
        }
    }

    @Then("^ConfigManger Receives Message <MESSAGE>$")
    public void configmanger_Receives_Message_MESSAGE(DataTable data) throws Throwable {
        int n = data.raw().size() - 1;
        String message = null;

        List<Map<String, String>> expectedList = data.raw().stream().
                filter(dataItems -> !dataItems.get(0).equalsIgnoreCase("MESSAGE")).
                map(dataItems ->
                        MessageUtilities.unmarshalJsonMessage(dataItems.get(0))).collect(Collectors.toCollection(ArrayList::new));

        for (int i = 1; i <= n; i++) {
            message = OutTestQueues.outTestQueues.getConfigMgr(); //expecting actual result to be in same sequence as expected result
            while (message != null && (message.contains("bookAttributes") || message.contains("ack_perf") || message.contains("invite_perf"))) { //ignore all junk bookAttributes messages
                message = OutTestQueues.outTestQueues.getConfigMgr();
            }
            Map<String, String> actual = MessageUtilities.unmarshalJsonMessage(message);
            Map<String, String> expected = expectedList.stream().filter(valueMap ->
                    Optional.ofNullable(valueMap.get("slang")).orElse(" ").equalsIgnoreCase(Optional.ofNullable(actual.get("slang")).orElse(" "))
                            && Optional.ofNullable(valueMap.get("tableName")).orElse("").equalsIgnoreCase(Optional.ofNullable(actual.get("tableName")).orElse(""))
                            && Optional.ofNullable(valueMap.get("alerttype")).orElse("").equalsIgnoreCase(Optional.ofNullable(actual.get("alerttype")).orElse(""))
            ).findFirst().get();
            MessageUtilities.doMapAssertion(expected, actual);
        }
    }

    @Then("^Client Receives (\\d+) Responses in NO Order using id \"([^\"]*)\"$")
    public void client_Receives_Responses_in_No_Order(int numOfResponses, String strId, DataTable arg2) throws Throwable {
        MessageUtilities.populateExpectedResultsMap(arg2, erh);
        HashMap<String, AbstractDataModel> response2 = new HashMap<>();
        for (int i = 0; i < numOfResponses; i++) {
            final AbstractDataModel fixOut = OutTestQueues.outTestQueues.getFixOut();
            if (fixOut instanceof DefaultExecutionReport) {
                DefaultExecutionReport er = new DefaultExecutionReport();
                fixOut.copyTo(er);
                response2.put(er.clOrdID(), er);
            }
        }
        if (response2.size() != numOfResponses) {
            throw new RuntimeException("did not get the correct number of responses");
        }

        List<List<String>> eResults = erh.getExpectedresult();
        int colId = arg2.topCells().indexOf(strId);
        int i = 0;
        for (List<String> list : eResults) {
            String id = erh.getTemplateId(list.get(colId));
            AbstractDataModel reMsg = response2.get(id);
            MessageUtilities.doAssertion(erh, reMsg, i++);

        }

    }

    @Then("^Client Receives (\\d+) Responses in NO Order using id \"([^\"]*)\" and \"([^\"]*)\"$")
    public void client_Receives_Responses_in_NO_Order_using_id_and(int numOfResponses, String strId1, String strId2, DataTable data) throws Throwable {
        MessageUtilities.populateExpectedResultsMap(data, erh);
        String message = null;
        Map<String, AbstractDataModel> responses = new HashMap<>();
        Map<String, Integer> orderOfResponse = new HashMap<>();
        for (int i = 0; i < numOfResponses; i++) {
            final AbstractDataModel fixOut = OutTestQueues.outTestQueues.getFixOut();
            if (fixOut instanceof DefaultExecutionReport) {
                DefaultExecutionReport er = new DefaultExecutionReport();
                String k = er.execType() + "_" + er.clOrdID();
                responses.put(k, er);
                orderOfResponse.put(k, i);
                trackCrossID(er);
            }
        }
        if (responses.size() != numOfResponses) {
            throw new RuntimeException("did not get the correct number of responses");
        }

        List<List<String>> eResults = erh.getExpectedresult();
        int colId = data.topCells().indexOf(strId1);
        int secondColId = data.topCells().indexOf(strId2);
        int i = 0;
        for (List<String> list : eResults) {
            String id = erh.getTemplateId(list.get(colId));
            String execType = list.get(secondColId);
            String k = execType + "_" + id;
            AbstractDataModel reMsg = responses.get(k);
            MessageUtilities.doAssertion(erh, reMsg, i++);
            //Check the sequence of exec types
            if (ExecType.CANCELED.equals(execType) || ExecType.REJECTED.equals(execType)) {
                if (orderOfResponse.containsKey(ExecType.NEW + "_" + id)) {
                    if (orderOfResponse.get(ExecType.NEW + "_" + id) > orderOfResponse.get(k))
                        fail("Sequence of Ack and Cxl/Rej is out of sync, Ack= " + orderOfResponse.get(ExecType.NEW + "_" + id) + " Cxl/Rej=" + orderOfResponse.get(k));
                }
            }
        }
    }


    @Then("^Validate Matched Orders$")
    public void validate_Matched_Orders(DataTable data) throws Throwable {
        int n = data.raw().size();   //table size
        for (int i = 1; i < n; i++) {
            String[] bucket = data.raw().get(i).get(0).split(",");
            Assert.assertEquals(erh.getCrossIDForClOrdID(erh.getTemplateId(bucket[0].trim())), erh.getCrossIDForClOrdID(erh.getTemplateId(bucket[1].trim())));
        }
    }


    @Then("^Client Receives a EMS FIX Response$")
    public void client_Receives_a_EMS_FIX_Response(DataTable arg1) throws Throwable {
        MessageUtilities.populateExpectedResultsMap(arg1, erh);
        int n = arg1.raw().size() - 1;
        for (int i = 0; i < n; i++) {
            MessageUtilities.doAssertion(erh, OutTestQueues.outTestQueues.getEmsOut(), i);
        }
    }

    @Then("^Client Does Not Receive Further Response$")
    public void client_Does_Not_Receive_Further_Response() throws Throwable {
        Assert.assertFalse("The responses contains additional messages", OutTestQueues.outTestQueues.getSizeFixOutQueue() != 0);
    }

    @Then("^ConfigManager Does Not Receive Further Response$")
    public void configmanager_Does_Not_Receive_Further_Response() throws Throwable {
        Assert.assertNull("The configmanager responses contains additional messages", OutTestQueues.outTestQueues.getConfigMgr());
    }

    @Given("^Market Data Received As$")
    public void market_Data_Received_As(DataTable data) throws Throwable {
        List<MarketDataDTO> mds = data.asList(MarketDataDTO.class);
        for (MarketDataDTO md : mds) {
            logger.info("START: Market Data results [Symbol {}], [Bid {}], [Ask {}]", md.getSymbol(), md.getBid(), md.getAsk());
            gmdMsgCallback.handleBookUpdate(md);
        }
        a_delay_of_milliseconds(500);
        for (MarketDataDTO md : mds) {
            logger.info("END: Market Data results [Symbol {}], [Bid {}], [Ask {}]", md.getSymbol(), md.getBid(), md.getAsk());
        }

    }

    @Given("^Market Data Status Update Recevied as$")
    public void market_Data_Status_Update_Recevied_as(DataTable data) throws Throwable {
        logger.debug("Market Data Status Updatd with data [{}]", data.toString());
        List<MarketDataDTO> mds = data.asList(MarketDataDTO.class);
        for (MarketDataDTO md : mds) {
            logger.info("Market Data results [Symbol {}], [Ask {}], [Bid {}], [tradingStatus {}]", md.getSymbol(), md.getAsk(), md.getBid(), md.getTradingStatus());
            gmdMsgCallback.handleInstrumentStatusMsg(md);
        }
        a_delay_of_milliseconds(1000);
    }

    @Given("^LULD Status Update Received As$")
    public void luld_Status_Update_Recevied_As(DataTable data) throws Throwable {
        logger.info("LULD Data Status Updatd with data [{}]", data.toString());
        List<LULDDataDTO> mds = data.asList(LULDDataDTO.class);
        for (LULDDataDTO md : mds) {
            logger.info("Market Data results [Symbol {}], [LowerLimit {}],[UpperLimit {}]", md.getSymbol(), md.getLowerLimit(), md.getUpperLimit());
            gmdMsgCallback.handleLULDBandMsg(md);
        }
        a_delay_of_milliseconds(500);
    }


    @Given("^a Admin Message is issued$")
    public void a_Admin_Message_is_issued(DataTable data) throws Throwable {
        logger.info("Admin Message is issued with data [{}]", data.toString());
        List<AdminMsgDTO> adminDTOMsgs = data.asList(AdminMsgDTO.class);
        adminDTOMsgs.stream()
                .map(adminMsgDTO -> ApplicationcontextProvider.getCfgMgrDataHandler().processInbound(adminMsgDTO.getMessage()))
                .forEach(adminMessageHelper::processAdminMessage);
    }

    @Given("^a delay of (\\d+) milliseconds$")
    public void a_delay_of_milliseconds(long ms) throws Throwable {
        logger.info("Sleeping [{}]", ms);
        Thread.sleep(ms);
    }

    @Given("^a clean Event Queue$")
    public void a_clean_event_queue() throws Throwable {
        OutTestQueues.outTestQueues.purgeFixOutQueue(); //this is required otherwise messages from previous scenario will be received and compared
        OutTestQueues.outTestQueues.purgeEmsOutQueue();
        OutTestQueues.outTestQueues.purgeConfigMgrQueue();
        logger.info("cleaning response queue ");
    }

    @Then("^ConfigManger Receives (\\d+) Messages$")
    public void configmanger_Receives_Messages(int count, DataTable arg2) throws Throwable {
        int size = OutTestQueues.outTestQueues.getSizeConfigMgrQueue();
        int goodMsgCnt = 0;
        String message = null;
        for (int i = 0; i < size; i++) {
            message = OutTestQueues.outTestQueues.getConfigMgr(); //expecting actual result to be in same sequence as expected result
            if (message != null && (message.contains("bookAttributes") || message.contains("ack_perf") || message.contains("invite_perf"))) { //ignore all junk bookAttributes messages
                //igonre
            } else {
                goodMsgCnt++;
            }
        }
        Assert.assertEquals(count, goodMsgCnt);
    }

    private class AdminMsgDTO {
        private String message;

        public String getMessage() {
            return message;
        }

    }

    private void trackCrossID(CitiFixMessage citiFix) {
        if (citiFix.getCrossID() != null) {
            erh.putCrossId(citiFix.getClOrdID(), citiFix.getCrossID());
        }
    }

    private void trackCrossID(AbstractDataModel msg) {
        if (msg.getString(CrossID.FIELD) != null) {
            erh.putCrossId(msg.getString(ClOrdID.FIELD), msg.getString(CrossID.FIELD));
        }
    }

    @After
    public void afterScenario() throws Throwable {
        massCancelBook();
        a_delay_of_milliseconds(5000);
        a_clean_event_queue();
        logger.info("finished scenario " + this.scenario.getName());
    }


}

