package com.citi.icg.cd.test.bdd.utils;

public class LULDDataDTO {
	
	public enum TradingStatus{
		HALTED('f'),
		OPENED_OR_TRADE_RESUME('o');
		
		private char gmdStatus;

		public char getGmdStatus() {
			return gmdStatus;
		}
		TradingStatus(char gmdStatus){
			this.gmdStatus = gmdStatus;
		}		
	}
	public enum ShortSaleRestriction{
	    SHORT_SALE_RESTRICTION_ACTIVATED('1'),
	    SHORT_SALE_RESTRICTION_REMOVED('0'),
	    SHORT_SALE_RESTRICTION_NOT_CHANGED('\0');
		private char shortSaleCode;
	    public char getShortSaleCode() {
			return shortSaleCode;
		}

		public void setShortSaleCode(char shortSaleCode) {
			this.shortSaleCode = shortSaleCode;
		}

		ShortSaleRestriction(char shortSaleCode){
	    	this.shortSaleCode = shortSaleCode;
	    }
	    
	}
	private String symbol;
	private double upperLimit;
	private double lowerLimit;
	private TradingStatus tradingStatus;
	private ShortSaleRestriction shortSaleRestriction;
	
	public ShortSaleRestriction getShortSaleRestriction() {
		return shortSaleRestriction;
	}
	public void setShortSaleRestriction(ShortSaleRestriction shortSaleRestriction) {
		this.shortSaleRestriction = shortSaleRestriction;
	}
	public TradingStatus getTradingStatus() {
		return tradingStatus;
	}
	public void setTradingStatus(TradingStatus tradingStatus) {
		this.tradingStatus = tradingStatus;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	
	public double getUpperLimit() {
		return upperLimit;
	}
	public void setUpperLimit(double upperLimit) {
		this.upperLimit = upperLimit;
	}
	public double getLowerLimit() {
		return lowerLimit;
	}
	public void setLowerLimit(double lowerLimit) {
		this.lowerLimit = lowerLimit;
	}
	



}
