package com.citi.icg.cd.test.bdd.services;

import java.util.Map;

import com.citi.icg.cd.bootstrap.services.SubscribeMarketDataService;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;

public class MockSubscribeMarketDataService extends SubscribeMarketDataService {

    protected MockSubscribeMarketDataService(Map<String, String> dependencyServiceMap,
                                             boolean shutdownIfServiceNotCompleted) {
        super(dependencyServiceMap, shutdownIfServiceNotCompleted);
    }

    @Override
    public boolean doService() {
        logger.info("Doing nothing in doService() as mock SubscribeMarketDataService for BDD: {}",
                MockGMDMessageCallback.class.getSimpleName());
        return true;

    }

    public boolean subscribeToGMD(String bookSymbol, String marketDataSymbol, boolean subscribe) {

        logger.info("Doing nothing in subscribeToGMD() as mock SubscribeMarketDataService for BDD: {}",
                MockGMDMessageCallback.class.getSimpleName());
        return true;
    }

    private GMDTickSubscriptionMsg getGmdTickSubscriptionMsg(String bookSymbol, String marketDataSymbol,
                                                             boolean subscribe) {
        logger.info("Doing nothing in getGmdTickSubscriptionMsg() as mock SubscribeMarketDataService for BDD: {}",
                MockGMDMessageCallback.class.getSimpleName());

        return new GMDTickSubscriptionMsg(bookSymbol, marketDataSymbol, subscribe);
    }

    @Override
    public String getServiceName() {
        return MockSubscribeMarketDataService.class.getSimpleName();
    }

}
