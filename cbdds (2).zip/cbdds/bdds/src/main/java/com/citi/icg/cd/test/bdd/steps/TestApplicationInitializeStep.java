package com.citi.icg.cd.test.bdd.steps;

import static org.junit.Assert.assertTrue;

import com.citi.icg.cd.test.bdd.TestApp;
import com.citi.icg.gc.Application;
import cucumber.api.java.en.Given;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration(classes=Application.class)
@SpringBootTest
public class TestApplicationInitializeStep {
	
	private final static Logger logger = LoggerFactory.getLogger(TestApplicationInitializeStep.class); 
	
	@Autowired
	private TestApp testApplication;
	
	@Given("^Engine is initialized$")
	public void test_init() {

		if (! testApplication.isInitialized()) {
			logger.info("Initializing config.test application");
			testApplication.start();
		}
		
		assertTrue("Test application is not initialized", testApplication.isInitialized());

		logger.info("Test application is initialized");
	}

}
