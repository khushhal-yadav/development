package com.citi.icg.cd.test.bdd.services;

import com.citi.icg.gc.Service;

public class HeartbeatMockupService extends Service {

	protected HeartbeatMockupService() {
		super(true);
	}

	@Override
	public boolean doService() {
		setInitialized(true);
		return true;
	}

	@Override
	public String getServiceName() {
		return HeartbeatMockupService.class.getName();
	}

}
