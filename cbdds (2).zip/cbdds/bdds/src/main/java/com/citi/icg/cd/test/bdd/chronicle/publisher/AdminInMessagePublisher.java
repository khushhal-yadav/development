package com.citi.icg.cd.test.bdd.chronicle.publisher;

import com.citi.icg.cioidark.chronicle.messaging.queue.AdminCommandIn;
import com.citi.icg.cioidark.chronicle.messaging.queue.AdminCommandOut;
import com.citi.icg.cioidark.chronicle.service.AbstractService;

public class AdminInMessagePublisher extends AbstractService implements AdminCommandOut {

    final private AdminCommandIn adminCommandIn;

    public AdminInMessagePublisher(AdminCommandIn adminCommandIn) {
        this.adminCommandIn = adminCommandIn;
        //NewFIXOrderProcessingSteps.adminCommandIn = adminCommandIn;
    }

    @Override
    public void adminMessage(String s) {

    }
}
