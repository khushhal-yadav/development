package com.citi.icg.cd.test.bdd.chronicle.publisher;

import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderIn;
import com.citi.icg.cioidark.chronicle.messaging.queue.ClientOrderOut;
import com.citi.icg.cioidark.chronicle.service.AbstractService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.OrderCancelReject;

public class FixOutOrderPublisher extends AbstractService implements ClientOrderOut {

    private static final Logger logger = LoggerFactory.getLogger(FixOutOrderPublisher.class);

    public FixOutOrderPublisher(ClientOrderIn clientOrderOut) {
    }

    @Override
    public void clientExecutionReport(ExecutionReport executionReport) {
        logger.info("Execution report publsihed: {}", executionReport.toString());
        //OutTestQueues.outTestQueues.publishFixOut(executionReport);

    }

    @Override
    public void clientOrderCancelReject(OrderCancelReject orderCancelReject) {

    }
}
