package com.citi.icg.cd.test.bdd.services;

import com.citi.icg.cd.md.services.StaleMarketDataMonitor;

public class MockCBMarketDataStaleMonitor extends StaleMarketDataMonitor {
	public MockCBMarketDataStaleMonitor() {
	}
}
