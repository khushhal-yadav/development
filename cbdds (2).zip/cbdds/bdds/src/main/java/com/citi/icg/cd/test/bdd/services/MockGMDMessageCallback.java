package com.citi.icg.cd.test.bdd.services;

import java.util.Calendar;

import com.citi.gmd.client.book.GMDAbstractBook;
import com.citi.gmd.client.messages.admin.GMDAdminRespMsg;
import com.citi.gmd.client.messages.component.GMDBasketQuoteMsg;
import com.citi.gmd.client.messages.component.GMDCacheClearMsg;
import com.citi.gmd.client.messages.component.GMDClosingTradeSummaryMsg;
import com.citi.gmd.client.messages.component.GMDEnhancedQuoteMsg;
import com.citi.gmd.client.messages.component.GMDFeedCfgInfoMsg;
import com.citi.gmd.client.messages.component.GMDFeedStatusMsg;
import com.citi.gmd.client.messages.component.GMDImbalanceMsg;
import com.citi.gmd.client.messages.component.GMDInstrumentStatusMsg;
import com.citi.gmd.client.messages.component.GMDLogOffRespMsg;
import com.citi.gmd.client.messages.component.GMDLogOnRejMsg;
import com.citi.gmd.client.messages.component.GMDLogOnRespMsg;
import com.citi.gmd.client.messages.component.GMDMktStatusMsg;
import com.citi.gmd.client.messages.component.GMDPassThruMsg;
import com.citi.gmd.client.messages.component.GMDPeggedOrderMsg;
import com.citi.gmd.client.messages.component.GMDSnpshotCompleteNotification;
import com.citi.gmd.client.messages.component.GMDStaticInfoMsg;
import com.citi.gmd.client.messages.component.GMDSubRespMsg;
import com.citi.gmd.client.messages.component.GMDTradeMsg;
import com.citi.gmd.client.messages.component.GMDTradeMsgDetailed;
import com.citi.gmd.client.messages.component.GMDUnSubRespMsg;
import com.citi.icg.cd.md.MarketDataConstants;
import com.citi.icg.cd.md.component.GMDMessageCallback;
import com.citi.icg.cd.test.bdd.utils.LULDDataDTO;
import com.citi.icg.cd.test.bdd.utils.MarketDataDTO;
import com.citi.icg.cd.test.bdd.utils.MarketDataDTO.ShortSaleRestriction;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDInstrumentTradingStatusMsg;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDLULDBandMsg;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDQuoteMsg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MockGMDMessageCallback extends GMDMessageCallback {

    private final static Logger logger = LoggerFactory.getLogger(MockGMDMessageCallback.class);

    public MockGMDMessageCallback() {
    }

    public void handleBookUpdate(MarketDataDTO md) {
        long ts = getTsWithAddedSeconds(4) * 1000000;
        logger.info("Mock Timestamp MD with 2 seconds added [{}]", ts);
        gmdTickMessageOut.handleQuoteMsg(new GMDQuoteMsg(md.getSymbol(), md.getBid(), md.getAsk(),
                1, 1, ts));

        //subscribtionManager.publishInstrumentStatus(md.getSymbol(), MarketDataDTO.TradingStatus.OPENED_OR_TRADE_RESUME.getGmdStatus(), MarketDataDTO.ShortSaleRestriction.SHORT_SALE_RESTRICTION_NOT_CHANGED.getShortSaleCode());
    }

    public void handleLULDBandMsg(LULDDataDTO md) {
        long ts = getTsWithAddedSeconds(4) * 1000000;
        logger.info("Mock Timestamp MD with 2 seconds added [{}]", ts);
        gmdTickMessageOut.handleLULDBandMsg(new GMDLULDBandMsg(md.getSymbol(), md.getUpperLimit(),
                md.getLowerLimit(), ts, ts));

        //subscribtionManager.publishInstrumentStatus(md.getSymbol(), MarketDataDTO.TradingStatus.OPENED_OR_TRADE_RESUME.getGmdStatus(), MarketDataDTO.ShortSaleRestriction.SHORT_SALE_RESTRICTION_NOT_CHANGED.getShortSaleCode());
    }

    public void handleInstrumentStatusMsg(MarketDataDTO md) {
        long ts = getTsWithAddedSeconds(4) * 1000000;
        char shortSaleStatus = md.getShortSaleRestriction() != null ? md.getShortSaleRestriction().getShortSaleCode()
                : ShortSaleRestriction.SHORT_SALE_RESTRICTION_NOT_CHANGED.getShortSaleCode();
        char tradingStatus = md.getTradingStatus() != null ? md.getTradingStatus().getGmdStatus() : 'o';
        gmdTickMessageOut.handleInstrumentTradingStatusMsg(new GMDInstrumentTradingStatusMsg(md.getSymbol(),
                MarketDataConstants.SNAPSHOT_UPDATE, tradingStatus, shortSaleStatus, ts));
    }

    private long getTsWithAddedSeconds(int sec) {
        Calendar calender = Calendar.getInstance();
        calender.add(Calendar.SECOND, sec);
        return calender.getTimeInMillis();
    }

    @Override
    public void handleQuoteMsg(com.citi.gmd.client.messages.component.GMDQuoteMsg gmdQuoteMsg) {

    }

    @Override
    public void handleTradeMsg(GMDTradeMsg gmdTradeMsg) {

    }

    @Override
    public void handleImbalanceMsg(GMDImbalanceMsg gmdImbalanceMsg) {

    }

    @Override
    public void handleCacheClearMsg(GMDCacheClearMsg gmdCacheClearMsg) {

    }

    @Override
    public void handleStaticInfoMsg(GMDStaticInfoMsg gmdStaticInfoMsg) {

    }

    @Override
    public void handleMarketStatusMsg(GMDMktStatusMsg gmdMktStatusMsg) {

    }

    @Override
    public void handleInstrumentStatusMsg(GMDInstrumentStatusMsg gmdInstrumentStatusMsg) {

    }

    @Override
    public void handleDetailedTradeMsg(GMDTradeMsgDetailed gmdTradeMsgDetailed) {

    }

    @Override
    public void handlePeggedOrderMsg(GMDPeggedOrderMsg gmdPeggedOrderMsg) {

    }

    @Override
    public void handleSubRespMsg(GMDSubRespMsg gmdSubRespMsg) {

    }

    @Override
    public void handleUnSubRespMsg(GMDUnSubRespMsg gmdUnSubRespMsg) {

    }

    @Override
    public void handleAdminRespMsg(GMDAdminRespMsg gmdAdminRespMsg) {

    }

    @Override
    public void handleFeedStatusMsg(GMDFeedStatusMsg gmdFeedStatusMsg) {

    }

    @Override
    public void handleFeedCfgInfoMsg(GMDFeedCfgInfoMsg gmdFeedCfgInfoMsg) {

    }

    @Override
    public void handleLogOnRespMsg(GMDLogOnRespMsg gmdLogOnRespMsg) {

    }

    @Override
    public void handleLogOffRespMsg(GMDLogOffRespMsg gmdLogOffRespMsg) {

    }

    @Override
    public void handleLogonRej(GMDLogOnRejMsg gmdLogOnRejMsg) {

    }

    @Override
    public void handleBasketQuoteMsg(GMDBasketQuoteMsg gmdBasketQuoteMsg) {

    }

    @Override
    public void handlePassThruMsg(GMDPassThruMsg gmdPassThruMsg) {

    }

    @Override
    public void handleSnapshotCompleteMsg(GMDSnpshotCompleteNotification gmdSnpshotCompleteNotification) {

    }

    @Override
    public void handleEnhancedQuoteMsg(GMDEnhancedQuoteMsg gmdEnhancedQuoteMsg) {

    }

    @Override
    public void handleClosingTradeSummaryMsg(GMDClosingTradeSummaryMsg gmdClosingTradeSummaryMsg) {

    }

    @Override
    public void handleLULDBandMsg(com.citi.gmd.client.messages.component.GMDLULDBandMsg gmdluldBandMsg) {

    }

    @Override
    public void handleBookUpdate(GMDAbstractBook gmdAbstractBook) {

    }
}
