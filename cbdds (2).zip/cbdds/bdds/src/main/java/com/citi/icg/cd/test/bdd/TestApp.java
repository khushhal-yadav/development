package com.citi.icg.cd.test.bdd;

public interface TestApp {
	public enum AppLifecycle {
		STARTED, INITIALIZED, RUNNING, SHUTTINGDOWN, STOPPED
	};
	
	public static interface AppLifecycleListener {
		void onAppLifecycleEvent(AppLifecycle event); 
	};
	
	void start();

	void stop();

	boolean isInitialized();
	
	void subscribeToAppLifecycleEvents(AppLifecycleListener listener);
	
}
