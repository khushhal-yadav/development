package com.citi.icg.cd.test.bdd.threadpool.event;

import com.citi.icg.cd.test.bdd.queue.OutTestQueues;
import com.citi.icg.cd.threadpool.event.EventSession;
import com.citi.icg.cd.threadpool.event.InboundDispEvent;
import com.citi.icg.cd.threadpool.event.OutboundDispEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.datamodel.AbstractDataModel;

public class MockEventSession extends EventSession {
    private static final Logger logger = LoggerFactory.getLogger(MockEventSession.class);

    public void inbound(AbstractDataModel msg, String syncKey) {
        logger.info("INBOUNDMSG|{}", msg.toString());
        InboundDispEvent dispEvent = new InboundDispEvent(msg);
        dispEvent.setEventSession(this);
        inboundTP.submit(dispEvent, syncKey);
    }

    public void inbound(AbstractDataModel msg, String syncKey, long seqNo) {
        logger.info("INBOUNDMSG|{}|{}", seqNo, msg.toString());
        InboundDispEvent dispEvent = new InboundDispEvent(msg, seqNo);
        dispEvent.setEventSession(this);
        inboundTP.submit(dispEvent, syncKey);
    }

    public void outbound(AbstractDataModel executionReport, String syncKey) {
        OutboundDispEvent dispEvent = new OutboundDispEvent(executionReport, logger);
        dispEvent.setEventSession(this);
        outboundTP.submit(dispEvent, syncKey);
    }

    public void send(AbstractDataModel msgToSend) {
        publishToClient(msgToSend);
    }

    public void sendtoAct(AbstractDataModel msgToSend) {
        publishToCtrs(msgToSend);
    }

    private void publishToCtrs(AbstractDataModel msgToSend) {
        OutTestQueues.outTestQueues.publishCtrsOut(msgToSend);
    }

    private void publishToClient(AbstractDataModel msgToSend) {
        OutTestQueues.outTestQueues.publishFixOut(msgToSend);
    }

}
