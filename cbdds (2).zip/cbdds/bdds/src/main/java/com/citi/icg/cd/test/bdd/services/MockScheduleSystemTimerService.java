package com.citi.icg.cd.test.bdd.services;

import com.citi.icg.gc.Service;

public class MockScheduleSystemTimerService extends Service {

	protected MockScheduleSystemTimerService() {
		super(true);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean doService() {
		// TODO Auto-generated method stub
		setInitialized(true);
		return true;
	}

	@Override
	public String getServiceName() {
		// TODO Auto-generated method stub
		return MockScheduleSystemTimerService.class.getName();
	}

}
