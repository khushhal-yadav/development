package com.citi.icg.cd.test.bdd.utils;

public class MarketDataDTO {
	
	public enum TradingStatus{
		HALTED('f'),
		OPENED_OR_TRADE_RESUME('o');
		
		private char gmdStatus;

		public char getGmdStatus() {
			return gmdStatus;
		}
		TradingStatus(char gmdStatus){
			this.gmdStatus = gmdStatus;
		}		
	}
	public enum ShortSaleRestriction{
	    SHORT_SALE_RESTRICTION_ACTIVATED('1'),
	    SHORT_SALE_RESTRICTION_REMOVED('0'),
	    SHORT_SALE_RESTRICTION_NOT_CHANGED('\0');
		private char shortSaleCode;
	    public char getShortSaleCode() {
			return shortSaleCode;
		}

		public void setShortSaleCode(char shortSaleCode) {
			this.shortSaleCode = shortSaleCode;
		}

		ShortSaleRestriction(char shortSaleCode){
	    	this.shortSaleCode = shortSaleCode;
	    }
	    
	}
	private String symbol;
	private double bid;
	private double ask;
	private TradingStatus tradingStatus;
	private ShortSaleRestriction shortSaleRestriction;
	
	public ShortSaleRestriction getShortSaleRestriction() {
		return shortSaleRestriction;
	}
	public void setShortSaleRestriction(ShortSaleRestriction shortSaleRestriction) {
		this.shortSaleRestriction = shortSaleRestriction;
	}
	public TradingStatus getTradingStatus() {
		return tradingStatus;
	}
	public void setTradingStatus(TradingStatus tradingStatus) {
		this.tradingStatus = tradingStatus;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public double getBid() {
		return bid;
	}
	public void setBid(double bid) {
		this.bid = bid;
	}
	public double getAsk() {
		return ask;
	}
	public void setAsk(double ask) {
		this.ask = ask;
	}
	



}
