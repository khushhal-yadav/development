package com.citi.icg.cd.test.bdd.queue;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import software.chronicle.fix.datamodel.AbstractDataModel;

public class OutTestQueues {

    public static OutTestQueues outTestQueues = new OutTestQueues();

    private OutTestQueues() {}

    private LinkedBlockingQueue<AbstractDataModel> fixOutQueue = new LinkedBlockingQueue<>();
    private LinkedBlockingQueue<String> configMgrQueue = new LinkedBlockingQueue<>();
    private LinkedBlockingQueue<AbstractDataModel> emsOutQueue = new LinkedBlockingQueue<>();
    private LinkedBlockingQueue<AbstractDataModel> ctrsOutQueue = new LinkedBlockingQueue<>();

    public AbstractDataModel getFixOut() throws InterruptedException {
        return fixOutQueue.poll(10000,  TimeUnit.MILLISECONDS);
    }

    public void publishFixOut(AbstractDataModel msg){
        fixOutQueue.offer(msg);
    }
    public void purgeFixOutQueue(){
        fixOutQueue.clear();
    }

    public int getSizeFixOutQueue(){
        return fixOutQueue.size();
    }

    public String getConfigMgr() throws InterruptedException {
        return configMgrQueue.poll(10000,  TimeUnit.MILLISECONDS);
    }

    public void publishConfigMgr(String msg){
        configMgrQueue.offer(msg);
    }

    public void purgeConfigMgrQueue(){
        configMgrQueue.clear();
    }

    public int getSizeConfigMgrQueue(){
        return configMgrQueue.size();
    }

    public AbstractDataModel getEmsOut() throws InterruptedException {
        return emsOutQueue.poll(10000,  TimeUnit.MILLISECONDS);
    }

    public void publishEmsOut(AbstractDataModel msg){
        emsOutQueue.offer(msg);
    }

    public void purgeEmsOutQueue(){
        emsOutQueue.clear();
    }

    public int getSizeEmsOutQueue(){
        return emsOutQueue.size();
    }

    public AbstractDataModel getCtrsOut() throws InterruptedException {
        return ctrsOutQueue.poll(10000,  TimeUnit.MILLISECONDS);
    }

    public void publishCtrsOut(AbstractDataModel msg){
        ctrsOutQueue.offer(msg);
    }

    public void purgeCtrsOutQueue(){
        ctrsOutQueue.clear();
    }

    public int getSizeCtrsOutQueue(){
        return ctrsOutQueue.size();
    }
}
