package com.citi.icg.cd.test.bdd.utils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.citi.icg.cioidark.citifix.TagConstants;
import com.citi.icg.cioidark.citifix.message.ExecutionReport;
import com.citi.icg.cioidark.dto.CfgMgrEvent;
import com.citi.icg.cioidark.fix.CitiFixMessage;
import com.citi.icg.cioidark.fix.field.date.UtcTimestampFormatter;
import com.citi.icg.cioidark.idgen.IDGenerator;
import com.google.gson.Gson;
import cucumber.api.DataTable;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.datamodel.AbstractDataModel;

public class MessageUtilities {
	private final static Logger logger = LoggerFactory.getLogger(MessageUtilities.class);
	private static Gson gson = new Gson();

	public static CitiFixMessage getCitiFixMessage(String testMessage){
		com.citi.icg.cioidark.fix.CitiFixMessage msg = new com.citi.icg.cioidark.fix.CitiFixMessage(testMessage);
		return msg;
	}

	//update all order related updates 
	public static void updateOrderFields(CitiFixMessage msg){
		DateTime now = DateTime.now();
		int rand = (int) Math.random();
		//msg.setTag(TagConstants.CLORDID,IDGenerator.newID());
		msg.setTag(TagConstants.SENDINGTIME, DateTime.now());
		msg.setTag(TagConstants.TRANSACTTIME, DateTime.now());
		msg.setTag(TagConstants.SENDERCOMPID, "CFORE");
		msg.setTag(TagConstants.SENDERSUBID, "BLOCUAT");
		msg.setTag(TagConstants.TARGETCOMPID, "BLOCUAT");
		msg.setTag(TagConstants.SRCTARGETCOMPID, "BLOCUAT");
		
		if(msg.getTag(TagConstants.MSGTYPE).equals("")){
			msg.setTag(TagConstants.MSGTYPE, "D");	
		}
		
		if(msg.getTag(TagConstants.CUSTOMERSLANG).equals("")){
			msg.setTag(TagConstants.CUSTOMERSLANG, "CUSTSLANG"+ rand);	
		}
		else if(msg.getTag(TagConstants.CUSTOMERSLANG).equals("{EMPTY}")){
			msg.setTag(TagConstants.CUSTOMERSLANG, "");	
		}
		if(msg.getTag(TagConstants.TIMEINFORCE).equals("")){
			msg.setTag(TagConstants.TIMEINFORCE, 0);	
		}
		else if(msg.getTag(TagConstants.TIMEINFORCE).equals("{EMPTY}")){
			msg.setTag(TagConstants.TIMEINFORCE, "");	
		}
		
		msg.setTag(TagConstants.ORDTYPE, 2);


	}

    //update all order related updates
    public static String updateOrderFields(String msg){
        DateTime now = DateTime.now();
        int rand = (int) Math.random();
        //msg.setTag(TagConstants.CLORDID,IDGenerator.newID());
        msg = msg + TagConstants.SENDINGTIME + "=" + UtcTimestampFormatter.getInstance().fromDateTime(DateTime.now());
        msg = msg + (char) 0x01 + TagConstants.TRANSACTTIME + "=" + UtcTimestampFormatter.getInstance().fromDateTime(DateTime.now());
        msg = msg + (char) 0x01 + TagConstants.SENDERCOMPID + "=BLOCUAT";
        msg = msg + (char) 0x01 + TagConstants.SENDERSUBID + "=BLOCUAT";
        msg = msg + (char) 0x01 + TagConstants.TARGETCOMPID + "=CFORE";
        msg = msg + (char) 0x01 + TagConstants.SRCTARGETCOMPID + "=BLOCUAT";

        if(!msg.contains(TagConstants.CUSTOMERSLANG+"="))
            msg = msg + (char) 0x01 + TagConstants.CUSTOMERSLANG + "=CUSTSLANG" + rand;


       /* if(msg.getTag(TagConstants.CUSTOMERSLANG).equals("")){
            msg.setTag(TagConstants.CUSTOMERSLANG, "CUSTSLANG"+ rand);
        }
        else if(msg.getTag(TagConstants.CUSTOMERSLANG).equals("{EMPTY}")){
            msg.setTag(TagConstants.CUSTOMERSLANG, "");
        }*/
        if(!msg.contains(TagConstants.TIMEINFORCE+"="))
            msg = msg + (char) 0x01 + TagConstants.TIMEINFORCE + "=0";

       /* if(msg.getTag(TagConstants.TIMEINFORCE).equals("")){
            msg.setTag(TagConstants.TIMEINFORCE, 0);
        }
        else if(msg.getTag(TagConstants.TIMEINFORCE).equals("{EMPTY}")){
            msg.setTag(TagConstants.TIMEINFORCE, "");
        }*/

        if(!msg.contains(TagConstants.ORDTYPE+"="))
        	msg = msg + (char) 0x01 + TagConstants.ORDTYPE + "=2";

        if(!msg.contains(TagConstants.MSGTYPE+"=")) {
            msg = TagConstants.MSGSEQNUM + "=1234" + (char) 0x01 + msg;
            msg = TagConstants.MSGTYPE + "=D" + (char) 0x01 + msg;
        } else {
            int msgTypeInd = msg.indexOf(TagConstants.MSGTYPE + "=") + 5;
            msg = msg.substring(0, msgTypeInd) + TagConstants.MSGSEQNUM + "=1234" + (char) 0x01 + msg.substring(msgTypeInd, msg.length());
        }

        //msg.setTag(TagConstants.ORDTYPE, 2);

        msg = "8=FIX.4.4" + (char) 0x01 + "9=" + (msg.length() + 1) + (char) 0x01 + msg;

        msg = msg + (char) 0x01 + "10=000" + (char) 0x01;

        return msg;
    }
	
	//update all execution related updates
	public static void updateExecFields(ExecutionReport er){
		
	}
	
	public static String populateCitiFixString(List<String> header, List<String> values) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
		List<Integer> taglist = getTagList(header);
		Map<Integer, String> param = new LinkedHashMap<>();
		for (int rr = 0; rr < values.size(); rr++) {
			if (StringUtils.isNotEmpty(values.get(rr)))
				param.put(taglist.get(rr), values.get(rr));
		}
		return convertToFixMessage(param);
	}
	
	private static String convertToFixMessage(Map<Integer, String> param){			
		StringBuffer fixMsg = new StringBuffer();
		for (Entry<Integer, String> entry : param.entrySet()) {
			fixMsg.append(entry.getKey());
			fixMsg.append("=");
			fixMsg.append(entry.getValue());
			fixMsg.append("");				
		}			
		return fixMsg.toString();			
	}
	
	private static List<Integer> getTagList(List<String> header) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException {
		int k = header.size(); //size of each row in the expected result
		// get all the tag numbers from header row
		List<Integer> taglist = new ArrayList<Integer>();
		for (int j = 0; j < k; j++) {
			String tagname = header.get(j);
			if(tagname.equals("10565")){//hardcoded for now, until rob g comes back
				taglist.add(10565);
			}
			else if(tagname.equals("7491")){
				taglist.add(7491);
			}else if (tagname.equals("11319")){
				taglist.add(11319);
			}else if (tagname.equals("11328")){
				taglist.add(11328);
			}else if (tagname.equals("9600")){
					taglist.add(9600);				
			}else if (tagname.equals("10428")){
				taglist.add(10428);				
			}else{
				taglist.add((TagConstants.class.getField(tagname)).getInt(TagConstants.class));
			}
			
		}
		return taglist;

	}
	
	//
	public static void populateExpectedResultsMap(DataTable data, ScenarioMetaDataHolder erh) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException {
		//ScenarioMetaDataHolder  erh = new ScenarioMetaDataHolder();
		
		int n = data.raw().size();   //table size
		List<Integer> taglist = getTagList(data.topCells());
		erh.setTagList(taglist);
		 List<List<String>> expectedoutput = new ArrayList<List<String>>(15);
		//store expected result in same sequence  
		//[[ClOrdId, Side, Symbol, Price, Qty], [BLOCUAT_083:28365/2016-03-24-10:42, Buy, IBM, 120.00, 1000.00], [BLOCUAT_083:28365/2016-03-24-10:42, Buy, IBM, 120.00, 1000.00]]
		for (int i=1;i<n;i++){
			expectedoutput.add(data.raw().get(i));
		}
		erh.setExpectedResult(expectedoutput);
	}
	
	public static String extractInnerContentString(String msg, String start, String end){
		String updated = msg.replace(start, "")
		.replace(end, "");
		return updated;	
	}
	
/*	public static void addToInputIds(String id,ScenarioMetaDataHolder erh){
		erh.addToInputIds(id);
	}*/
	public static void doAssertion(ScenarioMetaDataHolder erh,CitiFixMessage actualoutput,int idx){
		
		List<Integer> tags = erh.getTagList();
		List<String> expected = erh.getExpectedResultByIndex(idx); //get expected result
		int pos =0;
		for(Integer i: tags){ //check for each tag
			String expectedresult = expected.get(pos);
			if(expectedresult.equals("{IGNORE}")){
				//ignore
			}else if(expectedresult.equals("{EMPTY}")){
				boolean aValue = actualoutput.getTag(i) == null || (actualoutput.getTag(i) != null && actualoutput.getTag(i).equals(""));
				Assert.assertTrue("RowInExpectedResult = " + (pos + 1) +  " Tag" +i, aValue);
			}
			else if (expectedresult.startsWith("{CONTAINS[")){
				String msg = MessageUtilities.extractInnerContentString(expectedresult, "{CONTAINS[", "]}");
				Assert.assertTrue(actualoutput.getTag(i).contains(msg));				
			}else if (expectedresult.equals("{NOT_EMPTY}")){
				Assert.assertTrue("RowInExpectedResult = " + (pos + 1) +  " Tag" +i, actualoutput.getTag(i)!=null && !actualoutput.getTag(i).equals(""));
			}else if (erh.hasTemplateId(expectedresult)){
				Assert.assertEquals("RowInExpectedResult = " + (pos + 1) +  " Tag" +i,erh.getTemplateId(expectedresult),actualoutput.getTag(i));
			}
			else{
				Assert.assertEquals("RowInExpectedResult = " + (pos + 1) +  " Tag" +i,expectedresult,actualoutput.getTag(i));
			}
			pos++;
		}
		
	}

	public static void doAssertion(ScenarioMetaDataHolder erh, AbstractDataModel actualoutput, int idx){

		List<Integer> tags = erh.getTagList();
		List<String> expected = erh.getExpectedResultByIndex(idx); //get expected result
		int pos =0;
		for(Integer i: tags){ //check for each tag
			String expectedresult = expected.get(pos);
			if(expectedresult.equals("{IGNORE}")){
				//ignore
			}else if(expectedresult.equals("{EMPTY}")){
				boolean aValue = actualoutput.getString(i) == null || (actualoutput.getString(i) != null && actualoutput.getString(i).equals(""));
				Assert.assertTrue("RowInExpectedResult = " + (pos + 1) +  " Tag" +i, aValue);
			}
			else if (expectedresult.startsWith("{CONTAINS[")){
				String msg = MessageUtilities.extractInnerContentString(expectedresult, "{CONTAINS[", "]}");
				Assert.assertTrue(actualoutput.getString(i).contains(msg));
			}else if (expectedresult.equals("{NOT_EMPTY}")){
				Assert.assertTrue("RowInExpectedResult = " + (pos + 1) +  " Tag" +i, actualoutput.getString(i)!=null && !actualoutput.getString(i).equals(""));
			}else if (erh.hasTemplateId(expectedresult)){
				Assert.assertEquals("RowInExpectedResult = " + (pos + 1) +  " Tag" +i,erh.getTemplateId(expectedresult),actualoutput.getString(i));
			}
			else{
				Assert.assertEquals("RowInExpectedResult = " + (pos + 1) +  " Tag" +i,expectedresult,actualoutput.getString(i));
			}
			pos++;
		}

	}
	//replaces all placeholder ids with actual ids.
	//This also takes care of matching anything previously replaced template with exact same id. 
	//useful feature in case of new/mod/cxl scenarios
	public static CitiFixMessage replaceAndTrackTemplateIds(String msg, ScenarioMetaDataHolder smd){
		Pattern p = Pattern.compile("\\{CLORDID(.*?)\\}");
		Matcher m = p.matcher(msg);
		StringBuffer sb = new StringBuffer();
		while (m.find()) {
			String replaced = m.group();
			if(smd.getTemplateId(replaced) != null){
				m.appendReplacement(sb, smd.getTemplateId(replaced));
			}else{
				String newid = IDGenerator.newID();
				m.appendReplacement(sb, newid);
				smd.putTemplateId(replaced, newid);
			}
		}
		m.appendTail(sb);
		return new CitiFixMessage(sb.toString());
	}

	//replaces all placeholder ids with actual ids.
	//This also takes care of matching anything previously replaced template with exact same id.
	//useful feature in case of new/mod/cxl scenarios
	public static String replaceAndTrackTemplateIdsForFix(String msg, ScenarioMetaDataHolder smd){
		Pattern p = Pattern.compile("\\{CLORDID(.*?)\\}");
		Matcher m = p.matcher(msg);
		StringBuffer sb = new StringBuffer();
		while (m.find()) {
			String replaced = m.group();
			if(smd.getTemplateId(replaced) != null){
				m.appendReplacement(sb, smd.getTemplateId(replaced));
			}else{
				String newid = IDGenerator.newID();
				m.appendReplacement(sb, newid);
				smd.putTemplateId(replaced, newid);
			}
		}
		m.appendTail(sb);
		return sb.toString();
	}
	
	public static void main(String args[]){
		String msg = "8=FIX.4.49=22535=D34=360849=CFORE50=BLOCUAT52=20160324-14:42:56.34356={CLORD2}11={CLORD1}21=338=10040=P54=155=EBAY60=20160324-14:42:56.343207=NASD455=19323196528=P7420=210270=710625=0.010626=1.010=112";
		ScenarioMetaDataHolder smd = new ScenarioMetaDataHolder();
		replaceAndTrackTemplateIds(msg,smd);
		String msg2 = "8=FIX.4.49=22535=D34=360849=CFORE50=BLOCUAT52=20160324-14:42:56.34356={CLORD3}11={CLORD2}21=338=10040=P54=155=EBAY60=20160324-14:42:56.343207=NASD455=19323196528=P7420=210270=710625=0.010626=1.010=112";
		replaceAndTrackTemplateIds(msg2,smd);
	}
	
	
	public static Map<String,String> unmarshalJsonMessage(String wireMessage)
	{
		CfgMgrEvent event = fromWireMessage(wireMessage);
		Map<String, String> map = event.getAttributes();
		return map;		
	}
	
	public static CfgMgrEvent fromWireMessage(String wireMessage) {
		CfgMgrEvent event = gson.fromJson(wireMessage, CfgMgrEvent.class);
		return event;
	}
	
	public static void doMapAssertion(Map<String,String> expected,Map<String,String> actual){
		expected.forEach((k,v)->{
			switch (k) {
	         case "alerttime":	 
	         case "disabledtime":
	         case "enabledtime":
	         case "orderid":
	             break;
	         default:
	        	 
	        	 if (expected.get(k).contains("Too Late to Cross with Opposite side order.")) {
	        		 
	        		 Assert.assertTrue(expected.get(k).contains("Too Late to Cross with Opposite side order."));
	        	 }
	        	 else {
		        	 Assert.assertEquals("expected "+ k +":"+expected.get(k) + " actual-" + actual.get(k),expected.get(k),actual.get(k));

	        	 }
	        	 break;
	     }
		});
	}
	
}
