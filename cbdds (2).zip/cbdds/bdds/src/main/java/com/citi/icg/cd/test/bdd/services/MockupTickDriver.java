package com.citi.icg.cd.test.bdd.services;

import com.citi.icg.cd.md.component.AbstractTickDriver;
import com.citi.icg.cd.md.domain.SymbolInfo;
import com.citi.icg.cd.md.enumeration.MarketDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class MockupTickDriver extends AbstractTickDriver implements ApplicationContextAware {

	private final static Logger logger = LoggerFactory.getLogger(MockupTickDriver.class);
	
	private ApplicationContext ctx; 
	
	@Override
	public boolean login() {
		logger.info("MOCKUPO GMD: Connected");
		return true;
	}

	@Override
	public boolean logout() {
		return true;
	}

	@Override
	public boolean subscribe(SymbolInfo symInfo) {
		return true;
	}

	@Override
	public boolean unsubscribe(String symbol) {
		return true;
	}

	@Override
	public MarketDataSource getMarketDataSource() {
		return MarketDataSource.GMD;
	}

	@Override
	public boolean getConnected() {
		return true;
	}

	@Override
	public void init() {
		
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		this.ctx = arg0;
	}

	@Override
	public void ignoreMDTicks(String symbol) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resumeMDTicks(String symbol) {
		// TODO Auto-generated method stub
		
	}

}
