package com.citi.icg.cd.test.bdd;

import java.util.Map.Entry;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.citi.icg.cd.test.bdd.cdark.AppContextProvider;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = {"classpath:features"}, 
	tags = "~@wip",
	//tags = "@testme",
	strict=true,
	glue = { "com.citi.icg.cd.config.test.bdd.steps" },
	//plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/report.html"})
	plugin = {
        "pretty",
        "html:target/cucumber-cioidark","json:target/cucumber-cioidark.json"
        
    })
public class TestRunner implements ApplicationContextAware {
	private static final Logger logger = LoggerFactory.getLogger(TestRunner.class);
	
	private ApplicationContext ctx;
	
	@BeforeClass
	public static void setup() {
		
		logger.info("Launching config.test process with following ENV configured:");
		for (Entry<Object, Object> entry : System.getProperties().entrySet()) {
			logger.info("{} => {}", entry.getKey(), entry.getValue());
		}
		
	}
	
	@AfterClass
	public static void destroy() {

		TestApp testApp = AppContextProvider.getApplicationContext().getBean(TestApp.class);
		logger.info("Shutting down config.test application");

		testApp.stop();
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		ctx = arg0;  
		
		TestApp testApplication = ctx.getBean(TestApp.class);
		
		if (! testApplication.isInitialized()) {
			logger.info("Initializing config.test application");
			testApplication.start();
		}
	}
}
