package com.citi.icg.cioidark.chronicle.messaging.queue;

public interface CtrsMessageIn {

}
