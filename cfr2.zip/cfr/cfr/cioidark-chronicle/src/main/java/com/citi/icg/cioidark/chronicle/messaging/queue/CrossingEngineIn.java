package com.citi.icg.cioidark.chronicle.messaging.queue;

import com.citi.icg.cioidark.chronicle.messaging.message.admin.AdminMessage;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;

public interface CrossingEngineIn {

    void newOrderSingle(NewOrderSingle newOrderSingle);

    void orderCancelRequest(OrderCancelRequest orderCancelRequest);

    void orderCancelReplaceRequest(OrderCancelReplaceRequest orderCancelReplaceRequest);

    void marketData(MarketDataMessage marketDataMessage);

    void adminMessage(AdminMessage adminMessage);
}
