package com.citi.icg.cioidark.chronicle.messaging.message.gmd;

import java.util.Objects;
import java.util.Optional;

import net.openhft.chronicle.wire.AbstractMarshallable;

public class GMDInstrumentTradingStatusMsg extends AbstractMarshallable{

    final private String symbol;
    final private int marketDataStatus;
    final private char regulatoryTradingStatus;
    final private char regShoInd;
    final private long gmdSendTimeStamp;

    public GMDInstrumentTradingStatusMsg(String symbol, int marketDataStatus,
                                         char regulatoryTradingStatus, char regShoInd,
                                         long gmdSendTimeStamp) {
        this.symbol = symbol;
        this.marketDataStatus = marketDataStatus;
        this.regulatoryTradingStatus = regulatoryTradingStatus;
        this.regShoInd = regShoInd;
        this.gmdSendTimeStamp = gmdSendTimeStamp;
    }

    public String getSymbol() {
        return symbol;
    }

    public int getMarketDataStatus() {
        return marketDataStatus;
    }

    public char getRegulatoryTradingStatus() {
        return regulatoryTradingStatus;
    }

    public char getRegShoInd() {
        return regShoInd;
    }

    public long getGmdSendTimeStamp() {
        return gmdSendTimeStamp;
    }

    @Override
    public boolean equals(Object obj) {
        return Optional.ofNullable(obj)
                .filter(GMDInstrumentTradingStatusMsg.class::isInstance)
                .map(GMDInstrumentTradingStatusMsg.class::cast)
                .filter(o -> Objects.equals(this.symbol, o.symbol))
                .filter(o -> Objects.equals(this.marketDataStatus, o.marketDataStatus))
                .filter(o -> Objects.equals(this.regulatoryTradingStatus, o.regulatoryTradingStatus))
                .filter(o -> Objects.equals(this.regShoInd, o.regShoInd))
                .filter(o -> Objects.equals(this.gmdSendTimeStamp, o.gmdSendTimeStamp))
                .isPresent();
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), symbol, marketDataStatus, regulatoryTradingStatus,
                regShoInd, gmdSendTimeStamp);
    }
}
