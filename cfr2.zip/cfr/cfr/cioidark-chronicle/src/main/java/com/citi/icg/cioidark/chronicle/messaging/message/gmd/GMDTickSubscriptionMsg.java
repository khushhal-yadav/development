package com.citi.icg.cioidark.chronicle.messaging.message.gmd;

import java.util.Objects;
import java.util.Optional;

import net.openhft.chronicle.wire.AbstractMarshallable;

public class GMDTickSubscriptionMsg extends AbstractMarshallable {

    private String bookSymbol;
    private String marketDataSymbol;
    private boolean subscribe;

    public GMDTickSubscriptionMsg() {}

    public GMDTickSubscriptionMsg(String bookSymbol, String marketDataSymbol, boolean subscribe) {
        this.bookSymbol = bookSymbol;
        this.marketDataSymbol = marketDataSymbol;
        this.subscribe = subscribe;
    }

    public String getBookSymbol() {
        return bookSymbol;
    }

    public String getMarketDataSymbol() {
        return marketDataSymbol;
    }

    public boolean isSubscribe() {
        return subscribe;
    }

    @Override
    public boolean equals(Object obj) {
        return Optional.ofNullable(obj)
                .filter(GMDTickSubscriptionMsg.class::isInstance)
                .map(GMDTickSubscriptionMsg.class::cast)
                .filter(o -> Objects.equals(this.bookSymbol, o.bookSymbol))
                .filter(o -> Objects.equals(this.marketDataSymbol, o.marketDataSymbol))
                .filter(o -> Objects.equals(this.subscribe, o.subscribe))
                .isPresent();
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), bookSymbol, marketDataSymbol, subscribe);
    }
}
