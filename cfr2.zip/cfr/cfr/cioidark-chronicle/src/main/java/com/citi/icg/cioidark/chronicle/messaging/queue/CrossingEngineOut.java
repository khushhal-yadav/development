package com.citi.icg.cioidark.chronicle.messaging.queue;

import com.citi.icg.cioidark.chronicle.messaging.message.admin.AbstractBookAttributes;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.AbstractSystemProperty;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.DisableClient;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.IgnoreMDTick;
import com.citi.icg.cioidark.chronicle.messaging.message.alert.Alert;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import software.chronicle.fix.codegen.messages.ExecutionReport;

public interface CrossingEngineOut {
    void executionReport(ExecutionReport executionReport);

    void bookAttributes(AbstractBookAttributes bookAttributes);

    void systemProperties(AbstractSystemProperty systemProperties);

    void alert(Alert alert);

    void disableClient(DisableClient disableClient);

    void marketDataMessage(MarketDataMessage marketDataMessage);

    void subscribeTick(GMDTickSubscriptionMsg gmdTickSubscriptionMsg);

    void ignoreMDTick(IgnoreMDTick ignoreMDTick);
}
