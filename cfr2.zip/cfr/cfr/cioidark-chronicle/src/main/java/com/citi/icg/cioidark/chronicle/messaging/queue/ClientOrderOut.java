package com.citi.icg.cioidark.chronicle.messaging.queue;

import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.OrderCancelReject;

public interface ClientOrderOut {
    void clientExecutionReport(ExecutionReport executionReport);
    void clientOrderCancelReject(OrderCancelReject orderCancelReject);
}
