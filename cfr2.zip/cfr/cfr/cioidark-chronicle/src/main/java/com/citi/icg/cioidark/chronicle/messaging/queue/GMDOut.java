package com.citi.icg.cioidark.chronicle.messaging.queue;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;

public interface GMDOut {

    void marketData(MarketDataMessage marketDataMessage);
}
