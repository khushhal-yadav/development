package com.citi.icg.cioidark.chronicle.messaging.message.admin;

import net.openhft.chronicle.wire.AbstractMarshallable;

public class IgnoreMDTick extends AbstractMarshallable {

    private final String symbol;
    private final boolean ignore;

    public IgnoreMDTick(final String symbol, final boolean ignore) {
        this.symbol = symbol;
        this.ignore = ignore;
    }

    public String getSymbol() {
        return symbol;
    }

    public boolean isIgnore() {
        return ignore;
    }
}
