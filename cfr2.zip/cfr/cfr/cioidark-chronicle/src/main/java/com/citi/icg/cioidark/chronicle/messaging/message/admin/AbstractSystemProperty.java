package com.citi.icg.cioidark.chronicle.messaging.message.admin;

import java.util.Objects;

import net.openhft.chronicle.wire.AbstractMarshallable;
import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractSystemProperty extends AbstractMarshallable {
    private static final Logger logger = LoggerFactory.getLogger(AbstractSystemProperty.class.getName());

    private final static String env = System.getProperty("preferences.env");

    private static String propertyFiles;
    protected transient CompositeConfiguration systemProperties;
    protected static String chronicleConfigFile = "services.yaml";

    //only construction injection of properties, *ABSOLUTELY NO SETTERS
    public AbstractSystemProperty(String propertyFiles) throws ConfigurationException {
        this.propertyFiles = propertyFiles;
        systemProperties = new CompositeConfiguration();
        if (Objects.isNull(getPropertyFiles()))
            throw new ConfigurationException();
        for (String propertyFile : getPropertyFiles().split(";")) {
            systemProperties.addConfiguration(new PropertiesConfiguration(propertyFile));
        }
        logger.info("AbstractSystemProperty loaded :{}", this);
    }

    private static String getPropertyFiles() {
        return propertyFiles;
    }

    public final static String getChronicleConfigFile() {
        return chronicleConfigFile;
    }

    protected static String getPropertyFileNames(final String propertyFileName) {
        if (Objects.isNull(env))
            return propertyFileName;

        return propertyFileName + ";" + env + ".properties";
    }

    @Override
    public String toString() {
        return "AbstractSystemProperty{" +
                "propertyFiles='" + propertyFiles + '\'' +
                '}';
    }
}
