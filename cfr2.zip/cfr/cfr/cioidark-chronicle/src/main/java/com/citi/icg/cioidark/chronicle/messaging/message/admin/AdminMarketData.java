package com.citi.icg.cioidark.chronicle.messaging.message.admin;

import net.openhft.chronicle.wire.AbstractMarshallable;

public class AdminMarketData extends AbstractMarshallable {
	private double bid;
	private double offer;

	public AdminMarketData(double bid, double offer ){
		this.bid = bid;
		this.offer = offer;
	}
	
	public double getBid() {
		return bid;
	}
	
	public void setBid(double bid) {
		this.bid = bid;
	}
	
	public double getOffer() {
		return offer;
	}
	
	public void setOffer(double offer) {
		this.offer = offer;
	}
	
}
