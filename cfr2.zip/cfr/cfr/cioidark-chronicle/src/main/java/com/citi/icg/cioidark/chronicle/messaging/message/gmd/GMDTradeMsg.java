package com.citi.icg.cioidark.chronicle.messaging.message.gmd;

import java.util.Objects;
import java.util.Optional;

public class GMDTradeMsg {

    final private String symbol;
    final private String tradeCondString;
    final private char side;
    final private double tradeSize;
    final private double tradePrice;

    public GMDTradeMsg(String symbol, String tradeCondString, char side,
                       double tradeSize, double tradePrice) {
        this.symbol = symbol;
        this.tradeCondString = tradeCondString;
        this.side = side;
        this.tradeSize = tradeSize;
        this.tradePrice = tradePrice;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getTradeCondString() {
        return tradeCondString;
    }

    public char getSide() {
        return side;
    }

    public double getTradeSize() {
        return tradeSize;
    }

    public double getTradePrice() {
        return tradePrice;
    }

    @Override
    public boolean equals(Object obj) {
        return Optional.ofNullable(obj)
                .filter(GMDTradeMsg.class::isInstance)
                .map(GMDTradeMsg.class::cast)
                .filter(o -> Objects.equals(this.symbol, o.symbol))
                .filter(o -> Objects.equals(this.tradeCondString, o.tradeCondString))
                .filter(o -> Objects.equals(this.side, o.side))
                .filter(o -> Objects.equals(this.tradeSize, o.tradeSize))
                .filter(o -> Objects.equals(this.tradePrice, o.tradePrice))
                .isPresent();
    }

    @Override
    public int hashCode() {

        return Objects.hash(symbol, tradeCondString, side, tradeSize, tradePrice);
    }
}
