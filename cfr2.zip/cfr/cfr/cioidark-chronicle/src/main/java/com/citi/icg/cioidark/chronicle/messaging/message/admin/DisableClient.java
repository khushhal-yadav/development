package com.citi.icg.cioidark.chronicle.messaging.message.admin;

import net.openhft.chronicle.wire.AbstractMarshallable;

public class DisableClient extends AbstractMarshallable {
    private String clientId;
    private String symbol;
    private boolean isDisabled;
    private long disableTime;
    private long enableTime;
    private String user;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public boolean isDisabled() {
        return isDisabled;
    }

    public void setDisabled(boolean isDisabled) {
        this.isDisabled = isDisabled;
    }

    public long getDisableTime() {
        return disableTime;
    }

    public void setDisableTime(long disableTime) {
        this.disableTime = disableTime;
    }

    public long getEnableTime() {
        return enableTime;
    }

    public void setEnableTime(long enableTime) {
        this.enableTime = enableTime;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }


}
