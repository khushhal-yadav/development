package com.citi.icg.cioidark.chronicle;

import com.citi.icg.cioidark.chronicle.service.ChronicleInitializerService;
import com.citi.icg.cioidark.chronicle.messaging.message.admin.AbstractSystemProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StartService {

    private static final Logger logger = LoggerFactory.getLogger(StartService.class);

    public static void main(String[] args) {
        try {
            ChronicleInitializerService
                    .initialize(new String[]{AbstractSystemProperty.getChronicleConfigFile(), args[0], args[1]});
        } catch (Exception exception) {
            logger.error("ITRSALERT| Error starting service {} with {}", args[0], exception.getMessage());
            System.exit(1);
        }

    }
}
