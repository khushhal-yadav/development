package com.citi.icg.cioidark.chronicle.messaging.message.gmd;

import java.util.Objects;
import java.util.Optional;

import net.openhft.chronicle.wire.AbstractMarshallable;

public class GMDQuoteMsg extends AbstractMarshallable {

    final private String symbol;
    final private double bidPx;
    final private double offerPx;
    final private double bidSize;
    final private double offerSize;
    final private long gmdSendTimeStamp;

    public GMDQuoteMsg(String symbol, double bidPx, double offerPx, double bidSize,
                       double offerSize, long gmdSendTimeStamp) {
        this.symbol = symbol;
        this.bidPx = bidPx;
        this.offerPx = offerPx;
        this.bidSize = bidSize;
        this.offerSize = offerSize;
        this.gmdSendTimeStamp = gmdSendTimeStamp;
    }

    public String getSymbol() {
        return symbol;
    }

    public double getBidPx() {
        return bidPx;
    }

    public double getOfferPx() {
        return offerPx;
    }

    public double getBidSize() {
        return bidSize;
    }

    public double getOfferSize() {
        return offerSize;
    }

    public long getGmdSendTimeStamp() {
        return gmdSendTimeStamp;
    }

    @Override
    public boolean equals(Object obj) {
        return Optional.ofNullable(obj)
                .filter(GMDQuoteMsg.class::isInstance)
                .map(GMDQuoteMsg.class::cast)
                .filter(o -> Objects.equals(this.symbol, o.symbol))
                .filter(o -> Objects.equals(this.bidPx, o.bidPx))
                .filter(o -> Objects.equals(this.offerPx, o.offerPx))
                .filter(o -> Objects.equals(this.bidSize, o.bidSize))
                .filter(o -> Objects.equals(this.offerSize, o.offerSize))
                .filter(o -> Objects.equals(this.gmdSendTimeStamp, o.gmdSendTimeStamp))
                .isPresent();
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), symbol, bidPx, offerPx, bidSize, offerSize,
                gmdSendTimeStamp);
    }
}
