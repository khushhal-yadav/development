package com.citi.icg.cioidark.chronicle.messaging.message.alert;

import com.citi.icg.cioidark.enumeration.alert.AlertCategory;
import com.citi.icg.cioidark.enumeration.alert.AlertLevel;
import com.citi.icg.cioidark.enumeration.alert.AlertStatus;
import net.openhft.chronicle.wire.AbstractMarshallable;

public class Alert extends AbstractMarshallable {
    private final String symbol;
    private String orderId;
    private String clOrderId;
    private String newalerttime;
    private String msg;
    private AlertStatus status;
    private String updatedBy;
    private AlertLevel level;
    private String slang;
    private final AlertCategory alertType;

    public Alert(String symbol, AlertCategory alertType) {
        super();
        this.symbol = symbol;
        this.alertType = alertType;
    }

    public String getSymbol() {
        return symbol;
    }

    public AlertCategory getAlertType() {
        return alertType;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getClOrderId() {
        return clOrderId;
    }

    public void setClOrderId(String clOrderId) {
        this.clOrderId = clOrderId;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public AlertStatus getStatus() {
        return status;
    }

    public void setStatus(AlertStatus status) {
        this.status = status;
    }

    public AlertLevel getLevel() {
        return level;
    }

    public void setLevel(AlertLevel level) {
        this.level = level;
    }

    public String getSlang() {
        return slang;
    }

    public void setSlang(String slang) {
        this.slang = slang;
    }

    public String getNewalerttime() {
        return newalerttime;
    }

    public void setNewalerttime(String newalerttime) {
        this.newalerttime = newalerttime;
    }

}
