package com.citi.icg.cioidark.chronicle.messaging.queue;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;

public interface OMSIn {

    void clientNewOrderSingle(NewOrderSingle newOrderSingle);

    void clientOrderCancelRequest(OrderCancelRequest orderCancelRequest);

    void clientOrderCancelReplaceRequest(OrderCancelReplaceRequest orderCancelReplaceRequest);

    void executionReport(ExecutionReport executionReport);

    void marketData(MarketDataMessage marketDataMessage);
}

