package com.citi.icg.cioidark.chronicle.messaging.message.admin;

import net.openhft.chronicle.wire.AbstractMarshallable;

public abstract class AbstractBookAttributes extends AbstractMarshallable {
}
