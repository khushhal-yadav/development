package com.citi.icg.cioidark.chronicle.messaging.message.gmd;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;

import com.citi.icg.cioidark.util.DateUtil;
import net.openhft.chronicle.wire.AbstractMarshallable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MarketDataMessage extends AbstractMarshallable {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getSimpleName());


    private Tick tick;
    private String key = "";
    private static final double roundLotSize = Double.parseDouble(System.getProperty(("cititicker.inside.lotsize"), "100"));
    private static final double timelinessSecond = Double.parseDouble(System.getProperty("SrcStaleTimeInSeconds", "1"));
    private SecurityMarketData securityMarketData = null;
    private double upperLimit;
    private double lowerLimit;
    private Date LULDTime;
    private boolean isStatusEvent = false;
    private boolean updateBook;
    private boolean crossAttempt;
    private long sequenceId = 0L;

    public MarketDataMessage() {
    }

    public MarketDataMessage(double bidPx, double askPx, String symbol, long srcTime) {
        tick = new Tick(symbol, bidPx, askPx, 1, 1, srcTime);
        key = symbol;
    }

    public MarketDataMessage(double bidPx, double askPx, double bidSize, double askSize, long srcTime, String symbol) {
        tick = new Tick(symbol, bidPx, askPx, new Double(bidSize / roundLotSize).intValue(), new Double(askSize / roundLotSize).intValue(), srcTime);
        key = symbol;
    }

    public double getAskPx() {
        if (tick == null)
            return -1.0;
        return tick.getAskPx();
    }

    public double getBidPx() {
        if (tick == null)
            return -1.0;
        return tick.getBidPx();
    }

    public SecurityMarketData getSecurityMarketData() {
        return this.securityMarketData;
    }

    public void setSecurityMarketData(SecurityMarketData securityMarketData) {
        this.securityMarketData = securityMarketData;
    }

    public boolean isStatusEvent() {
        return isStatusEvent;
    }

    public void setStatusEvent(boolean isStatusEvent) {
        this.isStatusEvent = isStatusEvent;
    }

    public long getMarketDataArrivedTime() {
        if (tick == null)
            return System.currentTimeMillis();
        return tick.getArrivedTime();
    }

    public void setMarketDataArrivedTime(long time) {
        tick.setArrivedTime(time);
    }

    public int getStatus() {
        if (tick == null)
            return -1;
        return tick.getStatus();
    }

    public void setStatus(int s) {
        tick.setStatus(s);
    }

    public char getShortSaleRestricted() {
        return tick.getShortSaleRestricted();
    }

    public void setShortSaleRestricted(char shortSaleRestricted) {
        tick.setShortSaleRestricted(shortSaleRestricted);
    }

    public double getUpperLimit() {
        return upperLimit;
    }

    public void setUpperLimit(double upperLimit) {
        this.upperLimit = upperLimit;
    }

    public double getLowerLimit() {
        return lowerLimit;
    }

    public void setLowerLimit(double lowerLimit) {
        this.lowerLimit = lowerLimit;
    }

    public void setLULDTime(Date time) {
        this.LULDTime = time;
    }

    public Date getLULDTime() {
        return LULDTime;
    }

    public String getSymbol() {
        return tick.getTicker();
    }

    public boolean isUpdateBook() {
        return updateBook;
    }

    public void setUpdateBook(boolean updateBook) {
        this.updateBook = updateBook;
    }

    public boolean isCrossAttempt() {
        return crossAttempt;
    }

    public void setCrossAttempt(boolean crossAttempt) {
        this.crossAttempt = crossAttempt;
    }

    public long getSequenceId() {
        return sequenceId;
    }

    public void setSequenceId(long sequenceId) {
        this.sequenceId = sequenceId;
    }

    public long getSourceTimeInLong() {
        if (tick == null)
            return -1;
        return tick.getSrcTime();
    }

    public boolean isSourceStale() {
        long currentTime = System.currentTimeMillis();
        long srcTimeInMilli = this.tick.getSrcTime() / 1000000;
        long timeDeltaInMilliseconds = currentTime - srcTimeInMilli;
        double timelinessMilliSecond = timelinessSecond * 1000;

        if (timeDeltaInMilliseconds > timelinessMilliSecond) {
            logger.warn(this.getTick().getTicker() + "|Src time > |" + timelinessSecond + " second|" + DateUtil.getTime(new Date(srcTimeInMilli)));
            logger.warn(this.getTick().getTicker() + "|LTACHECK|MD|STALE|" + timeDeltaInMilliseconds + " ms");
            return true;
        } else
            return false;
    }

    private Tick getTick() {
        return tick;
    }

    public String toString() {
        StringBuilder result = new StringBuilder();
        result.append("|NBBO");
        result.append("|Symbol:");
        if (this.isStatusEvent()) {
            result.append(this.getSymbol()).append("|ArrivedTime:").append(this.getTime()).append("|LowerBand:").append(getLowerLimit()).append("|UpperLimit:").append(getUpperLimit());
        } else {
            result.append(this.getSymbol()).append("|Bid:").append(this.getBidPx()).append("|Ask:").append(this.getAskPx()).append("|ArrivedTime:").append(this.getMarketDataArrivedTime()).append("|SrcTime:").append(this.getSourceTimeInLong());
        }

        result.append("|UpdateBook:").append(this.isUpdateBook()).append("|CrossAttempt").append(this.isCrossAttempt())
                .append("|TickStatus:").append(this.getStatus()).append("|ShortSaleRestricted:").append(this.getShortSaleRestricted())
                .append("|SecurityMarketData").append(this.getSecurityMarketData());


        return result.toString();
    }

    public String getTime() {
        StringBuilder sb = new StringBuilder();
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(getMarketDataArrivedTime());
        sb.append(cal.get(Calendar.HOUR_OF_DAY)).append(":");
        sb.append(cal.get(Calendar.MINUTE)).append(":");
        sb.append(cal.get(Calendar.SECOND)).append(":");
        sb.append(cal.get(Calendar.MILLISECOND));
        return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
        return Optional.ofNullable(obj)
                .filter(MarketDataMessage.class::isInstance)
                .map(MarketDataMessage.class::cast)
                .filter(o -> Objects.equals(this.tick, o.tick))
                .filter(o -> Objects.equals(this.key, o.key))
                .filter(o -> Objects.equals(this.securityMarketData, o.securityMarketData))
                .filter(o -> Objects.equals(this.upperLimit, o.upperLimit))
                .filter(o -> Objects.equals(this.lowerLimit, o.lowerLimit))
                .filter(o -> Objects.equals(this.isStatusEvent, o.isStatusEvent))
                .filter(o -> Objects.equals(this.updateBook, o.updateBook))
                .filter(o -> Objects.equals(this.crossAttempt, o.crossAttempt))
                .filter(o -> Objects.equals(this.sequenceId, o.sequenceId))
                .isPresent();
    }

    @Override
    public int hashCode() {
        return Objects.hash(tick, key, securityMarketData, upperLimit, lowerLimit,
                isStatusEvent, updateBook, crossAttempt, sequenceId);
    }


}
