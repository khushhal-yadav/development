package com.citi.icg.cioidark.chronicle.messaging.queue;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReject;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;

public interface OMSOut {

    void newOrderSingle(NewOrderSingle newOrderSingle);

    void orderCancelRequest(OrderCancelRequest orderCancelRequest);

    void orderCancelReplaceRequest(OrderCancelReplaceRequest orderCancelReplaceRequest);

    void executionReport(ExecutionReport executionReport);

    void subscribeTick(GMDTickSubscriptionMsg gmdTickSubscriptionMsg);

    void clientExecutionReport(ExecutionReport executionReport);

    void clientOrderCancelReject(OrderCancelReject orderCancelReject);
}
