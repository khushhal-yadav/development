package com.citi.icg.cioidark.chronicle.messaging.queue;

import com.citi.icg.cioidark.chronicle.messaging.message.admin.AdminMessage;

public interface AdminCommandOut {

    void adminMessage(AdminMessage adminMessage);
}
