package com.citi.icg.cioidark.chronicle.messaging.message.admin;

import java.util.HashMap;
import java.util.List;

import net.openhft.chronicle.wire.AbstractMarshallable;

public class AdminMessage extends AbstractMarshallable {
	private AdminCommand command;
	private String symbol;
	private String instance;
	private String orderID;
	private HashMap<String,String> cxlOrdIdMap;
	private String delimitedCxlOrdId;
	private String crossID;
	private String clOrdID;
	private String execID;
	private double totalCrossQty;
	private double lastPx;
	private String account;
	private String sessionID;
	private int clientID ;
	private String symbolRange;
	private String mpid;
	private String soeId;

	private AdminMarketData marketData;
	private List<Property> properties;
	private AdminLULD LULD;

    public AdminMessage() {}

    public AdminMessage(AdminCommand command){
		this.command = command;
	}

	public void setProperties(List<Property> properties) {
		this.properties = properties;
	}
	
	public AdminCommand getCommand() {
		return command;
	}
	public void setCommand(AdminCommand command) {
		this.command = command;
	}
	
	public AdminMarketData getMarketData() {
		return marketData;
	}

	public void setMarketData(AdminMarketData marketData) {
		this.marketData = marketData;
	}
	
	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getInstance() {
		return instance;
	}

	public void setInstance(String instance) {
		this.instance = instance;
	}

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public List<Property> getProperties() {
		return properties;
	}

	public String getClOrdID() {
		return clOrdID;
	}

	public void setClOrdID(String clOrdID) {
		this.clOrdID = clOrdID;
	}

	public double getTotalCrossQty() {
		return totalCrossQty;
	}

	public void setTotalCrossQty(double totalCrossQty) {
		this.totalCrossQty = totalCrossQty;
	}

	public double getLastPx() {
		return lastPx;
	}

	public void setLastPx(double lastPx) {
		this.lastPx = lastPx;
	}

	public String getCrossID() {
		return crossID;
	}

	public void setCrossID(String crossID) {
		this.crossID = crossID;
	}

	public void setExecID(String execID) {
		this.execID = execID;
	}

	public String getExecID() {
		return execID;
	}
    
	public String getAccount() {
		return account;
	}
	
	public void setAccount(String account) {
		this.account = account;
	}
	
	public AdminLULD getLULD() {
		return LULD;
	}

	public void setLULD(AdminLULD lULD) {
		LULD = lULD;
	}
	
	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
	
	public int getClientID() {
		return clientID;
	}

	public void setClientID(int clientID) {
		this.clientID = clientID;
	}

	public String getSymbolRange() {
		return symbolRange;
	}

	public void setSymbolRange(String symbolRange) {
		this.symbolRange = symbolRange;
	}

	public String getMpid() {
		return mpid;
	}

	public void setMpid(String mpid) {
		this.mpid = mpid;
	}

	public String getDelimitedCxlOrdId() {
		return delimitedCxlOrdId;
	}

	public void setDelimitedCxlOrdId(String delimitedCxlOrdId) {
		this.delimitedCxlOrdId = delimitedCxlOrdId;
	}

	public HashMap<String,String> getCxlOrdIdMap() {
		return cxlOrdIdMap;
	}

	public void setCxlOrdIdMap(HashMap<String,String> cxlOrdIdMap) {
		this.cxlOrdIdMap = cxlOrdIdMap;
	}

	public String getSoeId() {
		return soeId;
	}

	public void setSoeId(String soeId) {
		this.soeId = soeId;
	}

	@Override
	public String toString() {
		return "AdminMessage [command=" + command + ", symbol=" + symbol + ", instance=" + instance + ", orderID="
				+ orderID + ", cxlOrdIdMap=" + cxlOrdIdMap + ", delimitedCxlOrdId=" + delimitedCxlOrdId + ", crossID="
				+ crossID + ", clOrdID=" + clOrdID + ", execID=" + execID + ", totalCrossQty=" + totalCrossQty
				+ ", lastPx=" + lastPx + ", account=" + account + ", sessionID=" + sessionID + ", clientID=" + clientID
				+ ", symbolRange=" + symbolRange + ", mpid=" + mpid + ", soeId=" + soeId + ", marketData=" + marketData
				+ ", properties=" + properties + ", LULD=" + LULD + "]";
	}

	

}
