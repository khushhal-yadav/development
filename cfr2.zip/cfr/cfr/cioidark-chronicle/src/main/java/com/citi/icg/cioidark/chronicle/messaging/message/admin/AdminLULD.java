package com.citi.icg.cioidark.chronicle.messaging.message.admin;

import net.openhft.chronicle.wire.AbstractMarshallable;

public class AdminLULD extends AbstractMarshallable {
	private double lowerLimit;
	private double upperLimit;
	
	public AdminLULD(double lowerLimit, double upperLimit){
		this.lowerLimit = lowerLimit;
		this.upperLimit = upperLimit;
	}
	
	
	public double getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(double lowerLimit) {
		this.lowerLimit = lowerLimit;
	}
	public double getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(double upperLimit) {
		this.upperLimit = upperLimit;
	}
}
