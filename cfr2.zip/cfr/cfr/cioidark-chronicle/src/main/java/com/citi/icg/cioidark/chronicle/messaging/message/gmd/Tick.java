package com.citi.icg.cioidark.chronicle.messaging.message.gmd;

import java.util.Objects;
import java.util.Optional;

import com.citi.icg.cioidark.enumeration.ShortSaleRestriction;
import net.openhft.chronicle.wire.AbstractMarshallable;

public class Tick extends AbstractMarshallable {

    private final String ticker;
    private final double bidPx;
    private final double askPx;
    private final double bidSize;
    private final double askSize;
    private final long srcTime;
    private long arrivedTime;
    private int status = -1;
    private char shortSaleRestricted = ShortSaleRestriction.SHORT_SALE_RESTRICTION_NOT_CHANGED.value();

    public Tick(final String ticker, final double bidPx, final double askPx, final double bidSize, final double askSize, final long srcTime) {
        this.ticker = ticker;
        this.bidPx = bidPx;
        this.askPx = askPx;
        this.bidSize = bidSize;
        this.askSize = askSize;
        this.srcTime = srcTime;
    }

    public String getTicker() {
        return ticker;
    }

    public double getBidPx() {
        return bidPx;
    }

    public double getAskPx() {
        return askPx;
    }

    public long getSrcTime() {
        return srcTime;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public char getShortSaleRestricted() {
        return shortSaleRestricted;
    }

    public void setShortSaleRestricted(char shortSaleRestricted) {
        this.shortSaleRestricted = shortSaleRestricted;
    }

    public long getArrivedTime() {
        return arrivedTime;
    }

    public void setArrivedTime(long arrivedTime) {
        this.arrivedTime = arrivedTime;
    }

    @Override
    public boolean equals(Object obj) {
        return Optional.ofNullable(obj)
                .filter(Tick.class::isInstance)
                .map(Tick.class::cast)
                .filter(o -> Objects.equals(this.ticker, o.ticker))
                .filter(o -> Objects.equals(this.bidPx, o.bidPx))
                .filter(o -> Objects.equals(this.askPx, o.askPx))
                .filter(o -> Objects.equals(this.bidSize, o.bidSize))
                .filter(o -> Objects.equals(this.askSize, o.askSize))
                .filter(o -> Objects.equals(this.status, o.status))
                .filter(o -> Objects.equals(this.srcTime, o.srcTime))
                .isPresent();
    }

    @Override
    public int hashCode() {
        return Objects.hash(ticker, bidPx, askPx, bidSize, askSize, status, srcTime);
    }

}
