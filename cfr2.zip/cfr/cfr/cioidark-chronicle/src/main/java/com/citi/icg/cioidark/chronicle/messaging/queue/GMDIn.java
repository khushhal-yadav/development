package com.citi.icg.cioidark.chronicle.messaging.queue;

import com.citi.icg.cioidark.chronicle.messaging.message.admin.IgnoreMDTick;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;

public interface GMDIn {

    void subscribeTick(GMDTickSubscriptionMsg gmdTickSubscriptionMsg);
    void ignoreMDTick(IgnoreMDTick ignoreMDTick);

}
