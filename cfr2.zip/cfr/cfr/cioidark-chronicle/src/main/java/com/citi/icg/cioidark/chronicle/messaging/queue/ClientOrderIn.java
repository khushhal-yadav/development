package com.citi.icg.cioidark.chronicle.messaging.queue;

import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;

public interface ClientOrderIn {

    void clientNewOrderSingle(NewOrderSingle newOrderSingle);
    void clientOrderCancelRequest(OrderCancelRequest orderCancelRequest);
    void clientOrderCancelReplaceRequest(OrderCancelReplaceRequest orderCancelReplaceRequest);
    void executionReport(ExecutionReport executionReport);
}
