package com.citi.icg.cioidark.chronicle.messaging.message.gmd;

import java.util.Objects;
import java.util.Optional;

import net.openhft.chronicle.wire.AbstractMarshallable;

/**
 * Symbology required for market data subscription
 *
 * @author ky54595
 */
public class SecurityMarketData extends AbstractMarshallable {

    private final String ticker;
    private final String marketDataSymbol;

    public SecurityMarketData(String bookSymbol, String marketDataSymbol) {
        this.ticker = bookSymbol;
        this.marketDataSymbol = marketDataSymbol;
    }

    public String getTicker() {
        return ticker;
    }

    public String getMarketDataSymbol() {
        return marketDataSymbol;
    }

    @Override
    public String toString() {
        return "Ticker: " + this.ticker + " Market Data Symbol: " + this.marketDataSymbol;
    }

    @Override
    public int hashCode() {
        return Objects.hash(Objects.hashCode(this.ticker),
                Objects.hashCode(this.marketDataSymbol));
    }

    @Override
    public boolean equals(Object obj) {
        return Optional.ofNullable(obj)
                .filter(SecurityMarketData.class::isInstance)
                .map(SecurityMarketData.class::cast)
                .filter(o -> Objects.equals(this.ticker, o.ticker))
                .filter(o -> Objects.equals(this.marketDataSymbol, o.marketDataSymbol))
                .isPresent();
    }

}
