package com.citi.icg.cioidark.chronicle.messaging.message.gmd;

import java.util.Objects;
import java.util.Optional;

import net.openhft.chronicle.wire.AbstractMarshallable;

public class GMDLULDBandMsg extends AbstractMarshallable {

    final private String symbol;
    final private double luldLowerPriceBand;
    final private double luldUpperPriceBand;
    final private long luldPriceBandTimestamp;
    final private long gmdSendTimeStamp;

    public GMDLULDBandMsg(String symbol, double luldLowerPriceBand, double luldUpperPriceBand,
                          long luldPriceBandTimestamp, long gmdSendTimeStamp) {
        this.symbol = symbol;
        this.luldLowerPriceBand = luldLowerPriceBand;
        this.luldUpperPriceBand = luldUpperPriceBand;
        this.luldPriceBandTimestamp = luldPriceBandTimestamp;
        this.gmdSendTimeStamp = gmdSendTimeStamp;
    }

    public String getSymbol() {
        return symbol;
    }

    public double getLuldLowerPriceBand() {
        return luldLowerPriceBand;
    }

    public double getLuldUpperPriceBand() {
        return luldUpperPriceBand;
    }

    public long getLuldPriceBandTimestamp() {
        return luldPriceBandTimestamp;
    }

    public long getGmdSendTimeStamp() {
        return gmdSendTimeStamp;
    }

    @Override
    public boolean equals(Object obj) {
        return Optional.ofNullable(obj)
                .filter(GMDLULDBandMsg.class::isInstance)
                .map(GMDLULDBandMsg.class::cast)
                .filter(o -> Objects.equals(this.symbol, o.symbol))
                .filter(o -> Objects.equals(this.luldLowerPriceBand, o.luldLowerPriceBand))
                .filter(o -> Objects.equals(this.luldUpperPriceBand, o.luldUpperPriceBand))
                .filter(o -> Objects.equals(this.luldPriceBandTimestamp, o.luldPriceBandTimestamp))
                .filter(o -> Objects.equals(this.gmdSendTimeStamp, o.gmdSendTimeStamp))
                .isPresent();
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), symbol, luldLowerPriceBand, luldUpperPriceBand,
                luldPriceBandTimestamp, gmdSendTimeStamp);
    }
}
