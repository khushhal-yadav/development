package com.citi.icg.cioidark.chronicle.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.services.api.dto.status.ErrorMessage;
import software.chronicle.services.api.dto.status.Heartbeat;
import software.chronicle.services.api.listener.ServiceContext;
import software.chronicle.services.api.listener.ServiceContextListener;
import software.chronicle.services.api.listener.ServiceLifecycleListener;
import software.chronicle.services.api.listener.StatusListener;
import software.chronicle.services.api.runner.ClusterNodeChangeResult;
import software.chronicle.services.api.source.HeartbeatSource;
import software.chronicle.services.api.source.PeriodicUpdateSource;

public class AbstractChronicleService implements
        ServiceContextListener,
        ServiceLifecycleListener,
        HeartbeatSource,
        PeriodicUpdateSource,
        StatusListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractChronicleService.class);
    protected static final String SUCCESS = "SUCCESS";
    protected static final String IGNORED = "IGNORED";

    protected ServiceContext serviceContext;
    protected Heartbeat heartbeat;

    @Override
    public void serviceContext(ServiceContext serviceContext) {
        this.serviceContext = serviceContext;
        heartbeat = new Heartbeat(serviceContext.serviceName() + '-' + serviceContext.hostId());
        if (this.serviceContext.runningReplicated()) {
            int podId = serviceContext.hostId();
            LOGGER.info("Setting up replicated mode for podId={}", podId);
        } else {
            LOGGER.info("Not running replicated");
        }
    }

    @Override
    public void start() {
        if (this.serviceContext.runningReplicated()) {
            int podId = serviceContext.hostId();
            LOGGER.info("Adding inputs in replicated mode for podId={}", podId);
            ClusterNodeChangeResult clusterNodeChangeResult = this.serviceContext.runnerController()
                    .addClusterNodeInputs(podId);
            String report = clusterNodeChangeResult.report("Start Added");
            String message = clusterNodeChangeResult.success() ? SUCCESS : IGNORED;
            LOGGER.info("{} {}", message, report);

            if (clusterNodeChangeResult.success()) onSubscribeToPod(podId);
        }
    }

    protected void onSubscribeToPod(int podId) {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Subscribed to host: {}", podId);
    }

    private static final String RECEIVED = "Received: {}"; // sonar inspired

    @Override
    public void heartbeatTimer(long currentTimeMillis) {
        if (LOGGER.isTraceEnabled()) LOGGER.trace("heartbeatTimer triggered at: " + currentTimeMillis);
    }

    @Override
    public void errorMessage(ErrorMessage message) {
        LOGGER.trace(" error {}", message);
    }

    @Override
    public void heartbeat(Heartbeat heartbeat) {
        if (LOGGER.isTraceEnabled()) LOGGER.trace(RECEIVED, heartbeat.toString());
    }

    @Override
    public void periodicUpdate(long currentTimeMillis) {
        if (LOGGER.isTraceEnabled()) LOGGER.trace("Received periodicUpdate={}", currentTimeMillis);
    }

}
