package com.citi.icg.cioidark.chronicle.service;

import java.io.IOException;

import net.openhft.chronicle.ChronicleCfg;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.wire.Marshallable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.services.api.ServicesDtoAlias;
import software.chronicle.services.api.runner.IRunner;
import software.chronicle.services.api.runner.RunnerCfg;
import software.chronicle.services.api.runner.RunnerContext;

public class ChronicleInitializerService {

    private static final Logger logger = LoggerFactory.getLogger(ChronicleInitializerService.class);

    public static boolean initialize(String[] args) throws IOException {
        try {
            String cfgFileName = args[0];
            String serviceName = args[1];

            int hostId1 = Integer.parseInt(args[2]);
            String instanceName = args.length <= 3 ? "default" : args[3];
            ServicesDtoAlias.addAlias();

            logger.info("Loading {}", IOTools.urlFor(ChronicleInitializerService.class, cfgFileName));

            ChronicleCfg engineCfg = Marshallable.fromFile(ChronicleCfg.class, cfgFileName);
            assert engineCfg != null;
            RunnerCfg runnerCfg = (RunnerCfg) engineCfg.installableMap.get("/etc");
            assert runnerCfg != null;

            int runnerVersion = Integer.getInteger("runner.version", 2);
            IRunner runner = runnerVersion == 2 ? new software.chronicle.runner.v2.Runner() : new software.chronicle.runner.v1.Runner();

            RunnerContext rc = new RunnerContext(serviceName)
                    .runnerCfg(runnerCfg)
                    .hostId(hostId1)
                    .instanceName(instanceName);

            runnerCfg.run(runner, rc);
            return true;
        }
        catch(IOException e){
            logger.error("IOI Error in Chronicle service {}", e.getMessage());
            throw e;
        }
    }
}
