package com.citi.icg.cioidark.qmf;

/*
 *  Author: Manmohan Salandri
 *  Version: 1.0
 * */
public interface RuleEvent {
	String getKey();
	RuleEventType getRuleEventType();
}