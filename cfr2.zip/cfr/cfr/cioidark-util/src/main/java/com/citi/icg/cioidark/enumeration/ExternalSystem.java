package com.citi.icg.cioidark.enumeration;

public enum ExternalSystem {

    CTRS("CTRS");

    private String value;

    ExternalSystem(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }

}
