package com.citi.icg.cioidark.util.objectPool;

import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

public class ObjectPool<P> extends GenericObjectPool<P> {

    public ObjectPool(PooledObjectFactory<P> factory) {
        super(factory);
    }

    public ObjectPool(PooledObjectFactory<P> factory, GenericObjectPoolConfig config) {
        super(factory, config);
    }
}
