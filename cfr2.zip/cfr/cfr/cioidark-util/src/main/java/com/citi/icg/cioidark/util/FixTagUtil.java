package com.citi.icg.cioidark.util;

import software.chronicle.fix.staticcode.messages.FixConstants;

public class FixTagUtil {

    public static boolean isValueSet(String value){
        return !FixConstants.isUnset(value)
                && !value.isEmpty();
    }

    public static boolean isValueSet(Long value){
        return !FixConstants.isUnset(value)
                && value > 0L;
    }

    public static boolean isValueSet(Character value){
        return !FixConstants.isUnset(value)
                && value != '\u0000';
    }

    public static boolean isValueSet(Double value){
        return !FixConstants.isUnset(value)
                && value > 0.0d;
    }
}
