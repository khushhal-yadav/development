package com.citi.icg.cioidark.util;

import java.io.PrintWriter;
import java.io.StringWriter;

public class Util {

	/**
	 * Handy conversion of a {@link Throwable} stack trace to a {@link String} if you aren't using {@link LiqFiLogger}
	 * @param e the exception from which to extract the stack trace
	 * @return a {@link String} with the stack trace for this {@link Throwable}
	 */
	public static String getStackTrace(Throwable e){
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		return sw.toString();
	}

	/**
	 * Convert fixed-point micro dollars to regular dollars
	 * @param microdollars
	 * @return
	 */
	public static double getDollarsFromMicroDollars(long microdollars) {
		return (double)microdollars/1000000;
	}

}
