package com.citi.icg.cioidark.enumeration;

public enum MarketDataSource {
	COLORDATA,
	QBUS_REDLINE,
	QBUS_COLORDATA,
	CITITICKER,
	RMDS,
	P2PS,
	GMD
}
