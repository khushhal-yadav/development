package com.citi.icg.cioidark.enumeration.alert;

public enum AlertLevel {
	LVL0(0),LVL1(1), LVL2(2), LVL3(3), LVL4(4);

	private final int lvl;

	AlertLevel(int lvl) {
		this.lvl = lvl;
	}

	public int getLvl() {
		return lvl;
	}
}
