package com.citi.icg.cioidark.qmf;

import java.util.concurrent.TimeUnit;

public class TimerTask implements RuleEvent {

    private final String taskId;
    private final TimerTaskType taskType;
    private final TimeUnit timerUnit;
    private final String key;
    private final RuleEventType ruleEventType;
    private String taskSubId;

    public TimerTask(String taskId, TimerTaskType taskType) {
        this(taskId, taskType, TimeUnit.MILLISECONDS);
    }

    private TimerTask(String taskId, TimerTaskType taskType, TimeUnit timerUnit) {
        this.taskId = taskId;
        this.taskType = taskType;
        this.key = taskId + taskType;
        this.timerUnit = timerUnit;
        this.ruleEventType = RuleEventType.TIMER;
    }

    @Override
    public String getKey() {
        return this.key;
    }

    @Override
    public RuleEventType getRuleEventType() {
        return this.ruleEventType;
    }

    public String getTaskId() {
        return taskId;
    }

    public TimerTaskType getTaskType() {
        return taskType;
    }

    public TimeUnit getTimerUnit() {
        return timerUnit;
    }

    public String getTaskSubId() {
        return taskSubId;
    }

    public void setTaskSubId(String taskSubId) {
        this.taskSubId = taskSubId;
    }

    @Override
    public String toString() {
        return "TimerTask{" +
                "taskId='" + taskId + '\'' +
                ", taskType=" + taskType +
                ", timerUnit=" + timerUnit +
                ", key='" + key + '\'' +
                ", ruleEventType=" + ruleEventType +
                ", taskSubId='" + taskSubId + '\'' +
                '}';
    }
}
