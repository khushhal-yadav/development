package com.citi.icg.cioidark.util.threadpool;

import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.citi.icg.cioidark.util.threadpool.event.Event;
import com.google.common.collect.Interner;
import com.google.common.collect.Interners;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CioiDarkThreadPool<T> {

    private final static Logger logger = LoggerFactory.getLogger(CioiDarkThreadPool.class);
    private final ThreadPoolExecutor tpe;
    private final int concurrencyQueueCapacity;
    public final Interner<String> interner;

    public final Map<String, String> submittedTaskMap = new ConcurrentHashMap<>();
    public final Map<String, BlockingQueue<Event<T>>> concurrencyMap = new ConcurrentHashMap<>();

    public CioiDarkThreadPool(String name, int coreSize, int maxSize, int frameworkTaskQueueCapacity, int concurrencyQueueCapacity, int concurrencyQueueThresholdSizeForAlert, int concurrencyQueueIncrementSizeForAlert, int priority) {
        ThreadFactory threadFactory;
        threadFactory = new CioiDarkThreadFactory(name, priority);
        tpe = new ThreadPoolExecutor(coreSize, maxSize, 0, TimeUnit.SECONDS, new ArrayBlockingQueue<>(frameworkTaskQueueCapacity), threadFactory);
        tpe.setCorePoolSize(coreSize);
        tpe.setMaximumPoolSize(maxSize);
        tpe.prestartAllCoreThreads();
        logger.info("Threadpool started with core thread size:" + coreSize);
        if (concurrencyQueueCapacity <= 0) {
            this.concurrencyQueueCapacity = Integer.MAX_VALUE;
        } else {
            this.concurrencyQueueCapacity = concurrencyQueueCapacity;
        }
        this.interner = Interners.newStrongInterner();
    }

    public void submit(final Event<T> event, final String synchronizer) {
        event.setSynchKey(synchronizer);
        submitForExecution(event, synchronizer);
    }

    private void submitForExecution(final Event<T> event, final String synchronizer) {

        synchronized (interner.intern(synchronizer)) {
            try {
                putEventinQueue(event, synchronizer);
            } catch (InterruptedException ex) {
                logger.error("ITRSALERT|UNPROCESSED MSG|" + event.getSynchKey() + "|" + event.getPayload(), ex);
            }

            if (!submittedTaskMap.containsKey(synchronizer)) {
                submittedTaskMap.put(synchronizer, synchronizer);
                CioiDarkThreadRunnable<T> cioiDarkThreadRunnable = new CioiDarkThreadRunnable<>(this, synchronizer);
                tpe.submit(cioiDarkThreadRunnable);
            }
        }
    }

    private void putEventinQueue(Event<T> event, String synchronizer) throws InterruptedException {
        if (!concurrencyMap.containsKey(synchronizer)) {
            BlockingQueue<Event<T>> blockingQueue = new LinkedBlockingQueue<>(this.concurrencyQueueCapacity);
            blockingQueue.put(event);
            concurrencyMap.put(synchronizer, blockingQueue);
        } else
            concurrencyMap.get(synchronizer).put(event);
    }
}