package com.citi.icg.cioidark.util;


import java.util.concurrent.locks.ReentrantLock;

/**
 * A unique (incremental) sequence number generator.
 * 
 * This class is a singleton
 */
public final class UniqueSeqNo {
    
	
	/**
     * reentrant lock with a fair ordering policy
     */
	private final ReentrantLock lock = new ReentrantLock(true); 
	
	/**
     * Stores the last sequence number returned
     */
	private static long seqNo;
	
	/**
     * Stores class instance (with eager initialization)
     */
	private static UniqueSeqNo instance = new UniqueSeqNo();
	
	/**
     * Private constructor
     */
	private UniqueSeqNo() {}	


	/**
     * Return class instance
     */
	public static UniqueSeqNo getInstance() {
		return instance;
	}
	
    /**
     * Unique (incremental) sequence number.
     */
	public long getSeqNo() {
		long seq;
		lock.lock();
		try {
			seqNo++;
			seq = seqNo;
		} finally {
			lock.unlock();
		}
		return seq;
	}


}