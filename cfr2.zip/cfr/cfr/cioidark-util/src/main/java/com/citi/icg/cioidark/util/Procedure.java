package com.citi.icg.cioidark.util;

public interface Procedure {
    void execute();
}
