/**
 * Title:        <p>
 * Description:  <p>
 * Copyright:    Copyright (c) <p>
 * Company:      <p>
 * @author
 * @version 1.0
 */
package com.citi.icg.cioidark.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDate;

public class DateUtil
{

	private final static String DOUBLE_ZERO = "00"; 
	
	private final Date m_date;

	private final Calendar m_calendar;

	private long m_timePartInLong;

	private long m_datePartInLong;

	private boolean m_IsTimePartComputed = false;

	private long m_fullDateInLong;

	private static final String defaultDt = fromDateToYYYYMMDD(new Date());
	private static final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss:SSS");

	// ??? pending: update getDateInYYYYMMDD the same way as
	// fromDateToYYYYMMDD
	public DateUtil(Date d)
	{
		m_date = d;
		m_calendar = new GregorianCalendar();
		m_calendar.setTime(m_date);
	}

	/**
	 * Method returns the current date in YYYYMMDD format
	 */
	public static String getDefaultDate()
	{
		return defaultDt;
	}

	/**
	 * Method takes strings representing date and time. Takes both to create a
	 * date. Note that the time portion contains 2 preceding spaces before the
	 * actual time. This may change in the future.
	 */
	public static Date getDateFromDateAndTime(String dateYYYYMMDD, String timeXXHHMMSS)
	{
		GregorianCalendar calendar = new GregorianCalendar();
		int year = Integer.parseInt(dateYYYYMMDD.substring(0, 4));
		int month = Integer.parseInt(dateYYYYMMDD.substring(4, 6));
		int day = Integer.parseInt(dateYYYYMMDD.substring(6));
		int hour = Integer.parseInt(timeXXHHMMSS.substring(2, 4));
		int minute = Integer.parseInt(timeXXHHMMSS.substring(4, 6));
		int second = Integer.parseInt(timeXXHHMMSS.substring(6));

		// month starts with 0 for January
		calendar.set(year, (month - 1), day, hour, minute, second);

		return calendar.getTime();
	}

	/**
	 * Method takes strings representing date and time in the following format:
	 * YYYYMMDD-HH:MM:SS i.e. 20020716-19:33:02
	 * 
	 * @return Date
	 */
	private static Date getDateFromString(String dateStr)
	{
		GregorianCalendar calendar = new GregorianCalendar();
		int year = Integer.parseInt(dateStr.substring(0, 4));
		int month = Integer.parseInt(dateStr.substring(4, 6));
		int day = Integer.parseInt(dateStr.substring(6, 8));
		int hour = Integer.parseInt(dateStr.substring(9, 11));
		int minute = Integer.parseInt(dateStr.substring(12, 14));
		int second = Integer.parseInt(dateStr.substring(15));

		// month starts with 0 for January
		calendar.set(year, (month - 1), day, hour, minute, second);

		return calendar.getTime();
	}

	/**
	 * Method takes strings representing date and time in the following format:
	 * YYYYMMDD-HH:MM:SS i.e. 20020716-19:33:02
	 * 
	 * @return Date
	 */
	private static Date getDateFromSybaseString(String dateStr)
	{
		GregorianCalendar calendar = new GregorianCalendar();
		int month = Integer.parseInt(dateStr.substring(0, 2));
		int day = Integer.parseInt(dateStr.substring(3, 5));
		int year = Integer.parseInt(dateStr.substring(6, 10));

		int hour = Integer.parseInt(dateStr.substring(11, 13));
		int minute = Integer.parseInt(dateStr.substring(14));

		// month starts with 0 for January
		calendar.set(year, (month - 1), day, hour, minute, 0);

		return calendar.getTime();
	}

	/**
	 * Method takes string representing time. Creates a date. Note that the time
	 * portion contains 2 preceding spaces before the actual time. This may
	 * change in the future.
	 * format example 16:00:00
	 */
	// public static Date getDateFromTime(String timeXXHHMMSS)
	public static Date getDateFromTime(String timeHHMMSS)
	{
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(new Date()); // defaults to todays date

		int hour = Integer.parseInt(timeHHMMSS.substring(0, 2));
		int minute = Integer.parseInt(timeHHMMSS.substring(3, 5));
		int second = Integer.parseInt(timeHHMMSS.substring(6, 8));
		// HOUR_OF_DAY based on 0 to 23
		calendar.set(GregorianCalendar.HOUR_OF_DAY, hour);
		calendar.set(GregorianCalendar.MINUTE, minute);
		calendar.set(GregorianCalendar.SECOND, second);
		calendar.set(GregorianCalendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	/**
	 * utility function to get Scheduler Date from time e.g. if time is 4:30pm,
	 * convert it to today's date at 4:30pm
	 */
	private static Date getSchedulerDate(String time)
	{
		// time is in 24 hour, like 16:30 is 4:30pm
		System.out.println("Received time: " + time);
		int colonIndex = time.indexOf(':');
		int hours = Integer.parseInt(time.substring(0, colonIndex));
		// int minutes = Integer.parseInt(endOfDayTime.substring(colonIndex +
		// 1));
		int minutes = Integer.parseInt(time.substring(colonIndex + 1, colonIndex + 3));
		colonIndex = time.indexOf(':', colonIndex + 1);
		int seconds = 0;
		if (colonIndex > 0)
		{
			seconds = Integer.parseInt(time.substring(colonIndex + 1));
		}

		GregorianCalendar calendar = new GregorianCalendar();
		// HOUR_OF_DAY based on 0 to 23
		calendar.set(GregorianCalendar.HOUR_OF_DAY, hours);
		calendar.set(GregorianCalendar.MINUTE, minutes);
		calendar.set(GregorianCalendar.SECOND, seconds);

		return calendar.getTime();
	}

	/**
	 * utility function to get Scheduler 'today' Date in 'long' from time e.g.
	 * if time is 4:30pm, convert it to today's date at 4:30pm
	 */
	public static long getSchedulerDateInLong(String endOfDayTime)
	{
		return getSchedulerDate(endOfDayTime).getTime();
	}

	public String getDateInYYYYMMDD()
	{
		StringBuffer s = new StringBuffer(8);

		int year = m_calendar.get(Calendar.YEAR);

		// now append year
		s.append(year);

		int month = m_calendar.get(Calendar.MONTH) + 1; // month starts from '0'
		if (month <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(month);

		int day = m_calendar.get(Calendar.DATE);
		if (day <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(day);

		return s.toString();
	}

	public StringBuffer getDateInYYYYMMDDAsStringBuffer()
	{
		StringBuffer s = new StringBuffer(8);
		s.append(m_calendar.get(Calendar.YEAR));
		s.append(m_calendar.get(Calendar.MONTH));
		s.append(m_calendar.get(Calendar.DATE));
		return s;
	}

	private StringBuffer getStringBufferTimeInHHMMSS()
	{
		StringBuffer s = new StringBuffer(8);

		int hr = m_calendar.get(Calendar.HOUR_OF_DAY);
		if (hr <= 9) // single digit
		{
			s.append('0');
		}
		// now append hr
		s.append(hr);

		int min = m_calendar.get(Calendar.MINUTE);
		if (min <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(min);

		int sec = m_calendar.get(Calendar.SECOND);
		if (sec <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(sec);
		return s;
	}

	public String getTimeInHHMMSSMM()
	{
		return this.getStringBufferTimeInHHMMSS().append("00").toString();
	}

	public String getTimeInHHMMSS()
	{
		return this.getStringBufferTimeInHHMMSS().toString();
	}

	private static String fromDateToYYYYMMDD(Date date)
	{
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		StringBuffer s = new StringBuffer(8);

		int year = calendar.get(Calendar.YEAR);

		// now append year
		s.append(year);

		int month = calendar.get(Calendar.MONTH) + 1; // month starts from '0'
		if (month <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(month);

		int day = calendar.get(Calendar.DATE);
		if (day <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(day);

		return s.toString();
	}

	private static String fromDateToMMDDYY(Date date)
	{
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		StringBuffer s = new StringBuffer(8);

		int month = calendar.get(Calendar.MONTH) + 1; // month starts from '0'
		if (month <= 9) // single digit
		{
			s.append('0');
		}
		// now append month
		s.append(month);

		int day = calendar.get(Calendar.DATE);
		if (day <= 9) // single digit
		{
			s.append('0');
		}
		// now append day
		s.append(day);

		int year = calendar.get(Calendar.YEAR);

		// leave 2 digits for the year
		year = (year < 2000 ? year - 1900 : year - 2000);

		if (year <= 9)
		{
			s.append('0');
		}
		// now append 2 digit year
		s.append(year);

		return s.toString();
	}

	private static String fromDateToHHMMSS(Date date)
	{
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		StringBuffer s = new StringBuffer(8);
		s.append("00");

		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		if (hr <= 9) // single digit
		{
			s.append('0');
		}
		// now append hr
		s.append(hr);

		int min = calendar.get(Calendar.MINUTE);
		if (min <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(min);

		int sec = calendar.get(Calendar.SECOND);
		if (sec <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(sec);

		return s.toString();
	}

	public static String getTime(Date date)
	{
		return convertDateToString(date);
	}
	
	private static String convertDateToString(Date date)
	{
		return sdf.format(date);
	}

	public static String fromDateToYYYYMMDDWithSeparater(Date date, String separater)
	{
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		StringBuffer s = new StringBuffer(8);
		s.append(calendar.get(Calendar.YEAR));
		s.append(separater);
		s.append(calendar.get(Calendar.MONTH));
		s.append(separater);
		s.append(calendar.get(Calendar.DATE));
		// System.out.println("s: " + s.toString());
		return s.toString();
	}

	public static String fromDateToYYYYMMDDWithSeparater(Date date, char separater)
	{
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		StringBuffer s = new StringBuffer(8);
		s.append(calendar.get(Calendar.YEAR));
		s.append(separater);
		s.append(calendar.get(Calendar.MONTH));
		s.append(separater);
		s.append(calendar.get(Calendar.DATE));
		// System.out.println("s: " + s.toString());
		return s.toString();
	}

	public long getTimeInLong()
	{
		return this.m_date.getTime();
	}

	public long getDatePartInLong()
	{
		int year = this.m_calendar.get(Calendar.YEAR);
		int month = this.m_calendar.get(Calendar.MONTH);
		int day = this.m_calendar.get(Calendar.DATE);
		Calendar calendar = new GregorianCalendar(year, month, day, 0, 0, 0);
		this.m_datePartInLong = calendar.getTime().getTime();

		this.m_fullDateInLong = this.m_calendar.getTime().getTime();

		this.m_timePartInLong = this.m_fullDateInLong - this.m_datePartInLong;
		this.m_IsTimePartComputed = true;
		return this.m_datePartInLong;
	}

	public long getTimePartInLong()
	{
		if (!this.m_IsTimePartComputed)
		{
			int year = this.m_calendar.get(Calendar.YEAR);
			int month = this.m_calendar.get(Calendar.MONTH);
			int day = this.m_calendar.get(Calendar.DATE);
			Calendar calendar = new GregorianCalendar(year, month, day);
			this.m_datePartInLong = calendar.getTime().getTime();

			this.m_fullDateInLong = this.m_calendar.getTime().getTime();

			this.m_timePartInLong = this.m_fullDateInLong - this.m_datePartInLong;
			this.m_IsTimePartComputed = true;
		}
		return this.m_timePartInLong;
	}

	/**
	 * method to get no. of days of two dates order of the dates doesn't matter;
	 * it is just the diff. of two dates
	 * 
	 * @return number of days between two dates
	 */
	private static int calendarDaysBetweenTwoDates(Date firstDate, Date secondDate)
	{
		// get time in milliseconds
		long diffDate = firstDate.getTime() - secondDate.getTime();
		// send the no. of days
		int num_days = (int) diffDate / (1000 * 24 * 60 * 60);

		return Math.abs(num_days);
	}

	/**
	 * method to get no. of days of two calendars; it uses the
	 * calendarDaysBetweenTwoDates to compute the no. of days. order of the
	 * calendars doesn't matter; it is just the diff. of two calendars
	 * 
	 * @return number of days between two calendars
	 */
	public static int calendarDaysBetweenTwoDates(Calendar c1, Calendar c2)
	{
		return calendarDaysBetweenTwoDates(c1.getTime(), c2.getTime());
	}

	/**
	 * Method to covert java.util.Date to Julian Date
	 */
	public static double convertDateToJulianDate(Date date)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		int dt = cal.get(Calendar.DATE);
		int hour = cal.get(Calendar.HOUR);
		int min = cal.get(Calendar.MINUTE);
		int sec = cal.get(Calendar.SECOND);

		double extra = 100.0 * year + month - 190002.5;
		double rjd = 367.0 * year;
		rjd -= Math.floor(7.0 * (year + Math.floor((month + 9.0) / 12.0)) / 4.0);
		rjd += Math.floor(275.0 * month / 9.0);
		rjd += dt;
		rjd += (hour + (min + sec / 60.0) / 60.) / 24.0;
		rjd += 1721013.5;
		rjd -= 0.5 * extra / Math.abs(extra);
		rjd += 0.5;

		return rjd;
	}

	public static String fromDateToLogDate(Date date, String separator)
	{
		return DateUtil.fromDateToMMDDYY(date) + separator + DateUtil.fromDateToHHMMSS(date).substring(2);

	}

	public static String fromDateToLogDate(Date date)
	{
		return DateUtil.fromDateToMMDDYY(date) + "_" + DateUtil.fromDateToHHMMSS(date).substring(2);
	}

	private static long convertToGMT(long date)
	{
		Calendar calendar = Calendar.getInstance();
		int gmtoffset = calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET);
		// Date newDate = new Date(date - gmtoffset);
		return date - gmtoffset;
	}

	public static long convertToGMT(long date, int gmtoffset)
	{
		return date - gmtoffset;
	}

	private static long convertFromGMT(long date)
	{
		Calendar calendar = Calendar.getInstance();
		int gmtoffset = -1 * (calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET));
		Date newDate = new Date(date - gmtoffset);
		return newDate.getTime();
	}

	public static Date convertToGMTDate(long date)
	{
		Calendar calendar = Calendar.getInstance();
		int gmtoffset = calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET);
		return new Date(date - gmtoffset);
	}

	private static Date convertFromGMTDate(long date)
	{
		Calendar calendar = Calendar.getInstance();
		int gmtoffset = -1 * (calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET));
		return new Date(date - gmtoffset);
	}

	public static String convertToGMTString(long date)
	{
		Calendar calendar = Calendar.getInstance();
		int gmtoffset = calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET);
		calendar.setTime(new Date(date - gmtoffset));

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		int min = calendar.get(Calendar.MINUTE);
		int sec = calendar.get(Calendar.SECOND);

		return "" + year + (month < 10 ? "0" + month : "" + month) + (day < 10 ? "0" + day : "" + day) + "-" + (hr < 10 ? "0" + hr : "" + hr) + ":" + (min < 10 ? "0" + min : "" + min) + ":"
				+ (sec < 10 ? "0" + sec : "" + sec);
	}

	private static String convertFromGMTString(long date)
	{
		Calendar calendar = Calendar.getInstance();
		int gmtoffset = -1 * (calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET));

		calendar.setTime(new Date(date - gmtoffset));
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		int min = calendar.get(Calendar.MINUTE);
		int sec = calendar.get(Calendar.SECOND);

		return "" + year + (month < 10 ? "0" + month : "" + month) + (day < 10 ? "0" + day : "" + day) + "-" + (hr < 10 ? "0" + hr : "" + hr) + ":" + (min < 10 ? "0" + min : "" + min) + ":"
				+ (sec < 10 ? "0" + sec : "" + sec);
	}

	/**
	 * Converts local date to GMT one. While the returned Date object contains
	 * thr proper date/time, the method toString() improperly states that it's
	 * the EDT time. Looks like a bug in the Calendar class...
	 */

	public static Date convertToGMT(Date date)
	{
		Calendar calendar = Calendar.getInstance();
		int gmtoffset = calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET);
		calendar.setTime(new Date(date.getTime() - gmtoffset));
		calendar.setTimeZone(TimeZone.getTimeZone("GMT")); // does not change
															// ???
		return calendar.getTime();
	}

	private static Date convertFromGMT(Date date)
	{
		Calendar calendar = Calendar.getInstance();
		int gmtoffset = -1 * (calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET));
		calendar.setTime(new Date(date.getTime() - gmtoffset));
		return calendar.getTime();
	}

	public static long convertToGMTlong(Date date)
	{
		return convertToGMT(date).getTime();
	}

	public static long convertFromGMTlong(Date date)
	{
		return convertFromGMT(date).getTime();
	}

	private static String convertToGMTString(Date date)
	{

		Calendar calendar = Calendar.getInstance();
		int gmtoffset = calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET);
		calendar.setTime(new Date(date.getTime() - gmtoffset));

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		int min = calendar.get(Calendar.MINUTE);
		int sec = calendar.get(Calendar.SECOND);

		return "" + year + (month < 10 ? "0" + month : "" + month) + (day < 10 ? "0" + day : "" + day) + "-" + (hr < 10 ? "0" + hr : "" + hr) + ":" + (min < 10 ? "0" + min : "" + min) + ":"
				+ (sec < 10 ? "0" + sec : "" + sec);
	}

	public static String convertFromGMTString(Date date)
	{
		Calendar calendar = Calendar.getInstance();

		int gmtoffset = -1 * (calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET));
		calendar.setTime(new Date(date.getTime() - gmtoffset));

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		int min = calendar.get(Calendar.MINUTE);
		int sec = calendar.get(Calendar.SECOND);

		return "" + year + (month < 10 ? "0" + month : "" + month) + (day < 10 ? "0" + day : "" + day) + "-" + (hr < 10 ? "0" + hr : "" + hr) + ":" + (min < 10 ? "0" + min : "" + min) + ":"
				+ (sec < 10 ? "0" + sec : "" + sec);
	}

	/**
	 * Method takes representing date and time in the following format:
	 * YYYYMMDD-HH:MM:SS i.e. 20020716-19:33:02
	 * 
	 * @return Date with GMT time
	 * 
	 */

	private static Date convertToGMTDate(String dateStr)
	{

		Date date = getDateFromString(dateStr);
		Calendar calendar = Calendar.getInstance();

		int gmtoffset = calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET);
		return new Date(date.getTime() - gmtoffset);
	}

	/**
	 * Method takes representing date and time in the following format:
	 * YYYYMMDD-HH:MM:SS i.e. 20020716-19:33:02
	 * 
	 * @return Date with the local time
	 * 
	 */
	private static Date convertFromGMTDate(String dateStr)
	{

		Date date = getDateFromString(dateStr);
		Calendar calendar = Calendar.getInstance();

		int gmtoffset = -1 * (calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET));
		return new Date(date.getTime() - gmtoffset);
	}

	/**
	 * Method takes representing date and time in the following format:
	 * YYYYMMDD-HH:MM:SS i.e. 20020716-19:33:02
	 * 
	 * @return long with the local time
	 * 
	 */
	public static long convertFromGMTlong(String dateStr)
	{

		return convertFromGMTDate(dateStr).getTime();
	}

	/**
	 * Method takes representing date and time in the following format:
	 * YYYYMMDD-HH:MM:SS i.e. 20020716-19:33:02
	 * 
	 * @return long with GMT time
	 * 
	 */

	private static long convertToGMTlong(String dateStr)
	{

		return convertToGMTDate(dateStr).getTime();
	}

	/**
	 * Method takes representing date and time in the following format:
	 * YYYYMMDD-HH:MM:SS i.e. 20020716-19:33:02
	 * 
	 * @return String with GMT time
	 * 
	 */
	private static String convertToGMT(String dateStr)
	{

		Date date = getDateFromString(dateStr);
		Calendar calendar = Calendar.getInstance();

		int gmtoffset = calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET);
		calendar.setTime(new Date(date.getTime() - gmtoffset));

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		int min = calendar.get(Calendar.MINUTE);
		int sec = calendar.get(Calendar.SECOND);

		return "" + year + (month < 10 ? "0" + month : "" + month) + (day < 10 ? "0" + day : "" + day) + "-" + (hr < 10 ? "0" + hr : "" + hr) + ":" + (min < 10 ? "0" + min : "" + min) + ":"
				+ (sec < 10 ? "0" + sec : "" + sec);
	}

	/**
	 * Method takes a date and time in the local military time, i.e. 08/05/2002
	 * 13:00 and converts it into GMT time
	 * 
	 * @return String with GMT time
	 * 
	 */
	private static String convertToGMTSybase(String dateStr)
	{

		Date date = getDateFromSybaseString(dateStr);
		Calendar calendar = Calendar.getInstance();

		int gmtoffset = calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET);
		calendar.setTime(new Date(date.getTime() - gmtoffset));

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		int min = calendar.get(Calendar.MINUTE);

		return "" + (month < 10 ? "0" + month : "" + month) + "/" + (day < 10 ? "0" + day : "" + day) + "/" + +year + " " + (hr < 10 ? "0" + hr : "" + hr) + ":"
				+ (min < 10 ? "0" + min : "" + min);
	}

	/**
	 * Method takes date and time in the following format: YYYYMMDD-HH:MM:SS
	 * i.e. 20020716-19:33:02
	 * 
	 * @return String with the local time
	 * 
	 */
	private static String convertFromGMT(String dateStr)
	{

		Date date = getDateFromString(dateStr);
		Calendar calendar = Calendar.getInstance();

		int gmtoffset = -1 * (calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET));
		calendar.setTime(new Date(date.getTime() - gmtoffset));

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		int min = calendar.get(Calendar.MINUTE);
		int sec = calendar.get(Calendar.SECOND);

		return "" + year + (month < 10 ? "0" + month : "" + month) + (day < 10 ? "0" + day : "" + day) + "-" + (hr < 10 ? "0" + hr : "" + hr) + ":" + (min < 10 ? "0" + min : "" + min) + ":"
				+ (sec < 10 ? "0" + sec : "" + sec);
	}

	/**
	 * Method takes date and time in the following format: HH:MM i.e. 19:33
	 * 
	 * @return String with the gmt time string
	 */
	public static String convertHHMMtoGMTString(String str)
	{
		try
		{
			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(new Date());
			StringTokenizer tokens = new StringTokenizer(str, ":");
			cal.set(GregorianCalendar.HOUR_OF_DAY, Integer.parseInt(tokens.nextToken()));
			cal.set(GregorianCalendar.MINUTE, Integer.parseInt(tokens.nextToken()));
			cal.set(GregorianCalendar.SECOND, 0);
			cal.set(GregorianCalendar.MILLISECOND, 0);
			return convertToGMTString(cal.getTime());
		}
		catch (NumberFormatException e)
		{
			e.printStackTrace();
			return null;
		}
		catch (NoSuchElementException e)
		{
			return null;
		}
	}

	public static void main(String[] args)
	{
		Date date = new Date();
		Date newDate = convertToGMT(date);

//		int j=2;
//		if(j == 2){
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.MILLISECOND, 6);
		System.out.println("Date = " + DateUtil.fromDateToHHMMSSMS(calendar));

		calendar.set(Calendar.MILLISECOND, 66);
		System.out.println("Date = " + DateUtil.fromDateToHHMMSSMS(calendar));

		calendar.set(Calendar.MILLISECOND, 666);
		System.out.println("Date = " + DateUtil.fromDateToHHMMSSMS(calendar));

//			return;
//		}
		// Print various conversions in current time zone
		System.out.println("Local time is " + date);
		System.out.println("GMT time is " + newDate);
		System.out.println("And now back to Local from GMT... ");
		System.out.println("The local time is " + convertFromGMT(newDate));

		System.out.println("Testing from string... " + "20020706-07:33:02");
		System.out.println("The GMTtime is " + convertToGMT("20020706-07:33:02"));
		System.out.println("The GMTtime is in long " + convertToGMTlong("20020706-07:33:02"));
		System.out.println("The GMTtime is in Date " + convertToGMTDate("20020706-07:33:02"));

		System.out.println("Converting from rom GMT time 20020706-07:33:02");
		System.out.println("The local time is " + convertFromGMT("20020706-07:33:02"));

		System.out.println("\nTesting conversion to GMT from long");
		System.out.println("The local time is " + date.getTime() + " or " + new Date(date.getTime()));

		long gmtLong = convertToGMT(date.getTime());
		System.out.println(" Which is in GMT  " + gmtLong + " or " + new Date(gmtLong));
		System.out.println("\n...and now back to local: " + convertFromGMT(gmtLong));

		System.out.println("from long to string: " + convertFromGMTString(gmtLong));
		System.out.println("from long to Date: " + convertFromGMTDate(gmtLong));

		System.out.println("Testing from string to Sybase GMT ... " + "08/05/2002 13:00");
		System.out.println("The GMTtime is " + convertToGMTSybase("08/05/2002 13:00"));

		System.out.println("The Scheduled time(13:00) is " + getSchedulerDate("13:00"));
		System.out.println("The Scheduled time(24:30) is " + getSchedulerDate("24:30"));
		System.out.println("The Scheduled time(00:30) is " + getSchedulerDate("00:30"));
		System.out.println("The Scheduled time(30:00) is " + getSchedulerDate("30:00"));

	}

	public static String fromDateToYYMMDDHHmmss(Calendar calendar)
	{
		StringBuffer s = new StringBuffer(12);
		int year = calendar.get(Calendar.YEAR);

		// leave 2 digits for the year
		year = (year < 2000 ? year - 1900 : year - 2000);

		if (year <= 9)
		{
			s.append('0');
		}
		// now append 2 digit year
		s.append(year);
		int month = calendar.get(Calendar.MONTH) + 1; // month starts from '0'
		if (month <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(month);

		int day = calendar.get(Calendar.DATE);
		if (day <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(day);

		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		if (hr <= 9) // single digit
		{
			s.append('0');
		}
		// now append hr
		s.append(hr);

		int min = calendar.get(Calendar.MINUTE);
		if (min <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(min);

		int sec = calendar.get(Calendar.SECOND);
		if (sec <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(sec);
		return s.toString();
	}
/*
 * Added By Bin, this method get a calendar object and return the time in YYYYMMDDHHmmss time format
 */
	public static String fromDateToYYYYMMDDHHmmss(Calendar calendar)
	{
		StringBuffer s = new StringBuffer(12);
		s.append(calendar.get(Calendar.YEAR));
		int month = calendar.get(Calendar.MONTH) + 1; // month starts from '0'
		if (month <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(month);

		int day = calendar.get(Calendar.DATE);
		if (day <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(day);

		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		if (hr <= 9) // single digit
		{
			s.append('0');
		}
		// now append hr
		s.append(hr);

		int min = calendar.get(Calendar.MINUTE);
		if (min <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(min);

		int sec = calendar.get(Calendar.SECOND);
		if (sec <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(sec);
		return s.toString();
	}
	public static String fromDateToHHMMSS(Calendar calendar)
	{
		StringBuffer s = new StringBuffer(8);
		s.append("00");

		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		if (hr <= 9) // single digit
		{
			s.append('0');
		}
		// now append hr
		s.append(hr);

		int min = calendar.get(Calendar.MINUTE);
		if (min <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(min);

		int sec = calendar.get(Calendar.SECOND);
		if (sec <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(sec);

		return s.toString();
	}

	private static String fromDateToHHMMSSMS(Calendar calendar)
	{
		StringBuffer s = new StringBuffer(12);

		int hr = calendar.get(Calendar.HOUR_OF_DAY);
		if (hr <= 9) // single digit
		{
			s.append('0');
		}
		// now append hr
		s.append(hr);
		s.append(':');
		int min = calendar.get(Calendar.MINUTE);
		if (min <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(min);
		s.append(':');
		int sec = calendar.get(Calendar.SECOND);
		if (sec <= 9) // single digit
		{
			s.append('0');
		}
		// now append min
		s.append(sec);
		s.append('.');
		int msec = calendar.get(Calendar.MILLISECOND);
		if(msec > 9 && msec <= 99){
			s.append('0');
		}
		else if (msec <= 9) // single digit
		{
			s.append(DOUBLE_ZERO);
		}
		// now append min
		s.append(msec);
		return s.toString();
	}

	public static Timestamp getCurrentTimeStampInGMT() {
		Calendar calendar = Calendar.getInstance();
		int gmtoffset = calendar.get(Calendar.DST_OFFSET) + calendar.get(Calendar.ZONE_OFFSET);
		Date date = new Date();
		calendar.setTime(new Date(date.getTime() - gmtoffset));
		calendar.setTimeZone(TimeZone.getTimeZone("GMT")); // does not change
		
		return new Timestamp(calendar.getTimeInMillis());
	}

	/**
	 * Separate the year, month, and day of month by the specified delimiter
	 * @param date the {@link LocalDate} to convert
	 * @param delim goes between the year, month, and day
	 * @return the formatted string represented by the passed in parameters
	 */
	private static String localDateToString(LocalDate date, String delim) {
		return String.format("%s%s%s%s%s",
				StringUtils.leftPad(Integer.toString(date.getYear()),4,'0'), delim,
				StringUtils.leftPad(Integer.toString(date.getMonthOfYear()),2,'0'), delim,
				StringUtils.leftPad(Integer.toString(date.getDayOfMonth()),2,'0')
				);
	}

	private static String localDateToString(java.time.LocalDate date, String delim) {
		return String.format("%s%s%s%s%s",
				StringUtils.leftPad(Integer.toString(date.getYear()),4,'0'), delim,
				StringUtils.leftPad(Integer.toString(date.getMonthValue()),2,'0'), delim,
				StringUtils.leftPad(Integer.toString(date.getDayOfMonth()),2,'0')
		);
	}
	
	/**
	 * Convert a {@link LocalDate} to YYYYMMDD format
	 * @param date the {@link LocalDate} to convert
	 * @return YYYYMMDD format date string
	 */
	public static String localDateToDigitString(LocalDate date) {
		return localDateToString(date, "");
	}

	public static String localDateToDigitString(java.time.LocalDate date) {
		return localDateToString(date, "");
	}
	
	/**
	 * Convenience method to abstract away needing to know about LocalDate
	 * @return YYYYMMDD format date string
	 */
	public static String currentDateToDigitString() {
		return localDateToDigitString(new LocalDate());
	}
	
	/**
	 * Convert a {@link LocalDate} to YYYY.MM.DD format
	 * @param date the {@link LocalDate} to convert
	 * @return YYYY.MM.DD format date string
	 */
	private static String localDateToDnaString(LocalDate date) {
		return localDateToString(date, ".");
	}

	/**
	 * Convert to YYYY.MM.DD format after subtracting days from the given date
	 * @param date {@link LocalDate} to convert
	 * @param days number of days to subtract before conversion
	 * @return YYYY.MM.DD format date string
	 */
	private static String subtractDays(LocalDate date, int days) {
		return localDateToDnaString(date.minusDays(days));
	}

	/**
	 * Convenience method to subtract from current day without passing a LocalDate
	 * @param days how many days to subtract
	 * @return YYYY.MM.DD format date string
	 */
	public static String getRelativePreviousDnaDate(int days) {
		return subtractDays(new LocalDate(), days);
	}

}
