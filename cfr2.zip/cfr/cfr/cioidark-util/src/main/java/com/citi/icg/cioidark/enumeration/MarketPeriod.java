package com.citi.icg.cioidark.enumeration;

public enum MarketPeriod {
    PRE_OPEN,
    CONTINUOUS_TRADING,
    POST_CLOSE,
    POST_CLOSE_CHKOUT,
    WARM_UP
}
