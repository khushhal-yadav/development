package com.citi.icg.cioidark.util.threadpool.event;

public abstract class DispatchableEvent<T> implements Event<T> {

    private String synchKey;
    private T payload;
    private long msgSeq;

    @Override
    public String getSynchKey() {
        return synchKey;
    }

    @Override
    public void setSynchKey(String synchKey) {
        this.synchKey = synchKey;
    }

    @Override
    public T getPayload() {
        return payload;
    }

    @Override
    public void setPayload(T payload) {
        this.payload = payload;
    }

    @Override
    public long getMsgSeq() {
        return this.msgSeq;
    }

    @Override
    public void setMsgSeq(long msgSeq) {
        this.msgSeq = msgSeq;
    }
}
