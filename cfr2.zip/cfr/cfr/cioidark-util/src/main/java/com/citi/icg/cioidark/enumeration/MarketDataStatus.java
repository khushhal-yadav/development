package com.citi.icg.cioidark.enumeration;

import java.util.HashMap;
import java.util.Map;

public enum MarketDataStatus {

    HALTED(7), NOTHALTED(8), QUOTEONLY(9), OPENED_OR_TRADE_RESUME(10), CLOSED(11), PAUSED(12), LULD_UPDATE(13), SNAPSHOT_UPDATE(14);

    private int value;
    private static Map<Integer, MarketDataStatus> map = new HashMap<>();

    static {
        for (MarketDataStatus constantEnum : MarketDataStatus.values()) {
            map.put(constantEnum.value, constantEnum);
        }
    }

    MarketDataStatus(int value) {
        this.value = value;
    }

    public int value() {
        return value;
    }

    public static MarketDataStatus valueOf(final int value) {
        return map.get(value);
    }
}
