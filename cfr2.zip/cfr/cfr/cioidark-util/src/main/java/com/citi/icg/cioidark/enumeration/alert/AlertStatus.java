package com.citi.icg.cioidark.enumeration.alert;

public enum AlertStatus {
	OPEN("open"), CLOSE("closed"), TakingAction("TakingAction");
	private final String status;

	AlertStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}
}
