package com.citi.icg.cioidark.enumeration;

public enum EventType {
    SOLICITED, UNSOLICITED, FORCED_OUT
}
