package com.citi.icg.cioidark.enumeration;

public enum ShortSaleRestriction {

    SHORT_SALE_RESTRICTION_ACTIVATED('Y'), SHORT_SALE_RESTRICTION_REMOVED('N'), SHORT_SALE_RESTRICTION_NOT_CHANGED('\u0000');

    private char value;

    ShortSaleRestriction(char value) {
        this.value = value;
    }

    public char value() {
        return value;
    }
}
