package com.citi.icg.cioidark.util;

import java.math.BigDecimal;

public class PriceUtil {
	public static double qtyRounding( double qty ) {
		long ord_qty = Math.round(qty);
		qty = Double.parseDouble(Long.toString(ord_qty));
		return qty;
	}

	public static double qtyRoundingThousand( double qty ) {
		double factor = Math.pow(10, 3);
		long ord_qty = Math.round(qty / factor) * 1000;
		qty = Double.parseDouble(Long.toString(ord_qty));
		return qty;
	}

	public static double qtyRoundingToTen( double qty ) {
		double factor = Math.pow(10, 1);
		long ord_qty = Math.round(qty / factor) * 10;
		qty = Double.parseDouble(Long.toString(ord_qty));
		return qty;
	}

	public static double priceRounding(double price) {
		if (price >= 1.0){
			price = PriceUtil.priceRounding(price, 2);

		}else{
			price = PriceUtil.priceRounding(price, 4);
		}
		return price;
	}
	
	public static double priceRoundingCustom(double price) {
		if (price >= 1.0){
			price = PriceUtil.priceRounding(price, 3);

		}else{
			price = PriceUtil.priceRounding(price, 4);
		}
		return price;
	}

	private static double priceRounding(double price, int places) {
		double rd_place = 10.0;
		for(int i=1; i < places; i++)
			rd_place = rd_place * 10.0;
		long ord_price = Math.round(price * rd_place);
		price = ord_price / rd_place;
		return price;
	}

	public static double priceRoundingTo2( double price ) {
		long ord_price = Math.round(price * 100.0);
		price = ord_price / 100.0;
		return price;
	}

	public static double customPriceRounding(double price) {
		price = PriceUtil.priceRounding(price, 3);
		int decimal = 0;
		Double tempPrice = PriceUtil.priceRounding(price * 100, 1);
		int decimalIndex = tempPrice.toString().indexOf(".");
		if (decimalIndex != -1) {
			decimal = Integer.valueOf(tempPrice.toString().substring(decimalIndex + 1));
		}

		BigDecimal bdPrice = new BigDecimal(price);
		BigDecimal afterPrice = null;

		if (decimal >= 7) {
			afterPrice = bdPrice.setScale(2, BigDecimal.ROUND_UP);
		} else {
			afterPrice = bdPrice.setScale(2, BigDecimal.ROUND_DOWN);
		}

		return afterPrice.doubleValue();
	}

	public static double priceRounddown(double price, int place) {
		BigDecimal bdPrice = new BigDecimal(price);
		double notRoundPrice = PriceUtil.priceRounding(price, place);
		if (notRoundPrice == price) return notRoundPrice;
		BigDecimal afterPrice = bdPrice.setScale(place, BigDecimal.ROUND_DOWN);

		return afterPrice.doubleValue();
	}

	public static double priceRoundUp(double price, int place) {
		BigDecimal bdPrice = new BigDecimal(price);

		double notRoundPrice = PriceUtil.priceRounding(bdPrice.doubleValue(), place);
		if (price == notRoundPrice)return notRoundPrice; 

		BigDecimal afterPrice = bdPrice.setScale((place), BigDecimal.ROUND_UP);
		return afterPrice.doubleValue() ;

	}	

	public static double priceRounddownTo2(double price) {

		BigDecimal bdPrice = new BigDecimal(price);
		double notRoundPrice = PriceUtil.priceRounding(price, 2);
		if (notRoundPrice == price) return notRoundPrice;
		BigDecimal afterPrice = bdPrice.setScale(2, BigDecimal.ROUND_DOWN);

		return afterPrice.doubleValue();
	}
}
