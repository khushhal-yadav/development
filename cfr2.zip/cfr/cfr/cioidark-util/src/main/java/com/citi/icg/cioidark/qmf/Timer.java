package com.citi.icg.cioidark.qmf;

import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;

import com.citi.icg.cioidark.util.BooleanUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Timer {

    private final static Logger logger = LoggerFactory.getLogger(Timer.class);

    public final static Timer timer = new Timer();

    private final ConcurrentHashMap<String, ScheduledFuture<?>> timerTasks;
    private final ScheduledThreadPoolExecutor stpe;
    private final int corePoolSize = 5;

    private Timer() {
        this.timerTasks = new ConcurrentHashMap<>();
        this.stpe = new ScheduledThreadPoolExecutor(this.corePoolSize, Executors.defaultThreadFactory());
    }

    public static Timer getInstance() {
        return timer;
    }

    public ScheduledFuture<?> schedule(final TimerRunnable timerRunnable, final TimerTask timerTask,
                                       final long delay, final long period) {
        ScheduledFuture<?> future;
        timerRunnable.setTimerTask(timerTask);

        if (period <= 0)
            future = stpe.schedule(timerRunnable, delay, timerTask.getTimerUnit());
        else
            future = stpe.scheduleWithFixedDelay(timerRunnable, delay, period, timerTask.getTimerUnit());

        logger.info("Task scheduled | {}", timerTask);
        this.timerTasks.put(timerTask.getKey(), future);
        return future;
    }

    public ScheduledFuture<?> schedule(final TimerRunnable timerRunnable, final TimerTask timerTask,
                                       final Date time, final long period) {
        final long delay = time.getTime() - System.currentTimeMillis();

        if (delay < 0)
            return schedule(timerRunnable, timerTask, 0, period);
        else
            return schedule(timerRunnable, timerTask, delay, period);
    }

    public void remove(final TimerTask timerTask) {
        ScheduledFuture<?> future = timerTasks.remove(timerTask.getKey());

        BooleanUtil.ifNotNullExecuteOrElse(
                future,
                () -> {
                    remove(future);
                    logger.info("Task removed for |" + timerTask.getTaskType() + "|" + timerTask.getTaskId());
                },
                () -> logger.info("No task to remove or currently scheduled for |" + timerTask.getTaskType() + "|" + timerTask.getTaskId())

        );
    }

    private void remove(final ScheduledFuture<?> future) {
        future.cancel(false);;
    }
}
