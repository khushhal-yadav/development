package com.citi.icg.cioidark.enumeration;

import java.util.HashMap;
import java.util.Map;

public enum Rank {
    A("A", 1),
    B("B", 2),
    C("C", 3),
    D("D", 4),
    DEFAULT("DEFAUL", 0);

    private String value;
    private int intValue;

    Rank(String value, int intValue) {
        this.value = value;
        this.intValue = intValue;
    }

    private static Map<String, Rank> map = new HashMap<>();

    static {
        for (Rank constantEnum : Rank.values()) {
            map.put(constantEnum.value, constantEnum);
        }
    }

    public String value() {
        return value;
    }

    public int intValue() {
        return intValue;
    }

    public static Rank valueOf(final int value) {
        return map.get(value);
    }
}

