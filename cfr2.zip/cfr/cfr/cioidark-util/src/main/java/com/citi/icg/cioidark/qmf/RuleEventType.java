package com.citi.icg.cioidark.qmf;

/*
 *  Author: Manmohan Salandri
 *  Version: 1.0
 * */

public enum RuleEventType{

	NEWORD(1,"D","NEWORD"),
	MODORD(2,"G","MODORD"),
	CXLORD(3,"F","CXLORD"),
	MKTDATA(4, "MD", "MKTDATA"),
	EXECRPT(5, "8", "EXECRPT"),
	MODCXLREJ(6,"9","MODCXLREJ"),
	EVENTINFO(7,"EVENTINFO","EVENTINFO"),
	EXECINFO(8, "EXECINFO","EXECINFO"),
	ACTRECORD(9,"ACTRECORD","ACTRECORD"),
	MSIRECORD(10, "MSIRECORD","MSIRECORD"),
	MESSAGE(11,"MESSAGE","MESSAGE"),
	UPDATELOAD(12,"UL","UPDATELOAD"),
	ADMIN(13,"BE","ADMIN"),
	TIMER(14,"TE","TIMER"),
	DISTMSG(15,"UZDO","DISTMSG"),
	BUSTRAN(16,"UBT","BUSTRAN"),
	IOI(17,"6","IOI"),
	CONFIGREQUEST(18,"PL","CONFIGREQUEST"),
	ROUTINGREQUEST(19,"RR","ROUTINGREQUEST"),
	ADVERTISEMENT(20, "7", "ADVERTISEMENT"),
	BBQURQ(21, "UZBBQURQ", "BBQURQ"),
	BBQURS(22, "UZBBQURS", "BBQURS"),
	PSQURQ(23, "UZPSQURQ", "PSQURQ"),
	PSQURS(24, "UZPSQURS", "PSQURS"),
	QURS(25, "UZQURS", "QURS"),
	PRICEOFFSET(26,"PO", "PRICEOFFSET"),
	UTTA(27,"UTTA","UTTA"),
	QUOTE(28,"S","QUOTE"),
	MIFIDQUOTE(29,"i","MIFIDQUOTE"),
	MASSCANCEL(30, "q", "MASSCANCEL"),
	QUOTERESPONSE(31, "AJ", "QUOTERESPONSE"),
	ANALYSTICDATA(32, "AD", "ANALYTICDATA");
	
	private final int eventType;
	private final String messageType;
	private final String name;

	RuleEventType(int eventType, String messageType, String name) {
		this.eventType = eventType;
		this.messageType = messageType;
		this.name = name;
	}
	
	public int getEventType() {
		
		return eventType;
	}
	
	public String getName() {
		return name;
	}

	public String getMessageType() {
		return messageType;
	}
	public static RuleEventType getEnumType(int val){
		switch(val){
			case 1: return NEWORD;
			case 2: return MODORD;
			case 3: return CXLORD;
			case 4: return MKTDATA;
			case 5: return EXECRPT;
			case 6: return MODCXLREJ;
			case 7: return EVENTINFO;
			case 8: return EXECINFO;
			case 9: return ACTRECORD;
			case 10: return MSIRECORD;
			case 11: return MESSAGE;
			case 12: return UPDATELOAD;
			case 13: return ADMIN;
			case 14: return TIMER;
			case 15: return DISTMSG;
			case 16: return BUSTRAN;
			case 17: return IOI;
			case 18: return CONFIGREQUEST;
			case 19: return ROUTINGREQUEST;
			case 20: return ADVERTISEMENT;
			case 21: return BBQURQ;
			case 22: return BBQURS;
			case 23: return PSQURQ;
			case 24: return PSQURS;
			case 25: return QURS;
			case 26: return PRICEOFFSET;		
			case 27: return UTTA;
			case 28: return QUOTE;
			case 29: return MIFIDQUOTE;
			case 30: return MASSCANCEL;
			case 31: return QUOTERESPONSE;
			case 32: return ANALYSTICDATA;
		
			default: return null;
		}
	}
	
	
	public static RuleEventType getEnumType(String val){
		switch (val) {
			case "D":
				return NEWORD;
			case "MD":
				return MKTDATA;
			case "G":
				return MODORD;
			case "F":
				return CXLORD;
			case "8":
				return EXECRPT;
			case "9":
				return MODCXLREJ;
			case "DO":
				return DISTMSG;
			case "BT":
				return BUSTRAN;
			case "5":
				return EVENTINFO;
			case "6":
				return IOI;
			case "10":
				return ACTRECORD;
			case "11":
				return MSIRECORD;
			case "MESSAGE":
				return MESSAGE;
			case "UL":
				return UPDATELOAD;
			case "ADMIN":
				return ADMIN;
			case "TIMER":
				return TIMER;
			case "PL":
				return CONFIGREQUEST;
			case "RR":
				return ROUTINGREQUEST;
			case "ADVERTISEMENT":
				return ADVERTISEMENT;
			case "UZBBQURQ":
				return BBQURQ;
			case "UZBBQURS":
				return BBQURS;
			case "":
				return PSQURQ;
			case "UZPSQURQ":
				return PSQURS;
			case "UZPSQURS":
				return QURS;
			case "PO":
				return PRICEOFFSET;
			case "UTTA":
				return UTTA;
			case "QUOTE":
				return QUOTE;
			case "i":
				return MIFIDQUOTE;
			case "q":
				return MASSCANCEL;
			case "AJ":
				return QUOTERESPONSE;
			default:
				return null;
		}
	}

}
