package com.citi.icg.cioidark.util.objectPool;

import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;

public class PooledObjectFactory<T> extends BasePooledObjectFactory<T> {

    private final Class<T> clazz;

    public PooledObjectFactory(Class<T> clazz) {
        this.clazz = clazz;
    }

    @Override
    public T create() throws Exception {
        return clazz.newInstance();
    }

    @Override
    public PooledObject<T> wrap(T p) {
        return new DefaultPooledObject<T>(p);
    }
}
