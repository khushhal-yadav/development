package com.citi.icg.cioidark.util.threadpool.event;

public interface Event<T> extends Runnable {

    String getSynchKey();
    void setSynchKey(final String synchKey);
    T getPayload();
    void setPayload(final T payload);
    long getMsgSeq();
    void setMsgSeq(final long msgSeq);


}
