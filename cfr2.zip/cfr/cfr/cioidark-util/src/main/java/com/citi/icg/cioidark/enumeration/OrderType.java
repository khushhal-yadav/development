package com.citi.icg.cioidark.enumeration;

public enum OrderType {

    CONDITIONAL_ORDER("8"), FIRMED_UP_ORDER("10");

    private String value;

    OrderType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
}
