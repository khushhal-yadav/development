package com.citi.icg.cioidark.qmf;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class TimerRunnable implements Runnable {

    protected final static Logger logger = LoggerFactory.getLogger(TimerRunnable.class);

    private TimerTask timerTask;

    public TimerTask getTimerTask() {
        return timerTask;
    }

    public void setTimerTask(TimerTask timerTask) {
        this.timerTask = timerTask;
    }
}
