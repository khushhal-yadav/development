package com.citi.icg.cioidark.util;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

import software.chronicle.fix.staticcode.messages.FixConstants;

/**
 * Util to simplify code complexity
 */
public class BooleanUtil {

    public static void ifTrueExecute(boolean condition, Procedure executeIfTrue) {
        ifTrueExecuteOrElse(condition, executeIfTrue, () -> {
        });
    }

    public static void ifFalseExecute(boolean condition, Procedure executeIfFalse) {
        ifFalseExecuteOrElse(condition, executeIfFalse, () -> {
        });
    }

    public static <T> void ifNotNullExecute(T param, Procedure executeIfNotNull) {
        ifNotNullExecuteOrElse(param, executeIfNotNull, () -> {
        });
    }

    public static <T> void ifTrueExecute(T param, boolean condition, Consumer<T> executeIfTrue) {
        ifTrueExecuteOrElse(param, () -> condition, executeIfTrue, () -> {
        });
    }

    public static <T> T ifTrueOrElse(boolean condition, T ifTrueValue, T elseValue) {
        return ifTrueOrElse(() -> condition, ifTrueValue, elseValue);
    }

    public static <T> void ifNotNullExecute(T param, Consumer<T> executeIfNotNull) {
        ifTrueExecuteOrElse(param, () -> (param != null), executeIfNotNull, () -> {
        });
    }

    public static <R> R ifTrueEvaluateOrElse(boolean condition, Supplier<R> evaluateIfTrue, Supplier<R> evaluateIfFalse) {
        return ifTrueEvaluateOrElse(() -> condition, evaluateIfTrue, evaluateIfFalse);
    }

    public static <T, R> R ifNotNullEvaluateOrElse(T param, Supplier<R> evaluateIfNotNull, Supplier<R> evaluateIfNull) {
        return ifTrueEvaluateOrElse(param != null, evaluateIfNotNull, evaluateIfNull);
    }

    public static <T, R> R ifNotNullEvaluateOtherwiseReturnDefault(T param, Supplier<R> evaluateIfNotNull, R defaultValue) {
        return ifTrueEvaluateOtherwiseReturnDefault(param != null, evaluateIfNotNull, defaultValue);
    }

    public static <T> T ifTrueEvaluateOtherwiseReturnDefault(boolean condition, Supplier<T> evaluateIfTrue, T defaultValue) {
        return ifTrueEvaluateOtherwiseReturnDefault(() -> condition, evaluateIfTrue, defaultValue);
    }

    public static <T> void ifTrueExecuteOrElse(T param, boolean condition, Consumer<T> executeIfTrue, Consumer<T> executeIfFalse) {
        ifTrueExecuteOrElse(param, () -> condition, executeIfTrue, executeIfFalse);
    }

    public static <T> void ifTrueExecuteOrElse(T param, boolean condition, Consumer<T> executeIfTrue, Procedure executeIfFalse) {
        ifTrueExecuteOrElse(param, () -> condition, executeIfTrue, executeIfFalse);
    }

    public static <T> void ifNotNullExecuteOrElse(T param, Consumer<T> executeIfNotNull, Procedure executeIfNull) {
        ifTrueExecuteOrElse(param, () -> param != null, executeIfNotNull, executeIfNull);
    }

    public static void ifTrueExecuteOrElse(boolean condition, Procedure executeIfTrue, Procedure executeIfFalse) {
        ifTrueExecuteOrElse(() -> condition, executeIfTrue, executeIfFalse);
    }

    private static void ifFalseExecuteOrElse(boolean condition, Procedure executeIfFalse, Procedure executeIfTrue) {
        ifTrueExecuteOrElse(() -> !condition, executeIfFalse, executeIfTrue);
    }

    public static <T> void ifNotNullExecuteOrElse(T param, Procedure executeIfNotNull, Procedure executeIfNull) {
        ifTrueExecuteOrElse(param != null, executeIfNotNull, executeIfNull);
    }

    private static void ifTrueExecuteOrElse(BooleanSupplier bs, Procedure p1, Procedure p2) {
        if (bs.getAsBoolean())
            p1.execute();
        else
            p2.execute();
    }

    private static <T> void ifTrueExecuteOrElse(T t, BooleanSupplier bs, Consumer<T> c1, Consumer<T> c2) {
        if (bs.getAsBoolean())
            c1.accept(t);
        else
            c2.accept(t);
    }

    private static <T> void ifTrueExecuteOrElse(T t, BooleanSupplier bs, Consumer<T> c, Procedure pr) {
        if (bs.getAsBoolean())
            c.accept(t);
        else
            pr.execute();
    }

    private static <T> T ifTrueEvaluateOtherwiseReturnDefault(BooleanSupplier bs, Supplier<T> s, T defaultValue) {
        if (bs.getAsBoolean())
            return s.get();
        else
            return defaultValue;
    }

    private static <R> R ifTrueEvaluateOrElse(BooleanSupplier bs, Supplier<R> s1, Supplier<R> s2) {
        if (bs.getAsBoolean())
            return s1.get();
        else
            return s2.get();
    }

    public static <T> T ifTrueOrElse(BooleanSupplier bs, T ifTrueValue, T elseValue) {
        if (bs.getAsBoolean())
            return ifTrueValue;
        else
            return elseValue;
    }

    public static void ifSetPopulateFixTag(String param, Consumer<String> c) {
        ifTrueSetFixTag(param, () -> !FixConstants.isUnset(param), c);
    }

    public static void ifSetPopulateFixTag(Double param, Consumer<Double> c) {
        ifTrueSetFixTag(param, () -> !FixConstants.isUnset(param), c);
    }

    public static void ifSetPopulateFixTag(Long param, Consumer<Long> c) {
        ifTrueSetFixTag(param, () -> !FixConstants.isUnset(param), c);
    }

    public static void ifSetPopulateFixTag(Character param, Consumer<Character> c) {
        ifTrueSetFixTag(param, () -> !FixConstants.isUnset(param), c);
    }

    public static void ifPresentSetFixTag(String param, Consumer<String> c) {
        ifTrueSetFixTag(param, () -> FixTagUtil.isValueSet(param), c);
    }

    public static void ifPresentSetFixTag(Long param, Consumer<Long> c) {
        ifTrueSetFixTag(param, () -> FixTagUtil.isValueSet(param), c);
    }

    public static void ifPresentSetFixTag(Double param, Consumer<Double> c) {
        ifTrueSetFixTag(param, () -> FixTagUtil.isValueSet(param), c);
    }

    public static void ifPresentSetFixTag(Character param, Consumer<Character> c) {
        ifTrueSetFixTag(param, () -> FixTagUtil.isValueSet(param), c);
    }

    private static <T> void ifTrueSetFixTag(T param, BooleanSupplier bs, Consumer<T> c) {
        if (bs.getAsBoolean())
            c.accept(param);
    }
}
