package com.citi.icg.cioidark.util.threadpool;


import java.util.concurrent.BlockingQueue;

import com.citi.icg.cioidark.util.Util;
import com.citi.icg.cioidark.util.threadpool.event.Event;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CioiDarkThreadRunnable<T> implements Runnable {

    private static final Logger logger = LoggerFactory.getLogger(CioiDarkThreadRunnable.class);
    private final CioiDarkThreadPool<T> threadPool;
    private final String synchronizer;

    public CioiDarkThreadRunnable(CioiDarkThreadPool<T> threadPool, String synchronizer) {
        this.threadPool = threadPool;
        this.synchronizer = synchronizer;
    }

    @Override
    public void run() {

        try {

            boolean queueNotEmpty = true;

            while(queueNotEmpty) {
                BlockingQueue<Event<T>> blockingQueue;
                synchronized (threadPool.interner.intern(synchronizer)) {
                    blockingQueue = threadPool.concurrencyMap.remove(synchronizer);
                }

                queueNotEmpty = blockingQueue != null && blockingQueue.size() > 0;

                if (queueNotEmpty) {
                    Event<T> event;
                    while ((event = blockingQueue.poll()) != null) {
                        event.run();
                    }
                }

                if (!queueNotEmpty) {
                    synchronized(threadPool.interner.intern(synchronizer)) {
                        if (threadPool.concurrencyMap.get(synchronizer) == null
                                || threadPool.concurrencyMap.get(synchronizer).size() == 0) {
                            threadPool.submittedTaskMap.remove(synchronizer);
                            queueNotEmpty = false;
                        }
                    }
                }
            }
        } catch (Throwable t) {
            logger.warn(Util.getStackTrace(t));
        }
    }
}
