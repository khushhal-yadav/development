package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LeafExecFlag {
    /**
     * Tag number for this field
     */
    int FIELD = 10217;

    /**
     * @param leafExecFlag &gt; FIX TAG 10217
     */
    void leafExecFlag(char leafExecFlag);

    default char leafExecFlag() {
        throw new UnsupportedOperationException();
    }
}
