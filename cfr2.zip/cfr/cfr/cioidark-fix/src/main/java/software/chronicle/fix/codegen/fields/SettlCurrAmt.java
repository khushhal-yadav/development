package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SettlCurrAmt {
    /**
     * Tag number for this field
     */
    int FIELD = 119;

    /**
     * @param settlCurrAmt &gt; FIX TAG 119
     */
    void settlCurrAmt(double settlCurrAmt);

    default double settlCurrAmt() {
        throw new UnsupportedOperationException();
    }
}
