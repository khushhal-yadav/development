package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface PreviousLinkSrcSystemID {
    /**
     * Tag number for this field
     */
    int FIELD = 10518;

    /**
     * @param previousLinkSrcSystemID &gt; FIX TAG 10518
     */
    void previousLinkSrcSystemID(long previousLinkSrcSystemID);

    default long previousLinkSrcSystemID() {
        throw new UnsupportedOperationException();
    }
}
