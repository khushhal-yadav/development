package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrderFlowClass {
    /**
     * Tag number for this field
     */
    int FIELD = 10201;

    /**
     * @param orderFlowClass &gt; FIX TAG 10201
     */
    void orderFlowClass(String orderFlowClass);

    default String orderFlowClass() {
        throw new UnsupportedOperationException();
    }
}
