package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SellerDays {
    /**
     * Tag number for this field
     */
    int FIELD = 287;

    /**
     * @param sellerDays &gt; FIX TAG 287
     */
    void sellerDays(long sellerDays);

    default long sellerDays() {
        throw new UnsupportedOperationException();
    }
}
