package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CrossInstruction {
    /**
     * Tag number for this field
     */
    int FIELD = 6438;

    String AGENCY_ONLY = "A";

    String NO_CROSSING = "C";

    String EVERYTHING = "E";

    String NO_FILLSERVER = "F";

    String NO_INSTITUTION = "I";

    String NO_LIQUIDITYPING = "L";

    String DO_NOT_CROSS_MARKET_MAKER = "M";

    String NO_RESTRICTION = "N";

    String DO_NOT_CROSS_SELF = "NS";

    String CROSS_WITH_PRINCIPAL_ONLY = "O";

    String NO_PRINCIPLE = "P";

    String SELF = "Q";

    String NO_RETAIL = "R";

    String CROSS_WITH_SELF_AS_PRIORITY = "S";

    String NO_WHOLESALE = "W";

    String NO_CROSSING_NO_POST = "X";

    String NO_CRB = "Y";

    String NO_CLIENT_CONDORDER = "Z";

    /**
     * @param crossInstruction &gt; FIX TAG 6438
     */
    void crossInstruction(String crossInstruction);

    default String crossInstruction() {
        throw new UnsupportedOperationException();
    }

    static String asString(String value) {
        return value;
    }
}
