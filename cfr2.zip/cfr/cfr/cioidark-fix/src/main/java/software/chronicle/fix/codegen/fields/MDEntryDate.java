package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MDEntryDate {
    /**
     * Tag number for this field
     */
    int FIELD = 272;

    /**
     * @param mDEntryDate &gt; FIX TAG 272
     */
    void mDEntryDate(String mDEntryDate);

    default String mDEntryDate() {
        throw new UnsupportedOperationException();
    }
}
