package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.fields.CashOrderQty;
import software.chronicle.fix.codegen.fields.ContractMultiplier;
import software.chronicle.fix.codegen.fields.CouponRate;
import software.chronicle.fix.codegen.fields.DKReason;
import software.chronicle.fix.codegen.fields.EncodedIssuer;
import software.chronicle.fix.codegen.fields.EncodedIssuerLen;
import software.chronicle.fix.codegen.fields.EncodedSecurityDescLen;
import software.chronicle.fix.codegen.fields.EncodedText;
import software.chronicle.fix.codegen.fields.EncodedTextLen;
import software.chronicle.fix.codegen.fields.ExecID;
import software.chronicle.fix.codegen.fields.IDSource;
import software.chronicle.fix.codegen.fields.Issuer;
import software.chronicle.fix.codegen.fields.LastPx;
import software.chronicle.fix.codegen.fields.LastShares;
import software.chronicle.fix.codegen.fields.MaturityDay;
import software.chronicle.fix.codegen.fields.MaturityMonthYear;
import software.chronicle.fix.codegen.fields.OptAttribute;
import software.chronicle.fix.codegen.fields.OrderID;
import software.chronicle.fix.codegen.fields.OrderQty;
import software.chronicle.fix.codegen.fields.PutOrCall;
import software.chronicle.fix.codegen.fields.SecurityDesc;
import software.chronicle.fix.codegen.fields.SecurityExchange;
import software.chronicle.fix.codegen.fields.SecurityID;
import software.chronicle.fix.codegen.fields.SecurityType;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.fields.StrikePrice;
import software.chronicle.fix.codegen.fields.Symbol;
import software.chronicle.fix.codegen.fields.SymbolSfx;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.fields.Text;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface DontKnowTrade extends HeaderTrailer, OrderID, ExecID, DKReason, Symbol, SymbolSfx, SecurityID, IDSource, SecurityType, MaturityMonthYear, MaturityDay, PutOrCall, StrikePrice, OptAttribute, ContractMultiplier, CouponRate, SecurityExchange, Issuer, EncodedIssuerLen, EncodedIssuer, SecurityDesc, EncodedSecurityDescLen, Side, OrderQty, CashOrderQty, LastShares, LastPx, Text, EncodedTextLen, EncodedText {
    @Deprecated
    static DontKnowTrade newDontKnowTrade(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.DontKnowTrade);
        mg.bytes(bytes);
        return mg;
    }

    static DontKnowTrade newDontKnowTrade(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.DontKnowTrade, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (orderID() == null) throw new RequiredTagMissing("orderID", 37);
        if (execID() == null) throw new RequiredTagMissing("execID", 17);
        if (dKReason() == FixMessage.UNSET_CHAR) throw new RequiredTagMissing("dKReason", 127);
        if (symbol() == null) throw new RequiredTagMissing("symbol", 55);
        if (side() == FixMessage.UNSET_CHAR) throw new RequiredTagMissing("side", 54);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        orderID(null);
        execID(null);
        dKReason(FixMessage.UNSET_CHAR);
        symbol(null);
        symbolSfx(null);
        securityID(null);
        idSource(null);
        securityType(null);
        maturityMonthYear(null);
        maturityDay(FixMessage.UNSET_LONG);
        putOrCall(FixMessage.UNSET_LONG);
        strikePrice(FixMessage.UNSET_DOUBLE);
        optAttribute(FixMessage.UNSET_CHAR);
        contractMultiplier(FixMessage.UNSET_DOUBLE);
        couponRate(FixMessage.UNSET_DOUBLE);
        securityExchange(null);
        issuer(null);
        encodedIssuerLen(FixMessage.UNSET_LONG);
        encodedIssuer(null);
        securityDesc(null);
        encodedSecurityDescLen(FixMessage.UNSET_LONG);
        side(FixMessage.UNSET_CHAR);
        orderQty(FixMessage.UNSET_DOUBLE);
        cashOrderQty(FixMessage.UNSET_DOUBLE);
        lastShares(FixMessage.UNSET_DOUBLE);
        lastPx(FixMessage.UNSET_DOUBLE);
        text(null);
        encodedTextLen(FixMessage.UNSET_LONG);
        encodedText(null);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((DontKnowTrade) msg);
    }

    default void copyTo(DontKnowTrade msg) {
        HeaderTrailer.super.copyTo(msg);
        if (orderID() != null) msg.orderID(orderID());
        if (execID() != null) msg.execID(execID());
        if (dKReason() != FixMessage.UNSET_CHAR) msg.dKReason(dKReason());
        if (symbol() != null) msg.symbol(symbol());
        if (symbolSfx() != null) msg.symbolSfx(symbolSfx());
        if (securityID() != null) msg.securityID(securityID());
        if (idSource() != null) msg.idSource(idSource());
        if (securityType() != null) msg.securityType(securityType());
        if (maturityMonthYear() != null) msg.maturityMonthYear(maturityMonthYear());
        if (maturityDay() != FixMessage.UNSET_LONG) msg.maturityDay(maturityDay());
        if (putOrCall() != FixMessage.UNSET_LONG) msg.putOrCall(putOrCall());
        if (!Double.isNaN(strikePrice())) msg.strikePrice(strikePrice());
        if (optAttribute() != FixMessage.UNSET_CHAR) msg.optAttribute(optAttribute());
        if (!Double.isNaN(contractMultiplier())) msg.contractMultiplier(contractMultiplier());
        if (!Double.isNaN(couponRate())) msg.couponRate(couponRate());
        if (securityExchange() != null) msg.securityExchange(securityExchange());
        if (issuer() != null) msg.issuer(issuer());
        if (encodedIssuerLen() != FixMessage.UNSET_LONG) msg.encodedIssuerLen(encodedIssuerLen());
        if (encodedIssuer() != null) msg.encodedIssuer(encodedIssuer());
        if (securityDesc() != null) msg.securityDesc(securityDesc());
        if (encodedSecurityDescLen() != FixMessage.UNSET_LONG) msg.encodedSecurityDescLen(encodedSecurityDescLen());
        if (side() != FixMessage.UNSET_CHAR) msg.side(side());
        if (!Double.isNaN(orderQty())) msg.orderQty(orderQty());
        if (!Double.isNaN(cashOrderQty())) msg.cashOrderQty(cashOrderQty());
        if (!Double.isNaN(lastShares())) msg.lastShares(lastShares());
        if (!Double.isNaN(lastPx())) msg.lastPx(lastPx());
        if (text() != null) msg.text(text());
        if (encodedTextLen() != FixMessage.UNSET_LONG) msg.encodedTextLen(encodedTextLen());
        if (encodedText() != null) msg.encodedText(encodedText());
    }
}
