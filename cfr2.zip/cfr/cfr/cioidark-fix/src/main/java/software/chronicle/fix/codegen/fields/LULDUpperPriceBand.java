package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LULDUpperPriceBand {
    /**
     * Tag number for this field
     */
    int FIELD = 10722;

    /**
     * @param lULDUpperPriceBand &gt; FIX TAG 10722
     */
    void lULDUpperPriceBand(double lULDUpperPriceBand);

    default double lULDUpperPriceBand() {
        throw new UnsupportedOperationException();
    }
}
