package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface NumberOfOrders {
    /**
     * Tag number for this field
     */
    int FIELD = 346;

    /**
     * @param numberOfOrders &gt; FIX TAG 346
     */
    void numberOfOrders(long numberOfOrders);

    default long numberOfOrders() {
        throw new UnsupportedOperationException();
    }
}
