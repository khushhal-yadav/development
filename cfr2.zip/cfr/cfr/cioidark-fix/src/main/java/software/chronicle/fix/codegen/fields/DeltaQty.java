package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface DeltaQty {
    /**
     * Tag number for this field
     */
    int FIELD = 9001;

    /**
     * @param deltaQty &gt; FIX TAG 9001
     */
    void deltaQty(double deltaQty);

    default double deltaQty() {
        throw new UnsupportedOperationException();
    }
}
