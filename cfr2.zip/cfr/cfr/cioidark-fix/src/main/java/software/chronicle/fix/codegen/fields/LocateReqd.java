package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LocateReqd {
    /**
     * Tag number for this field
     */
    int FIELD = 114;

    char NO = 'N';

    char YES = 'Y';

    /**
     * @param locateReqd &gt; FIX TAG 114
     */
    void locateReqd(char locateReqd);

    default char locateReqd() {
        throw new UnsupportedOperationException();
    }

    static String asString(char value) {
        switch (value) {
            case NO:
                    return "NO";
            case YES:
                    return "YES";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
