package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrderVersion {
    /**
     * Tag number for this field
     */
    int FIELD = 12052;

    /**
     * @param orderVersion &gt; FIX TAG 12052
     */
    void orderVersion(long orderVersion);

    default long orderVersion() {
        throw new UnsupportedOperationException();
    }
}
