package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CustomPrice1 {
    /**
     * Tag number for this field
     */
    int FIELD = 7491;

    /**
     * @param customPrice1 &gt; FIX TAG 7491
     */
    void customPrice1(String customPrice1);

    default String customPrice1() {
        throw new UnsupportedOperationException();
    }
}
