package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MinQty {
    /**
     * Tag number for this field
     */
    int FIELD = 110;

    /**
     * @param minQty &gt; FIX TAG 110
     */
    void minQty(double minQty);

    default double minQty() {
        throw new UnsupportedOperationException();
    }
}
