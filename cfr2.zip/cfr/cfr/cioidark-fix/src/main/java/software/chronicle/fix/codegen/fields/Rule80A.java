package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface Rule80A {
    /**
     * Tag number for this field
     */
    int FIELD = 47;

    char AGENCY_SINGLE_ORDER = 'A';

    char SHORT_EXEMPT_TRANSACTION_B = 'B';

    char PROGRAM_ORDER_NONINDEX_ARB_FOR_MEMBER_FIRMORG = 'C';

    char PROGRAM_ORDER_INDEX_ARB_FOR_MEMBER_FIRMORG = 'D';

    char REGISTERED_EQUITY_MARKET_MAKER_TRADES = 'E';

    char SHORT_EXEMPT_TRANSACTION_F = 'F';

    char SHORT_EXEMPT_TRANSACTION_H = 'H';

    char INDIVIDUAL_INVESTOR = 'I';

    char PROGRAM_ORDER_INDEX_ARB_FOR_INDIVIDUAL_CUSTOMER = 'J';

    char PROGRAM_ORDER_NONINDEX_ARB_FOR_INDIVIDUAL_CUSTOMER = 'K';

    char SHORT_EXEMPT_AFFILIATED = 'L';

    char PROGRAM_ORDER_INDEX_ARB_FOR_OTHER_MEMBER = 'M';

    char PROGRAM_ORDER_NONINDEX_ARB_FOR_OTHER_MEMBER = 'N';

    char COMPETING_DEALER_TRADES_O = 'O';

    char PRINCIPAL = 'P';

    char COMPETING_DEALER_TRADES_R = 'R';

    char SPECIALIST_TRADES = 'S';

    char COMPETING_DEALER_TRADES_T = 'T';

    char PROGRAM_ORDER_INDEX_ARB_FOR_OTHER_AGENCY = 'U';

    char ALL_OTHER_ORDERS_AS_AGENT_FOR_OTHER_MEMBER = 'W';

    char SHORT_EXEMPT_NOT_AFFILIATED = 'X';

    char PROGRAM_ORDER_NONINDEX_ARB_FOR_OTHER_AGENCY = 'Y';

    char SHORT_EXEMPT_NONMEMBER = 'Z';

    /**
     * @param rule80A &gt; FIX TAG 47
     */
    void rule80A(char rule80A);

    default char rule80A() {
        throw new UnsupportedOperationException();
    }

    static String asString(char value) {
        switch (value) {
            case AGENCY_SINGLE_ORDER:
                    return "AGENCY_SINGLE_ORDER";
            case SHORT_EXEMPT_TRANSACTION_B:
                    return "SHORT_EXEMPT_TRANSACTION_B";
            case PROGRAM_ORDER_NONINDEX_ARB_FOR_MEMBER_FIRMORG:
                    return "PROGRAM_ORDER_NONINDEX_ARB_FOR_MEMBER_FIRMORG";
            case PROGRAM_ORDER_INDEX_ARB_FOR_MEMBER_FIRMORG:
                    return "PROGRAM_ORDER_INDEX_ARB_FOR_MEMBER_FIRMORG";
            case REGISTERED_EQUITY_MARKET_MAKER_TRADES:
                    return "REGISTERED_EQUITY_MARKET_MAKER_TRADES";
            case SHORT_EXEMPT_TRANSACTION_F:
                    return "SHORT_EXEMPT_TRANSACTION_F";
            case SHORT_EXEMPT_TRANSACTION_H:
                    return "SHORT_EXEMPT_TRANSACTION_H";
            case INDIVIDUAL_INVESTOR:
                    return "INDIVIDUAL_INVESTOR";
            case PROGRAM_ORDER_INDEX_ARB_FOR_INDIVIDUAL_CUSTOMER:
                    return "PROGRAM_ORDER_INDEX_ARB_FOR_INDIVIDUAL_CUSTOMER";
            case PROGRAM_ORDER_NONINDEX_ARB_FOR_INDIVIDUAL_CUSTOMER:
                    return "PROGRAM_ORDER_NONINDEX_ARB_FOR_INDIVIDUAL_CUSTOMER";
            case SHORT_EXEMPT_AFFILIATED:
                    return "SHORT_EXEMPT_AFFILIATED";
            case PROGRAM_ORDER_INDEX_ARB_FOR_OTHER_MEMBER:
                    return "PROGRAM_ORDER_INDEX_ARB_FOR_OTHER_MEMBER";
            case PROGRAM_ORDER_NONINDEX_ARB_FOR_OTHER_MEMBER:
                    return "PROGRAM_ORDER_NONINDEX_ARB_FOR_OTHER_MEMBER";
            case COMPETING_DEALER_TRADES_O:
                    return "COMPETING_DEALER_TRADES_O";
            case PRINCIPAL:
                    return "PRINCIPAL";
            case COMPETING_DEALER_TRADES_R:
                    return "COMPETING_DEALER_TRADES_R";
            case SPECIALIST_TRADES:
                    return "SPECIALIST_TRADES";
            case COMPETING_DEALER_TRADES_T:
                    return "COMPETING_DEALER_TRADES_T";
            case PROGRAM_ORDER_INDEX_ARB_FOR_OTHER_AGENCY:
                    return "PROGRAM_ORDER_INDEX_ARB_FOR_OTHER_AGENCY";
            case ALL_OTHER_ORDERS_AS_AGENT_FOR_OTHER_MEMBER:
                    return "ALL_OTHER_ORDERS_AS_AGENT_FOR_OTHER_MEMBER";
            case SHORT_EXEMPT_NOT_AFFILIATED:
                    return "SHORT_EXEMPT_NOT_AFFILIATED";
            case PROGRAM_ORDER_NONINDEX_ARB_FOR_OTHER_AGENCY:
                    return "PROGRAM_ORDER_NONINDEX_ARB_FOR_OTHER_AGENCY";
            case SHORT_EXEMPT_NONMEMBER:
                    return "SHORT_EXEMPT_NONMEMBER";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
