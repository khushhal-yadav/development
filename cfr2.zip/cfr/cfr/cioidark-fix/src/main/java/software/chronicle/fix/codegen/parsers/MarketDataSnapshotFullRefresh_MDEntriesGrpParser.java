package software.chronicle.fix.codegen.parsers;

import software.chronicle.fix.codegen.components.MarketDataSnapshotFullRefresh_MDEntriesGrp;

/**
 * Generated at software.chronicle.fix.codegen.ComponentGenerator.generateComponent(ComponentGenerator.java)
 */
public interface MarketDataSnapshotFullRefresh_MDEntriesGrpParser {
    void parse(GeneratedCoreFieldParser fixParser, MarketDataSnapshotFullRefresh_MDEntriesGrp message, int groupNum);
}
