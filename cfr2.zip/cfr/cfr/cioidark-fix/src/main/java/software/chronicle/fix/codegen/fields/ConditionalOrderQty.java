package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ConditionalOrderQty {
    /**
     * Tag number for this field
     */
    int FIELD = 8060;

    /**
     * @param conditionalOrderQty &gt; FIX TAG 8060
     */
    void conditionalOrderQty(double conditionalOrderQty);

    default double conditionalOrderQty() {
        throw new UnsupportedOperationException();
    }
}
