package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface Currency {
    /**
     * Tag number for this field
     */
    int FIELD = 15;

    /**
     * @param currency &gt; FIX TAG 15
     */
    void currency(String currency);

    default String currency() {
        throw new UnsupportedOperationException();
    }
}
