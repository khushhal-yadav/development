package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface Account {
    /**
     * Tag number for this field
     */
    int FIELD = 1;

    /**
     * @param account &gt; FIX TAG 1
     */
    void account(String account);

    default String account() {
        throw new UnsupportedOperationException();
    }
}
