package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ExDestination {
    /**
     * Tag number for this field
     */
    int FIELD = 100;

    /**
     * @param exDestination &gt; FIX TAG 100
     */
    void exDestination(String exDestination);

    default String exDestination() {
        throw new UnsupportedOperationException();
    }
}
