package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface Tier {
    /**
     * Tag number for this field
     */
    int FIELD = 10270;

    /**
     * @param tier &gt; FIX TAG 10270
     */
    void tier(long tier);

    default long tier() {
        throw new UnsupportedOperationException();
    }
}
