package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MDEntryPositionNo {
    /**
     * Tag number for this field
     */
    int FIELD = 290;

    /**
     * @param mDEntryPositionNo &gt; FIX TAG 290
     */
    void mDEntryPositionNo(long mDEntryPositionNo);

    default long mDEntryPositionNo() {
        throw new UnsupportedOperationException();
    }
}
