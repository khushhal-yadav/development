package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MDEntrySize {
    /**
     * Tag number for this field
     */
    int FIELD = 271;

    /**
     * @param mDEntrySize &gt; FIX TAG 271
     */
    void mDEntrySize(double mDEntrySize);

    default double mDEntrySize() {
        throw new UnsupportedOperationException();
    }
}
