package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CashOrderQty {
    /**
     * Tag number for this field
     */
    int FIELD = 152;

    /**
     * @param cashOrderQty &gt; FIX TAG 152
     */
    void cashOrderQty(double cashOrderQty);

    default double cashOrderQty() {
        throw new UnsupportedOperationException();
    }
}
