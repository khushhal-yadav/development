package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TradingAcct {
    /**
     * Tag number for this field
     */
    int FIELD = 10050;

    /**
     * @param tradingAcct &gt; FIX TAG 10050
     */
    void tradingAcct(String tradingAcct);

    default String tradingAcct() {
        throw new UnsupportedOperationException();
    }
}
