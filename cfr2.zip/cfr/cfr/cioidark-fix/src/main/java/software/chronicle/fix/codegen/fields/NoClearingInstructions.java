package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface NoClearingInstructions {
    /**
     * Tag number for this field
     */
    int FIELD = 576;

    /**
     * @param noClearingInstructions &gt; FIX TAG 576
     */
    void noClearingInstructions(long noClearingInstructions);

    default long noClearingInstructions() {
        throw new UnsupportedOperationException();
    }
}
