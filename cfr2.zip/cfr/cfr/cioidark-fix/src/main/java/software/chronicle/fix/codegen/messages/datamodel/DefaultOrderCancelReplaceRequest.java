package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import java.util.concurrent.TimeUnit;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultOrderCancelReplaceRequest extends DefaultHeaderTrailer implements OrderCancelReplaceRequest, HeaderTrailer {
    private String orderID = null;

    private String clOrdID = null;

    private char side = FixMessage.UNSET_CHAR;

    private double orderQty = FixMessage.UNSET_DOUBLE;

    private double minQty = FixMessage.UNSET_DOUBLE;

    private char ordType = FixMessage.UNSET_CHAR;

    private String origClOrdID = null;

    private String symbol = null;

    private String symbolSfx = null;

    private String idSource = null;

    private char handlInst = FixMessage.UNSET_CHAR;

    private long transactTime = FixMessage.UNSET_LONG;

    private String account = null;

    private double price = FixMessage.UNSET_DOUBLE;

    private double bidPx = FixMessage.UNSET_DOUBLE;

    private double offerPx = FixMessage.UNSET_DOUBLE;

    private long quoteTime = FixMessage.UNSET_LONG;

    private char timeInForce = FixMessage.UNSET_CHAR;

    private long createdNS = FixMessage.UNSET_LONG;

    private double lastTraded = FixMessage.UNSET_DOUBLE;

    private double lastTradedDelta = FixMessage.UNSET_DOUBLE;

    private double bidPrice = FixMessage.UNSET_DOUBLE;

    private double askPrice = FixMessage.UNSET_DOUBLE;

    private char orderCapacity = FixMessage.UNSET_CHAR;

    private String clientID = null;

    private String exDestination = null;

    private String currency = null;

    private char rule80A = FixMessage.UNSET_CHAR;

    private String settlCurrency = null;

    private long customerOrFirm = FixMessage.UNSET_LONG;

    private char locateReqd = FixMessage.UNSET_CHAR;

    private String ordLinkID = null;

    private String ordLinkType = null;

    private String bookingType = null;

    private String tradingAcct = null;

    private String customPrice1 = null;

    private long tier = FixMessage.UNSET_LONG;

    private String noStrategyParameters = null;

    private String strategyParameterValue = null;

    private String crossStrategy = null;

    private String corellationClOrdID = null;

    private String previousLinkOrderID = null;

    private String rootOrderID = null;

    private String customerSlang = null;

    private long receiveTime = FixMessage.UNSET_LONG;

    private String crossRestrictionClientID = null;

    private String execInst = null;

    private String crossInstruction = null;

    private String avgPriceAcctIDSource = null;

    private String tickSizePilotGroup = null;

    private long clearingInstruction = FixMessage.UNSET_LONG;

    private long timeToLive = FixMessage.UNSET_LONG;

    private String srcTargetCompId = null;

    private String ioiID = null;

    private String securityID = null;

    private String securityAltID = null;

    private String securityAltIDSource = null;

    public char msgType() {
        return MessageManifest.OrderCancelReplaceRequest;
    }

    public String orderID() {
        return orderID;
    }

    @Override
    public void orderID(String orderID) {
        this.orderID = orderID;
    }

    public String clOrdID() {
        return clOrdID;
    }

    @Override
    public void clOrdID(String clOrdID) {
        this.clOrdID = clOrdID;
    }

    public char side() {
        return side;
    }

    @Override
    public void side(char side) {
        this.side = side;
    }

    public double orderQty() {
        return orderQty;
    }

    @Override
    public void orderQty(double orderQty) {
        this.orderQty = orderQty;
    }

    public double minQty() {
        return minQty;
    }

    @Override
    public void minQty(double minQty) {
        this.minQty = minQty;
    }

    public char ordType() {
        return ordType;
    }

    @Override
    public void ordType(char ordType) {
        this.ordType = ordType;
    }

    public String origClOrdID() {
        return origClOrdID;
    }

    @Override
    public void origClOrdID(String origClOrdID) {
        this.origClOrdID = origClOrdID;
    }

    public String symbol() {
        return symbol;
    }

    @Override
    public void symbol(String symbol) {
        this.symbol = symbol;
    }

    public String symbolSfx() {
        return symbolSfx;
    }

    @Override
    public void symbolSfx(String symbolSfx) {
        this.symbolSfx = symbolSfx;
    }

    public String idSource() {
        return idSource;
    }

    @Override
    public void idSource(String idSource) {
        this.idSource = idSource;
    }

    public char handlInst() {
        return handlInst;
    }

    @Override
    public void handlInst(char handlInst) {
        this.handlInst = handlInst;
    }

    public long transactTime() {
        return transactTime;
    }

    @Override
    public void transactTime(long transactTime, TimeUnit timeUnit) {
        transactTime(transactTime);
    }

    @Override
    public void transactTime(long transactTime) {
        this.transactTime = transactTime;
    }

    public String account() {
        return account;
    }

    @Override
    public void account(String account) {
        this.account = account;
    }

    public double price() {
        return price;
    }

    @Override
    public void price(double price) {
        this.price = price;
    }

    public double bidPx() {
        return bidPx;
    }

    @Override
    public void bidPx(double bidPx) {
        this.bidPx = bidPx;
    }

    public double offerPx() {
        return offerPx;
    }

    @Override
    public void offerPx(double offerPx) {
        this.offerPx = offerPx;
    }

    public long quoteTime() {
        return quoteTime;
    }

    @Override
    public void quoteTime(long quoteTime, TimeUnit timeUnit) {
        quoteTime(quoteTime);
    }

    @Override
    public void quoteTime(long quoteTime) {
        this.quoteTime = quoteTime;
    }

    public char timeInForce() {
        return timeInForce;
    }

    @Override
    public void timeInForce(char timeInForce) {
        this.timeInForce = timeInForce;
    }

    public long createdNS() {
        return createdNS;
    }

    @Override
    public void createdNS(long createdNS) {
        this.createdNS = createdNS;
    }

    public double lastTraded() {
        return lastTraded;
    }

    @Override
    public void lastTraded(double lastTraded) {
        this.lastTraded = lastTraded;
    }

    public double lastTradedDelta() {
        return lastTradedDelta;
    }

    @Override
    public void lastTradedDelta(double lastTradedDelta) {
        this.lastTradedDelta = lastTradedDelta;
    }

    public double bidPrice() {
        return bidPrice;
    }

    @Override
    public void bidPrice(double bidPrice) {
        this.bidPrice = bidPrice;
    }

    public double askPrice() {
        return askPrice;
    }

    @Override
    public void askPrice(double askPrice) {
        this.askPrice = askPrice;
    }

    public char orderCapacity() {
        return orderCapacity;
    }

    @Override
    public void orderCapacity(char orderCapacity) {
        this.orderCapacity = orderCapacity;
    }

    public String clientID() {
        return clientID;
    }

    @Override
    public void clientID(String clientID) {
        this.clientID = clientID;
    }

    public String exDestination() {
        return exDestination;
    }

    @Override
    public void exDestination(String exDestination) {
        this.exDestination = exDestination;
    }

    public String currency() {
        return currency;
    }

    @Override
    public void currency(String currency) {
        this.currency = currency;
    }

    public char rule80A() {
        return rule80A;
    }

    @Override
    public void rule80A(char rule80A) {
        this.rule80A = rule80A;
    }

    public String settlCurrency() {
        return settlCurrency;
    }

    @Override
    public void settlCurrency(String settlCurrency) {
        this.settlCurrency = settlCurrency;
    }

    public long customerOrFirm() {
        return customerOrFirm;
    }

    @Override
    public void customerOrFirm(long customerOrFirm) {
        this.customerOrFirm = customerOrFirm;
    }

    public char locateReqd() {
        return locateReqd;
    }

    @Override
    public void locateReqd(char locateReqd) {
        this.locateReqd = locateReqd;
    }

    public String ordLinkID() {
        return ordLinkID;
    }

    @Override
    public void ordLinkID(String ordLinkID) {
        this.ordLinkID = ordLinkID;
    }

    public String ordLinkType() {
        return ordLinkType;
    }

    @Override
    public void ordLinkType(String ordLinkType) {
        this.ordLinkType = ordLinkType;
    }

    public String bookingType() {
        return bookingType;
    }

    @Override
    public void bookingType(String bookingType) {
        this.bookingType = bookingType;
    }

    public String tradingAcct() {
        return tradingAcct;
    }

    @Override
    public void tradingAcct(String tradingAcct) {
        this.tradingAcct = tradingAcct;
    }

    public String customPrice1() {
        return customPrice1;
    }

    @Override
    public void customPrice1(String customPrice1) {
        this.customPrice1 = customPrice1;
    }

    public long tier() {
        return tier;
    }

    @Override
    public void tier(long tier) {
        this.tier = tier;
    }

    public String noStrategyParameters() {
        return noStrategyParameters;
    }

    @Override
    public void noStrategyParameters(String noStrategyParameters) {
        this.noStrategyParameters = noStrategyParameters;
    }

    public String strategyParameterValue() {
        return strategyParameterValue;
    }

    @Override
    public void strategyParameterValue(String strategyParameterValue) {
        this.strategyParameterValue = strategyParameterValue;
    }

    public String crossStrategy() {
        return crossStrategy;
    }

    @Override
    public void crossStrategy(String crossStrategy) {
        this.crossStrategy = crossStrategy;
    }

    public String corellationClOrdID() {
        return corellationClOrdID;
    }

    @Override
    public void corellationClOrdID(String corellationClOrdID) {
        this.corellationClOrdID = corellationClOrdID;
    }

    public String previousLinkOrderID() {
        return previousLinkOrderID;
    }

    @Override
    public void previousLinkOrderID(String previousLinkOrderID) {
        this.previousLinkOrderID = previousLinkOrderID;
    }

    public String rootOrderID() {
        return rootOrderID;
    }

    @Override
    public void rootOrderID(String rootOrderID) {
        this.rootOrderID = rootOrderID;
    }

    public String customerSlang() {
        return customerSlang;
    }

    @Override
    public void customerSlang(String customerSlang) {
        this.customerSlang = customerSlang;
    }

    public long receiveTime() {
        return receiveTime;
    }

    @Override
    public void receiveTime(long receiveTime, TimeUnit timeUnit) {
        receiveTime(receiveTime);
    }

    @Override
    public void receiveTime(long receiveTime) {
        this.receiveTime = receiveTime;
    }

    public String crossRestrictionClientID() {
        return crossRestrictionClientID;
    }

    @Override
    public void crossRestrictionClientID(String crossRestrictionClientID) {
        this.crossRestrictionClientID = crossRestrictionClientID;
    }

    public String execInst() {
        return execInst;
    }

    @Override
    public void execInst(String execInst) {
        this.execInst = execInst;
    }

    public String crossInstruction() {
        return crossInstruction;
    }

    @Override
    public void crossInstruction(String crossInstruction) {
        this.crossInstruction = crossInstruction;
    }

    public String avgPriceAcctIDSource() {
        return avgPriceAcctIDSource;
    }

    @Override
    public void avgPriceAcctIDSource(String avgPriceAcctIDSource) {
        this.avgPriceAcctIDSource = avgPriceAcctIDSource;
    }

    public String tickSizePilotGroup() {
        return tickSizePilotGroup;
    }

    @Override
    public void tickSizePilotGroup(String tickSizePilotGroup) {
        this.tickSizePilotGroup = tickSizePilotGroup;
    }

    public long clearingInstruction() {
        return clearingInstruction;
    }

    @Override
    public void clearingInstruction(long clearingInstruction) {
        this.clearingInstruction = clearingInstruction;
    }

    public long timeToLive() {
        return timeToLive;
    }

    @Override
    public void timeToLive(long timeToLive, TimeUnit timeUnit) {
        timeToLive(timeToLive);
    }

    @Override
    public void timeToLive(long timeToLive) {
        this.timeToLive = timeToLive;
    }

    public String srcTargetCompId() {
        return srcTargetCompId;
    }

    @Override
    public void srcTargetCompId(String srcTargetCompId) {
        this.srcTargetCompId = srcTargetCompId;
    }

    public String ioiID() {
        return ioiID;
    }

    @Override
    public void ioiID(String ioiID) {
        this.ioiID = ioiID;
    }

    public String securityID() {
        return securityID;
    }

    @Override
    public void securityID(String securityID) {
        this.securityID = securityID;
    }

    public String securityAltID() {
        return securityAltID;
    }

    @Override
    public void securityAltID(String securityAltID) {
        this.securityAltID = securityAltID;
    }

    public String securityAltIDSource() {
        return securityAltIDSource;
    }

    @Override
    public void securityAltIDSource(String securityAltIDSource) {
        this.securityAltIDSource = securityAltIDSource;
    }

    @Override
    public void reset() {
        OrderCancelReplaceRequest.super.reset();
    }
}
