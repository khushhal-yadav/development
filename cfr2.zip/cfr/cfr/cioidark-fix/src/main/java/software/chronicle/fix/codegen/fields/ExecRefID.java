package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ExecRefID {
    /**
     * Tag number for this field
     */
    int FIELD = 19;

    /**
     * @param execRefID &gt; FIX TAG 19
     */
    void execRefID(String execRefID);

    default String execRefID() {
        throw new UnsupportedOperationException();
    }
}
