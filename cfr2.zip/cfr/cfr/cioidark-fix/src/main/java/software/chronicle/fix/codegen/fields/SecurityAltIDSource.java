package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SecurityAltIDSource {
    /**
     * Tag number for this field
     */
    int FIELD = 456;

    /**
     * @param securityAltIDSource &gt; FIX TAG 456
     */
    void securityAltIDSource(String securityAltIDSource);

    default String securityAltIDSource() {
        throw new UnsupportedOperationException();
    }
}
