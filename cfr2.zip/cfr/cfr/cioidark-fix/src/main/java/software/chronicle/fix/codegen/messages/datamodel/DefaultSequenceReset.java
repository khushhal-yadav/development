package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.SequenceReset;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultSequenceReset extends DefaultHeaderTrailer implements SequenceReset, HeaderTrailer {
    private char gapFillFlag = FixMessage.UNSET_CHAR;

    private long newSeqNo = FixMessage.UNSET_LONG;

    public char msgType() {
        return MessageManifest.SequenceReset;
    }

    public char gapFillFlag() {
        return gapFillFlag;
    }

    @Override
    public void gapFillFlag(char gapFillFlag) {
        this.gapFillFlag = gapFillFlag;
    }

    public long newSeqNo() {
        return newSeqNo;
    }

    @Override
    public void newSeqNo(long newSeqNo) {
        this.newSeqNo = newSeqNo;
    }

    @Override
    public void reset() {
        SequenceReset.super.reset();
    }
}
