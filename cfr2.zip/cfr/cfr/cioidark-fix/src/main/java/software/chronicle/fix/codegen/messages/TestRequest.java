package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.fields.TestReqID;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface TestRequest extends HeaderTrailer, software.chronicle.fix.sessioncode.messages.TestRequest, TestReqID {
    @Deprecated
    static TestRequest newTestRequest(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.TestRequest);
        mg.bytes(bytes);
        return mg;
    }

    static TestRequest newTestRequest(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.TestRequest, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (testReqID() == null) throw new RequiredTagMissing("testReqID", 112);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        testReqID(null);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((TestRequest) msg);
    }

    default void copyTo(TestRequest msg) {
        HeaderTrailer.super.copyTo(msg);
        if (testReqID() != null) msg.testReqID(testReqID());
    }
}
