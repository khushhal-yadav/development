package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CumQty {
    /**
     * Tag number for this field
     */
    int FIELD = 14;

    /**
     * @param cumQty &gt; FIX TAG 14
     */
    void cumQty(double cumQty);

    default double cumQty() {
        throw new UnsupportedOperationException();
    }
}
