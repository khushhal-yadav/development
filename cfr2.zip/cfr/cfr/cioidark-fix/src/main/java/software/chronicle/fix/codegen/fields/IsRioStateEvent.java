package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface IsRioStateEvent {
    /**
     * Tag number for this field
     */
    int FIELD = 10104;

    /**
     * @param isRioStateEvent &gt; FIX TAG 10104
     */
    void isRioStateEvent(char isRioStateEvent);

    default char isRioStateEvent() {
        throw new UnsupportedOperationException();
    }
}
