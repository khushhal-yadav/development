package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrderFlowCategory {
    /**
     * Tag number for this field
     */
    int FIELD = 10202;

    /**
     * @param orderFlowCategory &gt; FIX TAG 10202
     */
    void orderFlowCategory(String orderFlowCategory);

    default String orderFlowCategory() {
        throw new UnsupportedOperationException();
    }
}
