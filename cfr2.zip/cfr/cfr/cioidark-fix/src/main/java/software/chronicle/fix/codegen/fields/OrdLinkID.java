package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrdLinkID {
    /**
     * Tag number for this field
     */
    int FIELD = 11053;

    /**
     * @param ordLinkID &gt; FIX TAG 11053
     */
    void ordLinkID(String ordLinkID);

    default String ordLinkID() {
        throw new UnsupportedOperationException();
    }
}
