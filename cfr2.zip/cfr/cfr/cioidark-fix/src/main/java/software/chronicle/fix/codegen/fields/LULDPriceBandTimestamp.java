package software.chronicle.fix.codegen.fields;

import java.util.concurrent.TimeUnit;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LULDPriceBandTimestamp {
    /**
     * Tag number for this field
     */
    int FIELD = 10723;

    /**
     * @param lULDPriceBandTimestamp &gt; FIX TAG 10723
     */
    void lULDPriceBandTimestamp(long lULDPriceBandTimestamp);

    default long lULDPriceBandTimestamp() {
        throw new UnsupportedOperationException();
    }

    default void lULDPriceBandTimestamp(long lULDPriceBandTimestamp, TimeUnit timeUnit) {
        throw new UnsupportedOperationException();
    }
}
