package software.chronicle.fix.codegen.fields;

import java.util.concurrent.TimeUnit;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TransactTime {
    /**
     * Tag number for this field
     */
    int FIELD = 60;

    /**
     * @param transactTime &gt; FIX TAG 60
     */
    void transactTime(long transactTime);

    default long transactTime() {
        throw new UnsupportedOperationException();
    }

    default void transactTime(long transactTime, TimeUnit timeUnit) {
        throw new UnsupportedOperationException();
    }
}
