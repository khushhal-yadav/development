package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OptOutLockedIn {
    /**
     * Tag number for this field
     */
    int FIELD = 10565;

    /**
     * @param optOutLockedIn &gt; FIX TAG 10565
     */
    void optOutLockedIn(String optOutLockedIn);

    default String optOutLockedIn() {
        throw new UnsupportedOperationException();
    }
}
