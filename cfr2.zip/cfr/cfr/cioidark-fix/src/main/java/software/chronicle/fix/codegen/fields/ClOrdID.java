package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ClOrdID {
    /**
     * Tag number for this field
     */
    int FIELD = 11;

    /**
     * @param clOrdID &gt; FIX TAG 11
     */
    void clOrdID(String clOrdID);

    default String clOrdID() {
        throw new UnsupportedOperationException();
    }
}
