package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MDEntryOriginator {
    /**
     * Tag number for this field
     */
    int FIELD = 282;

    /**
     * @param mDEntryOriginator &gt; FIX TAG 282
     */
    void mDEntryOriginator(String mDEntryOriginator);

    default String mDEntryOriginator() {
        throw new UnsupportedOperationException();
    }
}
