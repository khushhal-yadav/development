package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SecurityAltID {
    /**
     * Tag number for this field
     */
    int FIELD = 455;

    /**
     * @param securityAltID &gt; FIX TAG 455
     */
    void securityAltID(String securityAltID);

    default String securityAltID() {
        throw new UnsupportedOperationException();
    }
}
