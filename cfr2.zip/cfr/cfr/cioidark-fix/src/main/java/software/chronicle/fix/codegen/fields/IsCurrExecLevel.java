package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface IsCurrExecLevel {
    /**
     * Tag number for this field
     */
    int FIELD = 11027;

    /**
     * @param isCurrExecLevel &gt; FIX TAG 11027
     */
    void isCurrExecLevel(char isCurrExecLevel);

    default char isCurrExecLevel() {
        throw new UnsupportedOperationException();
    }
}
