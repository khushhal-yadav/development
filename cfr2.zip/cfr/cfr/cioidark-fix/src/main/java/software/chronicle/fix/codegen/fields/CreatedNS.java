package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CreatedNS {
    /**
     * Tag number for this field
     */
    int FIELD = 9999;

    /**
     * @param createdNS &gt; FIX TAG 9999
     */
    void createdNS(long createdNS);

    default long createdNS() {
        throw new UnsupportedOperationException();
    }
}
