package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface EncodedText {
    /**
     * Tag number for this field
     */
    int FIELD = 355;

    /**
     * @param encodedText &gt; FIX TAG 355
     */
    void encodedText(String encodedText);

    default String encodedText() {
        throw new UnsupportedOperationException();
    }
}
