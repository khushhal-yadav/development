package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface DeskID {
    /**
     * Tag number for this field
     */
    int FIELD = 284;

    /**
     * @param deskID &gt; FIX TAG 284
     */
    void deskID(String deskID);

    default String deskID() {
        throw new UnsupportedOperationException();
    }
}
