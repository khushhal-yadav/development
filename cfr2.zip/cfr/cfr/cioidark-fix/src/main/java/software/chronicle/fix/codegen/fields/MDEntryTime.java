package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MDEntryTime {
    /**
     * Tag number for this field
     */
    int FIELD = 273;

    /**
     * @param mDEntryTime &gt; FIX TAG 273
     */
    void mDEntryTime(String mDEntryTime);

    default String mDEntryTime() {
        throw new UnsupportedOperationException();
    }
}
