package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface PreviousLinkOrderUniqID {
    /**
     * Tag number for this field
     */
    int FIELD = 10519;

    /**
     * @param previousLinkOrderUniqID &gt; FIX TAG 10519
     */
    void previousLinkOrderUniqID(String previousLinkOrderUniqID);

    default String previousLinkOrderUniqID() {
        throw new UnsupportedOperationException();
    }
}
