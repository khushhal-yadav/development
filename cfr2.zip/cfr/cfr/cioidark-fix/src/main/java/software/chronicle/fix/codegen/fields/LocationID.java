package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LocationID {
    /**
     * Tag number for this field
     */
    int FIELD = 283;

    /**
     * @param locationID &gt; FIX TAG 283
     */
    void locationID(String locationID);

    default String locationID() {
        throw new UnsupportedOperationException();
    }
}
