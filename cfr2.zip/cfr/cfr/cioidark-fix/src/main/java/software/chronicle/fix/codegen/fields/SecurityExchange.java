package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SecurityExchange {
    /**
     * Tag number for this field
     */
    int FIELD = 207;

    /**
     * @param securityExchange &gt; FIX TAG 207
     */
    void securityExchange(String securityExchange);

    default String securityExchange() {
        throw new UnsupportedOperationException();
    }
}
