package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.fields.Account;
import software.chronicle.fix.codegen.fields.AvgPriceAcctIDSource;
import software.chronicle.fix.codegen.fields.BidPx;
import software.chronicle.fix.codegen.fields.BookingType;
import software.chronicle.fix.codegen.fields.ClOrdID;
import software.chronicle.fix.codegen.fields.ClearingInstruction;
import software.chronicle.fix.codegen.fields.ClientID;
import software.chronicle.fix.codegen.fields.CorellationClOrdID;
import software.chronicle.fix.codegen.fields.CreatedNS;
import software.chronicle.fix.codegen.fields.CrossID;
import software.chronicle.fix.codegen.fields.CrossInstruction;
import software.chronicle.fix.codegen.fields.CrossRestrictionClientID;
import software.chronicle.fix.codegen.fields.CrossStrategy;
import software.chronicle.fix.codegen.fields.CustomPrice1;
import software.chronicle.fix.codegen.fields.CustomerSlang;
import software.chronicle.fix.codegen.fields.ExecInst;
import software.chronicle.fix.codegen.fields.IDSource;
import software.chronicle.fix.codegen.fields.IOIID;
import software.chronicle.fix.codegen.fields.OfferPx;
import software.chronicle.fix.codegen.fields.OrdLinkID;
import software.chronicle.fix.codegen.fields.OrdLinkType;
import software.chronicle.fix.codegen.fields.OrderID;
import software.chronicle.fix.codegen.fields.OrderQty;
import software.chronicle.fix.codegen.fields.OrigClOrdID;
import software.chronicle.fix.codegen.fields.PreviousLinkOrderID;
import software.chronicle.fix.codegen.fields.Price;
import software.chronicle.fix.codegen.fields.QuoteTime;
import software.chronicle.fix.codegen.fields.ReceiveTime;
import software.chronicle.fix.codegen.fields.RootOrderID;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.fields.SrcTargetCompId;
import software.chronicle.fix.codegen.fields.StrategyParameterValue;
import software.chronicle.fix.codegen.fields.Symbol;
import software.chronicle.fix.codegen.fields.SymbolSfx;
import software.chronicle.fix.codegen.fields.TickSizePilotGroup;
import software.chronicle.fix.codegen.fields.TimeInForce;
import software.chronicle.fix.codegen.fields.TimeToLive;
import software.chronicle.fix.codegen.fields.TransactTime;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface OrderCancelRequest extends HeaderTrailer, OrderID, ClOrdID, Account, Side, OrigClOrdID, Symbol, SymbolSfx, IDSource, TransactTime, OrderQty, Price, BidPx, OfferPx, QuoteTime, TimeInForce, CreatedNS, ClientID, OrdLinkID, OrdLinkType, BookingType, CrossID, StrategyParameterValue, CrossStrategy, CustomPrice1, CorellationClOrdID, PreviousLinkOrderID, RootOrderID, CustomerSlang, ReceiveTime, CrossRestrictionClientID, ExecInst, CrossInstruction, AvgPriceAcctIDSource, TickSizePilotGroup, ClearingInstruction, TimeToLive, SrcTargetCompId, IOIID {
    @Deprecated
    static OrderCancelRequest newOrderCancelRequest(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.OrderCancelRequest);
        mg.bytes(bytes);
        return mg;
    }

    static OrderCancelRequest newOrderCancelRequest(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.OrderCancelRequest, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (clOrdID() == null) throw new RequiredTagMissing("clOrdID", 11);
        if (account() == null) throw new RequiredTagMissing("account", 1);
        if (side() == FixMessage.UNSET_CHAR) throw new RequiredTagMissing("side", 54);
        if (origClOrdID() == null) throw new RequiredTagMissing("origClOrdID", 41);
        if (symbol() == null) throw new RequiredTagMissing("symbol", 55);
        if (transactTime() == FixMessage.UNSET_LONG) throw new RequiredTagMissing("transactTime", 60);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        orderID(null);
        clOrdID(null);
        account(null);
        side(FixMessage.UNSET_CHAR);
        origClOrdID(null);
        symbol(null);
        symbolSfx(null);
        idSource(null);
        transactTime(FixMessage.UNSET_LONG);
        orderQty(FixMessage.UNSET_DOUBLE);
        price(FixMessage.UNSET_DOUBLE);
        bidPx(FixMessage.UNSET_DOUBLE);
        offerPx(FixMessage.UNSET_DOUBLE);
        quoteTime(FixMessage.UNSET_LONG);
        timeInForce(FixMessage.UNSET_CHAR);
        createdNS(FixMessage.UNSET_LONG);
        clientID(null);
        ordLinkID(null);
        ordLinkType(null);
        bookingType(null);
        crossID(null);
        strategyParameterValue(null);
        crossStrategy(null);
        customPrice1(null);
        corellationClOrdID(null);
        previousLinkOrderID(null);
        rootOrderID(null);
        customerSlang(null);
        receiveTime(FixMessage.UNSET_LONG);
        crossRestrictionClientID(null);
        execInst(null);
        crossInstruction(null);
        avgPriceAcctIDSource(null);
        tickSizePilotGroup(null);
        clearingInstruction(FixMessage.UNSET_LONG);
        timeToLive(FixMessage.UNSET_LONG);
        srcTargetCompId(null);
        ioiID(null);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((OrderCancelRequest) msg);
    }

    default void copyTo(OrderCancelRequest msg) {
        HeaderTrailer.super.copyTo(msg);
        if (orderID() != null) msg.orderID(orderID());
        if (clOrdID() != null) msg.clOrdID(clOrdID());
        if (account() != null) msg.account(account());
        if (side() != FixMessage.UNSET_CHAR) msg.side(side());
        if (origClOrdID() != null) msg.origClOrdID(origClOrdID());
        if (symbol() != null) msg.symbol(symbol());
        if (symbolSfx() != null) msg.symbolSfx(symbolSfx());
        if (idSource() != null) msg.idSource(idSource());
        if (transactTime() != FixMessage.UNSET_LONG) msg.transactTime(transactTime());
        if (!Double.isNaN(orderQty())) msg.orderQty(orderQty());
        if (!Double.isNaN(price())) msg.price(price());
        if (!Double.isNaN(bidPx())) msg.bidPx(bidPx());
        if (!Double.isNaN(offerPx())) msg.offerPx(offerPx());
        if (quoteTime() != FixMessage.UNSET_LONG) msg.quoteTime(quoteTime());
        if (timeInForce() != FixMessage.UNSET_CHAR) msg.timeInForce(timeInForce());
        if (createdNS() != FixMessage.UNSET_LONG) msg.createdNS(createdNS());
        if (clientID() != null) msg.clientID(clientID());
        if (ordLinkID() != null) msg.ordLinkID(ordLinkID());
        if (ordLinkType() != null) msg.ordLinkType(ordLinkType());
        if (bookingType() != null) msg.bookingType(bookingType());
        if (crossID() != null) msg.crossID(crossID());
        if (strategyParameterValue() != null) msg.strategyParameterValue(strategyParameterValue());
        if (crossStrategy() != null) msg.crossStrategy(crossStrategy());
        if (customPrice1() != null) msg.customPrice1(customPrice1());
        if (corellationClOrdID() != null) msg.corellationClOrdID(corellationClOrdID());
        if (previousLinkOrderID() != null) msg.previousLinkOrderID(previousLinkOrderID());
        if (rootOrderID() != null) msg.rootOrderID(rootOrderID());
        if (customerSlang() != null) msg.customerSlang(customerSlang());
        if (receiveTime() != FixMessage.UNSET_LONG) msg.receiveTime(receiveTime());
        if (crossRestrictionClientID() != null) msg.crossRestrictionClientID(crossRestrictionClientID());
        if (execInst() != null) msg.execInst(execInst());
        if (crossInstruction() != null) msg.crossInstruction(crossInstruction());
        if (avgPriceAcctIDSource() != null) msg.avgPriceAcctIDSource(avgPriceAcctIDSource());
        if (tickSizePilotGroup() != null) msg.tickSizePilotGroup(tickSizePilotGroup());
        if (clearingInstruction() != FixMessage.UNSET_LONG) msg.clearingInstruction(clearingInstruction());
        if (timeToLive() != FixMessage.UNSET_LONG) msg.timeToLive(timeToLive());
        if (srcTargetCompId() != null) msg.srcTargetCompId(srcTargetCompId());
        if (ioiID() != null) msg.ioiID(ioiID());
    }
}
