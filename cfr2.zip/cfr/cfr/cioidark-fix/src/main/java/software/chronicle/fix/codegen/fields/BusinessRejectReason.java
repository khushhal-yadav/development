package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface BusinessRejectReason {
    /**
     * Tag number for this field
     */
    int FIELD = 380;

    int OTHER = 0;

    int UNKOWN_ID = 1;

    int UNKNOWN_SECURITY = 2;

    int UNSUPPORTED_MESSAGE_TYPE = 3;

    int APPLICATION_NOT_AVAILABLE = 4;

    int CONDITIONALLY_REQUIRED_FIELD_MISSING = 5;

    /**
     * @param businessRejectReason &gt; FIX TAG 380
     */
    void businessRejectReason(long businessRejectReason);

    default long businessRejectReason() {
        throw new UnsupportedOperationException();
    }

    static String asString(int value) {
        switch (value) {
            case OTHER:
                    return "OTHER";
            case UNKOWN_ID:
                    return "UNKOWN_ID";
            case UNKNOWN_SECURITY:
                    return "UNKNOWN_SECURITY";
            case UNSUPPORTED_MESSAGE_TYPE:
                    return "UNSUPPORTED_MESSAGE_TYPE";
            case APPLICATION_NOT_AVAILABLE:
                    return "APPLICATION_NOT_AVAILABLE";
            case CONDITIONALLY_REQUIRED_FIELD_MISSING:
                    return "CONDITIONALLY_REQUIRED_FIELD_MISSING";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
