package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import java.util.concurrent.TimeUnit;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.CioiDarkOrder;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultCioiDarkOrder extends DefaultHeaderTrailer implements CioiDarkOrder, HeaderTrailer {
    private String clOrdID = null;

    private String account = null;

    private char handlInst = FixMessage.UNSET_CHAR;

    private String execInst = null;

    private double minQty = FixMessage.UNSET_DOUBLE;

    private String symbol = null;

    private String symbolSfx = null;

    private char side = FixMessage.UNSET_CHAR;

    private char locateReqd = FixMessage.UNSET_CHAR;

    private long transactTime = FixMessage.UNSET_LONG;

    private double orderQty = FixMessage.UNSET_DOUBLE;

    private char ordType = FixMessage.UNSET_CHAR;

    private double price = FixMessage.UNSET_DOUBLE;

    private double stopPx = FixMessage.UNSET_DOUBLE;

    private String ioiID = null;

    private char timeInForce = FixMessage.UNSET_CHAR;

    private char orderCapacity = FixMessage.UNSET_CHAR;

    private long targetStrategy = FixMessage.UNSET_LONG;

    private String targetStrategyParameters = null;

    private long orderVersion = FixMessage.UNSET_LONG;

    private long timeToLive = FixMessage.UNSET_LONG;

    private String customPrice1 = null;

    private String locateBroker = null;

    private String locateIdentifier = null;

    private long rootSrcSystemID = FixMessage.UNSET_LONG;

    private long previousLinkSrcSystemID = FixMessage.UNSET_LONG;

    private String orderID = null;

    private char ordStatus = FixMessage.UNSET_CHAR;

    private String crossRestrictionClientID = null;

    private double leavesQty = FixMessage.UNSET_DOUBLE;

    private double cxlQty = FixMessage.UNSET_DOUBLE;

    private String optOutLockedIn = null;

    private double sumOfStopExecQty = FixMessage.UNSET_DOUBLE;

    private String crossInstruction = null;

    private String customerSlang = null;

    private String noStrategyParameters = null;

    private long receiveTime = FixMessage.UNSET_LONG;

    private String strategyParameterValue = null;

    private String shortSaleExemptReason = null;

    private String crossStrategy = null;

    private String securityID = null;

    private String idSource = null;

    private String securityAltID = null;

    private String securityAltIDSource = null;

    private String srcTargetCompId = null;

    private String reportToExch = null;

    public char msgType() {
        return MessageManifest.CioiDarkOrder;
    }

    public String clOrdID() {
        return clOrdID;
    }

    @Override
    public void clOrdID(String clOrdID) {
        this.clOrdID = clOrdID;
    }

    public String account() {
        return account;
    }

    @Override
    public void account(String account) {
        this.account = account;
    }

    public char handlInst() {
        return handlInst;
    }

    @Override
    public void handlInst(char handlInst) {
        this.handlInst = handlInst;
    }

    public String execInst() {
        return execInst;
    }

    @Override
    public void execInst(String execInst) {
        this.execInst = execInst;
    }

    public double minQty() {
        return minQty;
    }

    @Override
    public void minQty(double minQty) {
        this.minQty = minQty;
    }

    public String symbol() {
        return symbol;
    }

    @Override
    public void symbol(String symbol) {
        this.symbol = symbol;
    }

    public String symbolSfx() {
        return symbolSfx;
    }

    @Override
    public void symbolSfx(String symbolSfx) {
        this.symbolSfx = symbolSfx;
    }

    public char side() {
        return side;
    }

    @Override
    public void side(char side) {
        this.side = side;
    }

    public char locateReqd() {
        return locateReqd;
    }

    @Override
    public void locateReqd(char locateReqd) {
        this.locateReqd = locateReqd;
    }

    public long transactTime() {
        return transactTime;
    }

    @Override
    public void transactTime(long transactTime, TimeUnit timeUnit) {
        transactTime(transactTime);
    }

    @Override
    public void transactTime(long transactTime) {
        this.transactTime = transactTime;
    }

    public double orderQty() {
        return orderQty;
    }

    @Override
    public void orderQty(double orderQty) {
        this.orderQty = orderQty;
    }

    public char ordType() {
        return ordType;
    }

    @Override
    public void ordType(char ordType) {
        this.ordType = ordType;
    }

    public double price() {
        return price;
    }

    @Override
    public void price(double price) {
        this.price = price;
    }

    public double stopPx() {
        return stopPx;
    }

    @Override
    public void stopPx(double stopPx) {
        this.stopPx = stopPx;
    }

    public String ioiID() {
        return ioiID;
    }

    @Override
    public void ioiID(String ioiID) {
        this.ioiID = ioiID;
    }

    public char timeInForce() {
        return timeInForce;
    }

    @Override
    public void timeInForce(char timeInForce) {
        this.timeInForce = timeInForce;
    }

    public char orderCapacity() {
        return orderCapacity;
    }

    @Override
    public void orderCapacity(char orderCapacity) {
        this.orderCapacity = orderCapacity;
    }

    public long targetStrategy() {
        return targetStrategy;
    }

    @Override
    public void targetStrategy(long targetStrategy) {
        this.targetStrategy = targetStrategy;
    }

    public String targetStrategyParameters() {
        return targetStrategyParameters;
    }

    @Override
    public void targetStrategyParameters(String targetStrategyParameters) {
        this.targetStrategyParameters = targetStrategyParameters;
    }

    public long orderVersion() {
        return orderVersion;
    }

    @Override
    public void orderVersion(long orderVersion) {
        this.orderVersion = orderVersion;
    }

    public long timeToLive() {
        return timeToLive;
    }

    @Override
    public void timeToLive(long timeToLive, TimeUnit timeUnit) {
        timeToLive(timeToLive);
    }

    @Override
    public void timeToLive(long timeToLive) {
        this.timeToLive = timeToLive;
    }

    public String customPrice1() {
        return customPrice1;
    }

    @Override
    public void customPrice1(String customPrice1) {
        this.customPrice1 = customPrice1;
    }

    public String locateBroker() {
        return locateBroker;
    }

    @Override
    public void locateBroker(String locateBroker) {
        this.locateBroker = locateBroker;
    }

    public String locateIdentifier() {
        return locateIdentifier;
    }

    @Override
    public void locateIdentifier(String locateIdentifier) {
        this.locateIdentifier = locateIdentifier;
    }

    public long rootSrcSystemID() {
        return rootSrcSystemID;
    }

    @Override
    public void rootSrcSystemID(long rootSrcSystemID) {
        this.rootSrcSystemID = rootSrcSystemID;
    }

    public long previousLinkSrcSystemID() {
        return previousLinkSrcSystemID;
    }

    @Override
    public void previousLinkSrcSystemID(long previousLinkSrcSystemID) {
        this.previousLinkSrcSystemID = previousLinkSrcSystemID;
    }

    public String orderID() {
        return orderID;
    }

    @Override
    public void orderID(String orderID) {
        this.orderID = orderID;
    }

    public char ordStatus() {
        return ordStatus;
    }

    @Override
    public void ordStatus(char ordStatus) {
        this.ordStatus = ordStatus;
    }

    public String crossRestrictionClientID() {
        return crossRestrictionClientID;
    }

    @Override
    public void crossRestrictionClientID(String crossRestrictionClientID) {
        this.crossRestrictionClientID = crossRestrictionClientID;
    }

    public double leavesQty() {
        return leavesQty;
    }

    @Override
    public void leavesQty(double leavesQty) {
        this.leavesQty = leavesQty;
    }

    public double cxlQty() {
        return cxlQty;
    }

    @Override
    public void cxlQty(double cxlQty) {
        this.cxlQty = cxlQty;
    }

    public String optOutLockedIn() {
        return optOutLockedIn;
    }

    @Override
    public void optOutLockedIn(String optOutLockedIn) {
        this.optOutLockedIn = optOutLockedIn;
    }

    public double sumOfStopExecQty() {
        return sumOfStopExecQty;
    }

    @Override
    public void sumOfStopExecQty(double sumOfStopExecQty) {
        this.sumOfStopExecQty = sumOfStopExecQty;
    }

    public String crossInstruction() {
        return crossInstruction;
    }

    @Override
    public void crossInstruction(String crossInstruction) {
        this.crossInstruction = crossInstruction;
    }

    public String customerSlang() {
        return customerSlang;
    }

    @Override
    public void customerSlang(String customerSlang) {
        this.customerSlang = customerSlang;
    }

    public String noStrategyParameters() {
        return noStrategyParameters;
    }

    @Override
    public void noStrategyParameters(String noStrategyParameters) {
        this.noStrategyParameters = noStrategyParameters;
    }

    public long receiveTime() {
        return receiveTime;
    }

    @Override
    public void receiveTime(long receiveTime, TimeUnit timeUnit) {
        receiveTime(receiveTime);
    }

    @Override
    public void receiveTime(long receiveTime) {
        this.receiveTime = receiveTime;
    }

    public String strategyParameterValue() {
        return strategyParameterValue;
    }

    @Override
    public void strategyParameterValue(String strategyParameterValue) {
        this.strategyParameterValue = strategyParameterValue;
    }

    public String shortSaleExemptReason() {
        return shortSaleExemptReason;
    }

    @Override
    public void shortSaleExemptReason(String shortSaleExemptReason) {
        this.shortSaleExemptReason = shortSaleExemptReason;
    }

    public String crossStrategy() {
        return crossStrategy;
    }

    @Override
    public void crossStrategy(String crossStrategy) {
        this.crossStrategy = crossStrategy;
    }

    public String securityID() {
        return securityID;
    }

    @Override
    public void securityID(String securityID) {
        this.securityID = securityID;
    }

    public String idSource() {
        return idSource;
    }

    @Override
    public void idSource(String idSource) {
        this.idSource = idSource;
    }

    public String securityAltID() {
        return securityAltID;
    }

    @Override
    public void securityAltID(String securityAltID) {
        this.securityAltID = securityAltID;
    }

    public String securityAltIDSource() {
        return securityAltIDSource;
    }

    @Override
    public void securityAltIDSource(String securityAltIDSource) {
        this.securityAltIDSource = securityAltIDSource;
    }

    public String srcTargetCompId() {
        return srcTargetCompId;
    }

    @Override
    public void srcTargetCompId(String srcTargetCompId) {
        this.srcTargetCompId = srcTargetCompId;
    }

    public String reportToExch() {
        return reportToExch;
    }

    @Override
    public void reportToExch(String reportToExch) {
        this.reportToExch = reportToExch;
    }

    @Override
    public void reset() {
        CioiDarkOrder.super.reset();
    }
}
