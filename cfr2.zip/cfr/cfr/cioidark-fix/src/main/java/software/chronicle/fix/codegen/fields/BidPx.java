package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface BidPx {
    /**
     * Tag number for this field
     */
    int FIELD = 132;

    /**
     * @param bidPx &gt; FIX TAG 132
     */
    void bidPx(double bidPx);

    default double bidPx() {
        throw new UnsupportedOperationException();
    }
}
