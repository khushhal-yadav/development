package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CorporateAction {
    /**
     * Tag number for this field
     */
    int FIELD = 292;

    char EXDIVIDEND = 'A';

    char EXDISTRIBUTION = 'B';

    char EXRIGHTS = 'C';

    char NEW = 'D';

    char EXINTEREST = 'E';

    /**
     * @param corporateAction &gt; FIX TAG 292
     */
    void corporateAction(char corporateAction);

    default char corporateAction() {
        throw new UnsupportedOperationException();
    }

    static String asString(char value) {
        switch (value) {
            case EXDIVIDEND:
                    return "EXDIVIDEND";
            case EXDISTRIBUTION:
                    return "EXDISTRIBUTION";
            case EXRIGHTS:
                    return "EXRIGHTS";
            case NEW:
                    return "NEW";
            case EXINTEREST:
                    return "EXINTEREST";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
