package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OfferPx {
    /**
     * Tag number for this field
     */
    int FIELD = 133;

    /**
     * @param offerPx &gt; FIX TAG 133
     */
    void offerPx(double offerPx);

    default double offerPx() {
        throw new UnsupportedOperationException();
    }
}
