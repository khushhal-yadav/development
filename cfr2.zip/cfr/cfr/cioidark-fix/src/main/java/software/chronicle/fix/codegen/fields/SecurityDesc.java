package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SecurityDesc {
    /**
     * Tag number for this field
     */
    int FIELD = 107;

    /**
     * @param securityDesc &gt; FIX TAG 107
     */
    void securityDesc(String securityDesc);

    default String securityDesc() {
        throw new UnsupportedOperationException();
    }
}
