package software.chronicle.fix.codegen.fields;

import java.util.concurrent.TimeUnit;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrigSendingTime {
    /**
     * Tag number for this field
     */
    int FIELD = 122;

    /**
     * @param origSendingTime &gt; FIX TAG 122
     */
    void origSendingTime(long origSendingTime);

    default long origSendingTime() {
        throw new UnsupportedOperationException();
    }

    default void origSendingTime(long origSendingTime, TimeUnit timeUnit) {
        throw new UnsupportedOperationException();
    }
}
