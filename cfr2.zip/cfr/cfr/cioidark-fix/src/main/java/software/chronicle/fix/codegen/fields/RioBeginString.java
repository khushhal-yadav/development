package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface RioBeginString {
    /**
     * Tag number for this field
     */
    int FIELD = 10438;

    /**
     * @param rioBeginString &gt; FIX TAG 10438
     */
    void rioBeginString(String rioBeginString);

    default String rioBeginString() {
        throw new UnsupportedOperationException();
    }
}
