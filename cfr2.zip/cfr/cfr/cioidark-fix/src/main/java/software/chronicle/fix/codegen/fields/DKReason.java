package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface DKReason {
    /**
     * Tag number for this field
     */
    int FIELD = 127;

    char UNKNOWN_SYMBOL = 'A';

    char WRONG_SIDE = 'B';

    char QUANTITY_EXCEEDS_ORDER = 'C';

    char NO_MATCHING_ORDER = 'D';

    char PRICE_EXCEEDS_LIMIT = 'E';

    char OTHER = 'Z';

    /**
     * @param dKReason &gt; FIX TAG 127
     */
    void dKReason(char dKReason);

    default char dKReason() {
        throw new UnsupportedOperationException();
    }

    static String asString(char value) {
        switch (value) {
            case UNKNOWN_SYMBOL:
                    return "UNKNOWN_SYMBOL";
            case WRONG_SIDE:
                    return "WRONG_SIDE";
            case QUANTITY_EXCEEDS_ORDER:
                    return "QUANTITY_EXCEEDS_ORDER";
            case NO_MATCHING_ORDER:
                    return "NO_MATCHING_ORDER";
            case PRICE_EXCEEDS_LIMIT:
                    return "PRICE_EXCEEDS_LIMIT";
            case OTHER:
                    return "OTHER";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
