package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OfferSize {
    /**
     * Tag number for this field
     */
    int FIELD = 135;

    /**
     * @param offerSize &gt; FIX TAG 135
     */
    void offerSize(double offerSize);

    default double offerSize() {
        throw new UnsupportedOperationException();
    }
}
