package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.fields.BeginSeqNo;
import software.chronicle.fix.sessioncode.fields.EndSeqNo;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface ResendRequest extends HeaderTrailer, software.chronicle.fix.sessioncode.messages.ResendRequest, BeginSeqNo, EndSeqNo {
    @Deprecated
    static ResendRequest newResendRequest(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.ResendRequest);
        mg.bytes(bytes);
        return mg;
    }

    static ResendRequest newResendRequest(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.ResendRequest, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (beginSeqNo() == FixMessage.UNSET_LONG) throw new RequiredTagMissing("beginSeqNo", 7);
        if (endSeqNo() == FixMessage.UNSET_LONG) throw new RequiredTagMissing("endSeqNo", 16);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        beginSeqNo(FixMessage.UNSET_LONG);
        endSeqNo(FixMessage.UNSET_LONG);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((ResendRequest) msg);
    }

    default void copyTo(ResendRequest msg) {
        HeaderTrailer.super.copyTo(msg);
        if (beginSeqNo() != FixMessage.UNSET_LONG) msg.beginSeqNo(beginSeqNo());
        if (endSeqNo() != FixMessage.UNSET_LONG) msg.endSeqNo(endSeqNo());
    }
}
