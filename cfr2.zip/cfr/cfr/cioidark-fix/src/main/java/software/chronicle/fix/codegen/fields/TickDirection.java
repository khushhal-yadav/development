package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TickDirection {
    /**
     * Tag number for this field
     */
    int FIELD = 274;

    char PLUS_TICK = '0';

    char ZEROPLUS_TICK = '1';

    char MINUS_TICK = '2';

    char ZEROMINUS_TICK = '3';

    /**
     * @param tickDirection &gt; FIX TAG 274
     */
    void tickDirection(char tickDirection);

    default char tickDirection() {
        throw new UnsupportedOperationException();
    }

    static String asString(char value) {
        switch (value) {
            case PLUS_TICK:
                    return "PLUS_TICK";
            case ZEROPLUS_TICK:
                    return "ZEROPLUS_TICK";
            case MINUS_TICK:
                    return "MINUS_TICK";
            case ZEROMINUS_TICK:
                    return "ZEROMINUS_TICK";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
