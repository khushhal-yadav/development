package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface StrategyParameterValue {
    /**
     * Tag number for this field
     */
    int FIELD = 960;

    /**
     * @param strategyParameterValue &gt; FIX TAG 960
     */
    void strategyParameterValue(String strategyParameterValue);

    default String strategyParameterValue() {
        throw new UnsupportedOperationException();
    }
}
