package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SymbolSfx {
    /**
     * Tag number for this field
     */
    int FIELD = 65;

    /**
     * @param symbolSfx &gt; FIX TAG 65
     */
    void symbolSfx(String symbolSfx);

    default String symbolSfx() {
        throw new UnsupportedOperationException();
    }
}
