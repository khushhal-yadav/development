package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.Maths;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.components.MarketDataSnapshotFullRefresh_MDEntriesGrp;
import software.chronicle.fix.codegen.fields.ContractMultiplier;
import software.chronicle.fix.codegen.fields.CorporateAction;
import software.chronicle.fix.codegen.fields.CouponRate;
import software.chronicle.fix.codegen.fields.EncodedIssuer;
import software.chronicle.fix.codegen.fields.EncodedIssuerLen;
import software.chronicle.fix.codegen.fields.EncodedSecurityDescLen;
import software.chronicle.fix.codegen.fields.FinancialStatus;
import software.chronicle.fix.codegen.fields.IDSource;
import software.chronicle.fix.codegen.fields.Issuer;
import software.chronicle.fix.codegen.fields.MDReqID;
import software.chronicle.fix.codegen.fields.MaturityDay;
import software.chronicle.fix.codegen.fields.MaturityMonthYear;
import software.chronicle.fix.codegen.fields.OptAttribute;
import software.chronicle.fix.codegen.fields.PutOrCall;
import software.chronicle.fix.codegen.fields.SecurityDesc;
import software.chronicle.fix.codegen.fields.SecurityExchange;
import software.chronicle.fix.codegen.fields.SecurityID;
import software.chronicle.fix.codegen.fields.SecurityType;
import software.chronicle.fix.codegen.fields.StrikePrice;
import software.chronicle.fix.codegen.fields.Symbol;
import software.chronicle.fix.codegen.fields.SymbolSfx;
import software.chronicle.fix.codegen.fields.TotalVolumeTraded;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface MarketDataSnapshotFullRefresh extends HeaderTrailer, MDReqID, Symbol, SymbolSfx, SecurityID, IDSource, SecurityType, MaturityMonthYear, MaturityDay, PutOrCall, StrikePrice, OptAttribute, ContractMultiplier, CouponRate, SecurityExchange, Issuer, EncodedIssuerLen, EncodedIssuer, SecurityDesc, EncodedSecurityDescLen, FinancialStatus, CorporateAction, TotalVolumeTraded, MarketDataSnapshotFullRefresh_MDEntriesGrp {
    @Deprecated
    static MarketDataSnapshotFullRefresh newMarketDataSnapshotFullRefresh(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.MarketDataSnapshotFullRefresh);
        mg.bytes(bytes);
        return mg;
    }

    static MarketDataSnapshotFullRefresh newMarketDataSnapshotFullRefresh(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.MarketDataSnapshotFullRefresh, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (symbol() == null) throw new RequiredTagMissing("symbol", 55);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        mDReqID(null);
        symbol(null);
        symbolSfx(null);
        securityID(null);
        idSource(null);
        securityType(null);
        maturityMonthYear(null);
        maturityDay(FixMessage.UNSET_LONG);
        putOrCall(FixMessage.UNSET_LONG);
        strikePrice(FixMessage.UNSET_DOUBLE);
        optAttribute(FixMessage.UNSET_CHAR);
        contractMultiplier(FixMessage.UNSET_DOUBLE);
        couponRate(FixMessage.UNSET_DOUBLE);
        securityExchange(null);
        issuer(null);
        encodedIssuerLen(FixMessage.UNSET_LONG);
        encodedIssuer(null);
        securityDesc(null);
        encodedSecurityDescLen(FixMessage.UNSET_LONG);
        financialStatus(FixMessage.UNSET_CHAR);
        corporateAction(FixMessage.UNSET_CHAR);
        totalVolumeTraded(FixMessage.UNSET_DOUBLE);
        // note: not set is different to 0 entries
        if (noMDEntries() > 0) {
            for (int cnoMDEntries = 0, maxnoMDEntries = Maths.toUInt31(noMDEntries()); cnoMDEntries < maxnoMDEntries; cnoMDEntries++) {
                marketDataSnapshotFullRefresh_MDEntriesGrp_1(cnoMDEntries).reset();
            }
        }
        noMDEntries(FixMessage.UNSET_LONG);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((MarketDataSnapshotFullRefresh) msg);
    }

    default void copyTo(MarketDataSnapshotFullRefresh msg) {
        HeaderTrailer.super.copyTo(msg);
        if (mDReqID() != null) msg.mDReqID(mDReqID());
        if (symbol() != null) msg.symbol(symbol());
        if (symbolSfx() != null) msg.symbolSfx(symbolSfx());
        if (securityID() != null) msg.securityID(securityID());
        if (idSource() != null) msg.idSource(idSource());
        if (securityType() != null) msg.securityType(securityType());
        if (maturityMonthYear() != null) msg.maturityMonthYear(maturityMonthYear());
        if (maturityDay() != FixMessage.UNSET_LONG) msg.maturityDay(maturityDay());
        if (putOrCall() != FixMessage.UNSET_LONG) msg.putOrCall(putOrCall());
        if (!Double.isNaN(strikePrice())) msg.strikePrice(strikePrice());
        if (optAttribute() != FixMessage.UNSET_CHAR) msg.optAttribute(optAttribute());
        if (!Double.isNaN(contractMultiplier())) msg.contractMultiplier(contractMultiplier());
        if (!Double.isNaN(couponRate())) msg.couponRate(couponRate());
        if (securityExchange() != null) msg.securityExchange(securityExchange());
        if (issuer() != null) msg.issuer(issuer());
        if (encodedIssuerLen() != FixMessage.UNSET_LONG) msg.encodedIssuerLen(encodedIssuerLen());
        if (encodedIssuer() != null) msg.encodedIssuer(encodedIssuer());
        if (securityDesc() != null) msg.securityDesc(securityDesc());
        if (encodedSecurityDescLen() != FixMessage.UNSET_LONG) msg.encodedSecurityDescLen(encodedSecurityDescLen());
        if (financialStatus() != FixMessage.UNSET_CHAR) msg.financialStatus(financialStatus());
        if (corporateAction() != FixMessage.UNSET_CHAR) msg.corporateAction(corporateAction());
        if (!Double.isNaN(totalVolumeTraded())) msg.totalVolumeTraded(totalVolumeTraded());
        // note: not set is different to 0 entries
        if (noMDEntries() >= 0) {
            msg.noMDEntries(noMDEntries());
            for (int cnoMDEntries = 0, maxnoMDEntries = Maths.toUInt31(noMDEntries()); cnoMDEntries < maxnoMDEntries; cnoMDEntries++) {
                marketDataSnapshotFullRefresh_MDEntriesGrp_1(cnoMDEntries).copyTo(msg.marketDataSnapshotFullRefresh_MDEntriesGrp_1(cnoMDEntries));
            }
        }
    }
}
