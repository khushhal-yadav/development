package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SourceFeed {
    /**
     * Tag number for this field
     */
    int FIELD = 11328;

    /**
     * @param sourceFeed &gt; FIX TAG 11328
     */
    void sourceFeed(String sourceFeed);

    default String sourceFeed() {
        throw new UnsupportedOperationException();
    }
}
