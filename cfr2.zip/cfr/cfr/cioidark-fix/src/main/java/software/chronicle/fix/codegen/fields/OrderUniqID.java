package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrderUniqID {
    /**
     * Tag number for this field
     */
    int FIELD = 10439;

    /**
     * @param orderUniqID &gt; FIX TAG 10439
     */
    void orderUniqID(String orderUniqID);

    default String orderUniqID() {
        throw new UnsupportedOperationException();
    }
}
