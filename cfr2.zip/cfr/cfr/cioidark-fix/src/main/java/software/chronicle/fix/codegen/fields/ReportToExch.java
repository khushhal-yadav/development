package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ReportToExch {
    /**
     * Tag number for this field
     */
    int FIELD = 113;

    String BOOKING = "B";

    String RPTINDF = "F";

    String RPTINDM = "M";

    String PARTYSENDINGWILLRPT = "N";

    String RPTINDO = "O";

    String RPTINDW = "W";

    String PARTYMUSTRPT = "Y";

    /**
     * @param reportToExch &gt; FIX TAG 113
     */
    void reportToExch(String reportToExch);

    default String reportToExch() {
        throw new UnsupportedOperationException();
    }

    static String asString(String value) {
        return value;
    }
}
