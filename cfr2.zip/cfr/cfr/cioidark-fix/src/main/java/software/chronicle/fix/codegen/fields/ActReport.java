package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ActReport {
    /**
     * Tag number for this field
     */
    int FIELD = 11037;

    String RPTINDF = "F";

    String RPTINDM = "M";

    String PARTYSENDINGWILLRPT = "N";

    String RPTINDO = "O";

    String RPTINDW = "W";

    String PARTYMUSTRPT = "Y";

    /**
     * @param actReport &gt; FIX TAG 11037
     */
    void actReport(String actReport);

    default String actReport() {
        throw new UnsupportedOperationException();
    }

    static String asString(String value) {
        return value;
    }
}
