package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface XParentOrderID {
    /**
     * Tag number for this field
     */
    int FIELD = 10243;

    /**
     * @param xParentOrderID &gt; FIX TAG 10243
     */
    void xParentOrderID(String xParentOrderID);

    default String xParentOrderID() {
        throw new UnsupportedOperationException();
    }
}
