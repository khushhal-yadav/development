package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CxlReason {
    /**
     * Tag number for this field
     */
    int FIELD = 6042;

    String CLIENT_CXL = "1";

    String UNSOL_CXL_MARKET_CLOSED = "2";

    String UNSOL_CXL_IOC = "3";

    String MASS_CXL = "4";

    String CXL_ON_DISCONNECT = "5";

    String ADMINISTRATIVE_CXL = "6";

    /**
     * @param cxlReason &gt; FIX TAG 6042
     */
    void cxlReason(String cxlReason);

    default String cxlReason() {
        throw new UnsupportedOperationException();
    }

    static String asString(String value) {
        return value;
    }
}
