package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LocateBroker {
    /**
     * Tag number for this field
     */
    int FIELD = 5700;

    /**
     * @param locateBroker &gt; FIX TAG 5700
     */
    void locateBroker(String locateBroker);

    default String locateBroker() {
        throw new UnsupportedOperationException();
    }
}
