package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ExecID {
    /**
     * Tag number for this field
     */
    int FIELD = 17;

    /**
     * @param execID &gt; FIX TAG 17
     */
    void execID(String execID);

    default String execID() {
        throw new UnsupportedOperationException();
    }
}
