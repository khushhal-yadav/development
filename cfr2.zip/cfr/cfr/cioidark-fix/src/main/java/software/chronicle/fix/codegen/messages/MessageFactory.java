package software.chronicle.fix.codegen.messages;

import software.chronicle.fix.staticcode.messages.MessageFactoryBase;

/**
 * Generated at software.chronicle.fix.codegen.MessageFactoryGenerator.generate(MessageFactoryGenerator.java)
 */
public interface MessageFactory extends MessageFactoryBase {
    Heartbeat heartbeat();

    Logon logon();

    TestRequest testRequest();

    ResendRequest resendRequest();

    Reject reject();

    SequenceReset sequenceReset();

    Logout logout();

    NewOrderSingle newOrderSingle();

    OrderCancelRequest orderCancelRequest();

    OrderCancelReplaceRequest orderCancelReplaceRequest();

    ExecutionReport executionReport();

    OrderCancelReject orderCancelReject();

    DontKnowTrade dontKnowTrade();

    RIOMessage rIOMessage();

    MarketDataSnapshotFullRefresh marketDataSnapshotFullRefresh();

    BusinessMessageReject businessMessageReject();

    CioiDarkOrder cioiDarkOrder();
}
