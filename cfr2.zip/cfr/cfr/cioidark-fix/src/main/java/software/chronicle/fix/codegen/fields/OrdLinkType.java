package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrdLinkType {
    /**
     * Tag number for this field
     */
    int FIELD = 11052;

    String STOP_ORDER = "1";

    String CROSSSBLOCK = "10";

    String WAVE_ID = "11";

    String PNOTE_ORDER = "12";

    String SWAP_ORDER = "13";

    String ETF_UNDERLYER = "14";

    String SPLIT_ORDER = "15";

    String SWING_CUST_ORDER = "16";

    String EIC_HEDGEORDER = "17";

    String GROUP_ORDER = "18";

    String LEPO_ORDER = "19";

    String STOP_EXECID = "2";

    String CRB_HEDGEORDER = "20";

    String ORD_ADR = "21";

    String MANNING_IOC = "22";

    String FACILITATION_ORDER = "23";

    String PRIN_FIRM_ORDER = "24";

    String QUICKTICKET_ORDER = "25";

    String CROSSLATE = "26";

    String TOBS_REP_ORDER = "27";

    String HYBD_SPLIT_ALLOC_ORDER = "28";

    String STOP_ZEXECID = "3";

    String STOP_MANUALCROSS = "4";

    String BASKET_ID = "5";

    String CROSSAON = "6";

    String CROSSIOC = "7";

    String CROSSONESIDE = "8";

    String CROSSSAMEPRICE = "9";

    String ALL_OR_NONE_BASKET_ID = "BSKT_AON";

    String BID_WANTED_IN_COMPETITION_BASKET_ID = "BWIC";

    String GTC_ORDER = "GTC";

    String HEDGEORDER = "HEDGEORDER";

    String ML_CROSS = "MLC";

    String MULTILEG_ID = "MLEG";

    String MULTILEGSUMMARY = "ML_SUMM";

    String NAV_RISK = "NAV_RISK";

    String OUTRIGHT_CONV_HEDGE = "OUTRIGHT_CONV_HEDGE";

    /**
     * @param ordLinkType &gt; FIX TAG 11052
     */
    void ordLinkType(String ordLinkType);

    default String ordLinkType() {
        throw new UnsupportedOperationException();
    }

    static String asString(String value) {
        return value;
    }
}
