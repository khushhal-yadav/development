package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CustomerOrFirm {
    /**
     * Tag number for this field
     */
    int FIELD = 204;

    int CUSTOMER = 0;

    int FIRM = 1;

    /**
     * @param customerOrFirm &gt; FIX TAG 204
     */
    void customerOrFirm(long customerOrFirm);

    default long customerOrFirm() {
        throw new UnsupportedOperationException();
    }

    static String asString(int value) {
        switch (value) {
            case CUSTOMER:
                    return "CUSTOMER";
            case FIRM:
                    return "FIRM";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
