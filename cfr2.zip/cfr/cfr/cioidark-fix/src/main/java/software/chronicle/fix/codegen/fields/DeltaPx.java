package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface DeltaPx {
    /**
     * Tag number for this field
     */
    int FIELD = 9002;

    /**
     * @param deltaPx &gt; FIX TAG 9002
     */
    void deltaPx(double deltaPx);

    default double deltaPx() {
        throw new UnsupportedOperationException();
    }
}
