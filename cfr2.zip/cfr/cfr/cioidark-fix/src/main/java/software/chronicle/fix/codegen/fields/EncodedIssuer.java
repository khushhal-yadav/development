package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface EncodedIssuer {
    /**
     * Tag number for this field
     */
    int FIELD = 349;

    /**
     * @param encodedIssuer &gt; FIX TAG 349
     */
    void encodedIssuer(String encodedIssuer);

    default String encodedIssuer() {
        throw new UnsupportedOperationException();
    }
}
