package software.chronicle.fix.codegen.parsers;

import java.lang.Override;
import java.util.concurrent.TimeUnit;
import net.openhft.chronicle.bytes.util.StringInternerBytes;
import software.chronicle.fix.codegen.components.MarketDataSnapshotFullRefresh_MDEntriesGrp;
import software.chronicle.fix.codegen.fields.Account;
import software.chronicle.fix.codegen.fields.AccountIDSource;
import software.chronicle.fix.codegen.fields.AccountType;
import software.chronicle.fix.codegen.fields.ActReport;
import software.chronicle.fix.codegen.fields.AskPrice;
import software.chronicle.fix.codegen.fields.AvgPriceAcct;
import software.chronicle.fix.codegen.fields.AvgPriceAcctIDSource;
import software.chronicle.fix.codegen.fields.AvgPx;
import software.chronicle.fix.codegen.fields.BidPrice;
import software.chronicle.fix.codegen.fields.BidPx;
import software.chronicle.fix.codegen.fields.BidSize;
import software.chronicle.fix.codegen.fields.BookingType;
import software.chronicle.fix.codegen.fields.BusinessRejectReason;
import software.chronicle.fix.codegen.fields.BusinessRejectRefID;
import software.chronicle.fix.codegen.fields.CashOrderQty;
import software.chronicle.fix.codegen.fields.ChannelName;
import software.chronicle.fix.codegen.fields.ClOrdID;
import software.chronicle.fix.codegen.fields.ClearingInstruction;
import software.chronicle.fix.codegen.fields.ClientID;
import software.chronicle.fix.codegen.fields.ConditionalOrderQty;
import software.chronicle.fix.codegen.fields.ContraAccount;
import software.chronicle.fix.codegen.fields.ContraAccountSrc;
import software.chronicle.fix.codegen.fields.ContraAccountType;
import software.chronicle.fix.codegen.fields.ContraBroker;
import software.chronicle.fix.codegen.fields.ContraOrderCapacity;
import software.chronicle.fix.codegen.fields.ContractMultiplier;
import software.chronicle.fix.codegen.fields.CorellationClOrdID;
import software.chronicle.fix.codegen.fields.CorporateAction;
import software.chronicle.fix.codegen.fields.Country;
import software.chronicle.fix.codegen.fields.CouponRate;
import software.chronicle.fix.codegen.fields.CreatedNS;
import software.chronicle.fix.codegen.fields.CrossID;
import software.chronicle.fix.codegen.fields.CrossInstruction;
import software.chronicle.fix.codegen.fields.CrossRestrictionClientID;
import software.chronicle.fix.codegen.fields.CrossStrategy;
import software.chronicle.fix.codegen.fields.CumQty;
import software.chronicle.fix.codegen.fields.Currency;
import software.chronicle.fix.codegen.fields.CustomPrice1;
import software.chronicle.fix.codegen.fields.CustomerOrFirm;
import software.chronicle.fix.codegen.fields.CustomerSlang;
import software.chronicle.fix.codegen.fields.CxlQty;
import software.chronicle.fix.codegen.fields.CxlReason;
import software.chronicle.fix.codegen.fields.CxlRejReason;
import software.chronicle.fix.codegen.fields.CxlRejResponseTo;
import software.chronicle.fix.codegen.fields.DKReason;
import software.chronicle.fix.codegen.fields.DeliverToCompID;
import software.chronicle.fix.codegen.fields.DeliverToSubID;
import software.chronicle.fix.codegen.fields.DeltaPx;
import software.chronicle.fix.codegen.fields.DeltaQty;
import software.chronicle.fix.codegen.fields.DeskID;
import software.chronicle.fix.codegen.fields.EncodedIssuer;
import software.chronicle.fix.codegen.fields.EncodedIssuerLen;
import software.chronicle.fix.codegen.fields.EncodedSecurityDescLen;
import software.chronicle.fix.codegen.fields.EncodedText;
import software.chronicle.fix.codegen.fields.EncodedTextLen;
import software.chronicle.fix.codegen.fields.ExDestination;
import software.chronicle.fix.codegen.fields.ExDestinationIDSource;
import software.chronicle.fix.codegen.fields.ExecID;
import software.chronicle.fix.codegen.fields.ExecInst;
import software.chronicle.fix.codegen.fields.ExecRefID;
import software.chronicle.fix.codegen.fields.ExecRestatementReason;
import software.chronicle.fix.codegen.fields.ExecTransType;
import software.chronicle.fix.codegen.fields.ExecType;
import software.chronicle.fix.codegen.fields.ExecutedBy;
import software.chronicle.fix.codegen.fields.ExpireDate;
import software.chronicle.fix.codegen.fields.ExpireTime;
import software.chronicle.fix.codegen.fields.FinancialStatus;
import software.chronicle.fix.codegen.fields.FirmId;
import software.chronicle.fix.codegen.fields.HandlInst;
import software.chronicle.fix.codegen.fields.IDSource;
import software.chronicle.fix.codegen.fields.IOIID;
import software.chronicle.fix.codegen.fields.IsCurrExecLevel;
import software.chronicle.fix.codegen.fields.IsRioStateEvent;
import software.chronicle.fix.codegen.fields.Issuer;
import software.chronicle.fix.codegen.fields.LULDLowerPriceBand;
import software.chronicle.fix.codegen.fields.LULDPriceBandTimestamp;
import software.chronicle.fix.codegen.fields.LULDUpperPriceBand;
import software.chronicle.fix.codegen.fields.LafExecID;
import software.chronicle.fix.codegen.fields.LastCapacity;
import software.chronicle.fix.codegen.fields.LastMkt;
import software.chronicle.fix.codegen.fields.LastParPx;
import software.chronicle.fix.codegen.fields.LastPx;
import software.chronicle.fix.codegen.fields.LastShares;
import software.chronicle.fix.codegen.fields.LastTraded;
import software.chronicle.fix.codegen.fields.LastTradedDelta;
import software.chronicle.fix.codegen.fields.LeafExecFlag;
import software.chronicle.fix.codegen.fields.LeafExecutionFlag;
import software.chronicle.fix.codegen.fields.LeafSrcSystemID;
import software.chronicle.fix.codegen.fields.LeavesQty;
import software.chronicle.fix.codegen.fields.LegalEntity;
import software.chronicle.fix.codegen.fields.LocateBroker;
import software.chronicle.fix.codegen.fields.LocateIdentifier;
import software.chronicle.fix.codegen.fields.LocateReqd;
import software.chronicle.fix.codegen.fields.LocationID;
import software.chronicle.fix.codegen.fields.MDEntryBuyer;
import software.chronicle.fix.codegen.fields.MDEntryDate;
import software.chronicle.fix.codegen.fields.MDEntryOriginator;
import software.chronicle.fix.codegen.fields.MDEntryPositionNo;
import software.chronicle.fix.codegen.fields.MDEntryPx;
import software.chronicle.fix.codegen.fields.MDEntrySeller;
import software.chronicle.fix.codegen.fields.MDEntrySize;
import software.chronicle.fix.codegen.fields.MDEntryTime;
import software.chronicle.fix.codegen.fields.MDEntryType;
import software.chronicle.fix.codegen.fields.MDMkt;
import software.chronicle.fix.codegen.fields.MDReqID;
import software.chronicle.fix.codegen.fields.MaturityDay;
import software.chronicle.fix.codegen.fields.MaturityMonthYear;
import software.chronicle.fix.codegen.fields.MinQty;
import software.chronicle.fix.codegen.fields.NoClearingInstructions;
import software.chronicle.fix.codegen.fields.NoStrategyParameters;
import software.chronicle.fix.codegen.fields.NoTempContraBrokers;
import software.chronicle.fix.codegen.fields.NumberOfOrders;
import software.chronicle.fix.codegen.fields.OfferPx;
import software.chronicle.fix.codegen.fields.OfferSize;
import software.chronicle.fix.codegen.fields.OnBehalfOfCompID;
import software.chronicle.fix.codegen.fields.OnBehalfOfSubID;
import software.chronicle.fix.codegen.fields.OpenCloseSettleFlag;
import software.chronicle.fix.codegen.fields.OpenQty;
import software.chronicle.fix.codegen.fields.OptAttribute;
import software.chronicle.fix.codegen.fields.OptOutLockedIn;
import software.chronicle.fix.codegen.fields.OrdLinkID;
import software.chronicle.fix.codegen.fields.OrdLinkType;
import software.chronicle.fix.codegen.fields.OrdRejReason;
import software.chronicle.fix.codegen.fields.OrdStatus;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.OrderCapacity;
import software.chronicle.fix.codegen.fields.OrderFlowCategory;
import software.chronicle.fix.codegen.fields.OrderFlowClass;
import software.chronicle.fix.codegen.fields.OrderFlowEntry;
import software.chronicle.fix.codegen.fields.OrderID;
import software.chronicle.fix.codegen.fields.OrderPlacer;
import software.chronicle.fix.codegen.fields.OrderQty;
import software.chronicle.fix.codegen.fields.OrderRestrictions;
import software.chronicle.fix.codegen.fields.OrderUniqID;
import software.chronicle.fix.codegen.fields.OrderVersion;
import software.chronicle.fix.codegen.fields.OrigClOrdID;
import software.chronicle.fix.codegen.fields.OrigCrossID;
import software.chronicle.fix.codegen.fields.OrigSendingTime;
import software.chronicle.fix.codegen.fields.ParentOrderUniqID;
import software.chronicle.fix.codegen.fields.PreviousLinkOrderID;
import software.chronicle.fix.codegen.fields.PreviousLinkOrderUniqID;
import software.chronicle.fix.codegen.fields.PreviousLinkSrcSystemID;
import software.chronicle.fix.codegen.fields.Price;
import software.chronicle.fix.codegen.fields.PriceType;
import software.chronicle.fix.codegen.fields.PutOrCall;
import software.chronicle.fix.codegen.fields.QuoteCondition;
import software.chronicle.fix.codegen.fields.QuoteEntryID;
import software.chronicle.fix.codegen.fields.QuoteID;
import software.chronicle.fix.codegen.fields.QuoteTime;
import software.chronicle.fix.codegen.fields.ReceiveTime;
import software.chronicle.fix.codegen.fields.ReplayInd;
import software.chronicle.fix.codegen.fields.ReportToExch;
import software.chronicle.fix.codegen.fields.RioBeginString;
import software.chronicle.fix.codegen.fields.RioMinorVersion;
import software.chronicle.fix.codegen.fields.RioMsgSeq;
import software.chronicle.fix.codegen.fields.RioMsgSeqSrc;
import software.chronicle.fix.codegen.fields.RioMsgSource;
import software.chronicle.fix.codegen.fields.RioTimestamp;
import software.chronicle.fix.codegen.fields.RioTransactTime;
import software.chronicle.fix.codegen.fields.RootOrderID;
import software.chronicle.fix.codegen.fields.RootOrderUniqID;
import software.chronicle.fix.codegen.fields.RootSrcSystemID;
import software.chronicle.fix.codegen.fields.Rule80A;
import software.chronicle.fix.codegen.fields.SalesPersonID;
import software.chronicle.fix.codegen.fields.SecurityAltID;
import software.chronicle.fix.codegen.fields.SecurityAltIDSource;
import software.chronicle.fix.codegen.fields.SecurityDesc;
import software.chronicle.fix.codegen.fields.SecurityExchange;
import software.chronicle.fix.codegen.fields.SecurityID;
import software.chronicle.fix.codegen.fields.SecurityType;
import software.chronicle.fix.codegen.fields.SellerDays;
import software.chronicle.fix.codegen.fields.SettlCurrAmt;
import software.chronicle.fix.codegen.fields.SettlCurrFxRate;
import software.chronicle.fix.codegen.fields.SettlCurrFxRateCalc;
import software.chronicle.fix.codegen.fields.SettlCurrency;
import software.chronicle.fix.codegen.fields.SettlmntTyp;
import software.chronicle.fix.codegen.fields.ShortSaleExemptReason;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.fields.SourceFeed;
import software.chronicle.fix.codegen.fields.SrcSystemID;
import software.chronicle.fix.codegen.fields.SrcTargetCompId;
import software.chronicle.fix.codegen.fields.StopPx;
import software.chronicle.fix.codegen.fields.StrategyParameterValue;
import software.chronicle.fix.codegen.fields.StrikePrice;
import software.chronicle.fix.codegen.fields.SumOfStopExecQty;
import software.chronicle.fix.codegen.fields.Symbol;
import software.chronicle.fix.codegen.fields.SymbolSfx;
import software.chronicle.fix.codegen.fields.TargetStrategy;
import software.chronicle.fix.codegen.fields.TargetStrategyParameters;
import software.chronicle.fix.codegen.fields.TempContraBroker;
import software.chronicle.fix.codegen.fields.TempContraBrokerSrc;
import software.chronicle.fix.codegen.fields.TempLastMkt;
import software.chronicle.fix.codegen.fields.TickSizePilotGroup;
import software.chronicle.fix.codegen.fields.Tier;
import software.chronicle.fix.codegen.fields.TimeInForce;
import software.chronicle.fix.codegen.fields.TimeToLive;
import software.chronicle.fix.codegen.fields.TotalVolumeTraded;
import software.chronicle.fix.codegen.fields.TradeCondition;
import software.chronicle.fix.codegen.fields.TradeDate;
import software.chronicle.fix.codegen.fields.TraderID;
import software.chronicle.fix.codegen.fields.TradingAcct;
import software.chronicle.fix.codegen.fields.TradingSessionID;
import software.chronicle.fix.codegen.fields.TransactTime;
import software.chronicle.fix.codegen.fields.TrdType;
import software.chronicle.fix.codegen.fields.XLastActivityUserID;
import software.chronicle.fix.codegen.fields.XParentOrderID;
import software.chronicle.fix.codegen.fields.ZExecID;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.pool.DateTimeParser;
import software.chronicle.fix.sessioncode.fields.BeginSeqNo;
import software.chronicle.fix.sessioncode.fields.EncryptMethod;
import software.chronicle.fix.sessioncode.fields.EndSeqNo;
import software.chronicle.fix.sessioncode.fields.GapFillFlag;
import software.chronicle.fix.sessioncode.fields.HeartBtInt;
import software.chronicle.fix.sessioncode.fields.MsgSeqNum;
import software.chronicle.fix.sessioncode.fields.NewSeqNo;
import software.chronicle.fix.sessioncode.fields.Password;
import software.chronicle.fix.sessioncode.fields.PossDupFlag;
import software.chronicle.fix.sessioncode.fields.PossResend;
import software.chronicle.fix.sessioncode.fields.RawData;
import software.chronicle.fix.sessioncode.fields.RawDataLength;
import software.chronicle.fix.sessioncode.fields.RefMsgType;
import software.chronicle.fix.sessioncode.fields.RefSeqNum;
import software.chronicle.fix.sessioncode.fields.RefTagID;
import software.chronicle.fix.sessioncode.fields.ResetSeqNumFlag;
import software.chronicle.fix.sessioncode.fields.SenderCompID;
import software.chronicle.fix.sessioncode.fields.SenderSubID;
import software.chronicle.fix.sessioncode.fields.SendingTime;
import software.chronicle.fix.sessioncode.fields.SessionRejectReason;
import software.chronicle.fix.sessioncode.fields.TargetCompID;
import software.chronicle.fix.sessioncode.fields.TargetSubID;
import software.chronicle.fix.sessioncode.fields.TestReqID;
import software.chronicle.fix.sessioncode.fields.Text;
import software.chronicle.fix.sessioncode.fields.Username;
import software.chronicle.fix.staticcode.parsers.CoreFieldParserBase;

/**
 * Generated at software.chronicle.fix.codegen.CoreFieldsParserGenerator.generateCode(CoreFieldsParserGenerator.java)
 */
public class GeneratedCoreFieldParser extends CoreFieldParserBase {
    /**
     * ^A1=
     */
    public static final int FIX_1_Account = 0x3d3101;

    /**
     * ^A660=
     */
    public static final long FIX_660_AccountIDSource = 0x3d30363601L;

    /**
     * ^A581=
     */
    public static final long FIX_581_AccountType = 0x3d31383501L;

    /**
     * ^A11037=
     */
    public static final long FIX_11037_ActReport = 0x3d373330313101L;

    /**
     * ^A11006=
     */
    public static final long FIX_11006_AskPrice = 0x3d363030313101L;

    /**
     * ^A10051=
     */
    public static final long FIX_10051_AvgPriceAcct = 0x3d313530303101L;

    /**
     * ^A10428=
     */
    public static final long FIX_10428_AvgPriceAcctIDSource = 0x3d383234303101L;

    /**
     * ^A6=
     */
    public static final int FIX_6_AvgPx = 0x3d3601;

    /**
     * ^A7=
     */
    public static final int FIX_7_BeginSeqNo = 0x3d3701;

    /**
     * ^A11005=
     */
    public static final long FIX_11005_BidPrice = 0x3d353030313101L;

    /**
     * ^A132=
     */
    public static final long FIX_132_BidPx = 0x3d32333101L;

    /**
     * ^A134=
     */
    public static final long FIX_134_BidSize = 0x3d34333101L;

    /**
     * ^A775=
     */
    public static final long FIX_775_BookingType = 0x3d35373701L;

    /**
     * ^A380=
     */
    public static final long FIX_380_BusinessRejectReason = 0x3d30383301L;

    /**
     * ^A379=
     */
    public static final long FIX_379_BusinessRejectRefID = 0x3d39373301L;

    /**
     * ^A152=
     */
    public static final long FIX_152_CashOrderQty = 0x3d32353101L;

    /**
     * ^A10053=
     */
    public static final long FIX_10053_ChannelName = 0x3d333530303101L;

    /**
     * ^A11=
     */
    public static final int FIX_11_ClOrdID = 0x3d313101;

    /**
     * ^A577=
     */
    public static final long FIX_577_ClearingInstruction = 0x3d37373501L;

    /**
     * ^A109=
     */
    public static final long FIX_109_ClientID = 0x3d39303101L;

    /**
     * ^A8060=
     */
    public static final long FIX_8060_ConditionalOrderQty = 0x3d3036303801L;

    /**
     * ^A10514=
     */
    public static final long FIX_10514_ContraAccount = 0x3d343135303101L;

    /**
     * ^A11040=
     */
    public static final long FIX_11040_ContraAccountSrc = 0x3d303430313101L;

    /**
     * ^A11041=
     */
    public static final long FIX_11041_ContraAccountType = 0x3d313430313101L;

    /**
     * ^A375=
     */
    public static final long FIX_375_ContraBroker = 0x3d35373301L;

    /**
     * ^A10158=
     */
    public static final long FIX_10158_ContraOrderCapacity = 0x3d383531303101L;

    /**
     * ^A231=
     */
    public static final long FIX_231_ContractMultiplier = 0x3d31333201L;

    /**
     * ^A9717=
     */
    public static final long FIX_9717_CorellationClOrdID = 0x3d3731373901L;

    /**
     * ^A292=
     */
    public static final long FIX_292_CorporateAction = 0x3d32393201L;

    /**
     * ^A421=
     */
    public static final long FIX_421_Country = 0x3d31323401L;

    /**
     * ^A223=
     */
    public static final long FIX_223_CouponRate = 0x3d33323201L;

    /**
     * ^A9999=
     */
    public static final long FIX_9999_CreatedNS = 0x3d3939393901L;

    /**
     * ^A548=
     */
    public static final long FIX_548_CrossID = 0x3d38343501L;

    /**
     * ^A6438=
     */
    public static final long FIX_6438_CrossInstruction = 0x3d3833343601L;

    /**
     * ^A10896=
     */
    public static final long FIX_10896_CrossRestrictionClientID = 0x3d363938303101L;

    /**
     * ^A7411=
     */
    public static final long FIX_7411_CrossStrategy = 0x3d3131343701L;

    /**
     * ^A14=
     */
    public static final int FIX_14_CumQty = 0x3d343101;

    /**
     * ^A15=
     */
    public static final int FIX_15_Currency = 0x3d353101;

    /**
     * ^A7491=
     */
    public static final long FIX_7491_CustomPrice1 = 0x3d3139343701L;

    /**
     * ^A204=
     */
    public static final long FIX_204_CustomerOrFirm = 0x3d34303201L;

    /**
     * ^A8004=
     */
    public static final long FIX_8004_CustomerSlang = 0x3d3430303801L;

    /**
     * ^A84=
     */
    public static final int FIX_84_CxlQty = 0x3d343801;

    /**
     * ^A6042=
     */
    public static final long FIX_6042_CxlReason = 0x3d3234303601L;

    /**
     * ^A102=
     */
    public static final long FIX_102_CxlRejReason = 0x3d32303101L;

    /**
     * ^A434=
     */
    public static final long FIX_434_CxlRejResponseTo = 0x3d34333401L;

    /**
     * ^A127=
     */
    public static final long FIX_127_DKReason = 0x3d37323101L;

    /**
     * ^A128=
     */
    public static final long FIX_128_DeliverToCompID = 0x3d38323101L;

    /**
     * ^A129=
     */
    public static final long FIX_129_DeliverToSubID = 0x3d39323101L;

    /**
     * ^A9002=
     */
    public static final long FIX_9002_DeltaPx = 0x3d3230303901L;

    /**
     * ^A9001=
     */
    public static final long FIX_9001_DeltaQty = 0x3d3130303901L;

    /**
     * ^A284=
     */
    public static final long FIX_284_DeskID = 0x3d34383201L;

    /**
     * ^A349=
     */
    public static final long FIX_349_EncodedIssuer = 0x3d39343301L;

    /**
     * ^A348=
     */
    public static final long FIX_348_EncodedIssuerLen = 0x3d38343301L;

    /**
     * ^A351=
     */
    public static final long FIX_351_EncodedSecurityDesc = 0x3d31353301L;

    /**
     * ^A350=
     */
    public static final long FIX_350_EncodedSecurityDescLen = 0x3d30353301L;

    /**
     * ^A355=
     */
    public static final long FIX_355_EncodedText = 0x3d35353301L;

    /**
     * ^A354=
     */
    public static final long FIX_354_EncodedTextLen = 0x3d34353301L;

    /**
     * ^A98=
     */
    public static final int FIX_98_EncryptMethod = 0x3d383901;

    /**
     * ^A16=
     */
    public static final int FIX_16_EndSeqNo = 0x3d363101;

    /**
     * ^A100=
     */
    public static final long FIX_100_ExDestination = 0x3d30303101L;

    /**
     * ^A1133=
     */
    public static final long FIX_1133_ExDestinationIDSource = 0x3d3333313101L;

    /**
     * ^A17=
     */
    public static final int FIX_17_ExecID = 0x3d373101;

    /**
     * ^A18=
     */
    public static final int FIX_18_ExecInst = 0x3d383101;

    /**
     * ^A19=
     */
    public static final int FIX_19_ExecRefID = 0x3d393101;

    /**
     * ^A378=
     */
    public static final long FIX_378_ExecRestatementReason = 0x3d38373301L;

    /**
     * ^A20=
     */
    public static final int FIX_20_ExecTransType = 0x3d303201;

    /**
     * ^A150=
     */
    public static final long FIX_150_ExecType = 0x3d30353101L;

    /**
     * ^A10021=
     */
    public static final long FIX_10021_ExecutedBy = 0x3d313230303101L;

    /**
     * ^A432=
     */
    public static final long FIX_432_ExpireDate = 0x3d32333401L;

    /**
     * ^A126=
     */
    public static final long FIX_126_ExpireTime = 0x3d36323101L;

    /**
     * ^A291=
     */
    public static final long FIX_291_FinancialStatus = 0x3d31393201L;

    /**
     * ^A10054=
     */
    public static final long FIX_10054_FirmId = 0x3d343530303101L;

    /**
     * ^A123=
     */
    public static final long FIX_123_GapFillFlag = 0x3d33323101L;

    /**
     * ^A21=
     */
    public static final int FIX_21_HandlInst = 0x3d313201;

    /**
     * ^A108=
     */
    public static final long FIX_108_HeartBtInt = 0x3d38303101L;

    /**
     * ^A22=
     */
    public static final int FIX_22_IDSource = 0x3d323201;

    /**
     * ^A23=
     */
    public static final int FIX_23_IOIID = 0x3d333201;

    /**
     * ^A11027=
     */
    public static final long FIX_11027_IsCurrExecLevel = 0x3d373230313101L;

    /**
     * ^A10104=
     */
    public static final long FIX_10104_IsRioStateEvent = 0x3d343031303101L;

    /**
     * ^A106=
     */
    public static final long FIX_106_Issuer = 0x3d36303101L;

    /**
     * ^A10721=
     */
    public static final long FIX_10721_LULDLowerPriceBand = 0x3d313237303101L;

    /**
     * ^A10723=
     */
    public static final long FIX_10723_LULDPriceBandTimestamp = 0x3d333237303101L;

    /**
     * ^A10722=
     */
    public static final long FIX_10722_LULDUpperPriceBand = 0x3d323237303101L;

    /**
     * ^A10964=
     */
    public static final long FIX_10964_LafExecID = 0x3d343639303101L;

    /**
     * ^A29=
     */
    public static final int FIX_29_LastCapacity = 0x3d393201;

    /**
     * ^A30=
     */
    public static final int FIX_30_LastMkt = 0x3d303301;

    /**
     * ^A669=
     */
    public static final long FIX_669_LastParPx = 0x3d39363601L;

    /**
     * ^A31=
     */
    public static final int FIX_31_LastPx = 0x3d313301;

    /**
     * ^A32=
     */
    public static final int FIX_32_LastShares = 0x3d323301;

    /**
     * ^A11001=
     */
    public static final long FIX_11001_LastTraded = 0x3d313030313101L;

    /**
     * ^A11002=
     */
    public static final long FIX_11002_LastTradedDelta = 0x3d323030313101L;

    /**
     * ^A10217=
     */
    public static final long FIX_10217_LeafExecFlag = 0x3d373132303101L;

    /**
     * ^A10217=
     */
    public static final long FIX_10217_LeafExecutionFlag = 0x3d373132303101L;

    /**
     * ^A10965=
     */
    public static final long FIX_10965_LeafSrcSystemID = 0x3d353639303101L;

    /**
     * ^A151=
     */
    public static final long FIX_151_LeavesQty = 0x3d31353101L;

    /**
     * ^A10031=
     */
    public static final long FIX_10031_LegalEntity = 0x3d313330303101L;

    /**
     * ^A5700=
     */
    public static final long FIX_5700_LocateBroker = 0x3d3030373501L;

    /**
     * ^A5701=
     */
    public static final long FIX_5701_LocateIdentifier = 0x3d3130373501L;

    /**
     * ^A114=
     */
    public static final long FIX_114_LocateReqd = 0x3d34313101L;

    /**
     * ^A283=
     */
    public static final long FIX_283_LocationID = 0x3d33383201L;

    /**
     * ^A288=
     */
    public static final long FIX_288_MDEntryBuyer = 0x3d38383201L;

    /**
     * ^A272=
     */
    public static final long FIX_272_MDEntryDate = 0x3d32373201L;

    /**
     * ^A282=
     */
    public static final long FIX_282_MDEntryOriginator = 0x3d32383201L;

    /**
     * ^A290=
     */
    public static final long FIX_290_MDEntryPositionNo = 0x3d30393201L;

    /**
     * ^A270=
     */
    public static final long FIX_270_MDEntryPx = 0x3d30373201L;

    /**
     * ^A289=
     */
    public static final long FIX_289_MDEntrySeller = 0x3d39383201L;

    /**
     * ^A271=
     */
    public static final long FIX_271_MDEntrySize = 0x3d31373201L;

    /**
     * ^A273=
     */
    public static final long FIX_273_MDEntryTime = 0x3d33373201L;

    /**
     * ^A269=
     */
    public static final long FIX_269_MDEntryType = 0x3d39363201L;

    /**
     * ^A275=
     */
    public static final long FIX_275_MDMkt = 0x3d35373201L;

    /**
     * ^A262=
     */
    public static final long FIX_262_MDReqID = 0x3d32363201L;

    /**
     * ^A268=
     */
    public static final long FIX_268_NoMDEntries = 0x3d38363201L;

    /**
     * ^A274=
     */
    public static final long FIX_274_TickDirection = 0x3d34373201L;

    /**
     * ^A336=
     */
    public static final long FIX_336_TradingSessionID = 0x3d36333301L;

    /**
     * ^A276=
     */
    public static final long FIX_276_QuoteCondition = 0x3d36373201L;

    /**
     * ^A277=
     */
    public static final long FIX_277_TradeCondition = 0x3d37373201L;

    /**
     * ^A286=
     */
    public static final long FIX_286_OpenCloseSettleFlag = 0x3d36383201L;

    /**
     * ^A59=
     */
    public static final int FIX_59_TimeInForce = 0x3d393501;

    /**
     * ^A110=
     */
    public static final long FIX_110_MinQty = 0x3d30313101L;

    /**
     * ^A287=
     */
    public static final long FIX_287_SellerDays = 0x3d37383201L;

    /**
     * ^A37=
     */
    public static final int FIX_37_OrderID = 0x3d373301;

    /**
     * ^A299=
     */
    public static final long FIX_299_QuoteEntryID = 0x3d39393201L;

    /**
     * ^A346=
     */
    public static final long FIX_346_NumberOfOrders = 0x3d36343301L;

    /**
     * ^A58=
     */
    public static final int FIX_58_Text = 0x3d383501;

    /**
     * ^A205=
     */
    public static final long FIX_205_MaturityDay = 0x3d35303201L;

    /**
     * ^A200=
     */
    public static final long FIX_200_MaturityMonthYear = 0x3d30303201L;

    /**
     * ^A34=
     */
    public static final int FIX_34_MsgSeqNum = 0x3d343301;

    /**
     * ^A36=
     */
    public static final int FIX_36_NewSeqNo = 0x3d363301;

    /**
     * ^A576=
     */
    public static final long FIX_576_NoClearingInstructions = 0x3d36373501L;

    /**
     * ^A957=
     */
    public static final long FIX_957_NoStrategyParameters = 0x3d37353901L;

    /**
     * ^A10533=
     */
    public static final long FIX_10533_NoTempContraBrokers = 0x3d333335303101L;

    /**
     * ^A133=
     */
    public static final long FIX_133_OfferPx = 0x3d33333101L;

    /**
     * ^A135=
     */
    public static final long FIX_135_OfferSize = 0x3d35333101L;

    /**
     * ^A115=
     */
    public static final long FIX_115_OnBehalfOfCompID = 0x3d35313101L;

    /**
     * ^A116=
     */
    public static final long FIX_116_OnBehalfOfSubID = 0x3d36313101L;

    /**
     * ^A11007=
     */
    public static final long FIX_11007_OpenQty = 0x3d373030313101L;

    /**
     * ^A206=
     */
    public static final long FIX_206_OptAttribute = 0x3d36303201L;

    /**
     * ^A10565=
     */
    public static final long FIX_10565_OptOutLockedIn = 0x3d353635303101L;

    /**
     * ^A11053=
     */
    public static final long FIX_11053_OrdLinkID = 0x3d333530313101L;

    /**
     * ^A11052=
     */
    public static final long FIX_11052_OrdLinkType = 0x3d323530313101L;

    /**
     * ^A103=
     */
    public static final long FIX_103_OrdRejReason = 0x3d33303101L;

    /**
     * ^A39=
     */
    public static final int FIX_39_OrdStatus = 0x3d393301;

    /**
     * ^A40=
     */
    public static final int FIX_40_OrdType = 0x3d303401;

    /**
     * ^A528=
     */
    public static final long FIX_528_OrderCapacity = 0x3d38323501L;

    /**
     * ^A10202=
     */
    public static final long FIX_10202_OrderFlowCategory = 0x3d323032303101L;

    /**
     * ^A10201=
     */
    public static final long FIX_10201_OrderFlowClass = 0x3d313032303101L;

    /**
     * ^A10201=
     */
    public static final long FIX_10201_OrderFlowEntry = 0x3d313032303101L;

    /**
     * ^A10895=
     */
    public static final long FIX_10895_OrderPlacer = 0x3d353938303101L;

    /**
     * ^A38=
     */
    public static final int FIX_38_OrderQty = 0x3d383301;

    /**
     * ^A529=
     */
    public static final long FIX_529_OrderRestrictions = 0x3d39323501L;

    /**
     * ^A10439=
     */
    public static final long FIX_10439_OrderUniqID = 0x3d393334303101L;

    /**
     * ^A12052=
     */
    public static final long FIX_12052_OrderVersion = 0x3d323530323101L;

    /**
     * ^A41=
     */
    public static final int FIX_41_OrigClOrdID = 0x3d313401;

    /**
     * ^A551=
     */
    public static final long FIX_551_OrigCrossID = 0x3d31353501L;

    /**
     * ^A122=
     */
    public static final long FIX_122_OrigSendingTime = 0x3d32323101L;

    /**
     * ^A10517=
     */
    public static final long FIX_10517_ParentOrderUniqID = 0x3d373135303101L;

    /**
     * ^A554=
     */
    public static final long FIX_554_Password = 0x3d34353501L;

    /**
     * ^A43=
     */
    public static final int FIX_43_PossDupFlag = 0x3d333401;

    /**
     * ^A97=
     */
    public static final int FIX_97_PossResend = 0x3d373901;

    /**
     * ^A10184=
     */
    public static final long FIX_10184_PreviousLinkOrderID = 0x3d343831303101L;

    /**
     * ^A10519=
     */
    public static final long FIX_10519_PreviousLinkOrderUniqID = 0x3d393135303101L;

    /**
     * ^A10518=
     */
    public static final long FIX_10518_PreviousLinkSrcSystemID = 0x3d383135303101L;

    /**
     * ^A44=
     */
    public static final int FIX_44_Price = 0x3d343401;

    /**
     * ^A423=
     */
    public static final long FIX_423_PriceType = 0x3d33323401L;

    /**
     * ^A201=
     */
    public static final long FIX_201_PutOrCall = 0x3d31303201L;

    /**
     * ^A117=
     */
    public static final long FIX_117_QuoteID = 0x3d37313101L;

    /**
     * ^A11048=
     */
    public static final long FIX_11048_QuoteTime = 0x3d383430313101L;

    /**
     * ^A96=
     */
    public static final int FIX_96_RawData = 0x3d363901;

    /**
     * ^A95=
     */
    public static final int FIX_95_RawDataLength = 0x3d353901;

    /**
     * ^A10080=
     */
    public static final long FIX_10080_ReceiveTime = 0x3d303830303101L;

    /**
     * ^A372=
     */
    public static final long FIX_372_RefMsgType = 0x3d32373301L;

    /**
     * ^A45=
     */
    public static final int FIX_45_RefSeqNum = 0x3d353401;

    /**
     * ^A371=
     */
    public static final long FIX_371_RefTagID = 0x3d31373301L;

    /**
     * ^A10657=
     */
    public static final long FIX_10657_ReplayInd = 0x3d373536303101L;

    /**
     * ^A113=
     */
    public static final long FIX_113_ReportToExch = 0x3d33313101L;

    /**
     * ^A141=
     */
    public static final long FIX_141_ResetSeqNumFlag = 0x3d31343101L;

    /**
     * ^A10438=
     */
    public static final long FIX_10438_RioBeginString = 0x3d383334303101L;

    /**
     * ^A10653=
     */
    public static final long FIX_10653_RioMinorVersion = 0x3d333536303101L;

    /**
     * ^A10655=
     */
    public static final long FIX_10655_RioMsgSeq = 0x3d353536303101L;

    /**
     * ^A10658=
     */
    public static final long FIX_10658_RioMsgSeqSrc = 0x3d383536303101L;

    /**
     * ^A10208=
     */
    public static final long FIX_10208_RioMsgSource = 0x3d383032303101L;

    /**
     * ^A10071=
     */
    public static final long FIX_10071_RioTimestamp = 0x3d313730303101L;

    /**
     * ^A10436=
     */
    public static final long FIX_10436_RioTransactTime = 0x3d363334303101L;

    /**
     * ^A11210=
     */
    public static final long FIX_11210_RootOrderID = 0x3d303132313101L;

    /**
     * ^A10516=
     */
    public static final long FIX_10516_RootOrderUniqID = 0x3d363135303101L;

    /**
     * ^A10515=
     */
    public static final long FIX_10515_RootSrcSystemID = 0x3d353135303101L;

    /**
     * ^A47=
     */
    public static final int FIX_47_Rule80A = 0x3d373401;

    /**
     * ^A10036=
     */
    public static final long FIX_10036_SalesPersonID = 0x3d363330303101L;

    /**
     * ^A455=
     */
    public static final long FIX_455_SecurityAltID = 0x3d35353401L;

    /**
     * ^A456=
     */
    public static final long FIX_456_SecurityAltIDSource = 0x3d36353401L;

    /**
     * ^A107=
     */
    public static final long FIX_107_SecurityDesc = 0x3d37303101L;

    /**
     * ^A207=
     */
    public static final long FIX_207_SecurityExchange = 0x3d37303201L;

    /**
     * ^A48=
     */
    public static final int FIX_48_SecurityID = 0x3d383401;

    /**
     * ^A167=
     */
    public static final long FIX_167_SecurityType = 0x3d37363101L;

    /**
     * ^A49=
     */
    public static final int FIX_49_SenderCompID = 0x3d393401;

    /**
     * ^A50=
     */
    public static final int FIX_50_SenderSubID = 0x3d303501;

    /**
     * ^A52=
     */
    public static final int FIX_52_SendingTime = 0x3d323501;

    /**
     * ^A373=
     */
    public static final long FIX_373_SessionRejectReason = 0x3d33373301L;

    /**
     * ^A119=
     */
    public static final long FIX_119_SettlCurrAmt = 0x3d39313101L;

    /**
     * ^A155=
     */
    public static final long FIX_155_SettlCurrFxRate = 0x3d35353101L;

    /**
     * ^A156=
     */
    public static final long FIX_156_SettlCurrFxRateCalc = 0x3d36353101L;

    /**
     * ^A120=
     */
    public static final long FIX_120_SettlCurrency = 0x3d30323101L;

    /**
     * ^A63=
     */
    public static final int FIX_63_SettlmntTyp = 0x3d333601;

    /**
     * ^A1688=
     */
    public static final long FIX_1688_ShortSaleExemptReason = 0x3d3838363101L;

    /**
     * ^A54=
     */
    public static final int FIX_54_Side = 0x3d343501;

    /**
     * ^A11328=
     */
    public static final long FIX_11328_SourceFeed = 0x3d383233313101L;

    /**
     * ^A10005=
     */
    public static final long FIX_10005_SrcSystemID = 0x3d353030303101L;

    /**
     * ^A10084=
     */
    public static final long FIX_10084_SrcTargetCompId = 0x3d343830303101L;

    /**
     * ^A99=
     */
    public static final int FIX_99_StopPx = 0x3d393901;

    /**
     * ^A960=
     */
    public static final long FIX_960_StrategyParameterValue = 0x3d30363901L;

    /**
     * ^A202=
     */
    public static final long FIX_202_StrikePrice = 0x3d32303201L;

    /**
     * ^A10065=
     */
    public static final long FIX_10065_SumOfStopExecQty = 0x3d353630303101L;

    /**
     * ^A55=
     */
    public static final int FIX_55_Symbol = 0x3d353501;

    /**
     * ^A65=
     */
    public static final int FIX_65_SymbolSfx = 0x3d353601;

    /**
     * ^A56=
     */
    public static final int FIX_56_TargetCompID = 0x3d363501;

    /**
     * ^A847=
     */
    public static final long FIX_847_TargetStrategy = 0x3d37343801L;

    /**
     * ^A848=
     */
    public static final long FIX_848_TargetStrategyParameters = 0x3d38343801L;

    /**
     * ^A57=
     */
    public static final int FIX_57_TargetSubID = 0x3d373501;

    /**
     * ^A10534=
     */
    public static final long FIX_10534_TempContraBroker = 0x3d343335303101L;

    /**
     * ^A10535=
     */
    public static final long FIX_10535_TempContraBrokerSrc = 0x3d353335303101L;

    /**
     * ^A10537=
     */
    public static final long FIX_10537_TempLastMkt = 0x3d373335303101L;

    /**
     * ^A112=
     */
    public static final long FIX_112_TestReqID = 0x3d32313101L;

    /**
     * ^A11319=
     */
    public static final long FIX_11319_TickSizePilotGroup = 0x3d393133313101L;

    /**
     * ^A10270=
     */
    public static final long FIX_10270_Tier = 0x3d303732303101L;

    /**
     * ^A10014=
     */
    public static final long FIX_10014_TimeToLive = 0x3d343130303101L;

    /**
     * ^A387=
     */
    public static final long FIX_387_TotalVolumeTraded = 0x3d37383301L;

    /**
     * ^A75=
     */
    public static final int FIX_75_TradeDate = 0x3d353701;

    /**
     * ^A10039=
     */
    public static final long FIX_10039_TraderID = 0x3d393330303101L;

    /**
     * ^A10050=
     */
    public static final long FIX_10050_TradingAcct = 0x3d303530303101L;

    /**
     * ^A60=
     */
    public static final int FIX_60_TransactTime = 0x3d303601;

    /**
     * ^A828=
     */
    public static final long FIX_828_TrdType = 0x3d38323801L;

    /**
     * ^A553=
     */
    public static final long FIX_553_Username = 0x3d33353501L;

    /**
     * ^A10241=
     */
    public static final long FIX_10241_XLastActivityUserID = 0x3d313432303101L;

    /**
     * ^A10243=
     */
    public static final long FIX_10243_XParentOrderID = 0x3d333432303101L;

    /**
     * ^A10018=
     */
    public static final long FIX_10018_ZExecID = 0x3d383130303101L;

    public GeneratedCoreFieldParser(StringInternerBytes stringInterner, DateTimeParser dateTimeParser, boolean validateCheckSum) {
        super(stringInterner, dateTimeParser, validateCheckSum);
    }

    @Override
    public TimeUnit internalTimeUnit() {
        return TimeUnit.MILLISECONDS;
    }

    public void standardHeader(HeaderTrailer ht) {
        senderCompID(ht);
        targetCompID(ht);
        msgSeqNum(ht);
        senderSubID(ht);
        targetSubID(ht);
        onBehalfOfCompID(ht);
        onBehalfOfSubID(ht);
        deliverToCompID(ht);
        deliverToSubID(ht);
        possDupFlag(ht);
        possResend(ht);
        sendingTime(ht);
        origSendingTime(ht);
    }

    public void account(Account target) {
        if ((fieldNumber & MASK_24) == FIX_1_Account) {
            bytes.readSkip(-1);
            target.account(parseString());
        }
    }

    public void accountIDSource(AccountIDSource target) {
        if (fieldNumber == (int)FIX_660_AccountIDSource && isNextCharAnEq()) {
            target.accountIDSource(parseString());
        }
    }

    public void accountType(AccountType target) {
        if (fieldNumber == (int)FIX_581_AccountType && isNextCharAnEq()) {
            target.accountType(parseString());
        }
    }

    public void actReport(ActReport target) {
        if (fieldNumber == (int)FIX_11037_ActReport && areNextThreeBytes((int)(FIX_11037_ActReport >> 32))) {
            target.actReport(parseString());
        }
    }

    public void askPrice(AskPrice target) {
        if (fieldNumber == (int)FIX_11006_AskPrice && areNextThreeBytes((int)(FIX_11006_AskPrice >> 32))) {
            target.askPrice(parseDouble());
        }
    }

    public void avgPriceAcct(AvgPriceAcct target) {
        if (fieldNumber == (int)FIX_10051_AvgPriceAcct && areNextThreeBytes((int)(FIX_10051_AvgPriceAcct >> 32))) {
            target.avgPriceAcct(parseString());
        }
    }

    public void avgPriceAcctIDSource(AvgPriceAcctIDSource target) {
        if (fieldNumber == (int)FIX_10428_AvgPriceAcctIDSource && areNextThreeBytes((int)(FIX_10428_AvgPriceAcctIDSource >> 32))) {
            target.avgPriceAcctIDSource(parseString());
        }
    }

    public void avgPx(AvgPx target) {
        if ((fieldNumber & MASK_24) == FIX_6_AvgPx) {
            bytes.readSkip(-1);
            target.avgPx(parseDouble());
        }
    }

    public void beginSeqNo(BeginSeqNo target) {
        if ((fieldNumber & MASK_24) == FIX_7_BeginSeqNo) {
            bytes.readSkip(-1);
            target.beginSeqNo(parseLong());
        }
    }

    public void bidPrice(BidPrice target) {
        if (fieldNumber == (int)FIX_11005_BidPrice && areNextThreeBytes((int)(FIX_11005_BidPrice >> 32))) {
            target.bidPrice(parseDouble());
        }
    }

    public void bidPx(BidPx target) {
        if (fieldNumber == (int)FIX_132_BidPx && isNextCharAnEq()) {
            target.bidPx(parseDouble());
        }
    }

    public void bidSize(BidSize target) {
        if (fieldNumber == (int)FIX_134_BidSize && isNextCharAnEq()) {
            target.bidSize(parseDouble());
        }
    }

    public void bookingType(BookingType target) {
        if (fieldNumber == (int)FIX_775_BookingType && isNextCharAnEq()) {
            target.bookingType(parseString());
        }
    }

    public void businessRejectReason(BusinessRejectReason target) {
        if (fieldNumber == (int)FIX_380_BusinessRejectReason && isNextCharAnEq()) {
            target.businessRejectReason(parseLong());
        }
    }

    public void businessRejectRefID(BusinessRejectRefID target) {
        if (fieldNumber == (int)FIX_379_BusinessRejectRefID && isNextCharAnEq()) {
            target.businessRejectRefID(parseString());
        }
    }

    public void cashOrderQty(CashOrderQty target) {
        if (fieldNumber == (int)FIX_152_CashOrderQty && isNextCharAnEq()) {
            target.cashOrderQty(parseDouble());
        }
    }

    public void channelName(ChannelName target) {
        if (fieldNumber == (int)FIX_10053_ChannelName && areNextThreeBytes((int)(FIX_10053_ChannelName >> 32))) {
            target.channelName(parseString());
        }
    }

    public void clOrdID(ClOrdID target) {
        if (fieldNumber == FIX_11_ClOrdID) {
            target.clOrdID(parseString());
        }
    }

    public void clearingInstruction(ClearingInstruction target) {
        if (fieldNumber == (int)FIX_577_ClearingInstruction && isNextCharAnEq()) {
            target.clearingInstruction(parseLong());
        }
    }

    public void clientID(ClientID target) {
        if (fieldNumber == (int)FIX_109_ClientID && isNextCharAnEq()) {
            target.clientID(parseString());
        }
    }

    public void conditionalOrderQty(ConditionalOrderQty target) {
        if (fieldNumber == (int)FIX_8060_ConditionalOrderQty && areNextTwoBytes((int)(FIX_8060_ConditionalOrderQty >> 32))) {
            target.conditionalOrderQty(parseDouble());
        }
    }

    public void contraAccount(ContraAccount target) {
        if (fieldNumber == (int)FIX_10514_ContraAccount && areNextThreeBytes((int)(FIX_10514_ContraAccount >> 32))) {
            target.contraAccount(parseString());
        }
    }

    public void contraAccountSrc(ContraAccountSrc target) {
        if (fieldNumber == (int)FIX_11040_ContraAccountSrc && areNextThreeBytes((int)(FIX_11040_ContraAccountSrc >> 32))) {
            target.contraAccountSrc(parseString());
        }
    }

    public void contraAccountType(ContraAccountType target) {
        if (fieldNumber == (int)FIX_11041_ContraAccountType && areNextThreeBytes((int)(FIX_11041_ContraAccountType >> 32))) {
            target.contraAccountType(parseString());
        }
    }

    public void contraBroker(ContraBroker target) {
        if (fieldNumber == (int)FIX_375_ContraBroker && isNextCharAnEq()) {
            target.contraBroker(parseString());
        }
    }

    public void contraOrderCapacity(ContraOrderCapacity target) {
        if (fieldNumber == (int)FIX_10158_ContraOrderCapacity && areNextThreeBytes((int)(FIX_10158_ContraOrderCapacity >> 32))) {
            target.contraOrderCapacity(parseChar());
        }
    }

    public void contractMultiplier(ContractMultiplier target) {
        if (fieldNumber == (int)FIX_231_ContractMultiplier && isNextCharAnEq()) {
            target.contractMultiplier(parseDouble());
        }
    }

    public void corellationClOrdID(CorellationClOrdID target) {
        if (fieldNumber == (int)FIX_9717_CorellationClOrdID && areNextTwoBytes((int)(FIX_9717_CorellationClOrdID >> 32))) {
            target.corellationClOrdID(parseString());
        }
    }

    public void corporateAction(CorporateAction target) {
        if (fieldNumber == (int)FIX_292_CorporateAction && isNextCharAnEq()) {
            target.corporateAction(parseChar());
        }
    }

    public void country(Country target) {
        if (fieldNumber == (int)FIX_421_Country && isNextCharAnEq()) {
            target.country(parseString());
        }
    }

    public void couponRate(CouponRate target) {
        if (fieldNumber == (int)FIX_223_CouponRate && isNextCharAnEq()) {
            target.couponRate(parseDouble());
        }
    }

    public void createdNS(CreatedNS target) {
        if (fieldNumber == (int)FIX_9999_CreatedNS && areNextTwoBytes((int)(FIX_9999_CreatedNS >> 32))) {
            target.createdNS(parseLong());
        }
    }

    public void crossID(CrossID target) {
        if (fieldNumber == (int)FIX_548_CrossID && isNextCharAnEq()) {
            target.crossID(parseString());
        }
    }

    public void crossInstruction(CrossInstruction target) {
        if (fieldNumber == (int)FIX_6438_CrossInstruction && areNextTwoBytes((int)(FIX_6438_CrossInstruction >> 32))) {
            target.crossInstruction(parseString());
        }
    }

    public void crossRestrictionClientID(CrossRestrictionClientID target) {
        if (fieldNumber == (int)FIX_10896_CrossRestrictionClientID && areNextThreeBytes((int)(FIX_10896_CrossRestrictionClientID >> 32))) {
            target.crossRestrictionClientID(parseString());
        }
    }

    public void crossStrategy(CrossStrategy target) {
        if (fieldNumber == (int)FIX_7411_CrossStrategy && areNextTwoBytes((int)(FIX_7411_CrossStrategy >> 32))) {
            target.crossStrategy(parseString());
        }
    }

    public void cumQty(CumQty target) {
        if (fieldNumber == FIX_14_CumQty) {
            target.cumQty(parseDouble());
        }
    }

    public void currency(Currency target) {
        if (fieldNumber == FIX_15_Currency) {
            target.currency(parseString());
        }
    }

    public void customPrice1(CustomPrice1 target) {
        if (fieldNumber == (int)FIX_7491_CustomPrice1 && areNextTwoBytes((int)(FIX_7491_CustomPrice1 >> 32))) {
            target.customPrice1(parseString());
        }
    }

    public void customerOrFirm(CustomerOrFirm target) {
        if (fieldNumber == (int)FIX_204_CustomerOrFirm && isNextCharAnEq()) {
            target.customerOrFirm(parseLong());
        }
    }

    public void customerSlang(CustomerSlang target) {
        if (fieldNumber == (int)FIX_8004_CustomerSlang && areNextTwoBytes((int)(FIX_8004_CustomerSlang >> 32))) {
            target.customerSlang(parseString());
        }
    }

    public void cxlQty(CxlQty target) {
        if (fieldNumber == FIX_84_CxlQty) {
            target.cxlQty(parseDouble());
        }
    }

    public void cxlReason(CxlReason target) {
        if (fieldNumber == (int)FIX_6042_CxlReason && areNextTwoBytes((int)(FIX_6042_CxlReason >> 32))) {
            target.cxlReason(parseString());
        }
    }

    public void cxlRejReason(CxlRejReason target) {
        if (fieldNumber == (int)FIX_102_CxlRejReason && isNextCharAnEq()) {
            target.cxlRejReason(parseLong());
        }
    }

    public void cxlRejResponseTo(CxlRejResponseTo target) {
        if (fieldNumber == (int)FIX_434_CxlRejResponseTo && isNextCharAnEq()) {
            target.cxlRejResponseTo(parseChar());
        }
    }

    public void dKReason(DKReason target) {
        if (fieldNumber == (int)FIX_127_DKReason && isNextCharAnEq()) {
            target.dKReason(parseChar());
        }
    }

    public void deliverToCompID(DeliverToCompID target) {
        if (fieldNumber == (int)FIX_128_DeliverToCompID && isNextCharAnEq()) {
            target.deliverToCompID(parseString());
        }
    }

    public void deliverToSubID(DeliverToSubID target) {
        if (fieldNumber == (int)FIX_129_DeliverToSubID && isNextCharAnEq()) {
            target.deliverToSubID(parseString());
        }
    }

    public void deltaPx(DeltaPx target) {
        if (fieldNumber == (int)FIX_9002_DeltaPx && areNextTwoBytes((int)(FIX_9002_DeltaPx >> 32))) {
            target.deltaPx(parseDouble());
        }
    }

    public void deltaQty(DeltaQty target) {
        if (fieldNumber == (int)FIX_9001_DeltaQty && areNextTwoBytes((int)(FIX_9001_DeltaQty >> 32))) {
            target.deltaQty(parseDouble());
        }
    }

    public void deskID(DeskID target) {
        if (fieldNumber == (int)FIX_284_DeskID && isNextCharAnEq()) {
            target.deskID(parseString());
        }
    }

    public void encodedIssuer(EncodedIssuer target) {
        if (fieldNumber == (int)FIX_349_EncodedIssuer && isNextCharAnEq()) {
            target.encodedIssuer(parseString());
        }
    }

    public void encodedIssuerLen(EncodedIssuerLen target) {
        if (fieldNumber == (int)FIX_348_EncodedIssuerLen && isNextCharAnEq()) {
            target.encodedIssuerLen(parseLong());
        }
    }

    public void encodedSecurityDesc() {
        if (fieldNumber == (int)FIX_351_EncodedSecurityDesc && isNextCharAnEq()) {
            bytes.readSkip(bytes.findByte((byte) 0x01));
            loadNextField();
        }
    }

    public void encodedSecurityDescLen(EncodedSecurityDescLen target) {
        if (fieldNumber == (int)FIX_350_EncodedSecurityDescLen && isNextCharAnEq()) {
            target.encodedSecurityDescLen(parseLong());
        }
    }

    public void encodedText(EncodedText target) {
        if (fieldNumber == (int)FIX_355_EncodedText && isNextCharAnEq()) {
            target.encodedText(parseString());
        }
    }

    public void encodedTextLen(EncodedTextLen target) {
        if (fieldNumber == (int)FIX_354_EncodedTextLen && isNextCharAnEq()) {
            target.encodedTextLen(parseLong());
        }
    }

    public void encryptMethod(EncryptMethod target) {
        if (fieldNumber == FIX_98_EncryptMethod) {
            target.encryptMethod(parseLong());
        }
    }

    public void endSeqNo(EndSeqNo target) {
        if (fieldNumber == FIX_16_EndSeqNo) {
            target.endSeqNo(parseLong());
        }
    }

    public void exDestination(ExDestination target) {
        if (fieldNumber == (int)FIX_100_ExDestination && isNextCharAnEq()) {
            target.exDestination(parseString());
        }
    }

    public void exDestinationIDSource(ExDestinationIDSource target) {
        if (fieldNumber == (int)FIX_1133_ExDestinationIDSource && areNextTwoBytes((int)(FIX_1133_ExDestinationIDSource >> 32))) {
            target.exDestinationIDSource(parseChar());
        }
    }

    public void execID(ExecID target) {
        if (fieldNumber == FIX_17_ExecID) {
            target.execID(parseString());
        }
    }

    public void execInst(ExecInst target) {
        if (fieldNumber == FIX_18_ExecInst) {
            target.execInst(parseString());
        }
    }

    public void execRefID(ExecRefID target) {
        if (fieldNumber == FIX_19_ExecRefID) {
            target.execRefID(parseString());
        }
    }

    public void execRestatementReason(ExecRestatementReason target) {
        if (fieldNumber == (int)FIX_378_ExecRestatementReason && isNextCharAnEq()) {
            target.execRestatementReason(parseLong());
        }
    }

    public void execTransType(ExecTransType target) {
        if (fieldNumber == FIX_20_ExecTransType) {
            target.execTransType(parseChar());
        }
    }

    public void execType(ExecType target) {
        if (fieldNumber == (int)FIX_150_ExecType && isNextCharAnEq()) {
            target.execType(parseChar());
        }
    }

    public void executedBy(ExecutedBy target) {
        if (fieldNumber == (int)FIX_10021_ExecutedBy && areNextThreeBytes((int)(FIX_10021_ExecutedBy >> 32))) {
            target.executedBy(parseString());
        }
    }

    public void expireDate(ExpireDate target) {
        if (fieldNumber == (int)FIX_432_ExpireDate && isNextCharAnEq()) {
            target.expireDate(parseString());
        }
    }

    public void expireTime(ExpireTime target) {
        if (fieldNumber == (int)FIX_126_ExpireTime && isNextCharAnEq()) {
            target.expireTime(parseTimeStamp());
        }
    }

    public void financialStatus(FinancialStatus target) {
        if (fieldNumber == (int)FIX_291_FinancialStatus && isNextCharAnEq()) {
            target.financialStatus(parseChar());
        }
    }

    public void firmId(FirmId target) {
        if (fieldNumber == (int)FIX_10054_FirmId && areNextThreeBytes((int)(FIX_10054_FirmId >> 32))) {
            target.firmId(parseString());
        }
    }

    public void gapFillFlag(GapFillFlag target) {
        if (fieldNumber == (int)FIX_123_GapFillFlag && isNextCharAnEq()) {
            target.gapFillFlag(parseChar());
        }
    }

    public void handlInst(HandlInst target) {
        if (fieldNumber == FIX_21_HandlInst) {
            target.handlInst(parseChar());
        }
    }

    public void heartBtInt(HeartBtInt target) {
        if (fieldNumber == (int)FIX_108_HeartBtInt && isNextCharAnEq()) {
            target.heartBtInt(parseLong());
        }
    }

    public void idSource(IDSource target) {
        if (fieldNumber == FIX_22_IDSource) {
            target.idSource(parseString());
        }
    }

    public void ioiID(IOIID target) {
        if (fieldNumber == FIX_23_IOIID) {
            target.ioiID(parseString());
        }
    }

    public void isCurrExecLevel(IsCurrExecLevel target) {
        if (fieldNumber == (int)FIX_11027_IsCurrExecLevel && areNextThreeBytes((int)(FIX_11027_IsCurrExecLevel >> 32))) {
            target.isCurrExecLevel(parseChar());
        }
    }

    public void isRioStateEvent(IsRioStateEvent target) {
        if (fieldNumber == (int)FIX_10104_IsRioStateEvent && areNextThreeBytes((int)(FIX_10104_IsRioStateEvent >> 32))) {
            target.isRioStateEvent(parseChar());
        }
    }

    public void issuer(Issuer target) {
        if (fieldNumber == (int)FIX_106_Issuer && isNextCharAnEq()) {
            target.issuer(parseString());
        }
    }

    public void lULDLowerPriceBand(LULDLowerPriceBand target) {
        if (fieldNumber == (int)FIX_10721_LULDLowerPriceBand && areNextThreeBytes((int)(FIX_10721_LULDLowerPriceBand >> 32))) {
            target.lULDLowerPriceBand(parseDouble());
        }
    }

    public void lULDPriceBandTimestamp(LULDPriceBandTimestamp target) {
        if (fieldNumber == (int)FIX_10723_LULDPriceBandTimestamp && areNextThreeBytes((int)(FIX_10723_LULDPriceBandTimestamp >> 32))) {
            target.lULDPriceBandTimestamp(parseTimeStamp());
        }
    }

    public void lULDUpperPriceBand(LULDUpperPriceBand target) {
        if (fieldNumber == (int)FIX_10722_LULDUpperPriceBand && areNextThreeBytes((int)(FIX_10722_LULDUpperPriceBand >> 32))) {
            target.lULDUpperPriceBand(parseDouble());
        }
    }

    public void lafExecID(LafExecID target) {
        if (fieldNumber == (int)FIX_10964_LafExecID && areNextThreeBytes((int)(FIX_10964_LafExecID >> 32))) {
            target.lafExecID(parseString());
        }
    }

    public void lastCapacity(LastCapacity target) {
        if (fieldNumber == FIX_29_LastCapacity) {
            target.lastCapacity(parseString());
        }
    }

    public void lastMkt(LastMkt target) {
        if (fieldNumber == FIX_30_LastMkt) {
            target.lastMkt(parseString());
        }
    }

    public void lastParPx(LastParPx target) {
        if (fieldNumber == (int)FIX_669_LastParPx && isNextCharAnEq()) {
            target.lastParPx(parseDouble());
        }
    }

    public void lastPx(LastPx target) {
        if (fieldNumber == FIX_31_LastPx) {
            target.lastPx(parseDouble());
        }
    }

    public void lastShares(LastShares target) {
        if (fieldNumber == FIX_32_LastShares) {
            target.lastShares(parseDouble());
        }
    }

    public void lastTraded(LastTraded target) {
        if (fieldNumber == (int)FIX_11001_LastTraded && areNextThreeBytes((int)(FIX_11001_LastTraded >> 32))) {
            target.lastTraded(parseDouble());
        }
    }

    public void lastTradedDelta(LastTradedDelta target) {
        if (fieldNumber == (int)FIX_11002_LastTradedDelta && areNextThreeBytes((int)(FIX_11002_LastTradedDelta >> 32))) {
            target.lastTradedDelta(parseDouble());
        }
    }

    public void leafExecFlag(LeafExecFlag target) {
        if (fieldNumber == (int)FIX_10217_LeafExecFlag && areNextThreeBytes((int)(FIX_10217_LeafExecFlag >> 32))) {
            target.leafExecFlag(parseChar());
        }
    }

    public void leafExecutionFlag(LeafExecutionFlag target) {
        if (fieldNumber == (int)FIX_10217_LeafExecutionFlag && areNextThreeBytes((int)(FIX_10217_LeafExecutionFlag >> 32))) {
            target.leafExecutionFlag(parseChar());
        }
    }

    public void leafSrcSystemID(LeafSrcSystemID target) {
        if (fieldNumber == (int)FIX_10965_LeafSrcSystemID && areNextThreeBytes((int)(FIX_10965_LeafSrcSystemID >> 32))) {
            target.leafSrcSystemID(parseLong());
        }
    }

    public void leavesQty(LeavesQty target) {
        if (fieldNumber == (int)FIX_151_LeavesQty && isNextCharAnEq()) {
            target.leavesQty(parseDouble());
        }
    }

    public void legalEntity(LegalEntity target) {
        if (fieldNumber == (int)FIX_10031_LegalEntity && areNextThreeBytes((int)(FIX_10031_LegalEntity >> 32))) {
            target.legalEntity(parseString());
        }
    }

    public void locateBroker(LocateBroker target) {
        if (fieldNumber == (int)FIX_5700_LocateBroker && areNextTwoBytes((int)(FIX_5700_LocateBroker >> 32))) {
            target.locateBroker(parseString());
        }
    }

    public void locateIdentifier(LocateIdentifier target) {
        if (fieldNumber == (int)FIX_5701_LocateIdentifier && areNextTwoBytes((int)(FIX_5701_LocateIdentifier >> 32))) {
            target.locateIdentifier(parseString());
        }
    }

    public void locateReqd(LocateReqd target) {
        if (fieldNumber == (int)FIX_114_LocateReqd && isNextCharAnEq()) {
            target.locateReqd(parseChar());
        }
    }

    public void locationID(LocationID target) {
        if (fieldNumber == (int)FIX_283_LocationID && isNextCharAnEq()) {
            target.locationID(parseString());
        }
    }

    public void mDEntryBuyer(MDEntryBuyer target) {
        if (fieldNumber == (int)FIX_288_MDEntryBuyer && isNextCharAnEq()) {
            target.mDEntryBuyer(parseString());
        }
    }

    public void mDEntryDate(MDEntryDate target) {
        if (fieldNumber == (int)FIX_272_MDEntryDate && isNextCharAnEq()) {
            target.mDEntryDate(parseString());
        }
    }

    public void mDEntryOriginator(MDEntryOriginator target) {
        if (fieldNumber == (int)FIX_282_MDEntryOriginator && isNextCharAnEq()) {
            target.mDEntryOriginator(parseString());
        }
    }

    public void mDEntryPositionNo(MDEntryPositionNo target) {
        if (fieldNumber == (int)FIX_290_MDEntryPositionNo && isNextCharAnEq()) {
            target.mDEntryPositionNo(parseLong());
        }
    }

    public void mDEntryPx(MDEntryPx target) {
        if (fieldNumber == (int)FIX_270_MDEntryPx && isNextCharAnEq()) {
            target.mDEntryPx(parseDouble());
        }
    }

    public void mDEntrySeller(MDEntrySeller target) {
        if (fieldNumber == (int)FIX_289_MDEntrySeller && isNextCharAnEq()) {
            target.mDEntrySeller(parseString());
        }
    }

    public void mDEntrySize(MDEntrySize target) {
        if (fieldNumber == (int)FIX_271_MDEntrySize && isNextCharAnEq()) {
            target.mDEntrySize(parseDouble());
        }
    }

    public void mDEntryTime(MDEntryTime target) {
        if (fieldNumber == (int)FIX_273_MDEntryTime && isNextCharAnEq()) {
            target.mDEntryTime(parseString());
        }
    }

    public void mDEntryType(MDEntryType target) {
        if (fieldNumber == (int)FIX_269_MDEntryType && isNextCharAnEq()) {
            target.mDEntryType(parseChar());
        }
    }

    public void mDMkt(MDMkt target) {
        if (fieldNumber == (int)FIX_275_MDMkt && isNextCharAnEq()) {
            target.mDMkt(parseString());
        }
    }

    public void mDReqID(MDReqID target) {
        if (fieldNumber == (int)FIX_262_MDReqID && isNextCharAnEq()) {
            target.mDReqID(parseString());
        }
    }

    public void noMDEntries(MarketDataSnapshotFullRefresh_MDEntriesGrp target, MarketDataSnapshotFullRefresh_MDEntriesGrpParser parser) {
        if (fieldNumber == (int)FIX_268_NoMDEntries && isNextCharAnEq()) {
            int num = parseInt();
            target.noMDEntries(num);
            parser.parse(this, target, num);
        }
    }

    public void tickDirection() {
        if (fieldNumber == (int)FIX_274_TickDirection && isNextCharAnEq()) {
            bytes.readSkip(bytes.findByte((byte) 0x01));
            loadNextField();
        }
    }

    public void tradingSessionID(TradingSessionID target) {
        if (fieldNumber == (int)FIX_336_TradingSessionID && isNextCharAnEq()) {
            target.tradingSessionID(parseString());
        }
    }

    public void quoteCondition(QuoteCondition target) {
        if (fieldNumber == (int)FIX_276_QuoteCondition && isNextCharAnEq()) {
            target.quoteCondition(parseString());
        }
    }

    public void tradeCondition(TradeCondition target) {
        if (fieldNumber == (int)FIX_277_TradeCondition && isNextCharAnEq()) {
            target.tradeCondition(parseString());
        }
    }

    public void openCloseSettleFlag(OpenCloseSettleFlag target) {
        if (fieldNumber == (int)FIX_286_OpenCloseSettleFlag && isNextCharAnEq()) {
            target.openCloseSettleFlag(parseChar());
        }
    }

    public void timeInForce(TimeInForce target) {
        if (fieldNumber == FIX_59_TimeInForce) {
            target.timeInForce(parseChar());
        }
    }

    public void minQty(MinQty target) {
        if (fieldNumber == (int)FIX_110_MinQty && isNextCharAnEq()) {
            target.minQty(parseDouble());
        }
    }

    public void sellerDays(SellerDays target) {
        if (fieldNumber == (int)FIX_287_SellerDays && isNextCharAnEq()) {
            target.sellerDays(parseLong());
        }
    }

    public void orderID(OrderID target) {
        if (fieldNumber == FIX_37_OrderID) {
            target.orderID(parseString());
        }
    }

    public void quoteEntryID(QuoteEntryID target) {
        if (fieldNumber == (int)FIX_299_QuoteEntryID && isNextCharAnEq()) {
            target.quoteEntryID(parseString());
        }
    }

    public void numberOfOrders(NumberOfOrders target) {
        if (fieldNumber == (int)FIX_346_NumberOfOrders && isNextCharAnEq()) {
            target.numberOfOrders(parseLong());
        }
    }

    public void text(Text target) {
        if (fieldNumber == FIX_58_Text) {
            target.text(parseString());
        }
    }

    public void maturityDay(MaturityDay target) {
        if (fieldNumber == (int)FIX_205_MaturityDay && isNextCharAnEq()) {
            target.maturityDay(parseLong());
        }
    }

    public void maturityMonthYear(MaturityMonthYear target) {
        if (fieldNumber == (int)FIX_200_MaturityMonthYear && isNextCharAnEq()) {
            target.maturityMonthYear(parseString());
        }
    }

    public void msgSeqNum(MsgSeqNum target) {
        if (fieldNumber == FIX_34_MsgSeqNum) {
            target.msgSeqNum(parseLong());
        }
    }

    public void newSeqNo(NewSeqNo target) {
        if (fieldNumber == FIX_36_NewSeqNo) {
            target.newSeqNo(parseLong());
        }
    }

    public void noClearingInstructions(NoClearingInstructions target) {
        if (fieldNumber == (int)FIX_576_NoClearingInstructions && isNextCharAnEq()) {
            target.noClearingInstructions(parseLong());
        }
    }

    public void noStrategyParameters(NoStrategyParameters target) {
        if (fieldNumber == (int)FIX_957_NoStrategyParameters && isNextCharAnEq()) {
            target.noStrategyParameters(parseString());
        }
    }

    public void noTempContraBrokers(NoTempContraBrokers target) {
        if (fieldNumber == (int)FIX_10533_NoTempContraBrokers && areNextThreeBytes((int)(FIX_10533_NoTempContraBrokers >> 32))) {
            target.noTempContraBrokers(parseLong());
        }
    }

    public void offerPx(OfferPx target) {
        if (fieldNumber == (int)FIX_133_OfferPx && isNextCharAnEq()) {
            target.offerPx(parseDouble());
        }
    }

    public void offerSize(OfferSize target) {
        if (fieldNumber == (int)FIX_135_OfferSize && isNextCharAnEq()) {
            target.offerSize(parseDouble());
        }
    }

    public void onBehalfOfCompID(OnBehalfOfCompID target) {
        if (fieldNumber == (int)FIX_115_OnBehalfOfCompID && isNextCharAnEq()) {
            target.onBehalfOfCompID(parseString());
        }
    }

    public void onBehalfOfSubID(OnBehalfOfSubID target) {
        if (fieldNumber == (int)FIX_116_OnBehalfOfSubID && isNextCharAnEq()) {
            target.onBehalfOfSubID(parseString());
        }
    }

    public void openQty(OpenQty target) {
        if (fieldNumber == (int)FIX_11007_OpenQty && areNextThreeBytes((int)(FIX_11007_OpenQty >> 32))) {
            target.openQty(parseDouble());
        }
    }

    public void optAttribute(OptAttribute target) {
        if (fieldNumber == (int)FIX_206_OptAttribute && isNextCharAnEq()) {
            target.optAttribute(parseChar());
        }
    }

    public void optOutLockedIn(OptOutLockedIn target) {
        if (fieldNumber == (int)FIX_10565_OptOutLockedIn && areNextThreeBytes((int)(FIX_10565_OptOutLockedIn >> 32))) {
            target.optOutLockedIn(parseString());
        }
    }

    public void ordLinkID(OrdLinkID target) {
        if (fieldNumber == (int)FIX_11053_OrdLinkID && areNextThreeBytes((int)(FIX_11053_OrdLinkID >> 32))) {
            target.ordLinkID(parseString());
        }
    }

    public void ordLinkType(OrdLinkType target) {
        if (fieldNumber == (int)FIX_11052_OrdLinkType && areNextThreeBytes((int)(FIX_11052_OrdLinkType >> 32))) {
            target.ordLinkType(parseString());
        }
    }

    public void ordRejReason(OrdRejReason target) {
        if (fieldNumber == (int)FIX_103_OrdRejReason && isNextCharAnEq()) {
            target.ordRejReason(parseLong());
        }
    }

    public void ordStatus(OrdStatus target) {
        if (fieldNumber == FIX_39_OrdStatus) {
            target.ordStatus(parseChar());
        }
    }

    public void ordType(OrdType target) {
        if (fieldNumber == FIX_40_OrdType) {
            target.ordType(parseChar());
        }
    }

    public void orderCapacity(OrderCapacity target) {
        if (fieldNumber == (int)FIX_528_OrderCapacity && isNextCharAnEq()) {
            target.orderCapacity(parseChar());
        }
    }

    public void orderFlowCategory(OrderFlowCategory target) {
        if (fieldNumber == (int)FIX_10202_OrderFlowCategory && areNextThreeBytes((int)(FIX_10202_OrderFlowCategory >> 32))) {
            target.orderFlowCategory(parseString());
        }
    }

    public void orderFlowClass(OrderFlowClass target) {
        if (fieldNumber == (int)FIX_10201_OrderFlowClass && areNextThreeBytes((int)(FIX_10201_OrderFlowClass >> 32))) {
            target.orderFlowClass(parseString());
        }
    }

    public void orderFlowEntry(OrderFlowEntry target) {
        if (fieldNumber == (int)FIX_10201_OrderFlowEntry && areNextThreeBytes((int)(FIX_10201_OrderFlowEntry >> 32))) {
            target.orderFlowEntry(parseString());
        }
    }

    public void orderPlacer(OrderPlacer target) {
        if (fieldNumber == (int)FIX_10895_OrderPlacer && areNextThreeBytes((int)(FIX_10895_OrderPlacer >> 32))) {
            target.orderPlacer(parseString());
        }
    }

    public void orderQty(OrderQty target) {
        if (fieldNumber == FIX_38_OrderQty) {
            target.orderQty(parseDouble());
        }
    }

    public void orderRestrictions(OrderRestrictions target) {
        if (fieldNumber == (int)FIX_529_OrderRestrictions && isNextCharAnEq()) {
            target.orderRestrictions(parseString());
        }
    }

    public void orderUniqID(OrderUniqID target) {
        if (fieldNumber == (int)FIX_10439_OrderUniqID && areNextThreeBytes((int)(FIX_10439_OrderUniqID >> 32))) {
            target.orderUniqID(parseString());
        }
    }

    public void orderVersion(OrderVersion target) {
        if (fieldNumber == (int)FIX_12052_OrderVersion && areNextThreeBytes((int)(FIX_12052_OrderVersion >> 32))) {
            target.orderVersion(parseLong());
        }
    }

    public void origClOrdID(OrigClOrdID target) {
        if (fieldNumber == FIX_41_OrigClOrdID) {
            target.origClOrdID(parseString());
        }
    }

    public void origCrossID(OrigCrossID target) {
        if (fieldNumber == (int)FIX_551_OrigCrossID && isNextCharAnEq()) {
            target.origCrossID(parseString());
        }
    }

    public void origSendingTime(OrigSendingTime target) {
        if (fieldNumber == (int)FIX_122_OrigSendingTime && isNextCharAnEq()) {
            target.origSendingTime(parseTimeStamp());
        }
    }

    public void parentOrderUniqID(ParentOrderUniqID target) {
        if (fieldNumber == (int)FIX_10517_ParentOrderUniqID && areNextThreeBytes((int)(FIX_10517_ParentOrderUniqID >> 32))) {
            target.parentOrderUniqID(parseString());
        }
    }

    public void password(Password target) {
        if (fieldNumber == (int)FIX_554_Password && isNextCharAnEq()) {
            target.password(parseString());
        }
    }

    public void possDupFlag(PossDupFlag target) {
        if (fieldNumber == FIX_43_PossDupFlag) {
            target.possDupFlag(parseChar());
        }
    }

    public void possResend(PossResend target) {
        if (fieldNumber == FIX_97_PossResend) {
            target.possResend(parseChar());
        }
    }

    public void previousLinkOrderID(PreviousLinkOrderID target) {
        if (fieldNumber == (int)FIX_10184_PreviousLinkOrderID && areNextThreeBytes((int)(FIX_10184_PreviousLinkOrderID >> 32))) {
            target.previousLinkOrderID(parseString());
        }
    }

    public void previousLinkOrderUniqID(PreviousLinkOrderUniqID target) {
        if (fieldNumber == (int)FIX_10519_PreviousLinkOrderUniqID && areNextThreeBytes((int)(FIX_10519_PreviousLinkOrderUniqID >> 32))) {
            target.previousLinkOrderUniqID(parseString());
        }
    }

    public void previousLinkSrcSystemID(PreviousLinkSrcSystemID target) {
        if (fieldNumber == (int)FIX_10518_PreviousLinkSrcSystemID && areNextThreeBytes((int)(FIX_10518_PreviousLinkSrcSystemID >> 32))) {
            target.previousLinkSrcSystemID(parseLong());
        }
    }

    public void price(Price target) {
        if (fieldNumber == FIX_44_Price) {
            target.price(parseDouble());
        }
    }

    public void priceType(PriceType target) {
        if (fieldNumber == (int)FIX_423_PriceType && isNextCharAnEq()) {
            target.priceType(parseLong());
        }
    }

    public void putOrCall(PutOrCall target) {
        if (fieldNumber == (int)FIX_201_PutOrCall && isNextCharAnEq()) {
            target.putOrCall(parseLong());
        }
    }

    public void quoteID(QuoteID target) {
        if (fieldNumber == (int)FIX_117_QuoteID && isNextCharAnEq()) {
            target.quoteID(parseString());
        }
    }

    public void quoteTime(QuoteTime target) {
        if (fieldNumber == (int)FIX_11048_QuoteTime && areNextThreeBytes((int)(FIX_11048_QuoteTime >> 32))) {
            target.quoteTime(parseTimeStamp());
        }
    }

    public void rawData(RawData target) {
        if (fieldNumber == FIX_96_RawData) {
            target.rawData(parseString());
        }
    }

    public void rawDataLength(RawDataLength target) {
        if (fieldNumber == FIX_95_RawDataLength) {
            target.rawDataLength(parseLong());
        }
    }

    public void receiveTime(ReceiveTime target) {
        if (fieldNumber == (int)FIX_10080_ReceiveTime && areNextThreeBytes((int)(FIX_10080_ReceiveTime >> 32))) {
            target.receiveTime(parseTimeStamp());
        }
    }

    public void refMsgType(RefMsgType target) {
        if (fieldNumber == (int)FIX_372_RefMsgType && isNextCharAnEq()) {
            target.refMsgType(parseChar());
        }
    }

    public void refSeqNum(RefSeqNum target) {
        if (fieldNumber == FIX_45_RefSeqNum) {
            target.refSeqNum(parseLong());
        }
    }

    public void refTagID(RefTagID target) {
        if (fieldNumber == (int)FIX_371_RefTagID && isNextCharAnEq()) {
            target.refTagID(parseLong());
        }
    }

    public void replayInd(ReplayInd target) {
        if (fieldNumber == (int)FIX_10657_ReplayInd && areNextThreeBytes((int)(FIX_10657_ReplayInd >> 32))) {
            target.replayInd(parseChar());
        }
    }

    public void reportToExch(ReportToExch target) {
        if (fieldNumber == (int)FIX_113_ReportToExch && isNextCharAnEq()) {
            target.reportToExch(parseString());
        }
    }

    public void resetSeqNumFlag(ResetSeqNumFlag target) {
        if (fieldNumber == (int)FIX_141_ResetSeqNumFlag && isNextCharAnEq()) {
            target.resetSeqNumFlag(parseChar());
        }
    }

    public void rioBeginString(RioBeginString target) {
        if (fieldNumber == (int)FIX_10438_RioBeginString && areNextThreeBytes((int)(FIX_10438_RioBeginString >> 32))) {
            target.rioBeginString(parseString());
        }
    }

    public void rioMinorVersion(RioMinorVersion target) {
        if (fieldNumber == (int)FIX_10653_RioMinorVersion && areNextThreeBytes((int)(FIX_10653_RioMinorVersion >> 32))) {
            target.rioMinorVersion(parseString());
        }
    }

    public void rioMsgSeq(RioMsgSeq target) {
        if (fieldNumber == (int)FIX_10655_RioMsgSeq && areNextThreeBytes((int)(FIX_10655_RioMsgSeq >> 32))) {
            target.rioMsgSeq(parseLong());
        }
    }

    public void rioMsgSeqSrc(RioMsgSeqSrc target) {
        if (fieldNumber == (int)FIX_10658_RioMsgSeqSrc && areNextThreeBytes((int)(FIX_10658_RioMsgSeqSrc >> 32))) {
            target.rioMsgSeqSrc(parseString());
        }
    }

    public void rioMsgSource(RioMsgSource target) {
        if (fieldNumber == (int)FIX_10208_RioMsgSource && areNextThreeBytes((int)(FIX_10208_RioMsgSource >> 32))) {
            target.rioMsgSource(parseString());
        }
    }

    public void rioTimestamp(RioTimestamp target) {
        if (fieldNumber == (int)FIX_10071_RioTimestamp && areNextThreeBytes((int)(FIX_10071_RioTimestamp >> 32))) {
            target.rioTimestamp(parseTimeStamp());
        }
    }

    public void rioTransactTime(RioTransactTime target) {
        if (fieldNumber == (int)FIX_10436_RioTransactTime && areNextThreeBytes((int)(FIX_10436_RioTransactTime >> 32))) {
            target.rioTransactTime(parseTimeStamp());
        }
    }

    public void rootOrderID(RootOrderID target) {
        if (fieldNumber == (int)FIX_11210_RootOrderID && areNextThreeBytes((int)(FIX_11210_RootOrderID >> 32))) {
            target.rootOrderID(parseString());
        }
    }

    public void rootOrderUniqID(RootOrderUniqID target) {
        if (fieldNumber == (int)FIX_10516_RootOrderUniqID && areNextThreeBytes((int)(FIX_10516_RootOrderUniqID >> 32))) {
            target.rootOrderUniqID(parseString());
        }
    }

    public void rootSrcSystemID(RootSrcSystemID target) {
        if (fieldNumber == (int)FIX_10515_RootSrcSystemID && areNextThreeBytes((int)(FIX_10515_RootSrcSystemID >> 32))) {
            target.rootSrcSystemID(parseLong());
        }
    }

    public void rule80A(Rule80A target) {
        if (fieldNumber == FIX_47_Rule80A) {
            target.rule80A(parseChar());
        }
    }

    public void salesPersonID(SalesPersonID target) {
        if (fieldNumber == (int)FIX_10036_SalesPersonID && areNextThreeBytes((int)(FIX_10036_SalesPersonID >> 32))) {
            target.salesPersonID(parseString());
        }
    }

    public void securityAltID(SecurityAltID target) {
        if (fieldNumber == (int)FIX_455_SecurityAltID && isNextCharAnEq()) {
            target.securityAltID(parseString());
        }
    }

    public void securityAltIDSource(SecurityAltIDSource target) {
        if (fieldNumber == (int)FIX_456_SecurityAltIDSource && isNextCharAnEq()) {
            target.securityAltIDSource(parseString());
        }
    }

    public void securityDesc(SecurityDesc target) {
        if (fieldNumber == (int)FIX_107_SecurityDesc && isNextCharAnEq()) {
            target.securityDesc(parseString());
        }
    }

    public void securityExchange(SecurityExchange target) {
        if (fieldNumber == (int)FIX_207_SecurityExchange && isNextCharAnEq()) {
            target.securityExchange(parseString());
        }
    }

    public void securityID(SecurityID target) {
        if (fieldNumber == FIX_48_SecurityID) {
            target.securityID(parseString());
        }
    }

    public void securityType(SecurityType target) {
        if (fieldNumber == (int)FIX_167_SecurityType && isNextCharAnEq()) {
            target.securityType(parseString());
        }
    }

    public void senderCompID(SenderCompID target) {
        if (fieldNumber == FIX_49_SenderCompID) {
            target.senderCompID(parseString());
        }
    }

    public void senderSubID(SenderSubID target) {
        if (fieldNumber == FIX_50_SenderSubID) {
            target.senderSubID(parseString());
        }
    }

    public void sendingTime(SendingTime target) {
        if (fieldNumber == FIX_52_SendingTime) {
            target.sendingTime(parseTimeStamp());
        }
    }

    public void sessionRejectReason(SessionRejectReason target) {
        if (fieldNumber == (int)FIX_373_SessionRejectReason && isNextCharAnEq()) {
            target.sessionRejectReason(parseLong());
        }
    }

    public void settlCurrAmt(SettlCurrAmt target) {
        if (fieldNumber == (int)FIX_119_SettlCurrAmt && isNextCharAnEq()) {
            target.settlCurrAmt(parseDouble());
        }
    }

    public void settlCurrFxRate(SettlCurrFxRate target) {
        if (fieldNumber == (int)FIX_155_SettlCurrFxRate && isNextCharAnEq()) {
            target.settlCurrFxRate(parseDouble());
        }
    }

    public void settlCurrFxRateCalc(SettlCurrFxRateCalc target) {
        if (fieldNumber == (int)FIX_156_SettlCurrFxRateCalc && isNextCharAnEq()) {
            target.settlCurrFxRateCalc(parseChar());
        }
    }

    public void settlCurrency(SettlCurrency target) {
        if (fieldNumber == (int)FIX_120_SettlCurrency && isNextCharAnEq()) {
            target.settlCurrency(parseString());
        }
    }

    public void settlmntTyp(SettlmntTyp target) {
        if (fieldNumber == FIX_63_SettlmntTyp) {
            target.settlmntTyp(parseChar());
        }
    }

    public void shortSaleExemptReason(ShortSaleExemptReason target) {
        if (fieldNumber == (int)FIX_1688_ShortSaleExemptReason && areNextTwoBytes((int)(FIX_1688_ShortSaleExemptReason >> 32))) {
            target.shortSaleExemptReason(parseString());
        }
    }

    public void side(Side target) {
        if (fieldNumber == FIX_54_Side) {
            target.side(parseChar());
        }
    }

    public void sourceFeed(SourceFeed target) {
        if (fieldNumber == (int)FIX_11328_SourceFeed && areNextThreeBytes((int)(FIX_11328_SourceFeed >> 32))) {
            target.sourceFeed(parseString());
        }
    }

    public void srcSystemID(SrcSystemID target) {
        if (fieldNumber == (int)FIX_10005_SrcSystemID && areNextThreeBytes((int)(FIX_10005_SrcSystemID >> 32))) {
            target.srcSystemID(parseLong());
        }
    }

    public void srcTargetCompId(SrcTargetCompId target) {
        if (fieldNumber == (int)FIX_10084_SrcTargetCompId && areNextThreeBytes((int)(FIX_10084_SrcTargetCompId >> 32))) {
            target.srcTargetCompId(parseString());
        }
    }

    public void stopPx(StopPx target) {
        if (fieldNumber == FIX_99_StopPx) {
            target.stopPx(parseDouble());
        }
    }

    public void strategyParameterValue(StrategyParameterValue target) {
        if (fieldNumber == (int)FIX_960_StrategyParameterValue && isNextCharAnEq()) {
            target.strategyParameterValue(parseString());
        }
    }

    public void strikePrice(StrikePrice target) {
        if (fieldNumber == (int)FIX_202_StrikePrice && isNextCharAnEq()) {
            target.strikePrice(parseDouble());
        }
    }

    public void sumOfStopExecQty(SumOfStopExecQty target) {
        if (fieldNumber == (int)FIX_10065_SumOfStopExecQty && areNextThreeBytes((int)(FIX_10065_SumOfStopExecQty >> 32))) {
            target.sumOfStopExecQty(parseDouble());
        }
    }

    public void symbol(Symbol target) {
        if (fieldNumber == FIX_55_Symbol) {
            target.symbol(parseString());
        }
    }

    public void symbolSfx(SymbolSfx target) {
        if (fieldNumber == FIX_65_SymbolSfx) {
            target.symbolSfx(parseString());
        }
    }

    public void targetCompID(TargetCompID target) {
        if (fieldNumber == FIX_56_TargetCompID) {
            target.targetCompID(parseString());
        }
    }

    public void targetStrategy(TargetStrategy target) {
        if (fieldNumber == (int)FIX_847_TargetStrategy && isNextCharAnEq()) {
            target.targetStrategy(parseLong());
        }
    }

    public void targetStrategyParameters(TargetStrategyParameters target) {
        if (fieldNumber == (int)FIX_848_TargetStrategyParameters && isNextCharAnEq()) {
            target.targetStrategyParameters(parseString());
        }
    }

    public void targetSubID(TargetSubID target) {
        if (fieldNumber == FIX_57_TargetSubID) {
            target.targetSubID(parseString());
        }
    }

    public void tempContraBroker(TempContraBroker target) {
        if (fieldNumber == (int)FIX_10534_TempContraBroker && areNextThreeBytes((int)(FIX_10534_TempContraBroker >> 32))) {
            target.tempContraBroker(parseString());
        }
    }

    public void tempContraBrokerSrc(TempContraBrokerSrc target) {
        if (fieldNumber == (int)FIX_10535_TempContraBrokerSrc && areNextThreeBytes((int)(FIX_10535_TempContraBrokerSrc >> 32))) {
            target.tempContraBrokerSrc(parseString());
        }
    }

    public void tempLastMkt(TempLastMkt target) {
        if (fieldNumber == (int)FIX_10537_TempLastMkt && areNextThreeBytes((int)(FIX_10537_TempLastMkt >> 32))) {
            target.tempLastMkt(parseString());
        }
    }

    public void testReqID(TestReqID target) {
        if (fieldNumber == (int)FIX_112_TestReqID && isNextCharAnEq()) {
            target.testReqID(parseString());
        }
    }

    public void tickSizePilotGroup(TickSizePilotGroup target) {
        if (fieldNumber == (int)FIX_11319_TickSizePilotGroup && areNextThreeBytes((int)(FIX_11319_TickSizePilotGroup >> 32))) {
            target.tickSizePilotGroup(parseString());
        }
    }

    public void tier(Tier target) {
        if (fieldNumber == (int)FIX_10270_Tier && areNextThreeBytes((int)(FIX_10270_Tier >> 32))) {
            target.tier(parseLong());
        }
    }

    public void timeToLive(TimeToLive target) {
        if (fieldNumber == (int)FIX_10014_TimeToLive && areNextThreeBytes((int)(FIX_10014_TimeToLive >> 32))) {
            target.timeToLive(parseTimeStamp());
        }
    }

    public void totalVolumeTraded(TotalVolumeTraded target) {
        if (fieldNumber == (int)FIX_387_TotalVolumeTraded && isNextCharAnEq()) {
            target.totalVolumeTraded(parseDouble());
        }
    }

    public void tradeDate(TradeDate target) {
        if (fieldNumber == FIX_75_TradeDate) {
            target.tradeDate(parseString());
        }
    }

    public void traderID(TraderID target) {
        if (fieldNumber == (int)FIX_10039_TraderID && areNextThreeBytes((int)(FIX_10039_TraderID >> 32))) {
            target.traderID(parseString());
        }
    }

    public void tradingAcct(TradingAcct target) {
        if (fieldNumber == (int)FIX_10050_TradingAcct && areNextThreeBytes((int)(FIX_10050_TradingAcct >> 32))) {
            target.tradingAcct(parseString());
        }
    }

    public void transactTime(TransactTime target) {
        if (fieldNumber == FIX_60_TransactTime) {
            target.transactTime(parseTimeStamp());
        }
    }

    public void trdType(TrdType target) {
        if (fieldNumber == (int)FIX_828_TrdType && isNextCharAnEq()) {
            target.trdType(parseLong());
        }
    }

    public void username(Username target) {
        if (fieldNumber == (int)FIX_553_Username && isNextCharAnEq()) {
            target.username(parseString());
        }
    }

    public void xLastActivityUserID(XLastActivityUserID target) {
        if (fieldNumber == (int)FIX_10241_XLastActivityUserID && areNextThreeBytes((int)(FIX_10241_XLastActivityUserID >> 32))) {
            target.xLastActivityUserID(parseString());
        }
    }

    public void xParentOrderID(XParentOrderID target) {
        if (fieldNumber == (int)FIX_10243_XParentOrderID && areNextThreeBytes((int)(FIX_10243_XParentOrderID >> 32))) {
            target.xParentOrderID(parseString());
        }
    }

    public void zExecID(ZExecID target) {
        if (fieldNumber == (int)FIX_10018_ZExecID && areNextThreeBytes((int)(FIX_10018_ZExecID >> 32))) {
            target.zExecID(parseString());
        }
    }
}
