package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ExecInst {
    /**
     * Tag number for this field
     */
    int FIELD = 18;

    String NOT_HELD = "1";

    String WORK = "2";

    String GO_ALONG = "3";

    String OVER_THE_DAY = "4";

    String HELD = "5";

    String PARTICIPATE_DONT_INITIATE = "6";

    String STRICT_SCALE = "7";

    String TRY_TO_SCALE = "8";

    String STAY_ON_BIDSIDE = "9";

    String STAY_ON_OFFERSIDE = "0";

    String NO_CROSS = "A";

    String OK_TO_CROSS = "B";

    String CALL_FIRST = "C";

    String PERCENT_OF_VOLUME = "D";

    String DO_NOT_INCREASE_DNI = "E";

    String DO_NOT_REDUCE_DNR = "F";

    String ALL_OR_NONE_AON = "G";

    String INSTITUTIONS_ONLY = "I";

    String LAST_PEG = "L";

    String MIDPRICE_PEG = "M";

    String NONNEGOTIABLE = "N";

    String OPENING_PEG = "O";

    String MARKET_PEG = "P";

    String PRIMARY_PEG = "R";

    String SUSPEND = "S";

    String FIXED_PEG = "T";

    String CUSTOMER_DISPLAY_INSTRUCTION = "U";

    String NETTING = "V";

    String PEG_TO_VWAP = "W";

    /**
     * @param execInst &gt; FIX TAG 18
     */
    void execInst(String execInst);

    default String execInst() {
        throw new UnsupportedOperationException();
    }

    static String asString(String value) {
        return value;
    }
}
