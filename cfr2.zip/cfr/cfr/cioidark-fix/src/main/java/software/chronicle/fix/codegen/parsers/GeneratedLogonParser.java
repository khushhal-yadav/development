package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.Logon;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedLogonParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, Logon logon) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(logon);
            fix.encryptMethod(logon); // 98
            fix.heartBtInt(logon); // 108
            fix.rawDataLength(logon); // 95
            fix.rawData(logon); // 96
            fix.resetSeqNumFlag(logon); // 141
            fix.username(logon); // 553
            fix.password(logon); // 554
            if (fix.checkFinished(logon, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, logon, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(logon.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(logon.msgSeqNum(), pos);
    }
}
