package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TickSizePilotGroup {
    /**
     * Tag number for this field
     */
    int FIELD = 11319;

    /**
     * @param tickSizePilotGroup &gt; FIX TAG 11319
     */
    void tickSizePilotGroup(String tickSizePilotGroup);

    default String tickSizePilotGroup() {
        throw new UnsupportedOperationException();
    }
}
