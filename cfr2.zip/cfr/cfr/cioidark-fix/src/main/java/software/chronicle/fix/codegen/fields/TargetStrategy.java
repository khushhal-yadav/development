package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TargetStrategy {
    /**
     * Tag number for this field
     */
    int FIELD = 847;

    /**
     * @param targetStrategy &gt; FIX TAG 847
     */
    void targetStrategy(long targetStrategy);

    default long targetStrategy() {
        throw new UnsupportedOperationException();
    }
}
