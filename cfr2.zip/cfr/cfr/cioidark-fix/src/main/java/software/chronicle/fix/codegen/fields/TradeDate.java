package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TradeDate {
    /**
     * Tag number for this field
     */
    int FIELD = 75;

    /**
     * @param tradeDate &gt; FIX TAG 75
     */
    void tradeDate(String tradeDate);

    default String tradeDate() {
        throw new UnsupportedOperationException();
    }
}
