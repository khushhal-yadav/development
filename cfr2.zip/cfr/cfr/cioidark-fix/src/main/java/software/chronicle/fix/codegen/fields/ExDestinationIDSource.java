package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ExDestinationIDSource {
    /**
     * Tag number for this field
     */
    int FIELD = 1133;

    /**
     * @param exDestinationIDSource &gt; FIX TAG 1133
     */
    void exDestinationIDSource(char exDestinationIDSource);

    default char exDestinationIDSource() {
        throw new UnsupportedOperationException();
    }
}
