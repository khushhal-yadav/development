package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.OrderCancelReject;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedOrderCancelRejectParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, OrderCancelReject orderCancelReject) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(orderCancelReject);
            fix.orderID(orderCancelReject); // 37
            fix.clOrdID(orderCancelReject); // 11
            fix.origClOrdID(orderCancelReject); // 41
            fix.ordStatus(orderCancelReject); // 39
            fix.text(orderCancelReject); // 58
            fix.transactTime(orderCancelReject); // 60
            fix.cxlRejResponseTo(orderCancelReject); // 434
            fix.cxlRejReason(orderCancelReject); // 102
            fix.createdNS(orderCancelReject); // 9999
            fix.price(orderCancelReject); // 44
            fix.lastTraded(orderCancelReject); // 11001
            fix.lastTradedDelta(orderCancelReject); // 11002
            fix.openQty(orderCancelReject); // 11007
            fix.deltaQty(orderCancelReject); // 9001
            fix.deltaPx(orderCancelReject); // 9002
            fix.account(orderCancelReject); // 1
            fix.symbol(orderCancelReject); // 55
            fix.symbolSfx(orderCancelReject); // 65
            fix.currency(orderCancelReject); // 15
            fix.side(orderCancelReject); // 54
            fix.ordLinkID(orderCancelReject); // 11053
            fix.ordLinkType(orderCancelReject); // 11052
            fix.bookingType(orderCancelReject); // 775
            fix.srcTargetCompId(orderCancelReject); // 10084
            fix.reportToExch(orderCancelReject); // 113
            fix.ioiID(orderCancelReject); // 23
            fix.crossID(orderCancelReject); // 548
            fix.origCrossID(orderCancelReject); // 551
            fix.priceType(orderCancelReject); // 423
            fix.bidPx(orderCancelReject); // 132
            fix.offerPx(orderCancelReject); // 133
            fix.execType(orderCancelReject); // 150
            fix.orderQty(orderCancelReject); // 38
            fix.orderVersion(orderCancelReject); // 12052
            fix.sourceFeed(orderCancelReject); // 11328
            fix.corellationClOrdID(orderCancelReject); // 9717
            fix.lastCapacity(orderCancelReject); // 29
            fix.srcSystemID(orderCancelReject); // 10005
            fix.orderFlowCategory(orderCancelReject); // 10202
            fix.executedBy(orderCancelReject); // 10021
            if (fix.checkFinished(orderCancelReject, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, orderCancelReject, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(orderCancelReject.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(orderCancelReject.msgSeqNum(), pos);
    }
}
