package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface NoTempContraBrokers {
    /**
     * Tag number for this field
     */
    int FIELD = 10533;

    /**
     * @param noTempContraBrokers &gt; FIX TAG 10533
     */
    void noTempContraBrokers(long noTempContraBrokers);

    default long noTempContraBrokers() {
        throw new UnsupportedOperationException();
    }
}
