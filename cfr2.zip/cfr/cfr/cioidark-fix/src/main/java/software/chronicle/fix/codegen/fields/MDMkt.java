package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MDMkt {
    /**
     * Tag number for this field
     */
    int FIELD = 275;

    /**
     * @param mDMkt &gt; FIX TAG 275
     */
    void mDMkt(String mDMkt);

    default String mDMkt() {
        throw new UnsupportedOperationException();
    }
}
