package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OpenQty {
    /**
     * Tag number for this field
     */
    int FIELD = 11007;

    /**
     * @param openQty &gt; FIX TAG 11007
     */
    void openQty(double openQty);

    default double openQty() {
        throw new UnsupportedOperationException();
    }
}
