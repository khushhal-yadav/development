package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface Country {
    /**
     * Tag number for this field
     */
    int FIELD = 421;

    /**
     * @param country &gt; FIX TAG 421
     */
    void country(String country);

    default String country() {
        throw new UnsupportedOperationException();
    }
}
