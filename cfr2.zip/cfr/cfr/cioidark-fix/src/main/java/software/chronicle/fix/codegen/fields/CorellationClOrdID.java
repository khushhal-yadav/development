package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CorellationClOrdID {
    /**
     * Tag number for this field
     */
    int FIELD = 9717;

    /**
     * @param corellationClOrdID &gt; FIX TAG 9717
     */
    void corellationClOrdID(String corellationClOrdID);

    default String corellationClOrdID() {
        throw new UnsupportedOperationException();
    }
}
