package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CxlRejReason {
    /**
     * Tag number for this field
     */
    int FIELD = 102;

    int TOO_LATE_TO_CANCEL = 0;

    int UNKNOWN_ORDER = 1;

    int BROKER_OPTION = 2;

    int ALREADY_PENDING = 3;

    /**
     * @param cxlRejReason &gt; FIX TAG 102
     */
    void cxlRejReason(long cxlRejReason);

    default long cxlRejReason() {
        throw new UnsupportedOperationException();
    }

    static String asString(int value) {
        switch (value) {
            case TOO_LATE_TO_CANCEL:
                    return "TOO_LATE_TO_CANCEL";
            case UNKNOWN_ORDER:
                    return "UNKNOWN_ORDER";
            case BROKER_OPTION:
                    return "BROKER_OPTION";
            case ALREADY_PENDING:
                    return "ALREADY_PENDING";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
