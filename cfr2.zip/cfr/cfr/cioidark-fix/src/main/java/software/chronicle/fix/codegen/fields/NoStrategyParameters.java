package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface NoStrategyParameters {
    /**
     * Tag number for this field
     */
    int FIELD = 957;

    /**
     * @param noStrategyParameters &gt; FIX TAG 957
     */
    void noStrategyParameters(String noStrategyParameters);

    default String noStrategyParameters() {
        throw new UnsupportedOperationException();
    }
}
