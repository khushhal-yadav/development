package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.components.MarketDataSnapshotFullRefresh_MDEntriesGrp;
import software.chronicle.fix.codegen.components.MarketDataSnapshotFullRefresh_MDEntriesGrp_1;
import software.chronicle.fix.codegen.messages.MarketDataSnapshotFullRefresh;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedMarketDataSnapshotFullRefreshParser extends OneMessageParser implements MarketDataSnapshotFullRefresh_MDEntriesGrpParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, MarketDataSnapshotFullRefresh marketDataSnapshotFullRefresh) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(marketDataSnapshotFullRefresh);
            fix.mDReqID(marketDataSnapshotFullRefresh); // 262
            fix.symbol(marketDataSnapshotFullRefresh); // 55
            fix.symbolSfx(marketDataSnapshotFullRefresh); // 65
            fix.securityID(marketDataSnapshotFullRefresh); // 48
            fix.idSource(marketDataSnapshotFullRefresh); // 22
            fix.securityType(marketDataSnapshotFullRefresh); // 167
            fix.maturityMonthYear(marketDataSnapshotFullRefresh); // 200
            fix.maturityDay(marketDataSnapshotFullRefresh); // 205
            fix.putOrCall(marketDataSnapshotFullRefresh); // 201
            fix.strikePrice(marketDataSnapshotFullRefresh); // 202
            fix.optAttribute(marketDataSnapshotFullRefresh); // 206
            fix.contractMultiplier(marketDataSnapshotFullRefresh); // 231
            fix.couponRate(marketDataSnapshotFullRefresh); // 223
            fix.securityExchange(marketDataSnapshotFullRefresh); // 207
            fix.issuer(marketDataSnapshotFullRefresh); // 106
            fix.encodedIssuerLen(marketDataSnapshotFullRefresh); // 348
            fix.encodedIssuer(marketDataSnapshotFullRefresh); // 349
            fix.securityDesc(marketDataSnapshotFullRefresh); // 107
            fix.encodedSecurityDescLen(marketDataSnapshotFullRefresh); // 350
            fix.encodedSecurityDesc(); // 351
            fix.financialStatus(marketDataSnapshotFullRefresh); // 291
            fix.corporateAction(marketDataSnapshotFullRefresh); // 292
            fix.totalVolumeTraded(marketDataSnapshotFullRefresh); // 387
            fix.noMDEntries(marketDataSnapshotFullRefresh, this); // 268
            if (fix.checkFinished(marketDataSnapshotFullRefresh, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, marketDataSnapshotFullRefresh, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(marketDataSnapshotFullRefresh.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(marketDataSnapshotFullRefresh.msgSeqNum(), pos);
    }

    public void parse(GeneratedCoreFieldParser fix, MarketDataSnapshotFullRefresh_MDEntriesGrp message, int groupNum) {
        for (int i = 0; i < groupNum; i++) {
            MarketDataSnapshotFullRefresh_MDEntriesGrp_1 marketDataSnapshotFullRefresh_MDEntriesGrp_1 = message.marketDataSnapshotFullRefresh_MDEntriesGrp_1(i);
            fix.mDEntryType(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 269
            for (int j = 0; j < 30; j++) {
                long start = fix.bytes().readPosition();
                fix.mDEntryPx(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 270
                fix.currency(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 15
                fix.mDEntrySize(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 271
                fix.mDEntryDate(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 272
                fix.mDEntryTime(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 273
                fix.tickDirection(); // 274
                fix.mDMkt(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 275
                fix.tradingSessionID(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 336
                fix.quoteCondition(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 276
                fix.tradeCondition(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 277
                fix.mDEntryOriginator(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 282
                fix.locationID(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 283
                fix.deskID(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 284
                fix.openCloseSettleFlag(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 286
                fix.timeInForce(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 59
                fix.expireDate(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 432
                fix.expireTime(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 126
                fix.minQty(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 110
                fix.execInst(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 18
                fix.sellerDays(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 287
                fix.orderID(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 37
                fix.quoteEntryID(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 299
                fix.mDEntryBuyer(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 288
                fix.mDEntrySeller(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 289
                fix.numberOfOrders(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 346
                fix.mDEntryPositionNo(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 290
                fix.text(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 58
                fix.encodedTextLen(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 354
                fix.encodedText(marketDataSnapshotFullRefresh_MDEntriesGrp_1); // 355
                if (start == fix.bytes().readPosition()) break;
            }
        }
    }
}
