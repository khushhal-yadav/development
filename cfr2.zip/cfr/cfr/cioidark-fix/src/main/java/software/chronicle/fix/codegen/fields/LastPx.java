package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LastPx {
    /**
     * Tag number for this field
     */
    int FIELD = 31;

    /**
     * @param lastPx &gt; FIX TAG 31
     */
    void lastPx(double lastPx);

    default double lastPx() {
        throw new UnsupportedOperationException();
    }
}
