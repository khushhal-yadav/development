package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CrossID {
    /**
     * Tag number for this field
     */
    int FIELD = 548;

    /**
     * @param crossID &gt; FIX TAG 548
     */
    void crossID(String crossID);

    default String crossID() {
        throw new UnsupportedOperationException();
    }
}
