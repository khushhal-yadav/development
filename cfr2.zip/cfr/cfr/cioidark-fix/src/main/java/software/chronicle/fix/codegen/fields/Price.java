package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface Price {
    /**
     * Tag number for this field
     */
    int FIELD = 44;

    /**
     * @param price &gt; FIX TAG 44
     */
    void price(double price);

    default double price() {
        throw new UnsupportedOperationException();
    }
}
