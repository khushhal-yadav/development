package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MaturityDay {
    /**
     * Tag number for this field
     */
    int FIELD = 205;

    /**
     * @param maturityDay &gt; FIX TAG 205
     */
    void maturityDay(long maturityDay);

    default long maturityDay() {
        throw new UnsupportedOperationException();
    }
}
