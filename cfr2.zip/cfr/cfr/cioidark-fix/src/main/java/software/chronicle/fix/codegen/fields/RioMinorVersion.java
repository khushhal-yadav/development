package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface RioMinorVersion {
    /**
     * Tag number for this field
     */
    int FIELD = 10653;

    /**
     * @param rioMinorVersion &gt; FIX TAG 10653
     */
    void rioMinorVersion(String rioMinorVersion);

    default String rioMinorVersion() {
        throw new UnsupportedOperationException();
    }
}
