package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CxlQty {
    /**
     * Tag number for this field
     */
    int FIELD = 84;

    /**
     * @param cxlQty &gt; FIX TAG 84
     */
    void cxlQty(double cxlQty);

    default double cxlQty() {
        throw new UnsupportedOperationException();
    }
}
