package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ExpireDate {
    /**
     * Tag number for this field
     */
    int FIELD = 432;

    /**
     * @param expireDate &gt; FIX TAG 432
     */
    void expireDate(String expireDate);

    default String expireDate() {
        throw new UnsupportedOperationException();
    }
}
