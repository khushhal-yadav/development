package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OnBehalfOfCompID {
    /**
     * Tag number for this field
     */
    int FIELD = 115;

    /**
     * @param onBehalfOfCompID &gt; FIX TAG 115
     */
    void onBehalfOfCompID(String onBehalfOfCompID);

    default String onBehalfOfCompID() {
        throw new UnsupportedOperationException();
    }
}
