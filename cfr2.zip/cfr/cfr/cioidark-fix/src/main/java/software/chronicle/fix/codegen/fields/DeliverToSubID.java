package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface DeliverToSubID {
    /**
     * Tag number for this field
     */
    int FIELD = 129;

    /**
     * @param deliverToSubID &gt; FIX TAG 129
     */
    void deliverToSubID(String deliverToSubID);

    default String deliverToSubID() {
        throw new UnsupportedOperationException();
    }
}
