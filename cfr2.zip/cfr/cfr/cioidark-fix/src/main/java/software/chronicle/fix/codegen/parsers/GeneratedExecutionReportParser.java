package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedExecutionReportParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, ExecutionReport executionReport) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(executionReport);
            fix.orderID(executionReport); // 37
            fix.clOrdID(executionReport); // 11
            fix.execID(executionReport); // 17
            fix.origClOrdID(executionReport); // 41
            fix.execType(executionReport); // 150
            fix.ordStatus(executionReport); // 39
            fix.account(executionReport); // 1
            fix.settlmntTyp(executionReport); // 63
            fix.side(executionReport); // 54
            fix.symbol(executionReport); // 55
            fix.symbolSfx(executionReport); // 65
            fix.idSource(executionReport); // 22
            fix.orderQty(executionReport); // 38
            fix.ordType(executionReport); // 40
            fix.price(executionReport); // 44
            fix.lastTraded(executionReport); // 11001
            fix.lastTradedDelta(executionReport); // 11002
            fix.openQty(executionReport); // 11007
            fix.timeInForce(executionReport); // 59
            fix.lastShares(executionReport); // 32
            fix.lastPx(executionReport); // 31
            fix.lastMkt(executionReport); // 30
            fix.lastCapacity(executionReport); // 29
            fix.orderCapacity(executionReport); // 528
            fix.leavesQty(executionReport); // 151
            fix.cumQty(executionReport); // 14
            fix.avgPx(executionReport); // 6
            fix.tradeDate(executionReport); // 75
            fix.transactTime(executionReport); // 60
            fix.createdNS(executionReport); // 9999
            fix.text(executionReport); // 58
            fix.deltaQty(executionReport); // 9001
            fix.deltaPx(executionReport); // 9002
            fix.execTransType(executionReport); // 20
            fix.cxlQty(executionReport); // 84
            fix.execRefID(executionReport); // 19
            fix.ordRejReason(executionReport); // 103
            fix.execRestatementReason(executionReport); // 378
            fix.rule80A(executionReport); // 47
            fix.settlCurrAmt(executionReport); // 119
            fix.currency(executionReport); // 15
            fix.settlCurrency(executionReport); // 120
            fix.settlCurrFxRate(executionReport); // 155
            fix.settlCurrFxRateCalc(executionReport); // 156
            fix.ordLinkID(executionReport); // 11053
            fix.ordLinkType(executionReport); // 11052
            fix.bookingType(executionReport); // 775
            fix.srcTargetCompId(executionReport); // 10084
            fix.orderVersion(executionReport); // 12052
            fix.quoteTime(executionReport); // 11048
            fix.bidPx(executionReport); // 132
            fix.offerPx(executionReport); // 133
            fix.bidSize(executionReport); // 134
            fix.offerSize(executionReport); // 135
            fix.locateReqd(executionReport); // 114
            fix.locateBroker(executionReport); // 5700
            fix.locateIdentifier(executionReport); // 5701
            fix.previousLinkSrcSystemID(executionReport); // 10518
            fix.contraOrderCapacity(executionReport); // 10158
            fix.orderFlowEntry(executionReport); // 10201
            fix.orderFlowClass(executionReport); // 10201
            fix.traderID(executionReport); // 10039
            fix.avgPriceAcct(executionReport); // 10051
            fix.legalEntity(executionReport); // 10031
            fix.securityID(executionReport); // 48
            fix.securityAltID(executionReport); // 455
            fix.securityAltIDSource(executionReport); // 456
            fix.crossInstruction(executionReport); // 6438
            fix.sumOfStopExecQty(executionReport); // 10065
            fix.receiveTime(executionReport); // 10080
            fix.crossRestrictionClientID(executionReport); // 10896
            fix.cxlReason(executionReport); // 6042
            fix.lULDLowerPriceBand(executionReport); // 10721
            fix.lULDUpperPriceBand(executionReport); // 10722
            fix.lULDPriceBandTimestamp(executionReport); // 10723
            fix.conditionalOrderQty(executionReport); // 8060
            fix.ioiID(executionReport); // 23
            fix.zExecID(executionReport); // 10018
            fix.actReport(executionReport); // 11037
            fix.noClearingInstructions(executionReport); // 576
            fix.clearingInstruction(executionReport); // 577
            fix.firmId(executionReport); // 10054
            fix.avgPriceAcctIDSource(executionReport); // 10428
            fix.tickSizePilotGroup(executionReport); // 11319
            fix.sourceFeed(executionReport); // 11328
            fix.customerSlang(executionReport); // 8004
            fix.rootSrcSystemID(executionReport); // 10515
            fix.srcSystemID(executionReport); // 10005
            fix.orderFlowCategory(executionReport); // 10202
            fix.executedBy(executionReport); // 10021
            fix.tempLastMkt(executionReport); // 10537
            fix.noTempContraBrokers(executionReport); // 10533
            fix.tempContraBroker(executionReport); // 10534
            fix.tempContraBrokerSrc(executionReport); // 10535
            fix.leafSrcSystemID(executionReport); // 10965
            fix.isCurrExecLevel(executionReport); // 11027
            fix.contraAccount(executionReport); // 10514
            fix.contraAccountSrc(executionReport); // 11040
            fix.contraAccountType(executionReport); // 11041
            fix.corellationClOrdID(executionReport); // 9717
            fix.previousLinkOrderID(executionReport); // 10184
            fix.rootOrderID(executionReport); // 11210
            fix.customPrice1(executionReport); // 7491
            fix.strategyParameterValue(executionReport); // 960
            fix.crossStrategy(executionReport); // 7411
            fix.crossID(executionReport); // 548
            fix.execInst(executionReport); // 18
            fix.minQty(executionReport); // 110
            fix.reportToExch(executionReport); // 113
            fix.lastParPx(executionReport); // 669
            if (fix.checkFinished(executionReport, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, executionReport, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(executionReport.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(executionReport.msgSeqNum(), pos);
    }
}
