package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrderID {
    /**
     * Tag number for this field
     */
    int FIELD = 37;

    /**
     * @param orderID &gt; FIX TAG 37
     */
    void orderID(String orderID);

    default String orderID() {
        throw new UnsupportedOperationException();
    }
}
