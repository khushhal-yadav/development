package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrderRestrictions {
    /**
     * Tag number for this field
     */
    int FIELD = 529;

    /**
     * @param orderRestrictions &gt; FIX TAG 529
     */
    void orderRestrictions(String orderRestrictions);

    default String orderRestrictions() {
        throw new UnsupportedOperationException();
    }
}
