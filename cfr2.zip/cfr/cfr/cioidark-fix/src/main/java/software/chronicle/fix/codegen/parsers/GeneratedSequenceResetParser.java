package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.SequenceReset;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedSequenceResetParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, SequenceReset sequenceReset) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(sequenceReset);
            fix.gapFillFlag(sequenceReset); // 123
            fix.newSeqNo(sequenceReset); // 36
            if (fix.checkFinished(sequenceReset, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, sequenceReset, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(sequenceReset.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(sequenceReset.msgSeqNum(), pos);
    }
}
