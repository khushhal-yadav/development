package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LastShares {
    /**
     * Tag number for this field
     */
    int FIELD = 32;

    /**
     * @param lastShares &gt; FIX TAG 32
     */
    void lastShares(double lastShares);

    default double lastShares() {
        throw new UnsupportedOperationException();
    }
}
