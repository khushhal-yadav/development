package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ExecRestatementReason {
    /**
     * Tag number for this field
     */
    int FIELD = 378;

    int GT_CORPORATE_ACTION = 0;

    int GT_RENEWAL_RESTATEMENT = 1;

    int VERBAL_CHANGE = 2;

    int REPRICING_OF_ORDER = 3;

    int BROKER_OPTION = 4;

    int PARTIAL_DECLINE_OF_ORDERQTY = 5;

    /**
     * @param execRestatementReason &gt; FIX TAG 378
     */
    void execRestatementReason(long execRestatementReason);

    default long execRestatementReason() {
        throw new UnsupportedOperationException();
    }

    static String asString(int value) {
        switch (value) {
            case GT_CORPORATE_ACTION:
                    return "GT_CORPORATE_ACTION";
            case GT_RENEWAL_RESTATEMENT:
                    return "GT_RENEWAL_RESTATEMENT";
            case VERBAL_CHANGE:
                    return "VERBAL_CHANGE";
            case REPRICING_OF_ORDER:
                    return "REPRICING_OF_ORDER";
            case BROKER_OPTION:
                    return "BROKER_OPTION";
            case PARTIAL_DECLINE_OF_ORDERQTY:
                    return "PARTIAL_DECLINE_OF_ORDERQTY";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
