package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface EncodedSecurityDesc {
    /**
     * Tag number for this field
     */
    int FIELD = 351;

    /**
     * @param encodedSecurityDesc &gt; FIX TAG 351
     */
    void encodedSecurityDesc(String encodedSecurityDesc);

    default String encodedSecurityDesc() {
        throw new UnsupportedOperationException();
    }
}
