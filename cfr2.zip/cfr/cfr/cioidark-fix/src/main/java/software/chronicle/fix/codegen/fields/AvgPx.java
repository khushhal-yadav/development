package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface AvgPx {
    /**
     * Tag number for this field
     */
    int FIELD = 6;

    /**
     * @param avgPx &gt; FIX TAG 6
     */
    void avgPx(double avgPx);

    default double avgPx() {
        throw new UnsupportedOperationException();
    }
}
