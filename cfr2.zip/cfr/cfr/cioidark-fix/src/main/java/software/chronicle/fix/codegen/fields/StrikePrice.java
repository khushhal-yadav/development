package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface StrikePrice {
    /**
     * Tag number for this field
     */
    int FIELD = 202;

    /**
     * @param strikePrice &gt; FIX TAG 202
     */
    void strikePrice(double strikePrice);

    default double strikePrice() {
        throw new UnsupportedOperationException();
    }
}
