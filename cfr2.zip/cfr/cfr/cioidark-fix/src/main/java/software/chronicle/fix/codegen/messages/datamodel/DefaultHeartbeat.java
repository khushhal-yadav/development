package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.Heartbeat;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultHeartbeat extends DefaultHeaderTrailer implements Heartbeat, HeaderTrailer {
    private String testReqID = null;

    public char msgType() {
        return MessageManifest.Heartbeat;
    }

    public String testReqID() {
        return testReqID;
    }

    @Override
    public void testReqID(String testReqID) {
        this.testReqID = testReqID;
    }

    @Override
    public void reset() {
        Heartbeat.super.reset();
    }
}
