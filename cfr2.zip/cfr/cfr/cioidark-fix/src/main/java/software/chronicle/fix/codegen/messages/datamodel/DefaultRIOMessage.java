package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import java.util.concurrent.TimeUnit;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.RIOMessage;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultRIOMessage extends DefaultHeaderTrailer implements RIOMessage, HeaderTrailer {
    private String account = null;

    private String accountIDSource = null;

    private String accountType = null;

    private double avgPx = FixMessage.UNSET_DOUBLE;

    private String clOrdID = null;

    private double cumQty = FixMessage.UNSET_DOUBLE;

    private String currency = null;

    private String execID = null;

    private String execInst = null;

    private String execRefID = null;

    private char handlInst = FixMessage.UNSET_CHAR;

    private String idSource = null;

    private String securityID = null;

    private String securityAltID = null;

    private String securityAltIDSource = null;

    private String lastCapacity = null;

    private String lastMkt = null;

    private double lastPx = FixMessage.UNSET_DOUBLE;

    private double lastShares = FixMessage.UNSET_DOUBLE;

    private String orderID = null;

    private long srcSystemID = FixMessage.UNSET_LONG;

    private String orderUniqID = null;

    private String xParentOrderID = null;

    private String parentOrderUniqID = null;

    private String previousLinkOrderID = null;

    private long previousLinkSrcSystemID = FixMessage.UNSET_LONG;

    private String previousLinkOrderUniqID = null;

    private String rootOrderID = null;

    private long rootSrcSystemID = FixMessage.UNSET_LONG;

    private String rootOrderUniqID = null;

    private double orderQty = FixMessage.UNSET_DOUBLE;

    private char ordStatus = FixMessage.UNSET_CHAR;

    private char ordType = FixMessage.UNSET_CHAR;

    private String origClOrdID = null;

    private double price = FixMessage.UNSET_DOUBLE;

    private char side = FixMessage.UNSET_CHAR;

    private String symbol = null;

    private String text = null;

    private char timeInForce = FixMessage.UNSET_CHAR;

    private long transactTime = FixMessage.UNSET_LONG;

    private char settlmntTyp = FixMessage.UNSET_CHAR;

    private String symbolSfx = null;

    private String tradeDate = null;

    private double cxlQty = FixMessage.UNSET_DOUBLE;

    private String exDestination = null;

    private char exDestinationIDSource = FixMessage.UNSET_CHAR;

    private long cxlRejReason = FixMessage.UNSET_LONG;

    private long ordRejReason = FixMessage.UNSET_LONG;

    private char locateReqd = FixMessage.UNSET_CHAR;

    private String settlCurrency = null;

    private char execType = FixMessage.UNSET_CHAR;

    private double leavesQty = FixMessage.UNSET_DOUBLE;

    private double settlCurrAmt = FixMessage.UNSET_DOUBLE;

    private double settlCurrFxRate = FixMessage.UNSET_DOUBLE;

    private char settlCurrFxRateCalc = FixMessage.UNSET_CHAR;

    private String securityType = null;

    private String securityExchange = null;

    private char refMsgType = FixMessage.UNSET_CHAR;

    private String country = null;

    private char orderCapacity = FixMessage.UNSET_CHAR;

    private String orderRestrictions = null;

    private long customerOrFirm = FixMessage.UNSET_LONG;

    private String clientID = null;

    private long rioTimestamp = FixMessage.UNSET_LONG;

    private char isRioStateEvent = FixMessage.UNSET_CHAR;

    private String orderFlowCategory = null;

    private String rioMsgSource = null;

    private char leafExecFlag = FixMessage.UNSET_CHAR;

    private long rioTransactTime = FixMessage.UNSET_LONG;

    private long orderVersion = FixMessage.UNSET_LONG;

    private String orderPlacer = null;

    private String lafExecID = null;

    private long leafSrcSystemID = FixMessage.UNSET_LONG;

    private String rioBeginString = null;

    private String rioMinorVersion = null;

    private long rioMsgSeq = FixMessage.UNSET_LONG;

    private char replayInd = FixMessage.UNSET_CHAR;

    private String rioMsgSeqSrc = null;

    private String channelName = null;

    private String ordLinkID = null;

    private String ordLinkType = null;

    private String bookingType = null;

    private String tradingAcct = null;

    private String contraBroker = null;

    private long trdType = FixMessage.UNSET_LONG;

    private String zExecID = null;

    private String salesPersonID = null;

    private String traderID = null;

    private long receiveTime = FixMessage.UNSET_LONG;

    private char leafExecutionFlag = FixMessage.UNSET_CHAR;

    private String xLastActivityUserID = null;

    private String tempLastMkt = null;

    private String ioiID = null;

    public char msgType() {
        return MessageManifest.RIOMessage;
    }

    public String account() {
        return account;
    }

    @Override
    public void account(String account) {
        this.account = account;
    }

    public String accountIDSource() {
        return accountIDSource;
    }

    @Override
    public void accountIDSource(String accountIDSource) {
        this.accountIDSource = accountIDSource;
    }

    public String accountType() {
        return accountType;
    }

    @Override
    public void accountType(String accountType) {
        this.accountType = accountType;
    }

    public double avgPx() {
        return avgPx;
    }

    @Override
    public void avgPx(double avgPx) {
        this.avgPx = avgPx;
    }

    public String clOrdID() {
        return clOrdID;
    }

    @Override
    public void clOrdID(String clOrdID) {
        this.clOrdID = clOrdID;
    }

    public double cumQty() {
        return cumQty;
    }

    @Override
    public void cumQty(double cumQty) {
        this.cumQty = cumQty;
    }

    public String currency() {
        return currency;
    }

    @Override
    public void currency(String currency) {
        this.currency = currency;
    }

    public String execID() {
        return execID;
    }

    @Override
    public void execID(String execID) {
        this.execID = execID;
    }

    public String execInst() {
        return execInst;
    }

    @Override
    public void execInst(String execInst) {
        this.execInst = execInst;
    }

    public String execRefID() {
        return execRefID;
    }

    @Override
    public void execRefID(String execRefID) {
        this.execRefID = execRefID;
    }

    public char handlInst() {
        return handlInst;
    }

    @Override
    public void handlInst(char handlInst) {
        this.handlInst = handlInst;
    }

    public String idSource() {
        return idSource;
    }

    @Override
    public void idSource(String idSource) {
        this.idSource = idSource;
    }

    public String securityID() {
        return securityID;
    }

    @Override
    public void securityID(String securityID) {
        this.securityID = securityID;
    }

    public String securityAltID() {
        return securityAltID;
    }

    @Override
    public void securityAltID(String securityAltID) {
        this.securityAltID = securityAltID;
    }

    public String securityAltIDSource() {
        return securityAltIDSource;
    }

    @Override
    public void securityAltIDSource(String securityAltIDSource) {
        this.securityAltIDSource = securityAltIDSource;
    }

    public String lastCapacity() {
        return lastCapacity;
    }

    @Override
    public void lastCapacity(String lastCapacity) {
        this.lastCapacity = lastCapacity;
    }

    public String lastMkt() {
        return lastMkt;
    }

    @Override
    public void lastMkt(String lastMkt) {
        this.lastMkt = lastMkt;
    }

    public double lastPx() {
        return lastPx;
    }

    @Override
    public void lastPx(double lastPx) {
        this.lastPx = lastPx;
    }

    public double lastShares() {
        return lastShares;
    }

    @Override
    public void lastShares(double lastShares) {
        this.lastShares = lastShares;
    }

    public String orderID() {
        return orderID;
    }

    @Override
    public void orderID(String orderID) {
        this.orderID = orderID;
    }

    public long srcSystemID() {
        return srcSystemID;
    }

    @Override
    public void srcSystemID(long srcSystemID) {
        this.srcSystemID = srcSystemID;
    }

    public String orderUniqID() {
        return orderUniqID;
    }

    @Override
    public void orderUniqID(String orderUniqID) {
        this.orderUniqID = orderUniqID;
    }

    public String xParentOrderID() {
        return xParentOrderID;
    }

    @Override
    public void xParentOrderID(String xParentOrderID) {
        this.xParentOrderID = xParentOrderID;
    }

    public String parentOrderUniqID() {
        return parentOrderUniqID;
    }

    @Override
    public void parentOrderUniqID(String parentOrderUniqID) {
        this.parentOrderUniqID = parentOrderUniqID;
    }

    public String previousLinkOrderID() {
        return previousLinkOrderID;
    }

    @Override
    public void previousLinkOrderID(String previousLinkOrderID) {
        this.previousLinkOrderID = previousLinkOrderID;
    }

    public long previousLinkSrcSystemID() {
        return previousLinkSrcSystemID;
    }

    @Override
    public void previousLinkSrcSystemID(long previousLinkSrcSystemID) {
        this.previousLinkSrcSystemID = previousLinkSrcSystemID;
    }

    public String previousLinkOrderUniqID() {
        return previousLinkOrderUniqID;
    }

    @Override
    public void previousLinkOrderUniqID(String previousLinkOrderUniqID) {
        this.previousLinkOrderUniqID = previousLinkOrderUniqID;
    }

    public String rootOrderID() {
        return rootOrderID;
    }

    @Override
    public void rootOrderID(String rootOrderID) {
        this.rootOrderID = rootOrderID;
    }

    public long rootSrcSystemID() {
        return rootSrcSystemID;
    }

    @Override
    public void rootSrcSystemID(long rootSrcSystemID) {
        this.rootSrcSystemID = rootSrcSystemID;
    }

    public String rootOrderUniqID() {
        return rootOrderUniqID;
    }

    @Override
    public void rootOrderUniqID(String rootOrderUniqID) {
        this.rootOrderUniqID = rootOrderUniqID;
    }

    public double orderQty() {
        return orderQty;
    }

    @Override
    public void orderQty(double orderQty) {
        this.orderQty = orderQty;
    }

    public char ordStatus() {
        return ordStatus;
    }

    @Override
    public void ordStatus(char ordStatus) {
        this.ordStatus = ordStatus;
    }

    public char ordType() {
        return ordType;
    }

    @Override
    public void ordType(char ordType) {
        this.ordType = ordType;
    }

    public String origClOrdID() {
        return origClOrdID;
    }

    @Override
    public void origClOrdID(String origClOrdID) {
        this.origClOrdID = origClOrdID;
    }

    public double price() {
        return price;
    }

    @Override
    public void price(double price) {
        this.price = price;
    }

    public char side() {
        return side;
    }

    @Override
    public void side(char side) {
        this.side = side;
    }

    public String symbol() {
        return symbol;
    }

    @Override
    public void symbol(String symbol) {
        this.symbol = symbol;
    }

    public String text() {
        return text;
    }

    @Override
    public void text(String text) {
        this.text = text;
    }

    public char timeInForce() {
        return timeInForce;
    }

    @Override
    public void timeInForce(char timeInForce) {
        this.timeInForce = timeInForce;
    }

    public long transactTime() {
        return transactTime;
    }

    @Override
    public void transactTime(long transactTime, TimeUnit timeUnit) {
        transactTime(transactTime);
    }

    @Override
    public void transactTime(long transactTime) {
        this.transactTime = transactTime;
    }

    public char settlmntTyp() {
        return settlmntTyp;
    }

    @Override
    public void settlmntTyp(char settlmntTyp) {
        this.settlmntTyp = settlmntTyp;
    }

    public String symbolSfx() {
        return symbolSfx;
    }

    @Override
    public void symbolSfx(String symbolSfx) {
        this.symbolSfx = symbolSfx;
    }

    public String tradeDate() {
        return tradeDate;
    }

    @Override
    public void tradeDate(String tradeDate) {
        this.tradeDate = tradeDate;
    }

    public double cxlQty() {
        return cxlQty;
    }

    @Override
    public void cxlQty(double cxlQty) {
        this.cxlQty = cxlQty;
    }

    public String exDestination() {
        return exDestination;
    }

    @Override
    public void exDestination(String exDestination) {
        this.exDestination = exDestination;
    }

    public char exDestinationIDSource() {
        return exDestinationIDSource;
    }

    @Override
    public void exDestinationIDSource(char exDestinationIDSource) {
        this.exDestinationIDSource = exDestinationIDSource;
    }

    public long cxlRejReason() {
        return cxlRejReason;
    }

    @Override
    public void cxlRejReason(long cxlRejReason) {
        this.cxlRejReason = cxlRejReason;
    }

    public long ordRejReason() {
        return ordRejReason;
    }

    @Override
    public void ordRejReason(long ordRejReason) {
        this.ordRejReason = ordRejReason;
    }

    public char locateReqd() {
        return locateReqd;
    }

    @Override
    public void locateReqd(char locateReqd) {
        this.locateReqd = locateReqd;
    }

    public String settlCurrency() {
        return settlCurrency;
    }

    @Override
    public void settlCurrency(String settlCurrency) {
        this.settlCurrency = settlCurrency;
    }

    public char execType() {
        return execType;
    }

    @Override
    public void execType(char execType) {
        this.execType = execType;
    }

    public double leavesQty() {
        return leavesQty;
    }

    @Override
    public void leavesQty(double leavesQty) {
        this.leavesQty = leavesQty;
    }

    public double settlCurrAmt() {
        return settlCurrAmt;
    }

    @Override
    public void settlCurrAmt(double settlCurrAmt) {
        this.settlCurrAmt = settlCurrAmt;
    }

    public double settlCurrFxRate() {
        return settlCurrFxRate;
    }

    @Override
    public void settlCurrFxRate(double settlCurrFxRate) {
        this.settlCurrFxRate = settlCurrFxRate;
    }

    public char settlCurrFxRateCalc() {
        return settlCurrFxRateCalc;
    }

    @Override
    public void settlCurrFxRateCalc(char settlCurrFxRateCalc) {
        this.settlCurrFxRateCalc = settlCurrFxRateCalc;
    }

    public String securityType() {
        return securityType;
    }

    @Override
    public void securityType(String securityType) {
        this.securityType = securityType;
    }

    public String securityExchange() {
        return securityExchange;
    }

    @Override
    public void securityExchange(String securityExchange) {
        this.securityExchange = securityExchange;
    }

    public char refMsgType() {
        return refMsgType;
    }

    @Override
    public void refMsgType(char refMsgType) {
        this.refMsgType = refMsgType;
    }

    public String country() {
        return country;
    }

    @Override
    public void country(String country) {
        this.country = country;
    }

    public char orderCapacity() {
        return orderCapacity;
    }

    @Override
    public void orderCapacity(char orderCapacity) {
        this.orderCapacity = orderCapacity;
    }

    public String orderRestrictions() {
        return orderRestrictions;
    }

    @Override
    public void orderRestrictions(String orderRestrictions) {
        this.orderRestrictions = orderRestrictions;
    }

    public long customerOrFirm() {
        return customerOrFirm;
    }

    @Override
    public void customerOrFirm(long customerOrFirm) {
        this.customerOrFirm = customerOrFirm;
    }

    public String clientID() {
        return clientID;
    }

    @Override
    public void clientID(String clientID) {
        this.clientID = clientID;
    }

    public long rioTimestamp() {
        return rioTimestamp;
    }

    @Override
    public void rioTimestamp(long rioTimestamp, TimeUnit timeUnit) {
        rioTimestamp(rioTimestamp);
    }

    @Override
    public void rioTimestamp(long rioTimestamp) {
        this.rioTimestamp = rioTimestamp;
    }

    public char isRioStateEvent() {
        return isRioStateEvent;
    }

    @Override
    public void isRioStateEvent(char isRioStateEvent) {
        this.isRioStateEvent = isRioStateEvent;
    }

    public String orderFlowCategory() {
        return orderFlowCategory;
    }

    @Override
    public void orderFlowCategory(String orderFlowCategory) {
        this.orderFlowCategory = orderFlowCategory;
    }

    public String rioMsgSource() {
        return rioMsgSource;
    }

    @Override
    public void rioMsgSource(String rioMsgSource) {
        this.rioMsgSource = rioMsgSource;
    }

    public char leafExecFlag() {
        return leafExecFlag;
    }

    @Override
    public void leafExecFlag(char leafExecFlag) {
        this.leafExecFlag = leafExecFlag;
    }

    public long rioTransactTime() {
        return rioTransactTime;
    }

    @Override
    public void rioTransactTime(long rioTransactTime, TimeUnit timeUnit) {
        rioTransactTime(rioTransactTime);
    }

    @Override
    public void rioTransactTime(long rioTransactTime) {
        this.rioTransactTime = rioTransactTime;
    }

    public long orderVersion() {
        return orderVersion;
    }

    @Override
    public void orderVersion(long orderVersion) {
        this.orderVersion = orderVersion;
    }

    public String orderPlacer() {
        return orderPlacer;
    }

    @Override
    public void orderPlacer(String orderPlacer) {
        this.orderPlacer = orderPlacer;
    }

    public String lafExecID() {
        return lafExecID;
    }

    @Override
    public void lafExecID(String lafExecID) {
        this.lafExecID = lafExecID;
    }

    public long leafSrcSystemID() {
        return leafSrcSystemID;
    }

    @Override
    public void leafSrcSystemID(long leafSrcSystemID) {
        this.leafSrcSystemID = leafSrcSystemID;
    }

    public String rioBeginString() {
        return rioBeginString;
    }

    @Override
    public void rioBeginString(String rioBeginString) {
        this.rioBeginString = rioBeginString;
    }

    public String rioMinorVersion() {
        return rioMinorVersion;
    }

    @Override
    public void rioMinorVersion(String rioMinorVersion) {
        this.rioMinorVersion = rioMinorVersion;
    }

    public long rioMsgSeq() {
        return rioMsgSeq;
    }

    @Override
    public void rioMsgSeq(long rioMsgSeq) {
        this.rioMsgSeq = rioMsgSeq;
    }

    public char replayInd() {
        return replayInd;
    }

    @Override
    public void replayInd(char replayInd) {
        this.replayInd = replayInd;
    }

    public String rioMsgSeqSrc() {
        return rioMsgSeqSrc;
    }

    @Override
    public void rioMsgSeqSrc(String rioMsgSeqSrc) {
        this.rioMsgSeqSrc = rioMsgSeqSrc;
    }

    public String channelName() {
        return channelName;
    }

    @Override
    public void channelName(String channelName) {
        this.channelName = channelName;
    }

    public String ordLinkID() {
        return ordLinkID;
    }

    @Override
    public void ordLinkID(String ordLinkID) {
        this.ordLinkID = ordLinkID;
    }

    public String ordLinkType() {
        return ordLinkType;
    }

    @Override
    public void ordLinkType(String ordLinkType) {
        this.ordLinkType = ordLinkType;
    }

    public String bookingType() {
        return bookingType;
    }

    @Override
    public void bookingType(String bookingType) {
        this.bookingType = bookingType;
    }

    public String tradingAcct() {
        return tradingAcct;
    }

    @Override
    public void tradingAcct(String tradingAcct) {
        this.tradingAcct = tradingAcct;
    }

    public String contraBroker() {
        return contraBroker;
    }

    @Override
    public void contraBroker(String contraBroker) {
        this.contraBroker = contraBroker;
    }

    public long trdType() {
        return trdType;
    }

    @Override
    public void trdType(long trdType) {
        this.trdType = trdType;
    }

    public String zExecID() {
        return zExecID;
    }

    @Override
    public void zExecID(String zExecID) {
        this.zExecID = zExecID;
    }

    public String salesPersonID() {
        return salesPersonID;
    }

    @Override
    public void salesPersonID(String salesPersonID) {
        this.salesPersonID = salesPersonID;
    }

    public String traderID() {
        return traderID;
    }

    @Override
    public void traderID(String traderID) {
        this.traderID = traderID;
    }

    public long receiveTime() {
        return receiveTime;
    }

    @Override
    public void receiveTime(long receiveTime, TimeUnit timeUnit) {
        receiveTime(receiveTime);
    }

    @Override
    public void receiveTime(long receiveTime) {
        this.receiveTime = receiveTime;
    }

    public char leafExecutionFlag() {
        return leafExecutionFlag;
    }

    @Override
    public void leafExecutionFlag(char leafExecutionFlag) {
        this.leafExecutionFlag = leafExecutionFlag;
    }

    public String xLastActivityUserID() {
        return xLastActivityUserID;
    }

    @Override
    public void xLastActivityUserID(String xLastActivityUserID) {
        this.xLastActivityUserID = xLastActivityUserID;
    }

    public String tempLastMkt() {
        return tempLastMkt;
    }

    @Override
    public void tempLastMkt(String tempLastMkt) {
        this.tempLastMkt = tempLastMkt;
    }

    public String ioiID() {
        return ioiID;
    }

    @Override
    public void ioiID(String ioiID) {
        this.ioiID = ioiID;
    }

    @Override
    public void reset() {
        RIOMessage.super.reset();
    }
}
