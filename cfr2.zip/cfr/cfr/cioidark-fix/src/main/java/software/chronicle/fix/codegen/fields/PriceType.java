package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface PriceType {
    /**
     * Tag number for this field
     */
    int FIELD = 423;

    int PERCENTAGE = 1;

    int PER_UNIT = 2;

    int FIXED_AMOUNT = 3;

    int DISCOUNT = 4;

    int PREMIUM = 5;

    int SPREAD = 6;

    int TED_PRICE = 7;

    int TED_YIELD = 8;

    int YIELD = 9;

    int FIXED_CABINET_TRADE_PRICE = 10;

    int VARIABLE_CABINET_TRADE_PRICE = 11;

    /**
     * @param priceType &gt; FIX TAG 423
     */
    void priceType(long priceType);

    default long priceType() {
        throw new UnsupportedOperationException();
    }

    static String asString(int value) {
        switch (value) {
            case PERCENTAGE:
                    return "PERCENTAGE";
            case PER_UNIT:
                    return "PER_UNIT";
            case FIXED_AMOUNT:
                    return "FIXED_AMOUNT";
            case DISCOUNT:
                    return "DISCOUNT";
            case PREMIUM:
                    return "PREMIUM";
            case SPREAD:
                    return "SPREAD";
            case TED_PRICE:
                    return "TED_PRICE";
            case TED_YIELD:
                    return "TED_YIELD";
            case YIELD:
                    return "YIELD";
            case FIXED_CABINET_TRADE_PRICE:
                    return "FIXED_CABINET_TRADE_PRICE";
            case VARIABLE_CABINET_TRADE_PRICE:
                    return "VARIABLE_CABINET_TRADE_PRICE";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
