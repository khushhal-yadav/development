package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OpenCloseSettleFlag {
    /**
     * Tag number for this field
     */
    int FIELD = 286;

    char DAILY_OPEN_CLOSE__SETTLEMENT_PRICE = '0';

    char SESSION_OPEN_CLOSE__SETTLEMENT_PRICE = '1';

    char DELIVERY_SETTLEMENT_PRICE = '2';

    /**
     * @param openCloseSettleFlag &gt; FIX TAG 286
     */
    void openCloseSettleFlag(char openCloseSettleFlag);

    default char openCloseSettleFlag() {
        throw new UnsupportedOperationException();
    }

    static String asString(char value) {
        switch (value) {
            case DAILY_OPEN_CLOSE__SETTLEMENT_PRICE:
                    return "DAILY_OPEN_CLOSE__SETTLEMENT_PRICE";
            case SESSION_OPEN_CLOSE__SETTLEMENT_PRICE:
                    return "SESSION_OPEN_CLOSE__SETTLEMENT_PRICE";
            case DELIVERY_SETTLEMENT_PRICE:
                    return "DELIVERY_SETTLEMENT_PRICE";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
