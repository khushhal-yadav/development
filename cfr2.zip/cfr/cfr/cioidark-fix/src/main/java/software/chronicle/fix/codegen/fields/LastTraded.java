package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LastTraded {
    /**
     * Tag number for this field
     */
    int FIELD = 11001;

    /**
     * @param lastTraded &gt; FIX TAG 11001
     */
    void lastTraded(double lastTraded);

    default double lastTraded() {
        throw new UnsupportedOperationException();
    }
}
