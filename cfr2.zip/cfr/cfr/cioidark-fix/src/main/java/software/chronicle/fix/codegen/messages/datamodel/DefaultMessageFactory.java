package software.chronicle.fix.codegen.messages.datamodel;

import software.chronicle.fix.codegen.messages.BusinessMessageReject;
import software.chronicle.fix.codegen.messages.CioiDarkOrder;
import software.chronicle.fix.codegen.messages.DontKnowTrade;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.Heartbeat;
import software.chronicle.fix.codegen.messages.Logon;
import software.chronicle.fix.codegen.messages.Logout;
import software.chronicle.fix.codegen.messages.MarketDataSnapshotFullRefresh;
import software.chronicle.fix.codegen.messages.MessageFactory;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReject;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.codegen.messages.RIOMessage;
import software.chronicle.fix.codegen.messages.Reject;
import software.chronicle.fix.codegen.messages.ResendRequest;
import software.chronicle.fix.codegen.messages.SequenceReset;
import software.chronicle.fix.codegen.messages.TestRequest;

/**
 * Generated at software.chronicle.fix.codegen.MessageFactoryGenerator.generate(MessageFactoryGenerator.java)
 */
public class DefaultMessageFactory implements MessageFactory {
    Heartbeat heartbeat = new DefaultHeartbeat();

    Logon logon = new DefaultLogon();

    TestRequest testRequest = new DefaultTestRequest();

    ResendRequest resendRequest = new DefaultResendRequest();

    Reject reject = new DefaultReject();

    SequenceReset sequenceReset = new DefaultSequenceReset();

    Logout logout = new DefaultLogout();

    NewOrderSingle newOrderSingle = new DefaultNewOrderSingle();

    OrderCancelRequest orderCancelRequest = new DefaultOrderCancelRequest();

    OrderCancelReplaceRequest orderCancelReplaceRequest = new DefaultOrderCancelReplaceRequest();

    ExecutionReport executionReport = new DefaultExecutionReport();

    OrderCancelReject orderCancelReject = new DefaultOrderCancelReject();

    DontKnowTrade dontKnowTrade = new DefaultDontKnowTrade();

    RIOMessage rIOMessage = new DefaultRIOMessage();

    MarketDataSnapshotFullRefresh marketDataSnapshotFullRefresh = new DefaultMarketDataSnapshotFullRefresh();

    BusinessMessageReject businessMessageReject = new DefaultBusinessMessageReject();

    CioiDarkOrder cioiDarkOrder = new DefaultCioiDarkOrder();

    public Heartbeat heartbeat() {
        return heartbeat;
    }

    public Logon logon() {
        return logon;
    }

    public TestRequest testRequest() {
        return testRequest;
    }

    public ResendRequest resendRequest() {
        return resendRequest;
    }

    public Reject reject() {
        return reject;
    }

    public SequenceReset sequenceReset() {
        return sequenceReset;
    }

    public Logout logout() {
        return logout;
    }

    public NewOrderSingle newOrderSingle() {
        return newOrderSingle;
    }

    public OrderCancelRequest orderCancelRequest() {
        return orderCancelRequest;
    }

    public OrderCancelReplaceRequest orderCancelReplaceRequest() {
        return orderCancelReplaceRequest;
    }

    public ExecutionReport executionReport() {
        return executionReport;
    }

    public OrderCancelReject orderCancelReject() {
        return orderCancelReject;
    }

    public DontKnowTrade dontKnowTrade() {
        return dontKnowTrade;
    }

    public RIOMessage rIOMessage() {
        return rIOMessage;
    }

    public MarketDataSnapshotFullRefresh marketDataSnapshotFullRefresh() {
        return marketDataSnapshotFullRefresh;
    }

    public BusinessMessageReject businessMessageReject() {
        return businessMessageReject;
    }

    public CioiDarkOrder cioiDarkOrder() {
        return cioiDarkOrder;
    }
}
