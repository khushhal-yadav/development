package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface FinancialStatus {
    /**
     * Tag number for this field
     */
    int FIELD = 291;

    char BANKRUPT = '1';

    /**
     * @param financialStatus &gt; FIX TAG 291
     */
    void financialStatus(char financialStatus);

    default char financialStatus() {
        throw new UnsupportedOperationException();
    }

    static String asString(char value) {
        switch (value) {
            case BANKRUPT:
                    return "BANKRUPT";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
