package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.DontKnowTrade;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultDontKnowTrade extends DefaultHeaderTrailer implements DontKnowTrade, HeaderTrailer {
    private String orderID = null;

    private String execID = null;

    private char dKReason = FixMessage.UNSET_CHAR;

    private String symbol = null;

    private String symbolSfx = null;

    private String securityID = null;

    private String idSource = null;

    private String securityType = null;

    private String maturityMonthYear = null;

    private long maturityDay = FixMessage.UNSET_LONG;

    private long putOrCall = FixMessage.UNSET_LONG;

    private double strikePrice = FixMessage.UNSET_DOUBLE;

    private char optAttribute = FixMessage.UNSET_CHAR;

    private double contractMultiplier = FixMessage.UNSET_DOUBLE;

    private double couponRate = FixMessage.UNSET_DOUBLE;

    private String securityExchange = null;

    private String issuer = null;

    private long encodedIssuerLen = FixMessage.UNSET_LONG;

    private String encodedIssuer = null;

    private String securityDesc = null;

    private long encodedSecurityDescLen = FixMessage.UNSET_LONG;

    private char side = FixMessage.UNSET_CHAR;

    private double orderQty = FixMessage.UNSET_DOUBLE;

    private double cashOrderQty = FixMessage.UNSET_DOUBLE;

    private double lastShares = FixMessage.UNSET_DOUBLE;

    private double lastPx = FixMessage.UNSET_DOUBLE;

    private String text = null;

    private long encodedTextLen = FixMessage.UNSET_LONG;

    private String encodedText = null;

    public char msgType() {
        return MessageManifest.DontKnowTrade;
    }

    public String orderID() {
        return orderID;
    }

    @Override
    public void orderID(String orderID) {
        this.orderID = orderID;
    }

    public String execID() {
        return execID;
    }

    @Override
    public void execID(String execID) {
        this.execID = execID;
    }

    public char dKReason() {
        return dKReason;
    }

    @Override
    public void dKReason(char dKReason) {
        this.dKReason = dKReason;
    }

    public String symbol() {
        return symbol;
    }

    @Override
    public void symbol(String symbol) {
        this.symbol = symbol;
    }

    public String symbolSfx() {
        return symbolSfx;
    }

    @Override
    public void symbolSfx(String symbolSfx) {
        this.symbolSfx = symbolSfx;
    }

    public String securityID() {
        return securityID;
    }

    @Override
    public void securityID(String securityID) {
        this.securityID = securityID;
    }

    public String idSource() {
        return idSource;
    }

    @Override
    public void idSource(String idSource) {
        this.idSource = idSource;
    }

    public String securityType() {
        return securityType;
    }

    @Override
    public void securityType(String securityType) {
        this.securityType = securityType;
    }

    public String maturityMonthYear() {
        return maturityMonthYear;
    }

    @Override
    public void maturityMonthYear(String maturityMonthYear) {
        this.maturityMonthYear = maturityMonthYear;
    }

    public long maturityDay() {
        return maturityDay;
    }

    @Override
    public void maturityDay(long maturityDay) {
        this.maturityDay = maturityDay;
    }

    public long putOrCall() {
        return putOrCall;
    }

    @Override
    public void putOrCall(long putOrCall) {
        this.putOrCall = putOrCall;
    }

    public double strikePrice() {
        return strikePrice;
    }

    @Override
    public void strikePrice(double strikePrice) {
        this.strikePrice = strikePrice;
    }

    public char optAttribute() {
        return optAttribute;
    }

    @Override
    public void optAttribute(char optAttribute) {
        this.optAttribute = optAttribute;
    }

    public double contractMultiplier() {
        return contractMultiplier;
    }

    @Override
    public void contractMultiplier(double contractMultiplier) {
        this.contractMultiplier = contractMultiplier;
    }

    public double couponRate() {
        return couponRate;
    }

    @Override
    public void couponRate(double couponRate) {
        this.couponRate = couponRate;
    }

    public String securityExchange() {
        return securityExchange;
    }

    @Override
    public void securityExchange(String securityExchange) {
        this.securityExchange = securityExchange;
    }

    public String issuer() {
        return issuer;
    }

    @Override
    public void issuer(String issuer) {
        this.issuer = issuer;
    }

    public long encodedIssuerLen() {
        return encodedIssuerLen;
    }

    @Override
    public void encodedIssuerLen(long encodedIssuerLen) {
        this.encodedIssuerLen = encodedIssuerLen;
    }

    public String encodedIssuer() {
        return encodedIssuer;
    }

    @Override
    public void encodedIssuer(String encodedIssuer) {
        this.encodedIssuer = encodedIssuer;
    }

    public String securityDesc() {
        return securityDesc;
    }

    @Override
    public void securityDesc(String securityDesc) {
        this.securityDesc = securityDesc;
    }

    public long encodedSecurityDescLen() {
        return encodedSecurityDescLen;
    }

    @Override
    public void encodedSecurityDescLen(long encodedSecurityDescLen) {
        this.encodedSecurityDescLen = encodedSecurityDescLen;
    }

    public char side() {
        return side;
    }

    @Override
    public void side(char side) {
        this.side = side;
    }

    public double orderQty() {
        return orderQty;
    }

    @Override
    public void orderQty(double orderQty) {
        this.orderQty = orderQty;
    }

    public double cashOrderQty() {
        return cashOrderQty;
    }

    @Override
    public void cashOrderQty(double cashOrderQty) {
        this.cashOrderQty = cashOrderQty;
    }

    public double lastShares() {
        return lastShares;
    }

    @Override
    public void lastShares(double lastShares) {
        this.lastShares = lastShares;
    }

    public double lastPx() {
        return lastPx;
    }

    @Override
    public void lastPx(double lastPx) {
        this.lastPx = lastPx;
    }

    public String text() {
        return text;
    }

    @Override
    public void text(String text) {
        this.text = text;
    }

    public long encodedTextLen() {
        return encodedTextLen;
    }

    @Override
    public void encodedTextLen(long encodedTextLen) {
        this.encodedTextLen = encodedTextLen;
    }

    public String encodedText() {
        return encodedText;
    }

    @Override
    public void encodedText(String encodedText) {
        this.encodedText = encodedText;
    }

    @Override
    public void reset() {
        DontKnowTrade.super.reset();
    }
}
