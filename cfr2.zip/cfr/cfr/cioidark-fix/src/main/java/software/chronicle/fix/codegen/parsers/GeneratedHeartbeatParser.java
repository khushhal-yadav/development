package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.Heartbeat;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedHeartbeatParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, Heartbeat heartbeat) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(heartbeat);
            fix.testReqID(heartbeat); // 112
            if (fix.checkFinished(heartbeat, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, heartbeat, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(heartbeat.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(heartbeat.msgSeqNum(), pos);
    }
}
