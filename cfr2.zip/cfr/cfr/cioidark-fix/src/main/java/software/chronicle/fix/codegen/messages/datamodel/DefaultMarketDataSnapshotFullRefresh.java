package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.components.MarketDataSnapshotFullRefresh_MDEntriesGrp_1;
import software.chronicle.fix.codegen.components.datamodel.DefaultMarketDataSnapshotFullRefresh_MDEntriesGrp_1;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.MarketDataSnapshotFullRefresh;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultMarketDataSnapshotFullRefresh extends DefaultHeaderTrailer implements MarketDataSnapshotFullRefresh, HeaderTrailer {
    private String mDReqID = null;

    private String symbol = null;

    private String symbolSfx = null;

    private String securityID = null;

    private String idSource = null;

    private String securityType = null;

    private String maturityMonthYear = null;

    private long maturityDay = FixMessage.UNSET_LONG;

    private long putOrCall = FixMessage.UNSET_LONG;

    private double strikePrice = FixMessage.UNSET_DOUBLE;

    private char optAttribute = FixMessage.UNSET_CHAR;

    private double contractMultiplier = FixMessage.UNSET_DOUBLE;

    private double couponRate = FixMessage.UNSET_DOUBLE;

    private String securityExchange = null;

    private String issuer = null;

    private long encodedIssuerLen = FixMessage.UNSET_LONG;

    private String encodedIssuer = null;

    private String securityDesc = null;

    private long encodedSecurityDescLen = FixMessage.UNSET_LONG;

    private char financialStatus = FixMessage.UNSET_CHAR;

    private char corporateAction = FixMessage.UNSET_CHAR;

    private double totalVolumeTraded = FixMessage.UNSET_DOUBLE;

    private MarketDataSnapshotFullRefresh_MDEntriesGrp_1[] marketDataSnapshotFullRefresh_MDEntriesGrp_1s;

    private long noMDEntries = UNSET_LONG;

    public char msgType() {
        return MessageManifest.MarketDataSnapshotFullRefresh;
    }

    public String mDReqID() {
        return mDReqID;
    }

    @Override
    public void mDReqID(String mDReqID) {
        this.mDReqID = mDReqID;
    }

    public String symbol() {
        return symbol;
    }

    @Override
    public void symbol(String symbol) {
        this.symbol = symbol;
    }

    public String symbolSfx() {
        return symbolSfx;
    }

    @Override
    public void symbolSfx(String symbolSfx) {
        this.symbolSfx = symbolSfx;
    }

    public String securityID() {
        return securityID;
    }

    @Override
    public void securityID(String securityID) {
        this.securityID = securityID;
    }

    public String idSource() {
        return idSource;
    }

    @Override
    public void idSource(String idSource) {
        this.idSource = idSource;
    }

    public String securityType() {
        return securityType;
    }

    @Override
    public void securityType(String securityType) {
        this.securityType = securityType;
    }

    public String maturityMonthYear() {
        return maturityMonthYear;
    }

    @Override
    public void maturityMonthYear(String maturityMonthYear) {
        this.maturityMonthYear = maturityMonthYear;
    }

    public long maturityDay() {
        return maturityDay;
    }

    @Override
    public void maturityDay(long maturityDay) {
        this.maturityDay = maturityDay;
    }

    public long putOrCall() {
        return putOrCall;
    }

    @Override
    public void putOrCall(long putOrCall) {
        this.putOrCall = putOrCall;
    }

    public double strikePrice() {
        return strikePrice;
    }

    @Override
    public void strikePrice(double strikePrice) {
        this.strikePrice = strikePrice;
    }

    public char optAttribute() {
        return optAttribute;
    }

    @Override
    public void optAttribute(char optAttribute) {
        this.optAttribute = optAttribute;
    }

    public double contractMultiplier() {
        return contractMultiplier;
    }

    @Override
    public void contractMultiplier(double contractMultiplier) {
        this.contractMultiplier = contractMultiplier;
    }

    public double couponRate() {
        return couponRate;
    }

    @Override
    public void couponRate(double couponRate) {
        this.couponRate = couponRate;
    }

    public String securityExchange() {
        return securityExchange;
    }

    @Override
    public void securityExchange(String securityExchange) {
        this.securityExchange = securityExchange;
    }

    public String issuer() {
        return issuer;
    }

    @Override
    public void issuer(String issuer) {
        this.issuer = issuer;
    }

    public long encodedIssuerLen() {
        return encodedIssuerLen;
    }

    @Override
    public void encodedIssuerLen(long encodedIssuerLen) {
        this.encodedIssuerLen = encodedIssuerLen;
    }

    public String encodedIssuer() {
        return encodedIssuer;
    }

    @Override
    public void encodedIssuer(String encodedIssuer) {
        this.encodedIssuer = encodedIssuer;
    }

    public String securityDesc() {
        return securityDesc;
    }

    @Override
    public void securityDesc(String securityDesc) {
        this.securityDesc = securityDesc;
    }

    public long encodedSecurityDescLen() {
        return encodedSecurityDescLen;
    }

    @Override
    public void encodedSecurityDescLen(long encodedSecurityDescLen) {
        this.encodedSecurityDescLen = encodedSecurityDescLen;
    }

    public char financialStatus() {
        return financialStatus;
    }

    @Override
    public void financialStatus(char financialStatus) {
        this.financialStatus = financialStatus;
    }

    public char corporateAction() {
        return corporateAction;
    }

    @Override
    public void corporateAction(char corporateAction) {
        this.corporateAction = corporateAction;
    }

    public double totalVolumeTraded() {
        return totalVolumeTraded;
    }

    @Override
    public void totalVolumeTraded(double totalVolumeTraded) {
        this.totalVolumeTraded = totalVolumeTraded;
    }

    public long noMDEntries() {
        return noMDEntries;
    }

    public void noMDEntries(long noMDEntries) {
        if (noMDEntries != UNSET_LONG && (marketDataSnapshotFullRefresh_MDEntriesGrp_1s == null || marketDataSnapshotFullRefresh_MDEntriesGrp_1s.length < noMDEntries)) {
            marketDataSnapshotFullRefresh_MDEntriesGrp_1s = new DefaultMarketDataSnapshotFullRefresh_MDEntriesGrp_1[(int)noMDEntries];
        }
        this.noMDEntries = noMDEntries;
    }

    public MarketDataSnapshotFullRefresh_MDEntriesGrp_1 marketDataSnapshotFullRefresh_MDEntriesGrp_1(int index) {
        MarketDataSnapshotFullRefresh_MDEntriesGrp_1 marketDataSnapshotFullRefresh_MDEntriesGrp_1 = marketDataSnapshotFullRefresh_MDEntriesGrp_1s[index];
        if(marketDataSnapshotFullRefresh_MDEntriesGrp_1==null) {
            return marketDataSnapshotFullRefresh_MDEntriesGrp_1s[index] = new DefaultMarketDataSnapshotFullRefresh_MDEntriesGrp_1();
        }
        return marketDataSnapshotFullRefresh_MDEntriesGrp_1;
    }

    @Override
    public void reset() {
        MarketDataSnapshotFullRefresh.super.reset();
    }
}
