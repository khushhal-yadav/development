package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LastTradedDelta {
    /**
     * Tag number for this field
     */
    int FIELD = 11002;

    /**
     * @param lastTradedDelta &gt; FIX TAG 11002
     */
    void lastTradedDelta(double lastTradedDelta);

    default double lastTradedDelta() {
        throw new UnsupportedOperationException();
    }
}
