package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ContraAccount {
    /**
     * Tag number for this field
     */
    int FIELD = 10514;

    /**
     * @param contraAccount &gt; FIX TAG 10514
     */
    void contraAccount(String contraAccount);

    default String contraAccount() {
        throw new UnsupportedOperationException();
    }
}
