package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface RioMsgSeqSrc {
    /**
     * Tag number for this field
     */
    int FIELD = 10658;

    /**
     * @param rioMsgSeqSrc &gt; FIX TAG 10658
     */
    void rioMsgSeqSrc(String rioMsgSeqSrc);

    default String rioMsgSeqSrc() {
        throw new UnsupportedOperationException();
    }
}
