package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.Reject;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultReject extends DefaultHeaderTrailer implements Reject, HeaderTrailer {
    private long refSeqNum = FixMessage.UNSET_LONG;

    private long refTagID = FixMessage.UNSET_LONG;

    private char refMsgType = FixMessage.UNSET_CHAR;

    private long sessionRejectReason = FixMessage.UNSET_LONG;

    private String text = null;

    private long encodedTextLen = FixMessage.UNSET_LONG;

    private String encodedText = null;

    public char msgType() {
        return MessageManifest.Reject;
    }

    public long refSeqNum() {
        return refSeqNum;
    }

    @Override
    public void refSeqNum(long refSeqNum) {
        this.refSeqNum = refSeqNum;
    }

    public long refTagID() {
        return refTagID;
    }

    @Override
    public void refTagID(long refTagID) {
        this.refTagID = refTagID;
    }

    public char refMsgType() {
        return refMsgType;
    }

    @Override
    public void refMsgType(char refMsgType) {
        this.refMsgType = refMsgType;
    }

    public long sessionRejectReason() {
        return sessionRejectReason;
    }

    @Override
    public void sessionRejectReason(long sessionRejectReason) {
        this.sessionRejectReason = sessionRejectReason;
    }

    public String text() {
        return text;
    }

    @Override
    public void text(String text) {
        this.text = text;
    }

    public long encodedTextLen() {
        return encodedTextLen;
    }

    @Override
    public void encodedTextLen(long encodedTextLen) {
        this.encodedTextLen = encodedTextLen;
    }

    public String encodedText() {
        return encodedText;
    }

    @Override
    public void encodedText(String encodedText) {
        this.encodedText = encodedText;
    }

    @Override
    public void reset() {
        Reject.super.reset();
    }
}
