package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.fields.Account;
import software.chronicle.fix.codegen.fields.ClOrdID;
import software.chronicle.fix.codegen.fields.CrossInstruction;
import software.chronicle.fix.codegen.fields.CrossRestrictionClientID;
import software.chronicle.fix.codegen.fields.CrossStrategy;
import software.chronicle.fix.codegen.fields.CustomPrice1;
import software.chronicle.fix.codegen.fields.CustomerSlang;
import software.chronicle.fix.codegen.fields.CxlQty;
import software.chronicle.fix.codegen.fields.ExecInst;
import software.chronicle.fix.codegen.fields.HandlInst;
import software.chronicle.fix.codegen.fields.IDSource;
import software.chronicle.fix.codegen.fields.IOIID;
import software.chronicle.fix.codegen.fields.LeavesQty;
import software.chronicle.fix.codegen.fields.LocateBroker;
import software.chronicle.fix.codegen.fields.LocateIdentifier;
import software.chronicle.fix.codegen.fields.LocateReqd;
import software.chronicle.fix.codegen.fields.MinQty;
import software.chronicle.fix.codegen.fields.NoStrategyParameters;
import software.chronicle.fix.codegen.fields.OptOutLockedIn;
import software.chronicle.fix.codegen.fields.OrdStatus;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.OrderCapacity;
import software.chronicle.fix.codegen.fields.OrderID;
import software.chronicle.fix.codegen.fields.OrderQty;
import software.chronicle.fix.codegen.fields.OrderVersion;
import software.chronicle.fix.codegen.fields.PreviousLinkSrcSystemID;
import software.chronicle.fix.codegen.fields.Price;
import software.chronicle.fix.codegen.fields.ReceiveTime;
import software.chronicle.fix.codegen.fields.ReportToExch;
import software.chronicle.fix.codegen.fields.RootSrcSystemID;
import software.chronicle.fix.codegen.fields.SecurityAltID;
import software.chronicle.fix.codegen.fields.SecurityAltIDSource;
import software.chronicle.fix.codegen.fields.SecurityID;
import software.chronicle.fix.codegen.fields.ShortSaleExemptReason;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.fields.SrcTargetCompId;
import software.chronicle.fix.codegen.fields.StopPx;
import software.chronicle.fix.codegen.fields.StrategyParameterValue;
import software.chronicle.fix.codegen.fields.SumOfStopExecQty;
import software.chronicle.fix.codegen.fields.Symbol;
import software.chronicle.fix.codegen.fields.SymbolSfx;
import software.chronicle.fix.codegen.fields.TargetStrategy;
import software.chronicle.fix.codegen.fields.TargetStrategyParameters;
import software.chronicle.fix.codegen.fields.TimeInForce;
import software.chronicle.fix.codegen.fields.TimeToLive;
import software.chronicle.fix.codegen.fields.TransactTime;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface CioiDarkOrder extends HeaderTrailer, ClOrdID, Account, HandlInst, ExecInst, MinQty, Symbol, SymbolSfx, Side, LocateReqd, TransactTime, OrderQty, OrdType, Price, StopPx, IOIID, TimeInForce, OrderCapacity, TargetStrategy, TargetStrategyParameters, OrderVersion, TimeToLive, CustomPrice1, LocateBroker, LocateIdentifier, RootSrcSystemID, PreviousLinkSrcSystemID, OrderID, OrdStatus, CrossRestrictionClientID, LeavesQty, CxlQty, OptOutLockedIn, SumOfStopExecQty, CrossInstruction, CustomerSlang, NoStrategyParameters, ReceiveTime, StrategyParameterValue, ShortSaleExemptReason, CrossStrategy, SecurityID, IDSource, SecurityAltID, SecurityAltIDSource, SrcTargetCompId, ReportToExch {
    @Deprecated
    static CioiDarkOrder newCioiDarkOrder(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.CioiDarkOrder);
        mg.bytes(bytes);
        return mg;
    }

    static CioiDarkOrder newCioiDarkOrder(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.CioiDarkOrder, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (clOrdID() == null) throw new RequiredTagMissing("clOrdID", 11);
        if (symbol() == null) throw new RequiredTagMissing("symbol", 55);
        if (symbolSfx() == null) throw new RequiredTagMissing("symbolSfx", 65);
        if (side() == FixMessage.UNSET_CHAR) throw new RequiredTagMissing("side", 54);
        if (transactTime() == FixMessage.UNSET_LONG) throw new RequiredTagMissing("transactTime", 60);
        if (Double.isNaN(orderQty())) throw new RequiredTagMissing("orderQty", 38);
        if (ordType() == FixMessage.UNSET_CHAR) throw new RequiredTagMissing("ordType", 40);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        clOrdID(null);
        account(null);
        handlInst(FixMessage.UNSET_CHAR);
        execInst(null);
        minQty(FixMessage.UNSET_DOUBLE);
        symbol(null);
        symbolSfx(null);
        side(FixMessage.UNSET_CHAR);
        locateReqd(FixMessage.UNSET_CHAR);
        transactTime(FixMessage.UNSET_LONG);
        orderQty(FixMessage.UNSET_DOUBLE);
        ordType(FixMessage.UNSET_CHAR);
        price(FixMessage.UNSET_DOUBLE);
        stopPx(FixMessage.UNSET_DOUBLE);
        ioiID(null);
        timeInForce(FixMessage.UNSET_CHAR);
        orderCapacity(FixMessage.UNSET_CHAR);
        targetStrategy(FixMessage.UNSET_LONG);
        targetStrategyParameters(null);
        orderVersion(FixMessage.UNSET_LONG);
        timeToLive(FixMessage.UNSET_LONG);
        customPrice1(null);
        locateBroker(null);
        locateIdentifier(null);
        rootSrcSystemID(FixMessage.UNSET_LONG);
        previousLinkSrcSystemID(FixMessage.UNSET_LONG);
        orderID(null);
        ordStatus(FixMessage.UNSET_CHAR);
        crossRestrictionClientID(null);
        leavesQty(FixMessage.UNSET_DOUBLE);
        cxlQty(FixMessage.UNSET_DOUBLE);
        optOutLockedIn(null);
        sumOfStopExecQty(FixMessage.UNSET_DOUBLE);
        crossInstruction(null);
        customerSlang(null);
        noStrategyParameters(null);
        receiveTime(FixMessage.UNSET_LONG);
        strategyParameterValue(null);
        shortSaleExemptReason(null);
        crossStrategy(null);
        securityID(null);
        idSource(null);
        securityAltID(null);
        securityAltIDSource(null);
        srcTargetCompId(null);
        reportToExch(null);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((CioiDarkOrder) msg);
    }

    default void copyTo(CioiDarkOrder msg) {
        HeaderTrailer.super.copyTo(msg);
        if (clOrdID() != null) msg.clOrdID(clOrdID());
        if (account() != null) msg.account(account());
        if (handlInst() != FixMessage.UNSET_CHAR) msg.handlInst(handlInst());
        if (execInst() != null) msg.execInst(execInst());
        if (!Double.isNaN(minQty())) msg.minQty(minQty());
        if (symbol() != null) msg.symbol(symbol());
        if (symbolSfx() != null) msg.symbolSfx(symbolSfx());
        if (side() != FixMessage.UNSET_CHAR) msg.side(side());
        if (locateReqd() != FixMessage.UNSET_CHAR) msg.locateReqd(locateReqd());
        if (transactTime() != FixMessage.UNSET_LONG) msg.transactTime(transactTime());
        if (!Double.isNaN(orderQty())) msg.orderQty(orderQty());
        if (ordType() != FixMessage.UNSET_CHAR) msg.ordType(ordType());
        if (!Double.isNaN(price())) msg.price(price());
        if (!Double.isNaN(stopPx())) msg.stopPx(stopPx());
        if (ioiID() != null) msg.ioiID(ioiID());
        if (timeInForce() != FixMessage.UNSET_CHAR) msg.timeInForce(timeInForce());
        if (orderCapacity() != FixMessage.UNSET_CHAR) msg.orderCapacity(orderCapacity());
        if (targetStrategy() != FixMessage.UNSET_LONG) msg.targetStrategy(targetStrategy());
        if (targetStrategyParameters() != null) msg.targetStrategyParameters(targetStrategyParameters());
        if (orderVersion() != FixMessage.UNSET_LONG) msg.orderVersion(orderVersion());
        if (timeToLive() != FixMessage.UNSET_LONG) msg.timeToLive(timeToLive());
        if (customPrice1() != null) msg.customPrice1(customPrice1());
        if (locateBroker() != null) msg.locateBroker(locateBroker());
        if (locateIdentifier() != null) msg.locateIdentifier(locateIdentifier());
        if (rootSrcSystemID() != FixMessage.UNSET_LONG) msg.rootSrcSystemID(rootSrcSystemID());
        if (previousLinkSrcSystemID() != FixMessage.UNSET_LONG) msg.previousLinkSrcSystemID(previousLinkSrcSystemID());
        if (orderID() != null) msg.orderID(orderID());
        if (ordStatus() != FixMessage.UNSET_CHAR) msg.ordStatus(ordStatus());
        if (crossRestrictionClientID() != null) msg.crossRestrictionClientID(crossRestrictionClientID());
        if (!Double.isNaN(leavesQty())) msg.leavesQty(leavesQty());
        if (!Double.isNaN(cxlQty())) msg.cxlQty(cxlQty());
        if (optOutLockedIn() != null) msg.optOutLockedIn(optOutLockedIn());
        if (!Double.isNaN(sumOfStopExecQty())) msg.sumOfStopExecQty(sumOfStopExecQty());
        if (crossInstruction() != null) msg.crossInstruction(crossInstruction());
        if (customerSlang() != null) msg.customerSlang(customerSlang());
        if (noStrategyParameters() != null) msg.noStrategyParameters(noStrategyParameters());
        if (receiveTime() != FixMessage.UNSET_LONG) msg.receiveTime(receiveTime());
        if (strategyParameterValue() != null) msg.strategyParameterValue(strategyParameterValue());
        if (shortSaleExemptReason() != null) msg.shortSaleExemptReason(shortSaleExemptReason());
        if (crossStrategy() != null) msg.crossStrategy(crossStrategy());
        if (securityID() != null) msg.securityID(securityID());
        if (idSource() != null) msg.idSource(idSource());
        if (securityAltID() != null) msg.securityAltID(securityAltID());
        if (securityAltIDSource() != null) msg.securityAltIDSource(securityAltIDSource());
        if (srcTargetCompId() != null) msg.srcTargetCompId(srcTargetCompId());
        if (reportToExch() != null) msg.reportToExch(reportToExch());
    }
}
