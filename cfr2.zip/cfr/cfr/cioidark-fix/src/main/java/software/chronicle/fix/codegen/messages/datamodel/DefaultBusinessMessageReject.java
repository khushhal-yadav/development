package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.BusinessMessageReject;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultBusinessMessageReject extends DefaultHeaderTrailer implements BusinessMessageReject, HeaderTrailer {
    private long refSeqNum = FixMessage.UNSET_LONG;

    private char refMsgType = FixMessage.UNSET_CHAR;

    private String businessRejectRefID = null;

    private long businessRejectReason = FixMessage.UNSET_LONG;

    private String text = null;

    private long encodedTextLen = FixMessage.UNSET_LONG;

    private String encodedText = null;

    public char msgType() {
        return MessageManifest.BusinessMessageReject;
    }

    public long refSeqNum() {
        return refSeqNum;
    }

    @Override
    public void refSeqNum(long refSeqNum) {
        this.refSeqNum = refSeqNum;
    }

    public char refMsgType() {
        return refMsgType;
    }

    @Override
    public void refMsgType(char refMsgType) {
        this.refMsgType = refMsgType;
    }

    public String businessRejectRefID() {
        return businessRejectRefID;
    }

    @Override
    public void businessRejectRefID(String businessRejectRefID) {
        this.businessRejectRefID = businessRejectRefID;
    }

    public long businessRejectReason() {
        return businessRejectReason;
    }

    @Override
    public void businessRejectReason(long businessRejectReason) {
        this.businessRejectReason = businessRejectReason;
    }

    public String text() {
        return text;
    }

    @Override
    public void text(String text) {
        this.text = text;
    }

    public long encodedTextLen() {
        return encodedTextLen;
    }

    @Override
    public void encodedTextLen(long encodedTextLen) {
        this.encodedTextLen = encodedTextLen;
    }

    public String encodedText() {
        return encodedText;
    }

    @Override
    public void encodedText(String encodedText) {
        this.encodedText = encodedText;
    }

    @Override
    public void reset() {
        BusinessMessageReject.super.reset();
    }
}
