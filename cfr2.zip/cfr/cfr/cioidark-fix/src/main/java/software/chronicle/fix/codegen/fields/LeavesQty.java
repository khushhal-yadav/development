package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LeavesQty {
    /**
     * Tag number for this field
     */
    int FIELD = 151;

    /**
     * @param leavesQty &gt; FIX TAG 151
     */
    void leavesQty(double leavesQty);

    default double leavesQty() {
        throw new UnsupportedOperationException();
    }
}
