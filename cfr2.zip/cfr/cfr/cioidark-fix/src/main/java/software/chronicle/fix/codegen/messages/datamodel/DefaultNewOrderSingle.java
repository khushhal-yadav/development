package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import java.util.concurrent.TimeUnit;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultNewOrderSingle extends DefaultHeaderTrailer implements NewOrderSingle, HeaderTrailer {
    private String clOrdID = null;

    private char side = FixMessage.UNSET_CHAR;

    private double orderQty = FixMessage.UNSET_DOUBLE;

    private char ordType = FixMessage.UNSET_CHAR;

    private String symbol = null;

    private String symbolSfx = null;

    private String idSource = null;

    private char handlInst = FixMessage.UNSET_CHAR;

    private long transactTime = FixMessage.UNSET_LONG;

    private String account = null;

    private double price = FixMessage.UNSET_DOUBLE;

    private char timeInForce = FixMessage.UNSET_CHAR;

    private long createdNS = FixMessage.UNSET_LONG;

    private double lastTraded = FixMessage.UNSET_DOUBLE;

    private double bidPx = FixMessage.UNSET_DOUBLE;

    private double offerPx = FixMessage.UNSET_DOUBLE;

    private double bidSize = FixMessage.UNSET_DOUBLE;

    private double offerSize = FixMessage.UNSET_DOUBLE;

    private char orderCapacity = FixMessage.UNSET_CHAR;

    private char rule80A = FixMessage.UNSET_CHAR;

    private String currency = null;

    private String settlCurrency = null;

    private char settlmntTyp = FixMessage.UNSET_CHAR;

    private long customerOrFirm = FixMessage.UNSET_LONG;

    private String clientID = null;

    private String exDestination = null;

    private char locateReqd = FixMessage.UNSET_CHAR;

    private String ordLinkID = null;

    private String ordLinkType = null;

    private String bookingType = null;

    private String orderID = null;

    private String tradingAcct = null;

    private String ioiID = null;

    private String quoteID = null;

    private long quoteTime = FixMessage.UNSET_LONG;

    private long targetStrategy = FixMessage.UNSET_LONG;

    private String targetStrategyParameters = null;

    private long previousLinkSrcSystemID = FixMessage.UNSET_LONG;

    private char contraOrderCapacity = FixMessage.UNSET_CHAR;

    private String orderFlowEntry = null;

    private String orderFlowClass = null;

    private String traderID = null;

    private String avgPriceAcct = null;

    private String legalEntity = null;

    private String securityID = null;

    private String securityAltID = null;

    private String securityAltIDSource = null;

    private String crossInstruction = null;

    private String noStrategyParameters = null;

    private String strategyParameterValue = null;

    private long receiveTime = FixMessage.UNSET_LONG;

    private char ordStatus = FixMessage.UNSET_CHAR;

    private double sumOfStopExecQty = FixMessage.UNSET_DOUBLE;

    private double cxlQty = FixMessage.UNSET_DOUBLE;

    private String crossRestrictionClientID = null;

    private double leavesQty = FixMessage.UNSET_DOUBLE;

    private String srcTargetCompId = null;

    private String shortSaleExemptReason = null;

    private long timeToLive = FixMessage.UNSET_LONG;

    private String avgPriceAcctIDSource = null;

    private String tickSizePilotGroup = null;

    private String sourceFeed = null;

    private String customerSlang = null;

    private long rootSrcSystemID = FixMessage.UNSET_LONG;

    private String optOutLockedIn = null;

    private long srcSystemID = FixMessage.UNSET_LONG;

    private String orderFlowCategory = null;

    private String executedBy = null;

    private String tempLastMkt = null;

    private long noTempContraBrokers = FixMessage.UNSET_LONG;

    private String tempContraBroker = null;

    private String tempContraBrokerSrc = null;

    private long leafSrcSystemID = FixMessage.UNSET_LONG;

    private char isCurrExecLevel = FixMessage.UNSET_CHAR;

    private String contraAccount = null;

    private String contraAccountSrc = null;

    private String contraAccountType = null;

    private long noClearingInstructions = FixMessage.UNSET_LONG;

    private long clearingInstruction = FixMessage.UNSET_LONG;

    private String corellationClOrdID = null;

    private String previousLinkOrderID = null;

    private String rootOrderID = null;

    private String crossStrategy = null;

    private String reportToExch = null;

    private String customPrice1 = null;

    private double minQty = FixMessage.UNSET_DOUBLE;

    private String execInst = null;

    private String locateBroker = null;

    private String locateIdentifier = null;

    public char msgType() {
        return MessageManifest.NewOrderSingle;
    }

    public String clOrdID() {
        return clOrdID;
    }

    @Override
    public void clOrdID(String clOrdID) {
        this.clOrdID = clOrdID;
    }

    public char side() {
        return side;
    }

    @Override
    public void side(char side) {
        this.side = side;
    }

    public double orderQty() {
        return orderQty;
    }

    @Override
    public void orderQty(double orderQty) {
        this.orderQty = orderQty;
    }

    public char ordType() {
        return ordType;
    }

    @Override
    public void ordType(char ordType) {
        this.ordType = ordType;
    }

    public String symbol() {
        return symbol;
    }

    @Override
    public void symbol(String symbol) {
        this.symbol = symbol;
    }

    public String symbolSfx() {
        return symbolSfx;
    }

    @Override
    public void symbolSfx(String symbolSfx) {
        this.symbolSfx = symbolSfx;
    }

    public String idSource() {
        return idSource;
    }

    @Override
    public void idSource(String idSource) {
        this.idSource = idSource;
    }

    public char handlInst() {
        return handlInst;
    }

    @Override
    public void handlInst(char handlInst) {
        this.handlInst = handlInst;
    }

    public long transactTime() {
        return transactTime;
    }

    @Override
    public void transactTime(long transactTime, TimeUnit timeUnit) {
        transactTime(transactTime);
    }

    @Override
    public void transactTime(long transactTime) {
        this.transactTime = transactTime;
    }

    public String account() {
        return account;
    }

    @Override
    public void account(String account) {
        this.account = account;
    }

    public double price() {
        return price;
    }

    @Override
    public void price(double price) {
        this.price = price;
    }

    public char timeInForce() {
        return timeInForce;
    }

    @Override
    public void timeInForce(char timeInForce) {
        this.timeInForce = timeInForce;
    }

    public long createdNS() {
        return createdNS;
    }

    @Override
    public void createdNS(long createdNS) {
        this.createdNS = createdNS;
    }

    public double lastTraded() {
        return lastTraded;
    }

    @Override
    public void lastTraded(double lastTraded) {
        this.lastTraded = lastTraded;
    }

    public double bidPx() {
        return bidPx;
    }

    @Override
    public void bidPx(double bidPx) {
        this.bidPx = bidPx;
    }

    public double offerPx() {
        return offerPx;
    }

    @Override
    public void offerPx(double offerPx) {
        this.offerPx = offerPx;
    }

    public double bidSize() {
        return bidSize;
    }

    @Override
    public void bidSize(double bidSize) {
        this.bidSize = bidSize;
    }

    public double offerSize() {
        return offerSize;
    }

    @Override
    public void offerSize(double offerSize) {
        this.offerSize = offerSize;
    }

    public char orderCapacity() {
        return orderCapacity;
    }

    @Override
    public void orderCapacity(char orderCapacity) {
        this.orderCapacity = orderCapacity;
    }

    public char rule80A() {
        return rule80A;
    }

    @Override
    public void rule80A(char rule80A) {
        this.rule80A = rule80A;
    }

    public String currency() {
        return currency;
    }

    @Override
    public void currency(String currency) {
        this.currency = currency;
    }

    public String settlCurrency() {
        return settlCurrency;
    }

    @Override
    public void settlCurrency(String settlCurrency) {
        this.settlCurrency = settlCurrency;
    }

    public char settlmntTyp() {
        return settlmntTyp;
    }

    @Override
    public void settlmntTyp(char settlmntTyp) {
        this.settlmntTyp = settlmntTyp;
    }

    public long customerOrFirm() {
        return customerOrFirm;
    }

    @Override
    public void customerOrFirm(long customerOrFirm) {
        this.customerOrFirm = customerOrFirm;
    }

    public String clientID() {
        return clientID;
    }

    @Override
    public void clientID(String clientID) {
        this.clientID = clientID;
    }

    public String exDestination() {
        return exDestination;
    }

    @Override
    public void exDestination(String exDestination) {
        this.exDestination = exDestination;
    }

    public char locateReqd() {
        return locateReqd;
    }

    @Override
    public void locateReqd(char locateReqd) {
        this.locateReqd = locateReqd;
    }

    public String ordLinkID() {
        return ordLinkID;
    }

    @Override
    public void ordLinkID(String ordLinkID) {
        this.ordLinkID = ordLinkID;
    }

    public String ordLinkType() {
        return ordLinkType;
    }

    @Override
    public void ordLinkType(String ordLinkType) {
        this.ordLinkType = ordLinkType;
    }

    public String bookingType() {
        return bookingType;
    }

    @Override
    public void bookingType(String bookingType) {
        this.bookingType = bookingType;
    }

    public String orderID() {
        return orderID;
    }

    @Override
    public void orderID(String orderID) {
        this.orderID = orderID;
    }

    public String tradingAcct() {
        return tradingAcct;
    }

    @Override
    public void tradingAcct(String tradingAcct) {
        this.tradingAcct = tradingAcct;
    }

    public String ioiID() {
        return ioiID;
    }

    @Override
    public void ioiID(String ioiID) {
        this.ioiID = ioiID;
    }

    public String quoteID() {
        return quoteID;
    }

    @Override
    public void quoteID(String quoteID) {
        this.quoteID = quoteID;
    }

    public long quoteTime() {
        return quoteTime;
    }

    @Override
    public void quoteTime(long quoteTime, TimeUnit timeUnit) {
        quoteTime(quoteTime);
    }

    @Override
    public void quoteTime(long quoteTime) {
        this.quoteTime = quoteTime;
    }

    public long targetStrategy() {
        return targetStrategy;
    }

    @Override
    public void targetStrategy(long targetStrategy) {
        this.targetStrategy = targetStrategy;
    }

    public String targetStrategyParameters() {
        return targetStrategyParameters;
    }

    @Override
    public void targetStrategyParameters(String targetStrategyParameters) {
        this.targetStrategyParameters = targetStrategyParameters;
    }

    public long previousLinkSrcSystemID() {
        return previousLinkSrcSystemID;
    }

    @Override
    public void previousLinkSrcSystemID(long previousLinkSrcSystemID) {
        this.previousLinkSrcSystemID = previousLinkSrcSystemID;
    }

    public char contraOrderCapacity() {
        return contraOrderCapacity;
    }

    @Override
    public void contraOrderCapacity(char contraOrderCapacity) {
        this.contraOrderCapacity = contraOrderCapacity;
    }

    public String orderFlowEntry() {
        return orderFlowEntry;
    }

    @Override
    public void orderFlowEntry(String orderFlowEntry) {
        this.orderFlowEntry = orderFlowEntry;
    }

    public String orderFlowClass() {
        return orderFlowClass;
    }

    @Override
    public void orderFlowClass(String orderFlowClass) {
        this.orderFlowClass = orderFlowClass;
    }

    public String traderID() {
        return traderID;
    }

    @Override
    public void traderID(String traderID) {
        this.traderID = traderID;
    }

    public String avgPriceAcct() {
        return avgPriceAcct;
    }

    @Override
    public void avgPriceAcct(String avgPriceAcct) {
        this.avgPriceAcct = avgPriceAcct;
    }

    public String legalEntity() {
        return legalEntity;
    }

    @Override
    public void legalEntity(String legalEntity) {
        this.legalEntity = legalEntity;
    }

    public String securityID() {
        return securityID;
    }

    @Override
    public void securityID(String securityID) {
        this.securityID = securityID;
    }

    public String securityAltID() {
        return securityAltID;
    }

    @Override
    public void securityAltID(String securityAltID) {
        this.securityAltID = securityAltID;
    }

    public String securityAltIDSource() {
        return securityAltIDSource;
    }

    @Override
    public void securityAltIDSource(String securityAltIDSource) {
        this.securityAltIDSource = securityAltIDSource;
    }

    public String crossInstruction() {
        return crossInstruction;
    }

    @Override
    public void crossInstruction(String crossInstruction) {
        this.crossInstruction = crossInstruction;
    }

    public String noStrategyParameters() {
        return noStrategyParameters;
    }

    @Override
    public void noStrategyParameters(String noStrategyParameters) {
        this.noStrategyParameters = noStrategyParameters;
    }

    public String strategyParameterValue() {
        return strategyParameterValue;
    }

    @Override
    public void strategyParameterValue(String strategyParameterValue) {
        this.strategyParameterValue = strategyParameterValue;
    }

    public long receiveTime() {
        return receiveTime;
    }

    @Override
    public void receiveTime(long receiveTime, TimeUnit timeUnit) {
        receiveTime(receiveTime);
    }

    @Override
    public void receiveTime(long receiveTime) {
        this.receiveTime = receiveTime;
    }

    public char ordStatus() {
        return ordStatus;
    }

    @Override
    public void ordStatus(char ordStatus) {
        this.ordStatus = ordStatus;
    }

    public double sumOfStopExecQty() {
        return sumOfStopExecQty;
    }

    @Override
    public void sumOfStopExecQty(double sumOfStopExecQty) {
        this.sumOfStopExecQty = sumOfStopExecQty;
    }

    public double cxlQty() {
        return cxlQty;
    }

    @Override
    public void cxlQty(double cxlQty) {
        this.cxlQty = cxlQty;
    }

    public String crossRestrictionClientID() {
        return crossRestrictionClientID;
    }

    @Override
    public void crossRestrictionClientID(String crossRestrictionClientID) {
        this.crossRestrictionClientID = crossRestrictionClientID;
    }

    public double leavesQty() {
        return leavesQty;
    }

    @Override
    public void leavesQty(double leavesQty) {
        this.leavesQty = leavesQty;
    }

    public String srcTargetCompId() {
        return srcTargetCompId;
    }

    @Override
    public void srcTargetCompId(String srcTargetCompId) {
        this.srcTargetCompId = srcTargetCompId;
    }

    public String shortSaleExemptReason() {
        return shortSaleExemptReason;
    }

    @Override
    public void shortSaleExemptReason(String shortSaleExemptReason) {
        this.shortSaleExemptReason = shortSaleExemptReason;
    }

    public long timeToLive() {
        return timeToLive;
    }

    @Override
    public void timeToLive(long timeToLive, TimeUnit timeUnit) {
        timeToLive(timeToLive);
    }

    @Override
    public void timeToLive(long timeToLive) {
        this.timeToLive = timeToLive;
    }

    public String avgPriceAcctIDSource() {
        return avgPriceAcctIDSource;
    }

    @Override
    public void avgPriceAcctIDSource(String avgPriceAcctIDSource) {
        this.avgPriceAcctIDSource = avgPriceAcctIDSource;
    }

    public String tickSizePilotGroup() {
        return tickSizePilotGroup;
    }

    @Override
    public void tickSizePilotGroup(String tickSizePilotGroup) {
        this.tickSizePilotGroup = tickSizePilotGroup;
    }

    public String sourceFeed() {
        return sourceFeed;
    }

    @Override
    public void sourceFeed(String sourceFeed) {
        this.sourceFeed = sourceFeed;
    }

    public String customerSlang() {
        return customerSlang;
    }

    @Override
    public void customerSlang(String customerSlang) {
        this.customerSlang = customerSlang;
    }

    public long rootSrcSystemID() {
        return rootSrcSystemID;
    }

    @Override
    public void rootSrcSystemID(long rootSrcSystemID) {
        this.rootSrcSystemID = rootSrcSystemID;
    }

    public String optOutLockedIn() {
        return optOutLockedIn;
    }

    @Override
    public void optOutLockedIn(String optOutLockedIn) {
        this.optOutLockedIn = optOutLockedIn;
    }

    public long srcSystemID() {
        return srcSystemID;
    }

    @Override
    public void srcSystemID(long srcSystemID) {
        this.srcSystemID = srcSystemID;
    }

    public String orderFlowCategory() {
        return orderFlowCategory;
    }

    @Override
    public void orderFlowCategory(String orderFlowCategory) {
        this.orderFlowCategory = orderFlowCategory;
    }

    public String executedBy() {
        return executedBy;
    }

    @Override
    public void executedBy(String executedBy) {
        this.executedBy = executedBy;
    }

    public String tempLastMkt() {
        return tempLastMkt;
    }

    @Override
    public void tempLastMkt(String tempLastMkt) {
        this.tempLastMkt = tempLastMkt;
    }

    public long noTempContraBrokers() {
        return noTempContraBrokers;
    }

    @Override
    public void noTempContraBrokers(long noTempContraBrokers) {
        this.noTempContraBrokers = noTempContraBrokers;
    }

    public String tempContraBroker() {
        return tempContraBroker;
    }

    @Override
    public void tempContraBroker(String tempContraBroker) {
        this.tempContraBroker = tempContraBroker;
    }

    public String tempContraBrokerSrc() {
        return tempContraBrokerSrc;
    }

    @Override
    public void tempContraBrokerSrc(String tempContraBrokerSrc) {
        this.tempContraBrokerSrc = tempContraBrokerSrc;
    }

    public long leafSrcSystemID() {
        return leafSrcSystemID;
    }

    @Override
    public void leafSrcSystemID(long leafSrcSystemID) {
        this.leafSrcSystemID = leafSrcSystemID;
    }

    public char isCurrExecLevel() {
        return isCurrExecLevel;
    }

    @Override
    public void isCurrExecLevel(char isCurrExecLevel) {
        this.isCurrExecLevel = isCurrExecLevel;
    }

    public String contraAccount() {
        return contraAccount;
    }

    @Override
    public void contraAccount(String contraAccount) {
        this.contraAccount = contraAccount;
    }

    public String contraAccountSrc() {
        return contraAccountSrc;
    }

    @Override
    public void contraAccountSrc(String contraAccountSrc) {
        this.contraAccountSrc = contraAccountSrc;
    }

    public String contraAccountType() {
        return contraAccountType;
    }

    @Override
    public void contraAccountType(String contraAccountType) {
        this.contraAccountType = contraAccountType;
    }

    public long noClearingInstructions() {
        return noClearingInstructions;
    }

    @Override
    public void noClearingInstructions(long noClearingInstructions) {
        this.noClearingInstructions = noClearingInstructions;
    }

    public long clearingInstruction() {
        return clearingInstruction;
    }

    @Override
    public void clearingInstruction(long clearingInstruction) {
        this.clearingInstruction = clearingInstruction;
    }

    public String corellationClOrdID() {
        return corellationClOrdID;
    }

    @Override
    public void corellationClOrdID(String corellationClOrdID) {
        this.corellationClOrdID = corellationClOrdID;
    }

    public String previousLinkOrderID() {
        return previousLinkOrderID;
    }

    @Override
    public void previousLinkOrderID(String previousLinkOrderID) {
        this.previousLinkOrderID = previousLinkOrderID;
    }

    public String rootOrderID() {
        return rootOrderID;
    }

    @Override
    public void rootOrderID(String rootOrderID) {
        this.rootOrderID = rootOrderID;
    }

    public String crossStrategy() {
        return crossStrategy;
    }

    @Override
    public void crossStrategy(String crossStrategy) {
        this.crossStrategy = crossStrategy;
    }

    public String reportToExch() {
        return reportToExch;
    }

    @Override
    public void reportToExch(String reportToExch) {
        this.reportToExch = reportToExch;
    }

    public String customPrice1() {
        return customPrice1;
    }

    @Override
    public void customPrice1(String customPrice1) {
        this.customPrice1 = customPrice1;
    }

    public double minQty() {
        return minQty;
    }

    @Override
    public void minQty(double minQty) {
        this.minQty = minQty;
    }

    public String execInst() {
        return execInst;
    }

    @Override
    public void execInst(String execInst) {
        this.execInst = execInst;
    }

    public String locateBroker() {
        return locateBroker;
    }

    @Override
    public void locateBroker(String locateBroker) {
        this.locateBroker = locateBroker;
    }

    public String locateIdentifier() {
        return locateIdentifier;
    }

    @Override
    public void locateIdentifier(String locateIdentifier) {
        this.locateIdentifier = locateIdentifier;
    }

    @Override
    public void reset() {
        NewOrderSingle.super.reset();
    }
}
