package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.fields.EncodedText;
import software.chronicle.fix.codegen.fields.EncodedTextLen;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.fields.RefMsgType;
import software.chronicle.fix.sessioncode.fields.RefSeqNum;
import software.chronicle.fix.sessioncode.fields.RefTagID;
import software.chronicle.fix.sessioncode.fields.SessionRejectReason;
import software.chronicle.fix.sessioncode.fields.Text;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface Reject extends HeaderTrailer, software.chronicle.fix.sessioncode.messages.Reject, RefSeqNum, RefTagID, RefMsgType, SessionRejectReason, Text, EncodedTextLen, EncodedText {
    @Deprecated
    static Reject newReject(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.Reject);
        mg.bytes(bytes);
        return mg;
    }

    static Reject newReject(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.Reject, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (refSeqNum() == FixMessage.UNSET_LONG) throw new RequiredTagMissing("refSeqNum", 45);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        refSeqNum(FixMessage.UNSET_LONG);
        refTagID(FixMessage.UNSET_LONG);
        refMsgType(FixMessage.UNSET_CHAR);
        sessionRejectReason(FixMessage.UNSET_LONG);
        text(null);
        encodedTextLen(FixMessage.UNSET_LONG);
        encodedText(null);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((Reject) msg);
    }

    default void copyTo(Reject msg) {
        HeaderTrailer.super.copyTo(msg);
        if (refSeqNum() != FixMessage.UNSET_LONG) msg.refSeqNum(refSeqNum());
        if (refTagID() != FixMessage.UNSET_LONG) msg.refTagID(refTagID());
        if (refMsgType() != FixMessage.UNSET_CHAR) msg.refMsgType(refMsgType());
        if (sessionRejectReason() != FixMessage.UNSET_LONG) msg.sessionRejectReason(sessionRejectReason());
        if (text() != null) msg.text(text());
        if (encodedTextLen() != FixMessage.UNSET_LONG) msg.encodedTextLen(encodedTextLen());
        if (encodedText() != null) msg.encodedText(encodedText());
    }
}
