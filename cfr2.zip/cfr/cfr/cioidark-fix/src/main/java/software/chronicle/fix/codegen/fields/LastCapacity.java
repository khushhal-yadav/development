package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LastCapacity {
    /**
     * Tag number for this field
     */
    int FIELD = 29;

    /**
     * @param lastCapacity &gt; FIX TAG 29
     */
    void lastCapacity(String lastCapacity);

    default String lastCapacity() {
        throw new UnsupportedOperationException();
    }
}
