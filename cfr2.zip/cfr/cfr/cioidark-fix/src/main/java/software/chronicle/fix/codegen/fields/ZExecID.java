package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ZExecID {
    /**
     * Tag number for this field
     */
    int FIELD = 10018;

    /**
     * @param zExecID &gt; FIX TAG 10018
     */
    void zExecID(String zExecID);

    default String zExecID() {
        throw new UnsupportedOperationException();
    }
}
