package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.TestRequest;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultTestRequest extends DefaultHeaderTrailer implements TestRequest, HeaderTrailer {
    private String testReqID = null;

    public char msgType() {
        return MessageManifest.TestRequest;
    }

    public String testReqID() {
        return testReqID;
    }

    @Override
    public void testReqID(String testReqID) {
        this.testReqID = testReqID;
    }

    @Override
    public void reset() {
        TestRequest.super.reset();
    }
}
