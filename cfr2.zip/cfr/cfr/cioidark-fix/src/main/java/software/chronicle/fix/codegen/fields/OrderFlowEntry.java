package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrderFlowEntry {
    /**
     * Tag number for this field
     */
    int FIELD = 10201;

    /**
     * @param orderFlowEntry &gt; FIX TAG 10201
     */
    void orderFlowEntry(String orderFlowEntry);

    default String orderFlowEntry() {
        throw new UnsupportedOperationException();
    }
}
