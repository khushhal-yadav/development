package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ContraBroker {
    /**
     * Tag number for this field
     */
    int FIELD = 375;

    /**
     * @param contraBroker &gt; FIX TAG 375
     */
    void contraBroker(String contraBroker);

    default String contraBroker() {
        throw new UnsupportedOperationException();
    }
}
