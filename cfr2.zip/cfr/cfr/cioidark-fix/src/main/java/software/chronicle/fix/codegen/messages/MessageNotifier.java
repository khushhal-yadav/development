package software.chronicle.fix.codegen.messages;

import java.io.StringWriter;
import java.lang.String;
import java.util.concurrent.BlockingQueue;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.generators.CoreGeneratorBase;

/**
 * Generated at software.chronicle.fix.codegen.MessageFactoryGenerator.generate(MessageFactoryGenerator.java)
 */
public interface MessageNotifier extends software.chronicle.fix.sessioncode.messages.MessageNotifier {
    static MessageNotifier printing(String description) {
        return net.openhft.chronicle.core.Mocker.logging(MessageNotifier.class, description, System.out);
    }

    static MessageNotifier logging(String description, StringWriter out) {
        return net.openhft.chronicle.core.Mocker.logging(MessageNotifier.class, description, out);
    }

    static MessageNotifier queuing(String description, BlockingQueue<String> q) {
        return net.openhft.chronicle.core.Mocker.queuing(MessageNotifier.class, description, q);
    }

    static MessageNotifier ignored() {
        return net.openhft.chronicle.core.Mocker.ignored(MessageNotifier.class);
    }

    default void onHeartbeat(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Heartbeat heartbeat) {
        onHeartbeat(session, (Heartbeat) heartbeat);
    }

    default void onHeartbeat(FixSessionHandler session, Heartbeat heartbeat) {
    }

    default void onLogon(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Logon logon) {
        onLogon(session, (Logon) logon);
    }

    default void onLogon(FixSessionHandler session, Logon logon) {
    }

    default void onTestRequest(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.TestRequest testRequest) {
        onTestRequest(session, (TestRequest) testRequest);
    }

    default void onTestRequest(FixSessionHandler session, TestRequest testRequest) {
    }

    default void onResendRequest(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.ResendRequest resendRequest) {
        onResendRequest(session, (ResendRequest) resendRequest);
    }

    default void onResendRequest(FixSessionHandler session, ResendRequest resendRequest) {
    }

    default void onReject(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Reject reject) {
        onReject(session, (Reject) reject);
    }

    default void onReject(FixSessionHandler session, Reject reject) {
    }

    default void onSequenceReset(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.SequenceReset sequenceReset) {
        onSequenceReset(session, (SequenceReset) sequenceReset);
    }

    default void onSequenceReset(FixSessionHandler session, SequenceReset sequenceReset) {
    }

    default void onLogout(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Logout logout) {
        onLogout(session, (Logout) logout);
    }

    default void onLogout(FixSessionHandler session, Logout logout) {
    }

    default MessageGenerator onNewOrderSingle(NewOrderSingle newOrderSingle) {
        return null;
    }

    default void onNewOrderSingle(FixSessionHandler session, NewOrderSingle newOrderSingle) {
        CoreGeneratorBase mg = onNewOrderSingle(newOrderSingle);
        if (mg != null) session.sendMessage(mg);
    }

    default MessageGenerator onOrderCancelRequest(OrderCancelRequest orderCancelRequest) {
        return null;
    }

    default void onOrderCancelRequest(FixSessionHandler session, OrderCancelRequest orderCancelRequest) {
        CoreGeneratorBase mg = onOrderCancelRequest(orderCancelRequest);
        if (mg != null) session.sendMessage(mg);
    }

    default MessageGenerator onOrderCancelReplaceRequest(OrderCancelReplaceRequest orderCancelReplaceRequest) {
        return null;
    }

    default void onOrderCancelReplaceRequest(FixSessionHandler session, OrderCancelReplaceRequest orderCancelReplaceRequest) {
        CoreGeneratorBase mg = onOrderCancelReplaceRequest(orderCancelReplaceRequest);
        if (mg != null) session.sendMessage(mg);
    }

    default MessageGenerator onExecutionReport(ExecutionReport executionReport) {
        return null;
    }

    default void onExecutionReport(FixSessionHandler session, ExecutionReport executionReport) {
        CoreGeneratorBase mg = onExecutionReport(executionReport);
        if (mg != null) session.sendMessage(mg);
    }

    default MessageGenerator onOrderCancelReject(OrderCancelReject orderCancelReject) {
        return null;
    }

    default void onOrderCancelReject(FixSessionHandler session, OrderCancelReject orderCancelReject) {
        CoreGeneratorBase mg = onOrderCancelReject(orderCancelReject);
        if (mg != null) session.sendMessage(mg);
    }

    default MessageGenerator onDontKnowTrade(DontKnowTrade dontKnowTrade) {
        return null;
    }

    default void onDontKnowTrade(FixSessionHandler session, DontKnowTrade dontKnowTrade) {
        CoreGeneratorBase mg = onDontKnowTrade(dontKnowTrade);
        if (mg != null) session.sendMessage(mg);
    }

    default MessageGenerator onRIOMessage(RIOMessage rIOMessage) {
        return null;
    }

    default void onRIOMessage(FixSessionHandler session, RIOMessage rIOMessage) {
        CoreGeneratorBase mg = onRIOMessage(rIOMessage);
        if (mg != null) session.sendMessage(mg);
    }

    default MessageGenerator onMarketDataSnapshotFullRefresh(MarketDataSnapshotFullRefresh marketDataSnapshotFullRefresh) {
        return null;
    }

    default void onMarketDataSnapshotFullRefresh(FixSessionHandler session, MarketDataSnapshotFullRefresh marketDataSnapshotFullRefresh) {
        CoreGeneratorBase mg = onMarketDataSnapshotFullRefresh(marketDataSnapshotFullRefresh);
        if (mg != null) session.sendMessage(mg);
    }

    default MessageGenerator onBusinessMessageReject(BusinessMessageReject businessMessageReject) {
        return null;
    }

    default void onBusinessMessageReject(FixSessionHandler session, BusinessMessageReject businessMessageReject) {
        CoreGeneratorBase mg = onBusinessMessageReject(businessMessageReject);
        if (mg != null) session.sendMessage(mg);
    }

    default MessageGenerator onCioiDarkOrder(CioiDarkOrder cioiDarkOrder) {
        return null;
    }

    default void onCioiDarkOrder(FixSessionHandler session, CioiDarkOrder cioiDarkOrder) {
        CoreGeneratorBase mg = onCioiDarkOrder(cioiDarkOrder);
        if (mg != null) session.sendMessage(mg);
    }
}
