package software.chronicle.fix.codegen;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.initFieldManifest(FieldGenerator.java)
 */
public interface FieldManifest {
    int Account = 1;

    int AccountIDSource = 660;

    int AccountType = 581;

    int ActReport = 11037;

    int AskPrice = 11006;

    int AvgPriceAcct = 10051;

    int AvgPriceAcctIDSource = 10428;

    int AvgPx = 6;

    int BeginSeqNo = 7;

    int BeginString = 8;

    int BidPrice = 11005;

    int BidPx = 132;

    int BidSize = 134;

    int BodyLength = 9;

    int BookingType = 775;

    int BusinessRejectReason = 380;

    int BusinessRejectRefID = 379;

    int CashOrderQty = 152;

    int ChannelName = 10053;

    int CheckSum = 10;

    int ClOrdID = 11;

    int ClearingInstruction = 577;

    int ClientID = 109;

    int ConditionalOrderQty = 8060;

    int ContraAccount = 10514;

    int ContraAccountSrc = 11040;

    int ContraAccountType = 11041;

    int ContraBroker = 375;

    int ContraOrderCapacity = 10158;

    int ContractMultiplier = 231;

    int CorellationClOrdID = 9717;

    int CorporateAction = 292;

    int Country = 421;

    int CouponRate = 223;

    int CreatedNS = 9999;

    int CrossID = 548;

    int CrossInstruction = 6438;

    int CrossRestrictionClientID = 10896;

    int CrossStrategy = 7411;

    int CumQty = 14;

    int Currency = 15;

    int CustomPrice1 = 7491;

    int CustomerOrFirm = 204;

    int CustomerSlang = 8004;

    int CxlQty = 84;

    int CxlReason = 6042;

    int CxlRejReason = 102;

    int CxlRejResponseTo = 434;

    int DKReason = 127;

    int DeliverToCompID = 128;

    int DeliverToSubID = 129;

    int DeltaPx = 9002;

    int DeltaQty = 9001;

    int DeskID = 284;

    int EncodedIssuer = 349;

    int EncodedIssuerLen = 348;

    int EncodedSecurityDesc = 351;

    int EncodedSecurityDescLen = 350;

    int EncodedText = 355;

    int EncodedTextLen = 354;

    int EncryptMethod = 98;

    int EndSeqNo = 16;

    int ExDestination = 100;

    int ExDestinationIDSource = 1133;

    int ExecID = 17;

    int ExecInst = 18;

    int ExecRefID = 19;

    int ExecRestatementReason = 378;

    int ExecTransType = 20;

    int ExecType = 150;

    int ExecutedBy = 10021;

    int ExpireDate = 432;

    int ExpireTime = 126;

    int FinancialStatus = 291;

    int FirmId = 10054;

    int GapFillFlag = 123;

    int HandlInst = 21;

    int HeartBtInt = 108;

    int IDSource = 22;

    int IOIID = 23;

    int IsCurrExecLevel = 11027;

    int IsRioStateEvent = 10104;

    int Issuer = 106;

    int LULDLowerPriceBand = 10721;

    int LULDPriceBandTimestamp = 10723;

    int LULDUpperPriceBand = 10722;

    int LafExecID = 10964;

    int LastCapacity = 29;

    int LastMkt = 30;

    int LastParPx = 669;

    int LastPx = 31;

    int LastShares = 32;

    int LastTraded = 11001;

    int LastTradedDelta = 11002;

    int LeafExecFlag = 10217;

    int LeafExecutionFlag = 10217;

    int LeafSrcSystemID = 10965;

    int LeavesQty = 151;

    int LegalEntity = 10031;

    int LocateBroker = 5700;

    int LocateIdentifier = 5701;

    int LocateReqd = 114;

    int LocationID = 283;

    int MDEntryBuyer = 288;

    int MDEntryDate = 272;

    int MDEntryOriginator = 282;

    int MDEntryPositionNo = 290;

    int MDEntryPx = 270;

    int MDEntrySeller = 289;

    int MDEntrySize = 271;

    int MDEntryTime = 273;

    int MDEntryType = 269;

    int MDMkt = 275;

    int MDReqID = 262;

    int MaturityDay = 205;

    int MaturityMonthYear = 200;

    int MinQty = 110;

    int MsgSeqNum = 34;

    int MsgType = 35;

    int NewSeqNo = 36;

    int NoClearingInstructions = 576;

    int NoMDEntries = 268;

    int NoStrategyParameters = 957;

    int NoTempContraBrokers = 10533;

    int NumberOfOrders = 346;

    int OfferPx = 133;

    int OfferSize = 135;

    int OnBehalfOfCompID = 115;

    int OnBehalfOfSubID = 116;

    int OpenCloseSettleFlag = 286;

    int OpenQty = 11007;

    int OptAttribute = 206;

    int OptOutLockedIn = 10565;

    int OrdLinkID = 11053;

    int OrdLinkType = 11052;

    int OrdRejReason = 103;

    int OrdStatus = 39;

    int OrdType = 40;

    int OrderCapacity = 528;

    int OrderFlowCategory = 10202;

    int OrderFlowClass = 10201;

    int OrderFlowEntry = 10201;

    int OrderID = 37;

    int OrderPlacer = 10895;

    int OrderQty = 38;

    int OrderRestrictions = 529;

    int OrderUniqID = 10439;

    int OrderVersion = 12052;

    int OrigClOrdID = 41;

    int OrigCrossID = 551;

    int OrigSendingTime = 122;

    int ParentOrderUniqID = 10517;

    int Password = 554;

    int PossDupFlag = 43;

    int PossResend = 97;

    int PreviousLinkOrderID = 10184;

    int PreviousLinkOrderUniqID = 10519;

    int PreviousLinkSrcSystemID = 10518;

    int Price = 44;

    int PriceType = 423;

    int PutOrCall = 201;

    int QuoteCondition = 276;

    int QuoteEntryID = 299;

    int QuoteID = 117;

    int QuoteTime = 11048;

    int RawData = 96;

    int RawDataLength = 95;

    int ReceiveTime = 10080;

    int RefMsgType = 372;

    int RefSeqNum = 45;

    int RefTagID = 371;

    int ReplayInd = 10657;

    int ReportToExch = 113;

    int ResetSeqNumFlag = 141;

    int RioBeginString = 10438;

    int RioMinorVersion = 10653;

    int RioMsgSeq = 10655;

    int RioMsgSeqSrc = 10658;

    int RioMsgSource = 10208;

    int RioTimestamp = 10071;

    int RioTransactTime = 10436;

    int RootOrderID = 11210;

    int RootOrderUniqID = 10516;

    int RootSrcSystemID = 10515;

    int Rule80A = 47;

    int SalesPersonID = 10036;

    int SecurityAltID = 455;

    int SecurityAltIDSource = 456;

    int SecurityDesc = 107;

    int SecurityExchange = 207;

    int SecurityID = 48;

    int SecurityType = 167;

    int SellerDays = 287;

    int SenderCompID = 49;

    int SenderSubID = 50;

    int SendingTime = 52;

    int SessionRejectReason = 373;

    int SettlCurrAmt = 119;

    int SettlCurrFxRate = 155;

    int SettlCurrFxRateCalc = 156;

    int SettlCurrency = 120;

    int SettlmntTyp = 63;

    int ShortSaleExemptReason = 1688;

    int Side = 54;

    int SourceFeed = 11328;

    int SrcSystemID = 10005;

    int SrcTargetCompId = 10084;

    int StopPx = 99;

    int StrategyParameterValue = 960;

    int StrikePrice = 202;

    int SumOfStopExecQty = 10065;

    int Symbol = 55;

    int SymbolSfx = 65;

    int TargetCompID = 56;

    int TargetStrategy = 847;

    int TargetStrategyParameters = 848;

    int TargetSubID = 57;

    int TempContraBroker = 10534;

    int TempContraBrokerSrc = 10535;

    int TempLastMkt = 10537;

    int TestReqID = 112;

    int Text = 58;

    int TickDirection = 274;

    int TickSizePilotGroup = 11319;

    int Tier = 10270;

    int TimeInForce = 59;

    int TimeToLive = 10014;

    int TotalVolumeTraded = 387;

    int TradeCondition = 277;

    int TradeDate = 75;

    int TraderID = 10039;

    int TradingAcct = 10050;

    int TradingSessionID = 336;

    int TransactTime = 60;

    int TrdType = 828;

    int Username = 553;

    int XLastActivityUserID = 10241;

    int XParentOrderID = 10243;

    int ZExecID = 10018;
}
