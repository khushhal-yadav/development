package software.chronicle.fix.codegen.components;

import software.chronicle.fix.codegen.fields.Currency;
import software.chronicle.fix.codegen.fields.DeskID;
import software.chronicle.fix.codegen.fields.EncodedText;
import software.chronicle.fix.codegen.fields.EncodedTextLen;
import software.chronicle.fix.codegen.fields.ExecInst;
import software.chronicle.fix.codegen.fields.ExpireDate;
import software.chronicle.fix.codegen.fields.ExpireTime;
import software.chronicle.fix.codegen.fields.LocationID;
import software.chronicle.fix.codegen.fields.MDEntryBuyer;
import software.chronicle.fix.codegen.fields.MDEntryDate;
import software.chronicle.fix.codegen.fields.MDEntryOriginator;
import software.chronicle.fix.codegen.fields.MDEntryPositionNo;
import software.chronicle.fix.codegen.fields.MDEntryPx;
import software.chronicle.fix.codegen.fields.MDEntrySeller;
import software.chronicle.fix.codegen.fields.MDEntrySize;
import software.chronicle.fix.codegen.fields.MDEntryTime;
import software.chronicle.fix.codegen.fields.MDEntryType;
import software.chronicle.fix.codegen.fields.MDMkt;
import software.chronicle.fix.codegen.fields.MinQty;
import software.chronicle.fix.codegen.fields.NumberOfOrders;
import software.chronicle.fix.codegen.fields.OpenCloseSettleFlag;
import software.chronicle.fix.codegen.fields.OrderID;
import software.chronicle.fix.codegen.fields.QuoteCondition;
import software.chronicle.fix.codegen.fields.QuoteEntryID;
import software.chronicle.fix.codegen.fields.SellerDays;
import software.chronicle.fix.codegen.fields.TickDirection;
import software.chronicle.fix.codegen.fields.TimeInForce;
import software.chronicle.fix.codegen.fields.TradeCondition;
import software.chronicle.fix.codegen.fields.TradingSessionID;
import software.chronicle.fix.sessioncode.fields.Text;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.ComponentGenerator.generateComponent(ComponentGenerator.java)
 */
public interface MarketDataSnapshotFullRefresh_MDEntriesGrp_1 extends MDEntryType, MDEntryPx, Currency, MDEntrySize, MDEntryDate, MDEntryTime, TickDirection, MDMkt, TradingSessionID, QuoteCondition, TradeCondition, MDEntryOriginator, LocationID, DeskID, OpenCloseSettleFlag, TimeInForce, ExpireDate, ExpireTime, MinQty, ExecInst, SellerDays, OrderID, QuoteEntryID, MDEntryBuyer, MDEntrySeller, NumberOfOrders, MDEntryPositionNo, Text, EncodedTextLen, EncodedText {
    /**
     * Tag number for this group
     */
    int FIELD = 268;

    default void copyTo(MarketDataSnapshotFullRefresh_MDEntriesGrp_1 msg) {
        if (mDEntryType() != FixMessage.UNSET_CHAR) msg.mDEntryType(mDEntryType());
        if (!Double.isNaN(mDEntryPx())) msg.mDEntryPx(mDEntryPx());
        if (currency() != null) msg.currency(currency());
        if (!Double.isNaN(mDEntrySize())) msg.mDEntrySize(mDEntrySize());
        if (mDEntryDate() != null) msg.mDEntryDate(mDEntryDate());
        if (mDEntryTime() != null) msg.mDEntryTime(mDEntryTime());
        if (tickDirection() != FixMessage.UNSET_CHAR) msg.tickDirection(tickDirection());
        if (mDMkt() != null) msg.mDMkt(mDMkt());
        if (tradingSessionID() != null) msg.tradingSessionID(tradingSessionID());
        if (quoteCondition() != null) msg.quoteCondition(quoteCondition());
        if (tradeCondition() != null) msg.tradeCondition(tradeCondition());
        if (mDEntryOriginator() != null) msg.mDEntryOriginator(mDEntryOriginator());
        if (locationID() != null) msg.locationID(locationID());
        if (deskID() != null) msg.deskID(deskID());
        if (openCloseSettleFlag() != FixMessage.UNSET_CHAR) msg.openCloseSettleFlag(openCloseSettleFlag());
        if (timeInForce() != FixMessage.UNSET_CHAR) msg.timeInForce(timeInForce());
        if (expireDate() != null) msg.expireDate(expireDate());
        if (expireTime() != FixMessage.UNSET_LONG) msg.expireTime(expireTime());
        if (!Double.isNaN(minQty())) msg.minQty(minQty());
        if (execInst() != null) msg.execInst(execInst());
        if (sellerDays() != FixMessage.UNSET_LONG) msg.sellerDays(sellerDays());
        if (orderID() != null) msg.orderID(orderID());
        if (quoteEntryID() != null) msg.quoteEntryID(quoteEntryID());
        if (mDEntryBuyer() != null) msg.mDEntryBuyer(mDEntryBuyer());
        if (mDEntrySeller() != null) msg.mDEntrySeller(mDEntrySeller());
        if (numberOfOrders() != FixMessage.UNSET_LONG) msg.numberOfOrders(numberOfOrders());
        if (mDEntryPositionNo() != FixMessage.UNSET_LONG) msg.mDEntryPositionNo(mDEntryPositionNo());
        if (text() != null) msg.text(text());
        if (encodedTextLen() != FixMessage.UNSET_LONG) msg.encodedTextLen(encodedTextLen());
        if (encodedText() != null) msg.encodedText(encodedText());
    }

    default void reset() {
        mDEntryType(FixMessage.UNSET_CHAR);
        mDEntryPx(FixMessage.UNSET_DOUBLE);
        currency(null);
        mDEntrySize(FixMessage.UNSET_DOUBLE);
        mDEntryDate(null);
        mDEntryTime(null);
        tickDirection(FixMessage.UNSET_CHAR);
        mDMkt(null);
        tradingSessionID(null);
        quoteCondition(null);
        tradeCondition(null);
        mDEntryOriginator(null);
        locationID(null);
        deskID(null);
        openCloseSettleFlag(FixMessage.UNSET_CHAR);
        timeInForce(FixMessage.UNSET_CHAR);
        expireDate(null);
        expireTime(FixMessage.UNSET_LONG);
        minQty(FixMessage.UNSET_DOUBLE);
        execInst(null);
        sellerDays(FixMessage.UNSET_LONG);
        orderID(null);
        quoteEntryID(null);
        mDEntryBuyer(null);
        mDEntrySeller(null);
        numberOfOrders(FixMessage.UNSET_LONG);
        mDEntryPositionNo(FixMessage.UNSET_LONG);
        text(null);
        encodedTextLen(FixMessage.UNSET_LONG);
        encodedText(null);
    }
}
