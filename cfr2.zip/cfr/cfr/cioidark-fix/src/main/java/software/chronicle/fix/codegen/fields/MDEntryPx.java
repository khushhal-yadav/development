package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MDEntryPx {
    /**
     * Tag number for this field
     */
    int FIELD = 270;

    /**
     * @param mDEntryPx &gt; FIX TAG 270
     */
    void mDEntryPx(double mDEntryPx);

    default double mDEntryPx() {
        throw new UnsupportedOperationException();
    }
}
