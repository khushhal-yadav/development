package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.CioiDarkOrder;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedCioiDarkOrderParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, CioiDarkOrder cioiDarkOrder) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(cioiDarkOrder);
            fix.clOrdID(cioiDarkOrder); // 11
            fix.account(cioiDarkOrder); // 1
            fix.handlInst(cioiDarkOrder); // 21
            fix.execInst(cioiDarkOrder); // 18
            fix.minQty(cioiDarkOrder); // 110
            fix.symbol(cioiDarkOrder); // 55
            fix.symbolSfx(cioiDarkOrder); // 65
            fix.side(cioiDarkOrder); // 54
            fix.locateReqd(cioiDarkOrder); // 114
            fix.transactTime(cioiDarkOrder); // 60
            fix.orderQty(cioiDarkOrder); // 38
            fix.ordType(cioiDarkOrder); // 40
            fix.price(cioiDarkOrder); // 44
            fix.stopPx(cioiDarkOrder); // 99
            fix.ioiID(cioiDarkOrder); // 23
            fix.timeInForce(cioiDarkOrder); // 59
            fix.orderCapacity(cioiDarkOrder); // 528
            fix.targetStrategy(cioiDarkOrder); // 847
            fix.targetStrategyParameters(cioiDarkOrder); // 848
            fix.orderVersion(cioiDarkOrder); // 12052
            fix.timeToLive(cioiDarkOrder); // 10014
            fix.customPrice1(cioiDarkOrder); // 7491
            fix.locateBroker(cioiDarkOrder); // 5700
            fix.locateIdentifier(cioiDarkOrder); // 5701
            fix.rootSrcSystemID(cioiDarkOrder); // 10515
            fix.previousLinkSrcSystemID(cioiDarkOrder); // 10518
            fix.orderID(cioiDarkOrder); // 37
            fix.ordStatus(cioiDarkOrder); // 39
            fix.crossRestrictionClientID(cioiDarkOrder); // 10896
            fix.leavesQty(cioiDarkOrder); // 151
            fix.cxlQty(cioiDarkOrder); // 84
            fix.optOutLockedIn(cioiDarkOrder); // 10565
            fix.sumOfStopExecQty(cioiDarkOrder); // 10065
            fix.crossInstruction(cioiDarkOrder); // 6438
            fix.customerSlang(cioiDarkOrder); // 8004
            fix.noStrategyParameters(cioiDarkOrder); // 957
            fix.receiveTime(cioiDarkOrder); // 10080
            fix.strategyParameterValue(cioiDarkOrder); // 960
            fix.shortSaleExemptReason(cioiDarkOrder); // 1688
            fix.crossStrategy(cioiDarkOrder); // 7411
            fix.securityID(cioiDarkOrder); // 48
            fix.idSource(cioiDarkOrder); // 22
            fix.securityAltID(cioiDarkOrder); // 455
            fix.securityAltIDSource(cioiDarkOrder); // 456
            fix.srcTargetCompId(cioiDarkOrder); // 10084
            fix.reportToExch(cioiDarkOrder); // 113
            if (fix.checkFinished(cioiDarkOrder, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, cioiDarkOrder, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(cioiDarkOrder.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(cioiDarkOrder.msgSeqNum(), pos);
    }
}
