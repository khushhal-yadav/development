package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ContraAccountType {
    /**
     * Tag number for this field
     */
    int FIELD = 11041;

    /**
     * @param contraAccountType &gt; FIX TAG 11041
     */
    void contraAccountType(String contraAccountType);

    default String contraAccountType() {
        throw new UnsupportedOperationException();
    }
}
