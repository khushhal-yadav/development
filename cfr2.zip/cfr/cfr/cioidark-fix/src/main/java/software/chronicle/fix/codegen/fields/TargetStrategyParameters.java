package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TargetStrategyParameters {
    /**
     * Tag number for this field
     */
    int FIELD = 848;

    /**
     * @param targetStrategyParameters &gt; FIX TAG 848
     */
    void targetStrategyParameters(String targetStrategyParameters);

    default String targetStrategyParameters() {
        throw new UnsupportedOperationException();
    }
}
