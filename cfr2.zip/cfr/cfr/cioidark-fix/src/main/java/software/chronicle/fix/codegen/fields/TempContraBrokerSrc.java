package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TempContraBrokerSrc {
    /**
     * Tag number for this field
     */
    int FIELD = 10535;

    /**
     * @param tempContraBrokerSrc &gt; FIX TAG 10535
     */
    void tempContraBrokerSrc(String tempContraBrokerSrc);

    default String tempContraBrokerSrc() {
        throw new UnsupportedOperationException();
    }
}
