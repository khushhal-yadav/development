package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.fields.EncryptMethod;
import software.chronicle.fix.sessioncode.fields.HeartBtInt;
import software.chronicle.fix.sessioncode.fields.Password;
import software.chronicle.fix.sessioncode.fields.RawData;
import software.chronicle.fix.sessioncode.fields.RawDataLength;
import software.chronicle.fix.sessioncode.fields.ResetSeqNumFlag;
import software.chronicle.fix.sessioncode.fields.Username;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface Logon extends HeaderTrailer, software.chronicle.fix.sessioncode.messages.Logon, EncryptMethod, HeartBtInt, RawDataLength, RawData, ResetSeqNumFlag, Username, Password {
    @Deprecated
    static Logon newLogon(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.Logon);
        mg.bytes(bytes);
        return mg;
    }

    static Logon newLogon(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.Logon, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (encryptMethod() == FixMessage.UNSET_LONG) throw new RequiredTagMissing("encryptMethod", 98);
        if (heartBtInt() == FixMessage.UNSET_LONG) throw new RequiredTagMissing("heartBtInt", 108);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        encryptMethod(FixMessage.UNSET_LONG);
        heartBtInt(FixMessage.UNSET_LONG);
        rawDataLength(FixMessage.UNSET_LONG);
        rawData(null);
        resetSeqNumFlag(FixMessage.UNSET_CHAR);
        username(null);
        password(null);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((Logon) msg);
    }

    default void copyTo(Logon msg) {
        HeaderTrailer.super.copyTo(msg);
        if (encryptMethod() != FixMessage.UNSET_LONG) msg.encryptMethod(encryptMethod());
        if (heartBtInt() != FixMessage.UNSET_LONG) msg.heartBtInt(heartBtInt());
        if (rawDataLength() != FixMessage.UNSET_LONG) msg.rawDataLength(rawDataLength());
        if (rawData() != null) msg.rawData(rawData());
        if (resetSeqNumFlag() != FixMessage.UNSET_CHAR) msg.resetSeqNumFlag(resetSeqNumFlag());
        if (username() != null) msg.username(username());
        if (password() != null) msg.password(password());
    }
}
