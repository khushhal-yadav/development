package software.chronicle.fix.codegen.components;

/**
 * Generated at software.chronicle.fix.codegen.ComponentGenerator.generateComponent(ComponentGenerator.java)
 */
public interface MarketDataSnapshotFullRefresh_MDEntriesGrp {
    /**
     * Tag number for this field
     */
    int FIELD = 268;

    /**
     * @param noMDEntries &gt; FIX TAG 268
     */
    void noMDEntries(long noMDEntries);

    default long noMDEntries() {
        throw new UnsupportedOperationException();
    }

    MarketDataSnapshotFullRefresh_MDEntriesGrp_1 marketDataSnapshotFullRefresh_MDEntriesGrp_1(int index);
}
