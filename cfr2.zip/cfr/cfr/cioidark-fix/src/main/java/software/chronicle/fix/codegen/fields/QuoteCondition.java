package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface QuoteCondition {
    /**
     * Tag number for this field
     */
    int FIELD = 276;

    String OPEN_ACTIVE = "A";

    String CLOSED_INACTIVE = "B";

    String EXCHANGE_BEST = "C";

    String CONSOLIDATED_BEST = "D";

    String LOCKED = "E";

    String CROSSED = "F";

    String DEPTH = "G";

    String FAST_TRADING = "H";

    String NONFIRM = "I";

    /**
     * @param quoteCondition &gt; FIX TAG 276
     */
    void quoteCondition(String quoteCondition);

    default String quoteCondition() {
        throw new UnsupportedOperationException();
    }

    static String asString(String value) {
        return value;
    }
}
