package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LocateIdentifier {
    /**
     * Tag number for this field
     */
    int FIELD = 5701;

    /**
     * @param locateIdentifier &gt; FIX TAG 5701
     */
    void locateIdentifier(String locateIdentifier);

    default String locateIdentifier() {
        throw new UnsupportedOperationException();
    }
}
