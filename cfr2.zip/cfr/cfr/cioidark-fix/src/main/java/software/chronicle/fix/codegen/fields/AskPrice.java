package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface AskPrice {
    /**
     * Tag number for this field
     */
    int FIELD = 11006;

    /**
     * @param askPrice &gt; FIX TAG 11006
     */
    void askPrice(double askPrice);

    default double askPrice() {
        throw new UnsupportedOperationException();
    }
}
