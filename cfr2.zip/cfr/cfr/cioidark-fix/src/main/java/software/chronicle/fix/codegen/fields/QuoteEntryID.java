package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface QuoteEntryID {
    /**
     * Tag number for this field
     */
    int FIELD = 299;

    /**
     * @param quoteEntryID &gt; FIX TAG 299
     */
    void quoteEntryID(String quoteEntryID);

    default String quoteEntryID() {
        throw new UnsupportedOperationException();
    }
}
