package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrderCapacity {
    /**
     * Tag number for this field
     */
    int FIELD = 528;

    char AGENCY = 'A';

    char PROPRIETARY = 'G';

    char INDIVIDUAL = 'I';

    char PRINCIPAL = 'P';

    char RISKLESS_PRINCIPAL = 'R';

    char AGENT_FOR_OTHER_MEMBER = 'W';

    /**
     * @param orderCapacity &gt; FIX TAG 528
     */
    void orderCapacity(char orderCapacity);

    default char orderCapacity() {
        throw new UnsupportedOperationException();
    }

    static String asString(char value) {
        switch (value) {
            case AGENCY:
                    return "AGENCY";
            case PROPRIETARY:
                    return "PROPRIETARY";
            case INDIVIDUAL:
                    return "INDIVIDUAL";
            case PRINCIPAL:
                    return "PRINCIPAL";
            case RISKLESS_PRINCIPAL:
                    return "RISKLESS_PRINCIPAL";
            case AGENT_FOR_OTHER_MEMBER:
                    return "AGENT_FOR_OTHER_MEMBER";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
