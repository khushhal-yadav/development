package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SettlCurrency {
    /**
     * Tag number for this field
     */
    int FIELD = 120;

    /**
     * @param settlCurrency &gt; FIX TAG 120
     */
    void settlCurrency(String settlCurrency);

    default String settlCurrency() {
        throw new UnsupportedOperationException();
    }
}
