package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SettlCurrFxRate {
    /**
     * Tag number for this field
     */
    int FIELD = 155;

    /**
     * @param settlCurrFxRate &gt; FIX TAG 155
     */
    void settlCurrFxRate(double settlCurrFxRate);

    default double settlCurrFxRate() {
        throw new UnsupportedOperationException();
    }
}
