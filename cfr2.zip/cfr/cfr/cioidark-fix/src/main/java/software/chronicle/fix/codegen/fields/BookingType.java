package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface BookingType {
    /**
     * Tag number for this field
     */
    int FIELD = 775;

    String REGULARBOOKING = "0";

    String CFDCONTRACTFORDIFFERENCE = "1";

    String GIVEUPORDER = "100";

    String CASHORDER = "101";

    String LEPOORDER = "102";

    String PNOTEINDICATOR = "103";

    String GIVEINORDER = "104";

    String HYBRID = "105";

    String HYBRIDSWAPORDER = "106";

    String HYBRIDGIVEUPORDER = "107";

    String PBCROSS = "108";

    String TOTALRETURNSWAP = "2";

    /**
     * @param bookingType &gt; FIX TAG 775
     */
    void bookingType(String bookingType);

    default String bookingType() {
        throw new UnsupportedOperationException();
    }

    static String asString(String value) {
        return value;
    }
}
