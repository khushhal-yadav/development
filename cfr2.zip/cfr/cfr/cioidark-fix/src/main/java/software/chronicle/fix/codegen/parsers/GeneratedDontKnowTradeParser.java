package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.DontKnowTrade;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedDontKnowTradeParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, DontKnowTrade dontKnowTrade) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(dontKnowTrade);
            fix.orderID(dontKnowTrade); // 37
            fix.execID(dontKnowTrade); // 17
            fix.dKReason(dontKnowTrade); // 127
            fix.symbol(dontKnowTrade); // 55
            fix.symbolSfx(dontKnowTrade); // 65
            fix.securityID(dontKnowTrade); // 48
            fix.idSource(dontKnowTrade); // 22
            fix.securityType(dontKnowTrade); // 167
            fix.maturityMonthYear(dontKnowTrade); // 200
            fix.maturityDay(dontKnowTrade); // 205
            fix.putOrCall(dontKnowTrade); // 201
            fix.strikePrice(dontKnowTrade); // 202
            fix.optAttribute(dontKnowTrade); // 206
            fix.contractMultiplier(dontKnowTrade); // 231
            fix.couponRate(dontKnowTrade); // 223
            fix.securityExchange(dontKnowTrade); // 207
            fix.issuer(dontKnowTrade); // 106
            fix.encodedIssuerLen(dontKnowTrade); // 348
            fix.encodedIssuer(dontKnowTrade); // 349
            fix.securityDesc(dontKnowTrade); // 107
            fix.encodedSecurityDescLen(dontKnowTrade); // 350
            fix.encodedSecurityDesc(); // 351
            fix.side(dontKnowTrade); // 54
            fix.orderQty(dontKnowTrade); // 38
            fix.cashOrderQty(dontKnowTrade); // 152
            fix.lastShares(dontKnowTrade); // 32
            fix.lastPx(dontKnowTrade); // 31
            fix.text(dontKnowTrade); // 58
            fix.encodedTextLen(dontKnowTrade); // 354
            fix.encodedText(dontKnowTrade); // 355
            if (fix.checkFinished(dontKnowTrade, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, dontKnowTrade, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(dontKnowTrade.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(dontKnowTrade.msgSeqNum(), pos);
    }
}
