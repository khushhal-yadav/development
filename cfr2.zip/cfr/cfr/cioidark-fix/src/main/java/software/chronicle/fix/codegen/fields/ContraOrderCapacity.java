package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ContraOrderCapacity {
    /**
     * Tag number for this field
     */
    int FIELD = 10158;

    /**
     * @param contraOrderCapacity &gt; FIX TAG 10158
     */
    void contraOrderCapacity(char contraOrderCapacity);

    default char contraOrderCapacity() {
        throw new UnsupportedOperationException();
    }
}
