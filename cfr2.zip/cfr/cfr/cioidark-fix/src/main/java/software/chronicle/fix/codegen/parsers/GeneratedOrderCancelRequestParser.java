package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedOrderCancelRequestParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, OrderCancelRequest orderCancelRequest) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(orderCancelRequest);
            fix.orderID(orderCancelRequest); // 37
            fix.clOrdID(orderCancelRequest); // 11
            fix.account(orderCancelRequest); // 1
            fix.side(orderCancelRequest); // 54
            fix.origClOrdID(orderCancelRequest); // 41
            fix.symbol(orderCancelRequest); // 55
            fix.symbolSfx(orderCancelRequest); // 65
            fix.idSource(orderCancelRequest); // 22
            fix.transactTime(orderCancelRequest); // 60
            fix.orderQty(orderCancelRequest); // 38
            fix.price(orderCancelRequest); // 44
            fix.bidPx(orderCancelRequest); // 132
            fix.offerPx(orderCancelRequest); // 133
            fix.quoteTime(orderCancelRequest); // 11048
            fix.timeInForce(orderCancelRequest); // 59
            fix.createdNS(orderCancelRequest); // 9999
            fix.clientID(orderCancelRequest); // 109
            fix.ordLinkID(orderCancelRequest); // 11053
            fix.ordLinkType(orderCancelRequest); // 11052
            fix.bookingType(orderCancelRequest); // 775
            fix.crossID(orderCancelRequest); // 548
            fix.strategyParameterValue(orderCancelRequest); // 960
            fix.crossStrategy(orderCancelRequest); // 7411
            fix.customPrice1(orderCancelRequest); // 7491
            fix.corellationClOrdID(orderCancelRequest); // 9717
            fix.previousLinkOrderID(orderCancelRequest); // 10184
            fix.rootOrderID(orderCancelRequest); // 11210
            fix.customerSlang(orderCancelRequest); // 8004
            fix.receiveTime(orderCancelRequest); // 10080
            fix.crossRestrictionClientID(orderCancelRequest); // 10896
            fix.execInst(orderCancelRequest); // 18
            fix.crossInstruction(orderCancelRequest); // 6438
            fix.avgPriceAcctIDSource(orderCancelRequest); // 10428
            fix.tickSizePilotGroup(orderCancelRequest); // 11319
            fix.clearingInstruction(orderCancelRequest); // 577
            fix.timeToLive(orderCancelRequest); // 10014
            fix.srcTargetCompId(orderCancelRequest); // 10084
            fix.ioiID(orderCancelRequest); // 23
            if (fix.checkFinished(orderCancelRequest, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, orderCancelRequest, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(orderCancelRequest.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(orderCancelRequest.msgSeqNum(), pos);
    }
}
