package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.Logon;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultLogon extends DefaultHeaderTrailer implements Logon, HeaderTrailer {
    private long encryptMethod = FixMessage.UNSET_LONG;

    private long heartBtInt = FixMessage.UNSET_LONG;

    private long rawDataLength = FixMessage.UNSET_LONG;

    private String rawData = null;

    private char resetSeqNumFlag = FixMessage.UNSET_CHAR;

    private String username = null;

    private String password = null;

    public char msgType() {
        return MessageManifest.Logon;
    }

    public long encryptMethod() {
        return encryptMethod;
    }

    @Override
    public void encryptMethod(long encryptMethod) {
        this.encryptMethod = encryptMethod;
    }

    public long heartBtInt() {
        return heartBtInt;
    }

    @Override
    public void heartBtInt(long heartBtInt) {
        this.heartBtInt = heartBtInt;
    }

    public long rawDataLength() {
        return rawDataLength;
    }

    @Override
    public void rawDataLength(long rawDataLength) {
        this.rawDataLength = rawDataLength;
    }

    public String rawData() {
        return rawData;
    }

    @Override
    public void rawData(String rawData) {
        this.rawData = rawData;
    }

    public char resetSeqNumFlag() {
        return resetSeqNumFlag;
    }

    @Override
    public void resetSeqNumFlag(char resetSeqNumFlag) {
        this.resetSeqNumFlag = resetSeqNumFlag;
    }

    public String username() {
        return username;
    }

    @Override
    public void username(String username) {
        this.username = username;
    }

    public String password() {
        return password;
    }

    @Override
    public void password(String password) {
        this.password = password;
    }

    @Override
    public void reset() {
        Logon.super.reset();
    }
}
