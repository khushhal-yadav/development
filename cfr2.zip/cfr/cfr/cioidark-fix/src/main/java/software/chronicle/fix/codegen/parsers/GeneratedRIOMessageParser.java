package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.RIOMessage;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedRIOMessageParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, RIOMessage rIOMessage) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(rIOMessage);
            fix.account(rIOMessage); // 1
            fix.accountIDSource(rIOMessage); // 660
            fix.accountType(rIOMessage); // 581
            fix.avgPx(rIOMessage); // 6
            fix.clOrdID(rIOMessage); // 11
            fix.cumQty(rIOMessage); // 14
            fix.currency(rIOMessage); // 15
            fix.execID(rIOMessage); // 17
            fix.execInst(rIOMessage); // 18
            fix.execRefID(rIOMessage); // 19
            fix.handlInst(rIOMessage); // 21
            fix.idSource(rIOMessage); // 22
            fix.securityID(rIOMessage); // 48
            fix.securityAltID(rIOMessage); // 455
            fix.securityAltIDSource(rIOMessage); // 456
            fix.lastCapacity(rIOMessage); // 29
            fix.lastMkt(rIOMessage); // 30
            fix.lastPx(rIOMessage); // 31
            fix.lastShares(rIOMessage); // 32
            fix.orderID(rIOMessage); // 37
            fix.srcSystemID(rIOMessage); // 10005
            fix.orderUniqID(rIOMessage); // 10439
            fix.xParentOrderID(rIOMessage); // 10243
            fix.parentOrderUniqID(rIOMessage); // 10517
            fix.previousLinkOrderID(rIOMessage); // 10184
            fix.previousLinkSrcSystemID(rIOMessage); // 10518
            fix.previousLinkOrderUniqID(rIOMessage); // 10519
            fix.rootOrderID(rIOMessage); // 11210
            fix.rootSrcSystemID(rIOMessage); // 10515
            fix.rootOrderUniqID(rIOMessage); // 10516
            fix.orderQty(rIOMessage); // 38
            fix.ordStatus(rIOMessage); // 39
            fix.ordType(rIOMessage); // 40
            fix.origClOrdID(rIOMessage); // 41
            fix.price(rIOMessage); // 44
            fix.side(rIOMessage); // 54
            fix.symbol(rIOMessage); // 55
            fix.text(rIOMessage); // 58
            fix.timeInForce(rIOMessage); // 59
            fix.transactTime(rIOMessage); // 60
            fix.settlmntTyp(rIOMessage); // 63
            fix.symbolSfx(rIOMessage); // 65
            fix.tradeDate(rIOMessage); // 75
            fix.cxlQty(rIOMessage); // 84
            fix.exDestination(rIOMessage); // 100
            fix.exDestinationIDSource(rIOMessage); // 1133
            fix.cxlRejReason(rIOMessage); // 102
            fix.ordRejReason(rIOMessage); // 103
            fix.locateReqd(rIOMessage); // 114
            fix.settlCurrency(rIOMessage); // 120
            fix.execType(rIOMessage); // 150
            fix.leavesQty(rIOMessage); // 151
            fix.settlCurrAmt(rIOMessage); // 119
            fix.settlCurrFxRate(rIOMessage); // 155
            fix.settlCurrFxRateCalc(rIOMessage); // 156
            fix.securityType(rIOMessage); // 167
            fix.securityExchange(rIOMessage); // 207
            fix.refMsgType(rIOMessage); // 372
            fix.country(rIOMessage); // 421
            fix.orderCapacity(rIOMessage); // 528
            fix.orderRestrictions(rIOMessage); // 529
            fix.customerOrFirm(rIOMessage); // 204
            fix.clientID(rIOMessage); // 109
            fix.rioTimestamp(rIOMessage); // 10071
            fix.isRioStateEvent(rIOMessage); // 10104
            fix.orderFlowCategory(rIOMessage); // 10202
            fix.rioMsgSource(rIOMessage); // 10208
            fix.leafExecFlag(rIOMessage); // 10217
            fix.rioTransactTime(rIOMessage); // 10436
            fix.orderVersion(rIOMessage); // 12052
            fix.orderPlacer(rIOMessage); // 10895
            fix.lafExecID(rIOMessage); // 10964
            fix.leafSrcSystemID(rIOMessage); // 10965
            fix.rioBeginString(rIOMessage); // 10438
            fix.rioMinorVersion(rIOMessage); // 10653
            fix.rioMsgSeq(rIOMessage); // 10655
            fix.replayInd(rIOMessage); // 10657
            fix.rioMsgSeqSrc(rIOMessage); // 10658
            fix.channelName(rIOMessage); // 10053
            fix.ordLinkID(rIOMessage); // 11053
            fix.ordLinkType(rIOMessage); // 11052
            fix.bookingType(rIOMessage); // 775
            fix.tradingAcct(rIOMessage); // 10050
            fix.contraBroker(rIOMessage); // 375
            fix.trdType(rIOMessage); // 828
            fix.zExecID(rIOMessage); // 10018
            fix.salesPersonID(rIOMessage); // 10036
            fix.traderID(rIOMessage); // 10039
            fix.receiveTime(rIOMessage); // 10080
            fix.leafExecutionFlag(rIOMessage); // 10217
            fix.xLastActivityUserID(rIOMessage); // 10241
            fix.tempLastMkt(rIOMessage); // 10537
            fix.ioiID(rIOMessage); // 23
            if (fix.checkFinished(rIOMessage, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, rIOMessage, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(rIOMessage.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(rIOMessage.msgSeqNum(), pos);
    }
}
