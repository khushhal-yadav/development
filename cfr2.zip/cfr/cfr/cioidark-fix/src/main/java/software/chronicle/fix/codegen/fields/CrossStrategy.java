package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CrossStrategy {
    /**
     * Tag number for this field
     */
    int FIELD = 7411;

    /**
     * @param crossStrategy &gt; FIX TAG 7411
     */
    void crossStrategy(String crossStrategy);

    default String crossStrategy() {
        throw new UnsupportedOperationException();
    }
}
