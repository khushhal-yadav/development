package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.ResendRequest;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultResendRequest extends DefaultHeaderTrailer implements ResendRequest, HeaderTrailer {
    private long beginSeqNo = FixMessage.UNSET_LONG;

    private long endSeqNo = FixMessage.UNSET_LONG;

    public char msgType() {
        return MessageManifest.ResendRequest;
    }

    public long beginSeqNo() {
        return beginSeqNo;
    }

    @Override
    public void beginSeqNo(long beginSeqNo) {
        this.beginSeqNo = beginSeqNo;
    }

    public long endSeqNo() {
        return endSeqNo;
    }

    @Override
    public void endSeqNo(long endSeqNo) {
        this.endSeqNo = endSeqNo;
    }

    @Override
    public void reset() {
        ResendRequest.super.reset();
    }
}
