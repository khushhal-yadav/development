package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ChannelName {
    /**
     * Tag number for this field
     */
    int FIELD = 10053;

    /**
     * @param channelName &gt; FIX TAG 10053
     */
    void channelName(String channelName);

    default String channelName() {
        throw new UnsupportedOperationException();
    }
}
