package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MDEntrySeller {
    /**
     * Tag number for this field
     */
    int FIELD = 289;

    /**
     * @param mDEntrySeller &gt; FIX TAG 289
     */
    void mDEntrySeller(String mDEntrySeller);

    default String mDEntrySeller() {
        throw new UnsupportedOperationException();
    }
}
