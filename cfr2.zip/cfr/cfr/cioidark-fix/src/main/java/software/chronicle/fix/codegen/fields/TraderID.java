package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TraderID {
    /**
     * Tag number for this field
     */
    int FIELD = 10039;

    /**
     * @param traderID &gt; FIX TAG 10039
     */
    void traderID(String traderID);

    default String traderID() {
        throw new UnsupportedOperationException();
    }
}
