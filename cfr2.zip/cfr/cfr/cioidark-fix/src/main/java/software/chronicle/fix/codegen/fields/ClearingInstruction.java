package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ClearingInstruction {
    /**
     * Tag number for this field
     */
    int FIELD = 577;

    int PROCESS_NORMALLY = 0;

    int EXCLUDE_FROM_ALL_NETTING = 1;

    int BILATERAL_NETTING_ONLY = 2;

    int EX_CLEARING = 3;

    int SPECIAL_TRADE = 4;

    int MULTILATERAL_NETTING = 5;

    int CLEAR_AGAINST_CENTRAL_COUNTERPARTY = 6;

    int EXCLUDE_FROM_CENTRAL_COUNTERPARTY = 7;

    int MANUAL_MODE = 8;

    int AUTOMATIC_POSTING_MODE = 9;

    int AUTOMATIC_GIVE_UP_MODE = 10;

    int QUALIFIED_SERVICE_REPRESENTATIVE = 11;

    int CUSTOMER_TRADE = 12;

    int SELF_CLEARING = 13;

    /**
     * @param clearingInstruction &gt; FIX TAG 577
     */
    void clearingInstruction(long clearingInstruction);

    default long clearingInstruction() {
        throw new UnsupportedOperationException();
    }

    static String asString(int value) {
        switch (value) {
            case PROCESS_NORMALLY:
                    return "PROCESS_NORMALLY";
            case EXCLUDE_FROM_ALL_NETTING:
                    return "EXCLUDE_FROM_ALL_NETTING";
            case BILATERAL_NETTING_ONLY:
                    return "BILATERAL_NETTING_ONLY";
            case EX_CLEARING:
                    return "EX_CLEARING";
            case SPECIAL_TRADE:
                    return "SPECIAL_TRADE";
            case MULTILATERAL_NETTING:
                    return "MULTILATERAL_NETTING";
            case CLEAR_AGAINST_CENTRAL_COUNTERPARTY:
                    return "CLEAR_AGAINST_CENTRAL_COUNTERPARTY";
            case EXCLUDE_FROM_CENTRAL_COUNTERPARTY:
                    return "EXCLUDE_FROM_CENTRAL_COUNTERPARTY";
            case MANUAL_MODE:
                    return "MANUAL_MODE";
            case AUTOMATIC_POSTING_MODE:
                    return "AUTOMATIC_POSTING_MODE";
            case AUTOMATIC_GIVE_UP_MODE:
                    return "AUTOMATIC_GIVE_UP_MODE";
            case QUALIFIED_SERVICE_REPRESENTATIVE:
                    return "QUALIFIED_SERVICE_REPRESENTATIVE";
            case CUSTOMER_TRADE:
                    return "CUSTOMER_TRADE";
            case SELF_CLEARING:
                    return "SELF_CLEARING";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
