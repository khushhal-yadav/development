package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import java.util.concurrent.TimeUnit;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.OrderCancelReject;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultOrderCancelReject extends DefaultHeaderTrailer implements OrderCancelReject, HeaderTrailer {
    private String orderID = null;

    private String clOrdID = null;

    private String origClOrdID = null;

    private char ordStatus = FixMessage.UNSET_CHAR;

    private String text = null;

    private long transactTime = FixMessage.UNSET_LONG;

    private char cxlRejResponseTo = FixMessage.UNSET_CHAR;

    private long cxlRejReason = FixMessage.UNSET_LONG;

    private long createdNS = FixMessage.UNSET_LONG;

    private double price = FixMessage.UNSET_DOUBLE;

    private double lastTraded = FixMessage.UNSET_DOUBLE;

    private double lastTradedDelta = FixMessage.UNSET_DOUBLE;

    private double openQty = FixMessage.UNSET_DOUBLE;

    private double deltaQty = FixMessage.UNSET_DOUBLE;

    private double deltaPx = FixMessage.UNSET_DOUBLE;

    private String account = null;

    private String symbol = null;

    private String symbolSfx = null;

    private String currency = null;

    private char side = FixMessage.UNSET_CHAR;

    private String ordLinkID = null;

    private String ordLinkType = null;

    private String bookingType = null;

    private String srcTargetCompId = null;

    private String reportToExch = null;

    private String ioiID = null;

    private String crossID = null;

    private String origCrossID = null;

    private long priceType = FixMessage.UNSET_LONG;

    private double bidPx = FixMessage.UNSET_DOUBLE;

    private double offerPx = FixMessage.UNSET_DOUBLE;

    private char execType = FixMessage.UNSET_CHAR;

    private double orderQty = FixMessage.UNSET_DOUBLE;

    private long orderVersion = FixMessage.UNSET_LONG;

    private String sourceFeed = null;

    private String corellationClOrdID = null;

    private String lastCapacity = null;

    private long srcSystemID = FixMessage.UNSET_LONG;

    private String orderFlowCategory = null;

    private String executedBy = null;

    public char msgType() {
        return MessageManifest.OrderCancelReject;
    }

    public String orderID() {
        return orderID;
    }

    @Override
    public void orderID(String orderID) {
        this.orderID = orderID;
    }

    public String clOrdID() {
        return clOrdID;
    }

    @Override
    public void clOrdID(String clOrdID) {
        this.clOrdID = clOrdID;
    }

    public String origClOrdID() {
        return origClOrdID;
    }

    @Override
    public void origClOrdID(String origClOrdID) {
        this.origClOrdID = origClOrdID;
    }

    public char ordStatus() {
        return ordStatus;
    }

    @Override
    public void ordStatus(char ordStatus) {
        this.ordStatus = ordStatus;
    }

    public String text() {
        return text;
    }

    @Override
    public void text(String text) {
        this.text = text;
    }

    public long transactTime() {
        return transactTime;
    }

    @Override
    public void transactTime(long transactTime, TimeUnit timeUnit) {
        transactTime(transactTime);
    }

    @Override
    public void transactTime(long transactTime) {
        this.transactTime = transactTime;
    }

    public char cxlRejResponseTo() {
        return cxlRejResponseTo;
    }

    @Override
    public void cxlRejResponseTo(char cxlRejResponseTo) {
        this.cxlRejResponseTo = cxlRejResponseTo;
    }

    public long cxlRejReason() {
        return cxlRejReason;
    }

    @Override
    public void cxlRejReason(long cxlRejReason) {
        this.cxlRejReason = cxlRejReason;
    }

    public long createdNS() {
        return createdNS;
    }

    @Override
    public void createdNS(long createdNS) {
        this.createdNS = createdNS;
    }

    public double price() {
        return price;
    }

    @Override
    public void price(double price) {
        this.price = price;
    }

    public double lastTraded() {
        return lastTraded;
    }

    @Override
    public void lastTraded(double lastTraded) {
        this.lastTraded = lastTraded;
    }

    public double lastTradedDelta() {
        return lastTradedDelta;
    }

    @Override
    public void lastTradedDelta(double lastTradedDelta) {
        this.lastTradedDelta = lastTradedDelta;
    }

    public double openQty() {
        return openQty;
    }

    @Override
    public void openQty(double openQty) {
        this.openQty = openQty;
    }

    public double deltaQty() {
        return deltaQty;
    }

    @Override
    public void deltaQty(double deltaQty) {
        this.deltaQty = deltaQty;
    }

    public double deltaPx() {
        return deltaPx;
    }

    @Override
    public void deltaPx(double deltaPx) {
        this.deltaPx = deltaPx;
    }

    public String account() {
        return account;
    }

    @Override
    public void account(String account) {
        this.account = account;
    }

    public String symbol() {
        return symbol;
    }

    @Override
    public void symbol(String symbol) {
        this.symbol = symbol;
    }

    public String symbolSfx() {
        return symbolSfx;
    }

    @Override
    public void symbolSfx(String symbolSfx) {
        this.symbolSfx = symbolSfx;
    }

    public String currency() {
        return currency;
    }

    @Override
    public void currency(String currency) {
        this.currency = currency;
    }

    public char side() {
        return side;
    }

    @Override
    public void side(char side) {
        this.side = side;
    }

    public String ordLinkID() {
        return ordLinkID;
    }

    @Override
    public void ordLinkID(String ordLinkID) {
        this.ordLinkID = ordLinkID;
    }

    public String ordLinkType() {
        return ordLinkType;
    }

    @Override
    public void ordLinkType(String ordLinkType) {
        this.ordLinkType = ordLinkType;
    }

    public String bookingType() {
        return bookingType;
    }

    @Override
    public void bookingType(String bookingType) {
        this.bookingType = bookingType;
    }

    public String srcTargetCompId() {
        return srcTargetCompId;
    }

    @Override
    public void srcTargetCompId(String srcTargetCompId) {
        this.srcTargetCompId = srcTargetCompId;
    }

    public String reportToExch() {
        return reportToExch;
    }

    @Override
    public void reportToExch(String reportToExch) {
        this.reportToExch = reportToExch;
    }

    public String ioiID() {
        return ioiID;
    }

    @Override
    public void ioiID(String ioiID) {
        this.ioiID = ioiID;
    }

    public String crossID() {
        return crossID;
    }

    @Override
    public void crossID(String crossID) {
        this.crossID = crossID;
    }

    public String origCrossID() {
        return origCrossID;
    }

    @Override
    public void origCrossID(String origCrossID) {
        this.origCrossID = origCrossID;
    }

    public long priceType() {
        return priceType;
    }

    @Override
    public void priceType(long priceType) {
        this.priceType = priceType;
    }

    public double bidPx() {
        return bidPx;
    }

    @Override
    public void bidPx(double bidPx) {
        this.bidPx = bidPx;
    }

    public double offerPx() {
        return offerPx;
    }

    @Override
    public void offerPx(double offerPx) {
        this.offerPx = offerPx;
    }

    public char execType() {
        return execType;
    }

    @Override
    public void execType(char execType) {
        this.execType = execType;
    }

    public double orderQty() {
        return orderQty;
    }

    @Override
    public void orderQty(double orderQty) {
        this.orderQty = orderQty;
    }

    public long orderVersion() {
        return orderVersion;
    }

    @Override
    public void orderVersion(long orderVersion) {
        this.orderVersion = orderVersion;
    }

    public String sourceFeed() {
        return sourceFeed;
    }

    @Override
    public void sourceFeed(String sourceFeed) {
        this.sourceFeed = sourceFeed;
    }

    public String corellationClOrdID() {
        return corellationClOrdID;
    }

    @Override
    public void corellationClOrdID(String corellationClOrdID) {
        this.corellationClOrdID = corellationClOrdID;
    }

    public String lastCapacity() {
        return lastCapacity;
    }

    @Override
    public void lastCapacity(String lastCapacity) {
        this.lastCapacity = lastCapacity;
    }

    public long srcSystemID() {
        return srcSystemID;
    }

    @Override
    public void srcSystemID(long srcSystemID) {
        this.srcSystemID = srcSystemID;
    }

    public String orderFlowCategory() {
        return orderFlowCategory;
    }

    @Override
    public void orderFlowCategory(String orderFlowCategory) {
        this.orderFlowCategory = orderFlowCategory;
    }

    public String executedBy() {
        return executedBy;
    }

    @Override
    public void executedBy(String executedBy) {
        this.executedBy = executedBy;
    }

    @Override
    public void reset() {
        OrderCancelReject.super.reset();
    }
}
