package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface StopPx {
    /**
     * Tag number for this field
     */
    int FIELD = 99;

    /**
     * @param stopPx &gt; FIX TAG 99
     */
    void stopPx(double stopPx);

    default double stopPx() {
        throw new UnsupportedOperationException();
    }
}
