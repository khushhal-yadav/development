package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrderQty {
    /**
     * Tag number for this field
     */
    int FIELD = 38;

    /**
     * @param orderQty &gt; FIX TAG 38
     */
    void orderQty(double orderQty);

    default double orderQty() {
        throw new UnsupportedOperationException();
    }
}
