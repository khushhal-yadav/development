package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LafExecID {
    /**
     * Tag number for this field
     */
    int FIELD = 10964;

    /**
     * @param lafExecID &gt; FIX TAG 10964
     */
    void lafExecID(String lafExecID);

    default String lafExecID() {
        throw new UnsupportedOperationException();
    }
}
