package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.fields.Account;
import software.chronicle.fix.codegen.fields.BidPx;
import software.chronicle.fix.codegen.fields.BookingType;
import software.chronicle.fix.codegen.fields.ClOrdID;
import software.chronicle.fix.codegen.fields.CorellationClOrdID;
import software.chronicle.fix.codegen.fields.CreatedNS;
import software.chronicle.fix.codegen.fields.CrossID;
import software.chronicle.fix.codegen.fields.Currency;
import software.chronicle.fix.codegen.fields.CxlRejReason;
import software.chronicle.fix.codegen.fields.CxlRejResponseTo;
import software.chronicle.fix.codegen.fields.DeltaPx;
import software.chronicle.fix.codegen.fields.DeltaQty;
import software.chronicle.fix.codegen.fields.ExecType;
import software.chronicle.fix.codegen.fields.ExecutedBy;
import software.chronicle.fix.codegen.fields.IOIID;
import software.chronicle.fix.codegen.fields.LastCapacity;
import software.chronicle.fix.codegen.fields.LastTraded;
import software.chronicle.fix.codegen.fields.LastTradedDelta;
import software.chronicle.fix.codegen.fields.OfferPx;
import software.chronicle.fix.codegen.fields.OpenQty;
import software.chronicle.fix.codegen.fields.OrdLinkID;
import software.chronicle.fix.codegen.fields.OrdLinkType;
import software.chronicle.fix.codegen.fields.OrdStatus;
import software.chronicle.fix.codegen.fields.OrderFlowCategory;
import software.chronicle.fix.codegen.fields.OrderID;
import software.chronicle.fix.codegen.fields.OrderQty;
import software.chronicle.fix.codegen.fields.OrderVersion;
import software.chronicle.fix.codegen.fields.OrigClOrdID;
import software.chronicle.fix.codegen.fields.OrigCrossID;
import software.chronicle.fix.codegen.fields.Price;
import software.chronicle.fix.codegen.fields.PriceType;
import software.chronicle.fix.codegen.fields.ReportToExch;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.fields.SourceFeed;
import software.chronicle.fix.codegen.fields.SrcSystemID;
import software.chronicle.fix.codegen.fields.SrcTargetCompId;
import software.chronicle.fix.codegen.fields.Symbol;
import software.chronicle.fix.codegen.fields.SymbolSfx;
import software.chronicle.fix.codegen.fields.TransactTime;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.fields.Text;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface OrderCancelReject extends HeaderTrailer, OrderID, ClOrdID, OrigClOrdID, OrdStatus, Text, TransactTime, CxlRejResponseTo, CxlRejReason, CreatedNS, Price, LastTraded, LastTradedDelta, OpenQty, DeltaQty, DeltaPx, Account, Symbol, SymbolSfx, Currency, Side, OrdLinkID, OrdLinkType, BookingType, SrcTargetCompId, ReportToExch, IOIID, CrossID, OrigCrossID, PriceType, BidPx, OfferPx, ExecType, OrderQty, OrderVersion, SourceFeed, CorellationClOrdID, LastCapacity, SrcSystemID, OrderFlowCategory, ExecutedBy {
    @Deprecated
    static OrderCancelReject newOrderCancelReject(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.OrderCancelReject);
        mg.bytes(bytes);
        return mg;
    }

    static OrderCancelReject newOrderCancelReject(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.OrderCancelReject, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (orderID() == null) throw new RequiredTagMissing("orderID", 37);
        if (clOrdID() == null) throw new RequiredTagMissing("clOrdID", 11);
        if (origClOrdID() == null) throw new RequiredTagMissing("origClOrdID", 41);
        if (ordStatus() == FixMessage.UNSET_CHAR) throw new RequiredTagMissing("ordStatus", 39);
        if (cxlRejResponseTo() == FixMessage.UNSET_CHAR) throw new RequiredTagMissing("cxlRejResponseTo", 434);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        orderID(null);
        clOrdID(null);
        origClOrdID(null);
        ordStatus(FixMessage.UNSET_CHAR);
        text(null);
        transactTime(FixMessage.UNSET_LONG);
        cxlRejResponseTo(FixMessage.UNSET_CHAR);
        cxlRejReason(FixMessage.UNSET_LONG);
        createdNS(FixMessage.UNSET_LONG);
        price(FixMessage.UNSET_DOUBLE);
        lastTraded(FixMessage.UNSET_DOUBLE);
        lastTradedDelta(FixMessage.UNSET_DOUBLE);
        openQty(FixMessage.UNSET_DOUBLE);
        deltaQty(FixMessage.UNSET_DOUBLE);
        deltaPx(FixMessage.UNSET_DOUBLE);
        account(null);
        symbol(null);
        symbolSfx(null);
        currency(null);
        side(FixMessage.UNSET_CHAR);
        ordLinkID(null);
        ordLinkType(null);
        bookingType(null);
        srcTargetCompId(null);
        reportToExch(null);
        ioiID(null);
        crossID(null);
        origCrossID(null);
        priceType(FixMessage.UNSET_LONG);
        bidPx(FixMessage.UNSET_DOUBLE);
        offerPx(FixMessage.UNSET_DOUBLE);
        execType(FixMessage.UNSET_CHAR);
        orderQty(FixMessage.UNSET_DOUBLE);
        orderVersion(FixMessage.UNSET_LONG);
        sourceFeed(null);
        corellationClOrdID(null);
        lastCapacity(null);
        srcSystemID(FixMessage.UNSET_LONG);
        orderFlowCategory(null);
        executedBy(null);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((OrderCancelReject) msg);
    }

    default void copyTo(OrderCancelReject msg) {
        HeaderTrailer.super.copyTo(msg);
        if (orderID() != null) msg.orderID(orderID());
        if (clOrdID() != null) msg.clOrdID(clOrdID());
        if (origClOrdID() != null) msg.origClOrdID(origClOrdID());
        if (ordStatus() != FixMessage.UNSET_CHAR) msg.ordStatus(ordStatus());
        if (text() != null) msg.text(text());
        if (transactTime() != FixMessage.UNSET_LONG) msg.transactTime(transactTime());
        if (cxlRejResponseTo() != FixMessage.UNSET_CHAR) msg.cxlRejResponseTo(cxlRejResponseTo());
        if (cxlRejReason() != FixMessage.UNSET_LONG) msg.cxlRejReason(cxlRejReason());
        if (createdNS() != FixMessage.UNSET_LONG) msg.createdNS(createdNS());
        if (!Double.isNaN(price())) msg.price(price());
        if (!Double.isNaN(lastTraded())) msg.lastTraded(lastTraded());
        if (!Double.isNaN(lastTradedDelta())) msg.lastTradedDelta(lastTradedDelta());
        if (!Double.isNaN(openQty())) msg.openQty(openQty());
        if (!Double.isNaN(deltaQty())) msg.deltaQty(deltaQty());
        if (!Double.isNaN(deltaPx())) msg.deltaPx(deltaPx());
        if (account() != null) msg.account(account());
        if (symbol() != null) msg.symbol(symbol());
        if (symbolSfx() != null) msg.symbolSfx(symbolSfx());
        if (currency() != null) msg.currency(currency());
        if (side() != FixMessage.UNSET_CHAR) msg.side(side());
        if (ordLinkID() != null) msg.ordLinkID(ordLinkID());
        if (ordLinkType() != null) msg.ordLinkType(ordLinkType());
        if (bookingType() != null) msg.bookingType(bookingType());
        if (srcTargetCompId() != null) msg.srcTargetCompId(srcTargetCompId());
        if (reportToExch() != null) msg.reportToExch(reportToExch());
        if (ioiID() != null) msg.ioiID(ioiID());
        if (crossID() != null) msg.crossID(crossID());
        if (origCrossID() != null) msg.origCrossID(origCrossID());
        if (priceType() != FixMessage.UNSET_LONG) msg.priceType(priceType());
        if (!Double.isNaN(bidPx())) msg.bidPx(bidPx());
        if (!Double.isNaN(offerPx())) msg.offerPx(offerPx());
        if (execType() != FixMessage.UNSET_CHAR) msg.execType(execType());
        if (!Double.isNaN(orderQty())) msg.orderQty(orderQty());
        if (orderVersion() != FixMessage.UNSET_LONG) msg.orderVersion(orderVersion());
        if (sourceFeed() != null) msg.sourceFeed(sourceFeed());
        if (corellationClOrdID() != null) msg.corellationClOrdID(corellationClOrdID());
        if (lastCapacity() != null) msg.lastCapacity(lastCapacity());
        if (srcSystemID() != FixMessage.UNSET_LONG) msg.srcSystemID(srcSystemID());
        if (orderFlowCategory() != null) msg.orderFlowCategory(orderFlowCategory());
        if (executedBy() != null) msg.executedBy(executedBy());
    }
}
