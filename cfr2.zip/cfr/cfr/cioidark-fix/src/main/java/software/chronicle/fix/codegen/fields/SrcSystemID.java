package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SrcSystemID {
    /**
     * Tag number for this field
     */
    int FIELD = 10005;

    /**
     * @param srcSystemID &gt; FIX TAG 10005
     */
    void srcSystemID(long srcSystemID);

    default long srcSystemID() {
        throw new UnsupportedOperationException();
    }
}
