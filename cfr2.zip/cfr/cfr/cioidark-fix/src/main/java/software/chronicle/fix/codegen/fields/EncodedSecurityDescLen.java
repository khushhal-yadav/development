package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface EncodedSecurityDescLen {
    /**
     * Tag number for this field
     */
    int FIELD = 350;

    /**
     * @param encodedSecurityDescLen &gt; FIX TAG 350
     */
    void encodedSecurityDescLen(long encodedSecurityDescLen);

    default long encodedSecurityDescLen() {
        throw new UnsupportedOperationException();
    }
}
