package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TotalVolumeTraded {
    /**
     * Tag number for this field
     */
    int FIELD = 387;

    /**
     * @param totalVolumeTraded &gt; FIX TAG 387
     */
    void totalVolumeTraded(double totalVolumeTraded);

    default double totalVolumeTraded() {
        throw new UnsupportedOperationException();
    }
}
