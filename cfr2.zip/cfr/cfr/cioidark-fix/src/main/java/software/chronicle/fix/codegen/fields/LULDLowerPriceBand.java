package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LULDLowerPriceBand {
    /**
     * Tag number for this field
     */
    int FIELD = 10721;

    /**
     * @param lULDLowerPriceBand &gt; FIX TAG 10721
     */
    void lULDLowerPriceBand(double lULDLowerPriceBand);

    default double lULDLowerPriceBand() {
        throw new UnsupportedOperationException();
    }
}
