package software.chronicle.fix.codegen.parsers;

import java.lang.Override;
import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.bytes.util.StringInternerBytes;
import net.openhft.chronicle.core.io.IORuntimeException;
import net.openhft.chronicle.wire.WireIn;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.codegen.messages.Heartbeat;
import software.chronicle.fix.codegen.messages.Logon;
import software.chronicle.fix.codegen.messages.Logout;
import software.chronicle.fix.codegen.messages.MessageFactory;
import software.chronicle.fix.codegen.messages.Reject;
import software.chronicle.fix.codegen.messages.ResendRequest;
import software.chronicle.fix.codegen.messages.SequenceReset;
import software.chronicle.fix.codegen.messages.TestRequest;
import software.chronicle.fix.codegen.messages.datamodel.DefaultMessageFactory;
import software.chronicle.fix.pool.DateTimeParser;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.InvalidMessageException;
import software.chronicle.fix.staticcode.messages.FixMessage;
import software.chronicle.fix.staticcode.parsers.MessageParserBase;

/**
 * Generated at software.chronicle.fix.codegen.MessageParserGenerator.generate(MessageParserGenerator.java)
 */
public class SessionMessageParser extends MessageParserBase {
    private MessageFactory messageFactory = new DefaultMessageFactory();

    private transient GeneratedCoreFieldParser coreFieldParser;

    private boolean validateCheckSum;

    private GeneratedHeartbeatParser heartbeatParser = new GeneratedHeartbeatParser();

    private GeneratedLogonParser logonParser = new GeneratedLogonParser();

    private GeneratedTestRequestParser testRequestParser = new GeneratedTestRequestParser();

    private GeneratedResendRequestParser resendRequestParser = new GeneratedResendRequestParser();

    private GeneratedRejectParser rejectParser = new GeneratedRejectParser();

    private GeneratedSequenceResetParser sequenceResetParser = new GeneratedSequenceResetParser();

    private GeneratedLogoutParser logoutParser = new GeneratedLogoutParser();

    public SessionMessageParser() {
        stringPool = 128;
        datePool = 128;
        resetParser();
    }

    @Override
    public void readMarshallable(WireIn wire) throws IORuntimeException {
        super.readMarshallable(wire);
        resetParser();
    }

    void resetParser() {
        coreFieldParser = new GeneratedCoreFieldParser(
                new StringInternerBytes(stringPool), new DateTimeParser(datePool), validateCheckSum);
        coreFieldParser.unexpectedFieldHandler(unexpectedFieldHandler);
    }

    @Override
    public void parse(long startPos, char msgType, long msgSeqNum, @NotNull FixSessionHandler session, @NotNull Bytes bytes) {
        coreFieldParser().bytes(bytes);
        FixMessage fixMessage = null;
        try {
            switch (msgType) {
                case '0': {
                    Heartbeat msg = messageFactory.heartbeat();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    heartbeatParser.parse(startPos, coreFieldParser, msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    session.onHeartbeat(msg);
                    return;
                }
                case 'A': {
                    Logon msg = messageFactory.logon();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    logonParser.parse(startPos, coreFieldParser, msg);
                    msg.validate();
                    session.onLogon(msg);
                    return;
                }
                case '1': {
                    TestRequest msg = messageFactory.testRequest();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    testRequestParser.parse(startPos, coreFieldParser, msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    session.onTestRequest(msg);
                    return;
                }
                case '2': {
                    ResendRequest msg = messageFactory.resendRequest();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    resendRequestParser.parse(startPos, coreFieldParser, msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    session.onResendRequest(msg);
                    return;
                }
                case '3': {
                    Reject msg = messageFactory.reject();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    rejectParser.parse(startPos, coreFieldParser, msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    session.onReject(msg);
                    return;
                }
                case '4': {
                    SequenceReset msg = messageFactory.sequenceReset();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    sequenceResetParser.parse(startPos, coreFieldParser, msg);
                    msg.validate();
                    session.onSequenceReset(msg);
                    return;
                }
                case '5': {
                    Logout msg = messageFactory.logout();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    logoutParser.parse(startPos, coreFieldParser, msg);
                    msg.validate();
                    session.onLogout(msg);
                    return;
                }
                default: {
                    session.onUnsupportedMessageType(msgType);
                    bytes.readSkip(bytes.readRemaining());
                }
            }
        } catch (InvalidMessageException e) {
            session.msgSeqNum(msgSeqNum);
            session.reject(msgSeqNum, e.getMessage(), msgType, e.getReason(), e.getTag());
        } finally {
            if (fixMessage != null) fixMessage.reset();
        }
    }

    public GeneratedCoreFieldParser coreFieldParser() {
        return coreFieldParser;
    }

    public SessionMessageParser messageFactory(MessageFactory messageFactory) {
        this.messageFactory = messageFactory;
        return this;
    }
}
