package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.fields.GapFillFlag;
import software.chronicle.fix.sessioncode.fields.NewSeqNo;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface SequenceReset extends HeaderTrailer, software.chronicle.fix.sessioncode.messages.SequenceReset, GapFillFlag, NewSeqNo {
    @Deprecated
    static SequenceReset newSequenceReset(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.SequenceReset);
        mg.bytes(bytes);
        return mg;
    }

    static SequenceReset newSequenceReset(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.SequenceReset, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (newSeqNo() == FixMessage.UNSET_LONG) throw new RequiredTagMissing("newSeqNo", 36);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        gapFillFlag(FixMessage.UNSET_CHAR);
        newSeqNo(FixMessage.UNSET_LONG);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((SequenceReset) msg);
    }

    default void copyTo(SequenceReset msg) {
        HeaderTrailer.super.copyTo(msg);
        if (gapFillFlag() != FixMessage.UNSET_CHAR) msg.gapFillFlag(gapFillFlag());
        if (newSeqNo() != FixMessage.UNSET_LONG) msg.newSeqNo(newSeqNo());
    }
}
