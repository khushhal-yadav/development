package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface EncodedIssuerLen {
    /**
     * Tag number for this field
     */
    int FIELD = 348;

    /**
     * @param encodedIssuerLen &gt; FIX TAG 348
     */
    void encodedIssuerLen(long encodedIssuerLen);

    default long encodedIssuerLen() {
        throw new UnsupportedOperationException();
    }
}
