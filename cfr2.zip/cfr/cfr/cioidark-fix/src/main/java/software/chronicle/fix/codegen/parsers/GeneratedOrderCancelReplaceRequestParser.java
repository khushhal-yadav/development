package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedOrderCancelReplaceRequestParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, OrderCancelReplaceRequest orderCancelReplaceRequest) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(orderCancelReplaceRequest);
            fix.orderID(orderCancelReplaceRequest); // 37
            fix.clOrdID(orderCancelReplaceRequest); // 11
            fix.side(orderCancelReplaceRequest); // 54
            fix.orderQty(orderCancelReplaceRequest); // 38
            fix.minQty(orderCancelReplaceRequest); // 110
            fix.ordType(orderCancelReplaceRequest); // 40
            fix.origClOrdID(orderCancelReplaceRequest); // 41
            fix.symbol(orderCancelReplaceRequest); // 55
            fix.symbolSfx(orderCancelReplaceRequest); // 65
            fix.idSource(orderCancelReplaceRequest); // 22
            fix.handlInst(orderCancelReplaceRequest); // 21
            fix.transactTime(orderCancelReplaceRequest); // 60
            fix.account(orderCancelReplaceRequest); // 1
            fix.price(orderCancelReplaceRequest); // 44
            fix.bidPx(orderCancelReplaceRequest); // 132
            fix.offerPx(orderCancelReplaceRequest); // 133
            fix.quoteTime(orderCancelReplaceRequest); // 11048
            fix.timeInForce(orderCancelReplaceRequest); // 59
            fix.createdNS(orderCancelReplaceRequest); // 9999
            fix.lastTraded(orderCancelReplaceRequest); // 11001
            fix.lastTradedDelta(orderCancelReplaceRequest); // 11002
            fix.bidPrice(orderCancelReplaceRequest); // 11005
            fix.askPrice(orderCancelReplaceRequest); // 11006
            fix.orderCapacity(orderCancelReplaceRequest); // 528
            fix.clientID(orderCancelReplaceRequest); // 109
            fix.exDestination(orderCancelReplaceRequest); // 100
            fix.currency(orderCancelReplaceRequest); // 15
            fix.rule80A(orderCancelReplaceRequest); // 47
            fix.settlCurrency(orderCancelReplaceRequest); // 120
            fix.customerOrFirm(orderCancelReplaceRequest); // 204
            fix.locateReqd(orderCancelReplaceRequest); // 114
            fix.ordLinkID(orderCancelReplaceRequest); // 11053
            fix.ordLinkType(orderCancelReplaceRequest); // 11052
            fix.bookingType(orderCancelReplaceRequest); // 775
            fix.tradingAcct(orderCancelReplaceRequest); // 10050
            fix.customPrice1(orderCancelReplaceRequest); // 7491
            fix.tier(orderCancelReplaceRequest); // 10270
            fix.noStrategyParameters(orderCancelReplaceRequest); // 957
            fix.strategyParameterValue(orderCancelReplaceRequest); // 960
            fix.crossStrategy(orderCancelReplaceRequest); // 7411
            fix.corellationClOrdID(orderCancelReplaceRequest); // 9717
            fix.previousLinkOrderID(orderCancelReplaceRequest); // 10184
            fix.rootOrderID(orderCancelReplaceRequest); // 11210
            fix.customerSlang(orderCancelReplaceRequest); // 8004
            fix.receiveTime(orderCancelReplaceRequest); // 10080
            fix.crossRestrictionClientID(orderCancelReplaceRequest); // 10896
            fix.execInst(orderCancelReplaceRequest); // 18
            fix.crossInstruction(orderCancelReplaceRequest); // 6438
            fix.avgPriceAcctIDSource(orderCancelReplaceRequest); // 10428
            fix.tickSizePilotGroup(orderCancelReplaceRequest); // 11319
            fix.clearingInstruction(orderCancelReplaceRequest); // 577
            fix.timeToLive(orderCancelReplaceRequest); // 10014
            fix.srcTargetCompId(orderCancelReplaceRequest); // 10084
            fix.ioiID(orderCancelReplaceRequest); // 23
            fix.securityID(orderCancelReplaceRequest); // 48
            fix.securityAltID(orderCancelReplaceRequest); // 455
            fix.securityAltIDSource(orderCancelReplaceRequest); // 456
            if (fix.checkFinished(orderCancelReplaceRequest, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, orderCancelReplaceRequest, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(orderCancelReplaceRequest.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(orderCancelReplaceRequest.msgSeqNum(), pos);
    }
}
