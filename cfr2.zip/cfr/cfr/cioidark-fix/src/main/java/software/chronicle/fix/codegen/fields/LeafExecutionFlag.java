package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LeafExecutionFlag {
    /**
     * Tag number for this field
     */
    int FIELD = 10217;

    /**
     * @param leafExecutionFlag &gt; FIX TAG 10217
     */
    void leafExecutionFlag(char leafExecutionFlag);

    default char leafExecutionFlag() {
        throw new UnsupportedOperationException();
    }
}
