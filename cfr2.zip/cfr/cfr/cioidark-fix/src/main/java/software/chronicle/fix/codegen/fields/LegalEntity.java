package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LegalEntity {
    /**
     * Tag number for this field
     */
    int FIELD = 10031;

    /**
     * @param legalEntity &gt; FIX TAG 10031
     */
    void legalEntity(String legalEntity);

    default String legalEntity() {
        throw new UnsupportedOperationException();
    }
}
