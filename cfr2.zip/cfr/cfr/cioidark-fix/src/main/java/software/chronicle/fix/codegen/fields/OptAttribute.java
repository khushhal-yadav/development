package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OptAttribute {
    /**
     * Tag number for this field
     */
    int FIELD = 206;

    /**
     * @param optAttribute &gt; FIX TAG 206
     */
    void optAttribute(char optAttribute);

    default char optAttribute() {
        throw new UnsupportedOperationException();
    }
}
