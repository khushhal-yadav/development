package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface EncodedTextLen {
    /**
     * Tag number for this field
     */
    int FIELD = 354;

    /**
     * @param encodedTextLen &gt; FIX TAG 354
     */
    void encodedTextLen(long encodedTextLen);

    default long encodedTextLen() {
        throw new UnsupportedOperationException();
    }
}
