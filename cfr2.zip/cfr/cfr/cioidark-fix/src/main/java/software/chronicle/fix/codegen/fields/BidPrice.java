package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface BidPrice {
    /**
     * Tag number for this field
     */
    int FIELD = 11005;

    /**
     * @param bidPrice &gt; FIX TAG 11005
     */
    void bidPrice(double bidPrice);

    default double bidPrice() {
        throw new UnsupportedOperationException();
    }
}
