package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrigCrossID {
    /**
     * Tag number for this field
     */
    int FIELD = 551;

    /**
     * @param origCrossID &gt; FIX TAG 551
     */
    void origCrossID(String origCrossID);

    default String origCrossID() {
        throw new UnsupportedOperationException();
    }
}
