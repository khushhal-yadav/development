package software.chronicle.fix.codegen.generators;

import java.lang.Deprecated;
import java.lang.Override;
import java.lang.String;
import java.util.concurrent.TimeUnit;
import software.chronicle.fix.codegen.components.MarketDataSnapshotFullRefresh_MDEntriesGrp_1;
import software.chronicle.fix.codegen.messages.BusinessMessageReject;
import software.chronicle.fix.codegen.messages.CioiDarkOrder;
import software.chronicle.fix.codegen.messages.DontKnowTrade;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.Heartbeat;
import software.chronicle.fix.codegen.messages.Logon;
import software.chronicle.fix.codegen.messages.Logout;
import software.chronicle.fix.codegen.messages.MarketDataSnapshotFullRefresh;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReject;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.codegen.messages.RIOMessage;
import software.chronicle.fix.codegen.messages.Reject;
import software.chronicle.fix.codegen.messages.ResendRequest;
import software.chronicle.fix.codegen.messages.SequenceReset;
import software.chronicle.fix.codegen.messages.TestRequest;
import software.chronicle.fix.codegen.parsers.GeneratedCoreFieldParser;
import software.chronicle.fix.staticcode.context.FixSessionContext;

/**
 * Generated at software.chronicle.fix.codegen.MessageGeneratorGenerator.generateCode(MessageGeneratorGenerator.java)
 */
public class MessageGenerator extends software.chronicle.fix.sessioncode.generators.MessageGenerator implements Heartbeat, Logon, TestRequest, ResendRequest, Reject, SequenceReset, Logout, NewOrderSingle, OrderCancelRequest, OrderCancelReplaceRequest, ExecutionReport, OrderCancelReject, DontKnowTrade, RIOMessage, MarketDataSnapshotFullRefresh, MarketDataSnapshotFullRefresh_MDEntriesGrp_1, BusinessMessageReject, CioiDarkOrder {
    public MessageGenerator(char msgType, FixSessionContext context) {
        super(msgType, context);
    }

    @Deprecated
    public MessageGenerator(char msgType) {
        super(msgType);
    }

    @Deprecated
    public MessageGenerator(MessageType messageType) {
        super(messageType.messageType());
    }

    @Override
    public TimeUnit internalTimeUnit() {
        return TimeUnit.MILLISECONDS;
    }

    @Override
    public void senderSubID(String senderSubID) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_50_SenderSubID);
        bytes.append8bit(senderSubID);
    }

    @Override
    public void targetSubID(String targetSubID) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_57_TargetSubID);
        bytes.append8bit(targetSubID);
    }

    @Override
    public void onBehalfOfCompID(String onBehalfOfCompID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_115_OnBehalfOfCompID, 5);
        bytes.append8bit(onBehalfOfCompID);
    }

    @Override
    public void onBehalfOfSubID(String onBehalfOfSubID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_116_OnBehalfOfSubID, 5);
        bytes.append8bit(onBehalfOfSubID);
    }

    @Override
    public void deliverToCompID(String deliverToCompID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_128_DeliverToCompID, 5);
        bytes.append8bit(deliverToCompID);
    }

    @Override
    public void deliverToSubID(String deliverToSubID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_129_DeliverToSubID, 5);
        bytes.append8bit(deliverToSubID);
    }

    @Override
    public void origSendingTime(long origSendingTime) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_122_OrigSendingTime, 5);
        appendTimeStamp(origSendingTime);
    }

    @Override
    public void testReqID(String testReqID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_112_TestReqID, 5);
        bytes.append8bit(testReqID);
    }

    @Override
    public void encryptMethod(long encryptMethod) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_98_EncryptMethod);
        bytes.append(encryptMethod);
    }

    @Override
    public void heartBtInt(long heartBtInt) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_108_HeartBtInt, 5);
        bytes.append(heartBtInt);
    }

    @Override
    public void rawDataLength(long rawDataLength) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_95_RawDataLength);
        bytes.append(rawDataLength);
    }

    @Override
    public void rawData(String rawData) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_96_RawData);
        bytes.append8bit(rawData);
    }

    @Override
    public void resetSeqNumFlag(char resetSeqNumFlag) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_141_ResetSeqNumFlag, 5);
        appendChar(resetSeqNumFlag);
    }

    @Override
    public void username(String username) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_553_Username, 5);
        bytes.append8bit(username);
    }

    @Override
    public void password(String password) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_554_Password, 5);
        bytes.append8bit(password);
    }

    @Override
    public void beginSeqNo(long beginSeqNo) {
        bytes.writeIntAdv(GeneratedCoreFieldParser.FIX_7_BeginSeqNo, 3);
        bytes.append(beginSeqNo);
    }

    @Override
    public void endSeqNo(long endSeqNo) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_16_EndSeqNo);
        bytes.append(endSeqNo);
    }

    @Override
    public void refSeqNum(long refSeqNum) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_45_RefSeqNum);
        bytes.append(refSeqNum);
    }

    @Override
    public void refTagID(long refTagID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_371_RefTagID, 5);
        bytes.append(refTagID);
    }

    @Override
    public void refMsgType(char refMsgType) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_372_RefMsgType, 5);
        appendChar(refMsgType);
    }

    @Override
    public void sessionRejectReason(long sessionRejectReason) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_373_SessionRejectReason, 5);
        bytes.append(sessionRejectReason);
    }

    @Override
    public void text(String text) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_58_Text);
        bytes.append8bit(text);
    }

    @Override
    public void encodedTextLen(long encodedTextLen) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_354_EncodedTextLen, 5);
        bytes.append(encodedTextLen);
    }

    @Override
    public void encodedText(String encodedText) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_355_EncodedText, 5);
        bytes.append8bit(encodedText);
    }

    @Override
    public void gapFillFlag(char gapFillFlag) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_123_GapFillFlag, 5);
        appendChar(gapFillFlag);
    }

    @Override
    public void newSeqNo(long newSeqNo) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_36_NewSeqNo);
        bytes.append(newSeqNo);
    }

    @Override
    public void clOrdID(String clOrdID) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_11_ClOrdID);
        bytes.append8bit(clOrdID);
    }

    @Override
    public void side(char side) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_54_Side);
        appendChar(side);
    }

    @Override
    public void orderQty(double orderQty) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_38_OrderQty);
        appendDouble(orderQty);
    }

    @Override
    public void ordType(char ordType) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_40_OrdType);
        appendChar(ordType);
    }

    @Override
    public void symbol(String symbol) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_55_Symbol);
        bytes.append8bit(symbol);
    }

    @Override
    public void symbolSfx(String symbolSfx) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_65_SymbolSfx);
        bytes.append8bit(symbolSfx);
    }

    @Override
    public void idSource(String idSource) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_22_IDSource);
        bytes.append8bit(idSource);
    }

    @Override
    public void handlInst(char handlInst) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_21_HandlInst);
        appendChar(handlInst);
    }

    @Override
    public void transactTime(long transactTime) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_60_TransactTime);
        appendTimeStamp(transactTime);
    }

    @Override
    public void account(String account) {
        bytes.writeIntAdv(GeneratedCoreFieldParser.FIX_1_Account, 3);
        bytes.append8bit(account);
    }

    @Override
    public void price(double price) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_44_Price);
        appendDouble(price);
    }

    @Override
    public void timeInForce(char timeInForce) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_59_TimeInForce);
        appendChar(timeInForce);
    }

    @Override
    public void createdNS(long createdNS) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_9999_CreatedNS, 6);
        bytes.append(createdNS);
    }

    @Override
    public void lastTraded(double lastTraded) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11001_LastTraded, 7);
        appendDouble(lastTraded);
    }

    @Override
    public void bidPx(double bidPx) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_132_BidPx, 5);
        appendDouble(bidPx);
    }

    @Override
    public void offerPx(double offerPx) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_133_OfferPx, 5);
        appendDouble(offerPx);
    }

    @Override
    public void bidSize(double bidSize) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_134_BidSize, 5);
        appendDouble(bidSize);
    }

    @Override
    public void offerSize(double offerSize) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_135_OfferSize, 5);
        appendDouble(offerSize);
    }

    @Override
    public void orderCapacity(char orderCapacity) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_528_OrderCapacity, 5);
        appendChar(orderCapacity);
    }

    @Override
    public void rule80A(char rule80A) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_47_Rule80A);
        appendChar(rule80A);
    }

    @Override
    public void currency(String currency) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_15_Currency);
        bytes.append8bit(currency);
    }

    @Override
    public void settlCurrency(String settlCurrency) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_120_SettlCurrency, 5);
        bytes.append8bit(settlCurrency);
    }

    @Override
    public void settlmntTyp(char settlmntTyp) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_63_SettlmntTyp);
        appendChar(settlmntTyp);
    }

    @Override
    public void customerOrFirm(long customerOrFirm) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_204_CustomerOrFirm, 5);
        bytes.append(customerOrFirm);
    }

    @Override
    public void clientID(String clientID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_109_ClientID, 5);
        bytes.append8bit(clientID);
    }

    @Override
    public void exDestination(String exDestination) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_100_ExDestination, 5);
        bytes.append8bit(exDestination);
    }

    @Override
    public void locateReqd(char locateReqd) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_114_LocateReqd, 5);
        appendChar(locateReqd);
    }

    @Override
    public void ordLinkID(String ordLinkID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11053_OrdLinkID, 7);
        bytes.append8bit(ordLinkID);
    }

    @Override
    public void ordLinkType(String ordLinkType) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11052_OrdLinkType, 7);
        bytes.append8bit(ordLinkType);
    }

    @Override
    public void bookingType(String bookingType) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_775_BookingType, 5);
        bytes.append8bit(bookingType);
    }

    @Override
    public void orderID(String orderID) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_37_OrderID);
        bytes.append8bit(orderID);
    }

    @Override
    public void tradingAcct(String tradingAcct) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10050_TradingAcct, 7);
        bytes.append8bit(tradingAcct);
    }

    @Override
    public void ioiID(String ioiID) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_23_IOIID);
        bytes.append8bit(ioiID);
    }

    @Override
    public void quoteID(String quoteID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_117_QuoteID, 5);
        bytes.append8bit(quoteID);
    }

    @Override
    public void quoteTime(long quoteTime) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11048_QuoteTime, 7);
        appendTimeStamp(quoteTime);
    }

    @Override
    public void targetStrategy(long targetStrategy) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_847_TargetStrategy, 5);
        bytes.append(targetStrategy);
    }

    @Override
    public void targetStrategyParameters(String targetStrategyParameters) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_848_TargetStrategyParameters, 5);
        bytes.append8bit(targetStrategyParameters);
    }

    @Override
    public void previousLinkSrcSystemID(long previousLinkSrcSystemID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10518_PreviousLinkSrcSystemID, 7);
        bytes.append(previousLinkSrcSystemID);
    }

    @Override
    public void contraOrderCapacity(char contraOrderCapacity) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10158_ContraOrderCapacity, 7);
        appendChar(contraOrderCapacity);
    }

    @Override
    public void orderFlowEntry(String orderFlowEntry) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10201_OrderFlowEntry, 7);
        bytes.append8bit(orderFlowEntry);
    }

    @Override
    public void orderFlowClass(String orderFlowClass) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10201_OrderFlowClass, 7);
        bytes.append8bit(orderFlowClass);
    }

    @Override
    public void traderID(String traderID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10039_TraderID, 7);
        bytes.append8bit(traderID);
    }

    @Override
    public void avgPriceAcct(String avgPriceAcct) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10051_AvgPriceAcct, 7);
        bytes.append8bit(avgPriceAcct);
    }

    @Override
    public void legalEntity(String legalEntity) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10031_LegalEntity, 7);
        bytes.append8bit(legalEntity);
    }

    @Override
    public void securityID(String securityID) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_48_SecurityID);
        bytes.append8bit(securityID);
    }

    @Override
    public void securityAltID(String securityAltID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_455_SecurityAltID, 5);
        bytes.append8bit(securityAltID);
    }

    @Override
    public void securityAltIDSource(String securityAltIDSource) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_456_SecurityAltIDSource, 5);
        bytes.append8bit(securityAltIDSource);
    }

    @Override
    public void crossInstruction(String crossInstruction) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_6438_CrossInstruction, 6);
        bytes.append8bit(crossInstruction);
    }

    @Override
    public void noStrategyParameters(String noStrategyParameters) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_957_NoStrategyParameters, 5);
        bytes.append8bit(noStrategyParameters);
    }

    @Override
    public void strategyParameterValue(String strategyParameterValue) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_960_StrategyParameterValue, 5);
        bytes.append8bit(strategyParameterValue);
    }

    @Override
    public void receiveTime(long receiveTime) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10080_ReceiveTime, 7);
        appendTimeStamp(receiveTime);
    }

    @Override
    public void ordStatus(char ordStatus) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_39_OrdStatus);
        appendChar(ordStatus);
    }

    @Override
    public void sumOfStopExecQty(double sumOfStopExecQty) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10065_SumOfStopExecQty, 7);
        appendDouble(sumOfStopExecQty);
    }

    @Override
    public void cxlQty(double cxlQty) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_84_CxlQty);
        appendDouble(cxlQty);
    }

    @Override
    public void crossRestrictionClientID(String crossRestrictionClientID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10896_CrossRestrictionClientID, 7);
        bytes.append8bit(crossRestrictionClientID);
    }

    @Override
    public void leavesQty(double leavesQty) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_151_LeavesQty, 5);
        appendDouble(leavesQty);
    }

    @Override
    public void srcTargetCompId(String srcTargetCompId) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10084_SrcTargetCompId, 7);
        bytes.append8bit(srcTargetCompId);
    }

    @Override
    public void shortSaleExemptReason(String shortSaleExemptReason) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_1688_ShortSaleExemptReason, 6);
        bytes.append8bit(shortSaleExemptReason);
    }

    @Override
    public void timeToLive(long timeToLive) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10014_TimeToLive, 7);
        appendTimeStamp(timeToLive);
    }

    @Override
    public void avgPriceAcctIDSource(String avgPriceAcctIDSource) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10428_AvgPriceAcctIDSource, 7);
        bytes.append8bit(avgPriceAcctIDSource);
    }

    @Override
    public void tickSizePilotGroup(String tickSizePilotGroup) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11319_TickSizePilotGroup, 7);
        bytes.append8bit(tickSizePilotGroup);
    }

    @Override
    public void sourceFeed(String sourceFeed) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11328_SourceFeed, 7);
        bytes.append8bit(sourceFeed);
    }

    @Override
    public void customerSlang(String customerSlang) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_8004_CustomerSlang, 6);
        bytes.append8bit(customerSlang);
    }

    @Override
    public void rootSrcSystemID(long rootSrcSystemID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10515_RootSrcSystemID, 7);
        bytes.append(rootSrcSystemID);
    }

    @Override
    public void optOutLockedIn(String optOutLockedIn) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10565_OptOutLockedIn, 7);
        bytes.append8bit(optOutLockedIn);
    }

    @Override
    public void srcSystemID(long srcSystemID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10005_SrcSystemID, 7);
        bytes.append(srcSystemID);
    }

    @Override
    public void orderFlowCategory(String orderFlowCategory) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10202_OrderFlowCategory, 7);
        bytes.append8bit(orderFlowCategory);
    }

    @Override
    public void executedBy(String executedBy) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10021_ExecutedBy, 7);
        bytes.append8bit(executedBy);
    }

    @Override
    public void tempLastMkt(String tempLastMkt) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10537_TempLastMkt, 7);
        bytes.append8bit(tempLastMkt);
    }

    @Override
    public void noTempContraBrokers(long noTempContraBrokers) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10533_NoTempContraBrokers, 7);
        bytes.append(noTempContraBrokers);
    }

    @Override
    public void tempContraBroker(String tempContraBroker) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10534_TempContraBroker, 7);
        bytes.append8bit(tempContraBroker);
    }

    @Override
    public void tempContraBrokerSrc(String tempContraBrokerSrc) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10535_TempContraBrokerSrc, 7);
        bytes.append8bit(tempContraBrokerSrc);
    }

    @Override
    public void leafSrcSystemID(long leafSrcSystemID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10965_LeafSrcSystemID, 7);
        bytes.append(leafSrcSystemID);
    }

    @Override
    public void isCurrExecLevel(char isCurrExecLevel) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11027_IsCurrExecLevel, 7);
        appendChar(isCurrExecLevel);
    }

    @Override
    public void contraAccount(String contraAccount) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10514_ContraAccount, 7);
        bytes.append8bit(contraAccount);
    }

    @Override
    public void contraAccountSrc(String contraAccountSrc) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11040_ContraAccountSrc, 7);
        bytes.append8bit(contraAccountSrc);
    }

    @Override
    public void contraAccountType(String contraAccountType) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11041_ContraAccountType, 7);
        bytes.append8bit(contraAccountType);
    }

    @Override
    public void noClearingInstructions(long noClearingInstructions) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_576_NoClearingInstructions, 5);
        bytes.append(noClearingInstructions);
    }

    @Override
    public void clearingInstruction(long clearingInstruction) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_577_ClearingInstruction, 5);
        bytes.append(clearingInstruction);
    }

    @Override
    public void corellationClOrdID(String corellationClOrdID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_9717_CorellationClOrdID, 6);
        bytes.append8bit(corellationClOrdID);
    }

    @Override
    public void previousLinkOrderID(String previousLinkOrderID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10184_PreviousLinkOrderID, 7);
        bytes.append8bit(previousLinkOrderID);
    }

    @Override
    public void rootOrderID(String rootOrderID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11210_RootOrderID, 7);
        bytes.append8bit(rootOrderID);
    }

    @Override
    public void crossStrategy(String crossStrategy) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_7411_CrossStrategy, 6);
        bytes.append8bit(crossStrategy);
    }

    @Override
    public void reportToExch(String reportToExch) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_113_ReportToExch, 5);
        bytes.append8bit(reportToExch);
    }

    @Override
    public void customPrice1(String customPrice1) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_7491_CustomPrice1, 6);
        bytes.append8bit(customPrice1);
    }

    @Override
    public void minQty(double minQty) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_110_MinQty, 5);
        appendDouble(minQty);
    }

    @Override
    public void execInst(String execInst) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_18_ExecInst);
        bytes.append8bit(execInst);
    }

    @Override
    public void locateBroker(String locateBroker) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_5700_LocateBroker, 6);
        bytes.append8bit(locateBroker);
    }

    @Override
    public void locateIdentifier(String locateIdentifier) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_5701_LocateIdentifier, 6);
        bytes.append8bit(locateIdentifier);
    }

    @Override
    public void origClOrdID(String origClOrdID) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_41_OrigClOrdID);
        bytes.append8bit(origClOrdID);
    }

    @Override
    public void crossID(String crossID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_548_CrossID, 5);
        bytes.append8bit(crossID);
    }

    @Override
    public void lastTradedDelta(double lastTradedDelta) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11002_LastTradedDelta, 7);
        appendDouble(lastTradedDelta);
    }

    @Override
    public void bidPrice(double bidPrice) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11005_BidPrice, 7);
        appendDouble(bidPrice);
    }

    @Override
    public void askPrice(double askPrice) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11006_AskPrice, 7);
        appendDouble(askPrice);
    }

    @Override
    public void tier(long tier) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10270_Tier, 7);
        bytes.append(tier);
    }

    @Override
    public void execID(String execID) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_17_ExecID);
        bytes.append8bit(execID);
    }

    @Override
    public void execType(char execType) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_150_ExecType, 5);
        appendChar(execType);
    }

    @Override
    public void openQty(double openQty) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11007_OpenQty, 7);
        appendDouble(openQty);
    }

    @Override
    public void lastShares(double lastShares) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_32_LastShares);
        appendDouble(lastShares);
    }

    @Override
    public void lastPx(double lastPx) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_31_LastPx);
        appendDouble(lastPx);
    }

    @Override
    public void lastMkt(String lastMkt) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_30_LastMkt);
        bytes.append8bit(lastMkt);
    }

    @Override
    public void lastCapacity(String lastCapacity) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_29_LastCapacity);
        bytes.append8bit(lastCapacity);
    }

    @Override
    public void cumQty(double cumQty) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_14_CumQty);
        appendDouble(cumQty);
    }

    @Override
    public void avgPx(double avgPx) {
        bytes.writeIntAdv(GeneratedCoreFieldParser.FIX_6_AvgPx, 3);
        appendDouble(avgPx);
    }

    @Override
    public void tradeDate(String tradeDate) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_75_TradeDate);
        bytes.append8bit(tradeDate);
    }

    @Override
    public void deltaQty(double deltaQty) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_9001_DeltaQty, 6);
        appendDouble(deltaQty);
    }

    @Override
    public void deltaPx(double deltaPx) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_9002_DeltaPx, 6);
        appendDouble(deltaPx);
    }

    @Override
    public void execTransType(char execTransType) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_20_ExecTransType);
        appendChar(execTransType);
    }

    @Override
    public void execRefID(String execRefID) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_19_ExecRefID);
        bytes.append8bit(execRefID);
    }

    @Override
    public void ordRejReason(long ordRejReason) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_103_OrdRejReason, 5);
        bytes.append(ordRejReason);
    }

    @Override
    public void execRestatementReason(long execRestatementReason) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_378_ExecRestatementReason, 5);
        bytes.append(execRestatementReason);
    }

    @Override
    public void settlCurrAmt(double settlCurrAmt) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_119_SettlCurrAmt, 5);
        appendDouble(settlCurrAmt);
    }

    @Override
    public void settlCurrFxRate(double settlCurrFxRate) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_155_SettlCurrFxRate, 5);
        appendDouble(settlCurrFxRate);
    }

    @Override
    public void settlCurrFxRateCalc(char settlCurrFxRateCalc) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_156_SettlCurrFxRateCalc, 5);
        appendChar(settlCurrFxRateCalc);
    }

    @Override
    public void orderVersion(long orderVersion) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_12052_OrderVersion, 7);
        bytes.append(orderVersion);
    }

    @Override
    public void cxlReason(String cxlReason) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_6042_CxlReason, 6);
        bytes.append8bit(cxlReason);
    }

    @Override
    public void lULDLowerPriceBand(double lULDLowerPriceBand) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10721_LULDLowerPriceBand, 7);
        appendDouble(lULDLowerPriceBand);
    }

    @Override
    public void lULDUpperPriceBand(double lULDUpperPriceBand) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10722_LULDUpperPriceBand, 7);
        appendDouble(lULDUpperPriceBand);
    }

    @Override
    public void lULDPriceBandTimestamp(long lULDPriceBandTimestamp) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10723_LULDPriceBandTimestamp, 7);
        appendTimeStamp(lULDPriceBandTimestamp);
    }

    @Override
    public void conditionalOrderQty(double conditionalOrderQty) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_8060_ConditionalOrderQty, 6);
        appendDouble(conditionalOrderQty);
    }

    @Override
    public void zExecID(String zExecID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10018_ZExecID, 7);
        bytes.append8bit(zExecID);
    }

    @Override
    public void actReport(String actReport) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_11037_ActReport, 7);
        bytes.append8bit(actReport);
    }

    @Override
    public void firmId(String firmId) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10054_FirmId, 7);
        bytes.append8bit(firmId);
    }

    @Override
    public void lastParPx(double lastParPx) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_669_LastParPx, 5);
        appendDouble(lastParPx);
    }

    @Override
    public void cxlRejResponseTo(char cxlRejResponseTo) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_434_CxlRejResponseTo, 5);
        appendChar(cxlRejResponseTo);
    }

    @Override
    public void cxlRejReason(long cxlRejReason) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_102_CxlRejReason, 5);
        bytes.append(cxlRejReason);
    }

    @Override
    public void origCrossID(String origCrossID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_551_OrigCrossID, 5);
        bytes.append8bit(origCrossID);
    }

    @Override
    public void priceType(long priceType) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_423_PriceType, 5);
        bytes.append(priceType);
    }

    @Override
    public void dKReason(char dKReason) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_127_DKReason, 5);
        appendChar(dKReason);
    }

    @Override
    public void securityType(String securityType) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_167_SecurityType, 5);
        bytes.append8bit(securityType);
    }

    @Override
    public void maturityMonthYear(String maturityMonthYear) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_200_MaturityMonthYear, 5);
        bytes.append8bit(maturityMonthYear);
    }

    @Override
    public void maturityDay(long maturityDay) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_205_MaturityDay, 5);
        bytes.append(maturityDay);
    }

    @Override
    public void putOrCall(long putOrCall) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_201_PutOrCall, 5);
        bytes.append(putOrCall);
    }

    @Override
    public void strikePrice(double strikePrice) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_202_StrikePrice, 5);
        appendDouble(strikePrice);
    }

    @Override
    public void optAttribute(char optAttribute) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_206_OptAttribute, 5);
        appendChar(optAttribute);
    }

    @Override
    public void contractMultiplier(double contractMultiplier) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_231_ContractMultiplier, 5);
        appendDouble(contractMultiplier);
    }

    @Override
    public void couponRate(double couponRate) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_223_CouponRate, 5);
        appendDouble(couponRate);
    }

    @Override
    public void securityExchange(String securityExchange) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_207_SecurityExchange, 5);
        bytes.append8bit(securityExchange);
    }

    @Override
    public void issuer(String issuer) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_106_Issuer, 5);
        bytes.append8bit(issuer);
    }

    @Override
    public void encodedIssuerLen(long encodedIssuerLen) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_348_EncodedIssuerLen, 5);
        bytes.append(encodedIssuerLen);
    }

    @Override
    public void encodedIssuer(String encodedIssuer) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_349_EncodedIssuer, 5);
        bytes.append8bit(encodedIssuer);
    }

    @Override
    public void securityDesc(String securityDesc) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_107_SecurityDesc, 5);
        bytes.append8bit(securityDesc);
    }

    @Override
    public void encodedSecurityDescLen(long encodedSecurityDescLen) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_350_EncodedSecurityDescLen, 5);
        bytes.append(encodedSecurityDescLen);
    }

    public void encodedSecurityDesc(String encodedSecurityDesc) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_351_EncodedSecurityDesc, 5);
        bytes.append8bit(encodedSecurityDesc);
    }

    @Override
    public void cashOrderQty(double cashOrderQty) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_152_CashOrderQty, 5);
        appendDouble(cashOrderQty);
    }

    @Override
    public void accountIDSource(String accountIDSource) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_660_AccountIDSource, 5);
        bytes.append8bit(accountIDSource);
    }

    @Override
    public void accountType(String accountType) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_581_AccountType, 5);
        bytes.append8bit(accountType);
    }

    @Override
    public void orderUniqID(String orderUniqID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10439_OrderUniqID, 7);
        bytes.append8bit(orderUniqID);
    }

    @Override
    public void xParentOrderID(String xParentOrderID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10243_XParentOrderID, 7);
        bytes.append8bit(xParentOrderID);
    }

    @Override
    public void parentOrderUniqID(String parentOrderUniqID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10517_ParentOrderUniqID, 7);
        bytes.append8bit(parentOrderUniqID);
    }

    @Override
    public void previousLinkOrderUniqID(String previousLinkOrderUniqID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10519_PreviousLinkOrderUniqID, 7);
        bytes.append8bit(previousLinkOrderUniqID);
    }

    @Override
    public void rootOrderUniqID(String rootOrderUniqID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10516_RootOrderUniqID, 7);
        bytes.append8bit(rootOrderUniqID);
    }

    @Override
    public void exDestinationIDSource(char exDestinationIDSource) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_1133_ExDestinationIDSource, 6);
        appendChar(exDestinationIDSource);
    }

    @Override
    public void country(String country) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_421_Country, 5);
        bytes.append8bit(country);
    }

    @Override
    public void orderRestrictions(String orderRestrictions) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_529_OrderRestrictions, 5);
        bytes.append8bit(orderRestrictions);
    }

    @Override
    public void rioTimestamp(long rioTimestamp) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10071_RioTimestamp, 7);
        appendTimeStamp(rioTimestamp);
    }

    @Override
    public void isRioStateEvent(char isRioStateEvent) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10104_IsRioStateEvent, 7);
        appendChar(isRioStateEvent);
    }

    @Override
    public void rioMsgSource(String rioMsgSource) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10208_RioMsgSource, 7);
        bytes.append8bit(rioMsgSource);
    }

    @Override
    public void leafExecFlag(char leafExecFlag) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10217_LeafExecFlag, 7);
        appendChar(leafExecFlag);
    }

    @Override
    public void rioTransactTime(long rioTransactTime) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10436_RioTransactTime, 7);
        appendTimeStamp(rioTransactTime);
    }

    @Override
    public void orderPlacer(String orderPlacer) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10895_OrderPlacer, 7);
        bytes.append8bit(orderPlacer);
    }

    @Override
    public void lafExecID(String lafExecID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10964_LafExecID, 7);
        bytes.append8bit(lafExecID);
    }

    @Override
    public void rioBeginString(String rioBeginString) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10438_RioBeginString, 7);
        bytes.append8bit(rioBeginString);
    }

    @Override
    public void rioMinorVersion(String rioMinorVersion) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10653_RioMinorVersion, 7);
        bytes.append8bit(rioMinorVersion);
    }

    @Override
    public void rioMsgSeq(long rioMsgSeq) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10655_RioMsgSeq, 7);
        bytes.append(rioMsgSeq);
    }

    @Override
    public void replayInd(char replayInd) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10657_ReplayInd, 7);
        appendChar(replayInd);
    }

    @Override
    public void rioMsgSeqSrc(String rioMsgSeqSrc) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10658_RioMsgSeqSrc, 7);
        bytes.append8bit(rioMsgSeqSrc);
    }

    @Override
    public void channelName(String channelName) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10053_ChannelName, 7);
        bytes.append8bit(channelName);
    }

    @Override
    public void contraBroker(String contraBroker) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_375_ContraBroker, 5);
        bytes.append8bit(contraBroker);
    }

    @Override
    public void trdType(long trdType) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_828_TrdType, 5);
        bytes.append(trdType);
    }

    @Override
    public void salesPersonID(String salesPersonID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10036_SalesPersonID, 7);
        bytes.append8bit(salesPersonID);
    }

    @Override
    public void leafExecutionFlag(char leafExecutionFlag) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10217_LeafExecutionFlag, 7);
        appendChar(leafExecutionFlag);
    }

    @Override
    public void xLastActivityUserID(String xLastActivityUserID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_10241_XLastActivityUserID, 7);
        bytes.append8bit(xLastActivityUserID);
    }

    @Override
    public void mDReqID(String mDReqID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_262_MDReqID, 5);
        bytes.append8bit(mDReqID);
    }

    @Override
    public void financialStatus(char financialStatus) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_291_FinancialStatus, 5);
        appendChar(financialStatus);
    }

    @Override
    public void corporateAction(char corporateAction) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_292_CorporateAction, 5);
        appendChar(corporateAction);
    }

    @Override
    public void totalVolumeTraded(double totalVolumeTraded) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_387_TotalVolumeTraded, 5);
        appendDouble(totalVolumeTraded);
    }

    @Override
    public void noMDEntries(long noMDEntries) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_268_NoMDEntries, 5);
        bytes.append(noMDEntries);
    }

    @Override
    public void mDEntryType(char mDEntryType) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_269_MDEntryType, 5);
        appendChar(mDEntryType);
    }

    @Override
    public void mDEntryPx(double mDEntryPx) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_270_MDEntryPx, 5);
        appendDouble(mDEntryPx);
    }

    @Override
    public void mDEntrySize(double mDEntrySize) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_271_MDEntrySize, 5);
        appendDouble(mDEntrySize);
    }

    @Override
    public void mDEntryDate(String mDEntryDate) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_272_MDEntryDate, 5);
        bytes.append8bit(mDEntryDate);
    }

    @Override
    public void mDEntryTime(String mDEntryTime) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_273_MDEntryTime, 5);
        bytes.append8bit(mDEntryTime);
    }

    public void tickDirection(char tickDirection) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_274_TickDirection, 5);
        appendChar(tickDirection);
    }

    @Override
    public void mDMkt(String mDMkt) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_275_MDMkt, 5);
        bytes.append8bit(mDMkt);
    }

    @Override
    public void tradingSessionID(String tradingSessionID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_336_TradingSessionID, 5);
        bytes.append8bit(tradingSessionID);
    }

    @Override
    public void quoteCondition(String quoteCondition) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_276_QuoteCondition, 5);
        bytes.append8bit(quoteCondition);
    }

    @Override
    public void tradeCondition(String tradeCondition) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_277_TradeCondition, 5);
        bytes.append8bit(tradeCondition);
    }

    @Override
    public void mDEntryOriginator(String mDEntryOriginator) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_282_MDEntryOriginator, 5);
        bytes.append8bit(mDEntryOriginator);
    }

    @Override
    public void locationID(String locationID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_283_LocationID, 5);
        bytes.append8bit(locationID);
    }

    @Override
    public void deskID(String deskID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_284_DeskID, 5);
        bytes.append8bit(deskID);
    }

    @Override
    public void openCloseSettleFlag(char openCloseSettleFlag) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_286_OpenCloseSettleFlag, 5);
        appendChar(openCloseSettleFlag);
    }

    @Override
    public void expireDate(String expireDate) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_432_ExpireDate, 5);
        bytes.append8bit(expireDate);
    }

    @Override
    public void expireTime(long expireTime) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_126_ExpireTime, 5);
        appendTimeStamp(expireTime);
    }

    @Override
    public void sellerDays(long sellerDays) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_287_SellerDays, 5);
        bytes.append(sellerDays);
    }

    @Override
    public void quoteEntryID(String quoteEntryID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_299_QuoteEntryID, 5);
        bytes.append8bit(quoteEntryID);
    }

    @Override
    public void mDEntryBuyer(String mDEntryBuyer) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_288_MDEntryBuyer, 5);
        bytes.append8bit(mDEntryBuyer);
    }

    @Override
    public void mDEntrySeller(String mDEntrySeller) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_289_MDEntrySeller, 5);
        bytes.append8bit(mDEntrySeller);
    }

    @Override
    public void numberOfOrders(long numberOfOrders) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_346_NumberOfOrders, 5);
        bytes.append(numberOfOrders);
    }

    @Override
    public void mDEntryPositionNo(long mDEntryPositionNo) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_290_MDEntryPositionNo, 5);
        bytes.append(mDEntryPositionNo);
    }

    @Override
    public MarketDataSnapshotFullRefresh_MDEntriesGrp_1 marketDataSnapshotFullRefresh_MDEntriesGrp_1(int index) {
        return this;
    }

    @Override
    public void businessRejectRefID(String businessRejectRefID) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_379_BusinessRejectRefID, 5);
        bytes.append8bit(businessRejectRefID);
    }

    @Override
    public void businessRejectReason(long businessRejectReason) {
        bytes.writeLongAdv(GeneratedCoreFieldParser.FIX_380_BusinessRejectReason, 5);
        bytes.append(businessRejectReason);
    }

    @Override
    public void stopPx(double stopPx) {
        bytes.writeInt(GeneratedCoreFieldParser.FIX_99_StopPx);
        appendDouble(stopPx);
    }

    public String account() {
        throw new UnsupportedOperationException();
    }

    public String avgPriceAcct() {
        throw new UnsupportedOperationException();
    }

    public String avgPriceAcctIDSource() {
        throw new UnsupportedOperationException();
    }

    public double avgPx() {
        throw new UnsupportedOperationException();
    }

    public double bidPx() {
        throw new UnsupportedOperationException();
    }

    public double bidSize() {
        throw new UnsupportedOperationException();
    }

    public String bookingType() {
        throw new UnsupportedOperationException();
    }

    public String clOrdID() {
        throw new UnsupportedOperationException();
    }

    public long clearingInstruction() {
        throw new UnsupportedOperationException();
    }

    public String clientID() {
        throw new UnsupportedOperationException();
    }

    public String contraAccount() {
        throw new UnsupportedOperationException();
    }

    public String contraAccountSrc() {
        throw new UnsupportedOperationException();
    }

    public String contraAccountType() {
        throw new UnsupportedOperationException();
    }

    public char contraOrderCapacity() {
        throw new UnsupportedOperationException();
    }

    public double contractMultiplier() {
        throw new UnsupportedOperationException();
    }

    public String corellationClOrdID() {
        throw new UnsupportedOperationException();
    }

    public double couponRate() {
        throw new UnsupportedOperationException();
    }

    public long createdNS() {
        throw new UnsupportedOperationException();
    }

    public String crossID() {
        throw new UnsupportedOperationException();
    }

    public String crossInstruction() {
        throw new UnsupportedOperationException();
    }

    public String crossRestrictionClientID() {
        throw new UnsupportedOperationException();
    }

    public String crossStrategy() {
        throw new UnsupportedOperationException();
    }

    public double cumQty() {
        throw new UnsupportedOperationException();
    }

    public String currency() {
        throw new UnsupportedOperationException();
    }

    public String customPrice1() {
        throw new UnsupportedOperationException();
    }

    public long customerOrFirm() {
        throw new UnsupportedOperationException();
    }

    public String customerSlang() {
        throw new UnsupportedOperationException();
    }

    public double cxlQty() {
        throw new UnsupportedOperationException();
    }

    public long cxlRejReason() {
        throw new UnsupportedOperationException();
    }

    public double deltaPx() {
        throw new UnsupportedOperationException();
    }

    public double deltaQty() {
        throw new UnsupportedOperationException();
    }

    public String encodedIssuer() {
        throw new UnsupportedOperationException();
    }

    public long encodedIssuerLen() {
        throw new UnsupportedOperationException();
    }

    public String encodedSecurityDesc() {
        throw new UnsupportedOperationException();
    }

    public long encodedSecurityDescLen() {
        throw new UnsupportedOperationException();
    }

    public String encodedText() {
        throw new UnsupportedOperationException();
    }

    public long encodedTextLen() {
        throw new UnsupportedOperationException();
    }

    public String exDestination() {
        throw new UnsupportedOperationException();
    }

    public String execID() {
        throw new UnsupportedOperationException();
    }

    public String execInst() {
        throw new UnsupportedOperationException();
    }

    public String execRefID() {
        throw new UnsupportedOperationException();
    }

    public char execType() {
        throw new UnsupportedOperationException();
    }

    public String executedBy() {
        throw new UnsupportedOperationException();
    }

    public char handlInst() {
        throw new UnsupportedOperationException();
    }

    public String idSource() {
        throw new UnsupportedOperationException();
    }

    public String ioiID() {
        throw new UnsupportedOperationException();
    }

    public char isCurrExecLevel() {
        throw new UnsupportedOperationException();
    }

    public String issuer() {
        throw new UnsupportedOperationException();
    }

    public String lastCapacity() {
        throw new UnsupportedOperationException();
    }

    public String lastMkt() {
        throw new UnsupportedOperationException();
    }

    public double lastPx() {
        throw new UnsupportedOperationException();
    }

    public double lastShares() {
        throw new UnsupportedOperationException();
    }

    public double lastTraded() {
        throw new UnsupportedOperationException();
    }

    public double lastTradedDelta() {
        throw new UnsupportedOperationException();
    }

    public long leafSrcSystemID() {
        throw new UnsupportedOperationException();
    }

    public double leavesQty() {
        throw new UnsupportedOperationException();
    }

    public String legalEntity() {
        throw new UnsupportedOperationException();
    }

    public String locateBroker() {
        throw new UnsupportedOperationException();
    }

    public String locateIdentifier() {
        throw new UnsupportedOperationException();
    }

    public char locateReqd() {
        throw new UnsupportedOperationException();
    }

    public long maturityDay() {
        throw new UnsupportedOperationException();
    }

    public String maturityMonthYear() {
        throw new UnsupportedOperationException();
    }

    public double minQty() {
        throw new UnsupportedOperationException();
    }

    public long noClearingInstructions() {
        throw new UnsupportedOperationException();
    }

    public String noStrategyParameters() {
        throw new UnsupportedOperationException();
    }

    public long noTempContraBrokers() {
        throw new UnsupportedOperationException();
    }

    public double offerPx() {
        throw new UnsupportedOperationException();
    }

    public double offerSize() {
        throw new UnsupportedOperationException();
    }

    public double openQty() {
        throw new UnsupportedOperationException();
    }

    public char optAttribute() {
        throw new UnsupportedOperationException();
    }

    public String optOutLockedIn() {
        throw new UnsupportedOperationException();
    }

    public String ordLinkID() {
        throw new UnsupportedOperationException();
    }

    public String ordLinkType() {
        throw new UnsupportedOperationException();
    }

    public long ordRejReason() {
        throw new UnsupportedOperationException();
    }

    public char ordStatus() {
        throw new UnsupportedOperationException();
    }

    public char ordType() {
        throw new UnsupportedOperationException();
    }

    public char orderCapacity() {
        throw new UnsupportedOperationException();
    }

    public String orderFlowCategory() {
        throw new UnsupportedOperationException();
    }

    public String orderFlowClass() {
        throw new UnsupportedOperationException();
    }

    public String orderFlowEntry() {
        throw new UnsupportedOperationException();
    }

    public String orderID() {
        throw new UnsupportedOperationException();
    }

    public double orderQty() {
        throw new UnsupportedOperationException();
    }

    public long orderVersion() {
        throw new UnsupportedOperationException();
    }

    public String origClOrdID() {
        throw new UnsupportedOperationException();
    }

    public String previousLinkOrderID() {
        throw new UnsupportedOperationException();
    }

    public long previousLinkSrcSystemID() {
        throw new UnsupportedOperationException();
    }

    public double price() {
        throw new UnsupportedOperationException();
    }

    public long putOrCall() {
        throw new UnsupportedOperationException();
    }

    public long quoteTime() {
        throw new UnsupportedOperationException();
    }

    public long receiveTime() {
        throw new UnsupportedOperationException();
    }

    public char refMsgType() {
        throw new UnsupportedOperationException();
    }

    public long refSeqNum() {
        throw new UnsupportedOperationException();
    }

    public String reportToExch() {
        throw new UnsupportedOperationException();
    }

    public String rootOrderID() {
        throw new UnsupportedOperationException();
    }

    public long rootSrcSystemID() {
        throw new UnsupportedOperationException();
    }

    public char rule80A() {
        throw new UnsupportedOperationException();
    }

    public String securityAltID() {
        throw new UnsupportedOperationException();
    }

    public String securityAltIDSource() {
        throw new UnsupportedOperationException();
    }

    public String securityDesc() {
        throw new UnsupportedOperationException();
    }

    public String securityExchange() {
        throw new UnsupportedOperationException();
    }

    public String securityID() {
        throw new UnsupportedOperationException();
    }

    public String securityType() {
        throw new UnsupportedOperationException();
    }

    public double settlCurrAmt() {
        throw new UnsupportedOperationException();
    }

    public double settlCurrFxRate() {
        throw new UnsupportedOperationException();
    }

    public char settlCurrFxRateCalc() {
        throw new UnsupportedOperationException();
    }

    public String settlCurrency() {
        throw new UnsupportedOperationException();
    }

    public char settlmntTyp() {
        throw new UnsupportedOperationException();
    }

    public String shortSaleExemptReason() {
        throw new UnsupportedOperationException();
    }

    public char side() {
        throw new UnsupportedOperationException();
    }

    public String sourceFeed() {
        throw new UnsupportedOperationException();
    }

    public long srcSystemID() {
        throw new UnsupportedOperationException();
    }

    public String srcTargetCompId() {
        throw new UnsupportedOperationException();
    }

    public String strategyParameterValue() {
        throw new UnsupportedOperationException();
    }

    public double strikePrice() {
        throw new UnsupportedOperationException();
    }

    public double sumOfStopExecQty() {
        throw new UnsupportedOperationException();
    }

    public String symbol() {
        throw new UnsupportedOperationException();
    }

    public String symbolSfx() {
        throw new UnsupportedOperationException();
    }

    public long targetStrategy() {
        throw new UnsupportedOperationException();
    }

    public String targetStrategyParameters() {
        throw new UnsupportedOperationException();
    }

    public String tempContraBroker() {
        throw new UnsupportedOperationException();
    }

    public String tempContraBrokerSrc() {
        throw new UnsupportedOperationException();
    }

    public String tempLastMkt() {
        throw new UnsupportedOperationException();
    }

    public String testReqID() {
        throw new UnsupportedOperationException();
    }

    public String text() {
        throw new UnsupportedOperationException();
    }

    public String tickSizePilotGroup() {
        throw new UnsupportedOperationException();
    }

    public char timeInForce() {
        throw new UnsupportedOperationException();
    }

    public long timeToLive() {
        throw new UnsupportedOperationException();
    }

    public String tradeDate() {
        throw new UnsupportedOperationException();
    }

    public String traderID() {
        throw new UnsupportedOperationException();
    }

    public String tradingAcct() {
        throw new UnsupportedOperationException();
    }

    public long transactTime() {
        throw new UnsupportedOperationException();
    }

    public String zExecID() {
        throw new UnsupportedOperationException();
    }

    public enum MessageType {
        Heartbeat('0'),

        Logon('A'),

        TestRequest('1'),

        ResendRequest('2'),

        Reject('3'),

        SequenceReset('4'),

        Logout('5'),

        NewOrderSingle('D'),

        OrderCancelRequest('F'),

        OrderCancelReplaceRequest('G'),

        ExecutionReport('8'),

        OrderCancelReject('9'),

        DontKnowTrade('Q'),

        RIOMessage(('R' << 8) + 'I'),

        MarketDataSnapshotFullRefresh('W'),

        BusinessMessageReject('j'),

        CioiDarkOrder('x');

        final char messageType;

        MessageType(int messageType) {
            this.messageType = (char) messageType;
        }

        public char messageType() {
            return messageType;
        }
    }
}
