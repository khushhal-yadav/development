package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface RootSrcSystemID {
    /**
     * Tag number for this field
     */
    int FIELD = 10515;

    /**
     * @param rootSrcSystemID &gt; FIX TAG 10515
     */
    void rootSrcSystemID(long rootSrcSystemID);

    default long rootSrcSystemID() {
        throw new UnsupportedOperationException();
    }
}
