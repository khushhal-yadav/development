package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface RioMsgSource {
    /**
     * Tag number for this field
     */
    int FIELD = 10208;

    /**
     * @param rioMsgSource &gt; FIX TAG 10208
     */
    void rioMsgSource(String rioMsgSource);

    default String rioMsgSource() {
        throw new UnsupportedOperationException();
    }
}
