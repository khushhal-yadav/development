package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SecurityID {
    /**
     * Tag number for this field
     */
    int FIELD = 48;

    /**
     * @param securityID &gt; FIX TAG 48
     */
    void securityID(String securityID);

    default String securityID() {
        throw new UnsupportedOperationException();
    }
}
