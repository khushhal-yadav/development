package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface LastParPx {
    /**
     * Tag number for this field
     */
    int FIELD = 669;

    /**
     * @param lastParPx &gt; FIX TAG 669
     */
    void lastParPx(double lastParPx);

    default double lastParPx() {
        throw new UnsupportedOperationException();
    }
}
