package software.chronicle.fix.codegen.fields;

import java.util.concurrent.TimeUnit;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ExpireTime {
    /**
     * Tag number for this field
     */
    int FIELD = 126;

    /**
     * @param expireTime &gt; FIX TAG 126
     */
    void expireTime(long expireTime);

    default long expireTime() {
        throw new UnsupportedOperationException();
    }

    default void expireTime(long expireTime, TimeUnit timeUnit) {
        throw new UnsupportedOperationException();
    }
}
