package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SalesPersonID {
    /**
     * Tag number for this field
     */
    int FIELD = 10036;

    /**
     * @param salesPersonID &gt; FIX TAG 10036
     */
    void salesPersonID(String salesPersonID);

    default String salesPersonID() {
        throw new UnsupportedOperationException();
    }
}
