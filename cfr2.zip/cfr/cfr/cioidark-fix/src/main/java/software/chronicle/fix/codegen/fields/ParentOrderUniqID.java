package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ParentOrderUniqID {
    /**
     * Tag number for this field
     */
    int FIELD = 10517;

    /**
     * @param parentOrderUniqID &gt; FIX TAG 10517
     */
    void parentOrderUniqID(String parentOrderUniqID);

    default String parentOrderUniqID() {
        throw new UnsupportedOperationException();
    }
}
