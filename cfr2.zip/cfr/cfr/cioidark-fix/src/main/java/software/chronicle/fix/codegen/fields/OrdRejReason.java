package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrdRejReason {
    /**
     * Tag number for this field
     */
    int FIELD = 103;

    int BROKER_OPTION = 0;

    int UNKNOWN_SYMBOL = 1;

    int EXCHANGE_CLOSED = 2;

    int ORDER_EXCEEDS_LIMIT = 3;

    int TOO_LATE_TO_ENTER = 4;

    int UNKNOWN_ORDER = 5;

    int DUPLICATE_ORDER = 6;

    int DUPLICATE_VERBAL = 7;

    int STALE_ORDER = 8;

    /**
     * @param ordRejReason &gt; FIX TAG 103
     */
    void ordRejReason(long ordRejReason);

    default long ordRejReason() {
        throw new UnsupportedOperationException();
    }

    static String asString(int value) {
        switch (value) {
            case BROKER_OPTION:
                    return "BROKER_OPTION";
            case UNKNOWN_SYMBOL:
                    return "UNKNOWN_SYMBOL";
            case EXCHANGE_CLOSED:
                    return "EXCHANGE_CLOSED";
            case ORDER_EXCEEDS_LIMIT:
                    return "ORDER_EXCEEDS_LIMIT";
            case TOO_LATE_TO_ENTER:
                    return "TOO_LATE_TO_ENTER";
            case UNKNOWN_ORDER:
                    return "UNKNOWN_ORDER";
            case DUPLICATE_ORDER:
                    return "DUPLICATE_ORDER";
            case DUPLICATE_VERBAL:
                    return "DUPLICATE_VERBAL";
            case STALE_ORDER:
                    return "STALE_ORDER";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
