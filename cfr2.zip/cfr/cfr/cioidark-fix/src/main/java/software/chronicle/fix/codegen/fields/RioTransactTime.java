package software.chronicle.fix.codegen.fields;

import java.util.concurrent.TimeUnit;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface RioTransactTime {
    /**
     * Tag number for this field
     */
    int FIELD = 10436;

    /**
     * @param rioTransactTime &gt; FIX TAG 10436
     */
    void rioTransactTime(long rioTransactTime);

    default long rioTransactTime() {
        throw new UnsupportedOperationException();
    }

    default void rioTransactTime(long rioTransactTime, TimeUnit timeUnit) {
        throw new UnsupportedOperationException();
    }
}
