package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SettlCurrFxRateCalc {
    /**
     * Tag number for this field
     */
    int FIELD = 156;

    char DIVIDE = 'D';

    char MULTIPLY = 'M';

    /**
     * @param settlCurrFxRateCalc &gt; FIX TAG 156
     */
    void settlCurrFxRateCalc(char settlCurrFxRateCalc);

    default char settlCurrFxRateCalc() {
        throw new UnsupportedOperationException();
    }

    static String asString(char value) {
        switch (value) {
            case DIVIDE:
                    return "DIVIDE";
            case MULTIPLY:
                    return "MULTIPLY";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
