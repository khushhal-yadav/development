package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ShortSaleExemptReason {
    /**
     * Tag number for this field
     */
    int FIELD = 1688;

    /**
     * @param shortSaleExemptReason &gt; FIX TAG 1688
     */
    void shortSaleExemptReason(String shortSaleExemptReason);

    default String shortSaleExemptReason() {
        throw new UnsupportedOperationException();
    }
}
