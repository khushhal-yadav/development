package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.BusinessMessageReject;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedBusinessMessageRejectParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, BusinessMessageReject businessMessageReject) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(businessMessageReject);
            fix.refSeqNum(businessMessageReject); // 45
            fix.refMsgType(businessMessageReject); // 372
            fix.businessRejectRefID(businessMessageReject); // 379
            fix.businessRejectReason(businessMessageReject); // 380
            fix.text(businessMessageReject); // 58
            fix.encodedTextLen(businessMessageReject); // 354
            fix.encodedText(businessMessageReject); // 355
            if (fix.checkFinished(businessMessageReject, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, businessMessageReject, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(businessMessageReject.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(businessMessageReject.msgSeqNum(), pos);
    }
}
