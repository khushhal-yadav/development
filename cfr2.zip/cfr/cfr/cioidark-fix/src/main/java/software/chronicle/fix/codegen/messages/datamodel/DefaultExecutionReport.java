package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import java.util.concurrent.TimeUnit;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultExecutionReport extends DefaultHeaderTrailer implements ExecutionReport, HeaderTrailer {
    private String orderID = null;

    private String clOrdID = null;

    private String execID = null;

    private String origClOrdID = null;

    private char execType = FixMessage.UNSET_CHAR;

    private char ordStatus = FixMessage.UNSET_CHAR;

    private String account = null;

    private char settlmntTyp = FixMessage.UNSET_CHAR;

    private char side = FixMessage.UNSET_CHAR;

    private String symbol = null;

    private String symbolSfx = null;

    private String idSource = null;

    private double orderQty = FixMessage.UNSET_DOUBLE;

    private char ordType = FixMessage.UNSET_CHAR;

    private double price = FixMessage.UNSET_DOUBLE;

    private double lastTraded = FixMessage.UNSET_DOUBLE;

    private double lastTradedDelta = FixMessage.UNSET_DOUBLE;

    private double openQty = FixMessage.UNSET_DOUBLE;

    private char timeInForce = FixMessage.UNSET_CHAR;

    private double lastShares = FixMessage.UNSET_DOUBLE;

    private double lastPx = FixMessage.UNSET_DOUBLE;

    private String lastMkt = null;

    private String lastCapacity = null;

    private char orderCapacity = FixMessage.UNSET_CHAR;

    private double leavesQty = FixMessage.UNSET_DOUBLE;

    private double cumQty = FixMessage.UNSET_DOUBLE;

    private double avgPx = FixMessage.UNSET_DOUBLE;

    private String tradeDate = null;

    private long transactTime = FixMessage.UNSET_LONG;

    private long createdNS = FixMessage.UNSET_LONG;

    private String text = null;

    private double deltaQty = FixMessage.UNSET_DOUBLE;

    private double deltaPx = FixMessage.UNSET_DOUBLE;

    private char execTransType = FixMessage.UNSET_CHAR;

    private double cxlQty = FixMessage.UNSET_DOUBLE;

    private String execRefID = null;

    private long ordRejReason = FixMessage.UNSET_LONG;

    private long execRestatementReason = FixMessage.UNSET_LONG;

    private char rule80A = FixMessage.UNSET_CHAR;

    private double settlCurrAmt = FixMessage.UNSET_DOUBLE;

    private String currency = null;

    private String settlCurrency = null;

    private double settlCurrFxRate = FixMessage.UNSET_DOUBLE;

    private char settlCurrFxRateCalc = FixMessage.UNSET_CHAR;

    private String ordLinkID = null;

    private String ordLinkType = null;

    private String bookingType = null;

    private String srcTargetCompId = null;

    private long orderVersion = FixMessage.UNSET_LONG;

    private long quoteTime = FixMessage.UNSET_LONG;

    private double bidPx = FixMessage.UNSET_DOUBLE;

    private double offerPx = FixMessage.UNSET_DOUBLE;

    private double bidSize = FixMessage.UNSET_DOUBLE;

    private double offerSize = FixMessage.UNSET_DOUBLE;

    private char locateReqd = FixMessage.UNSET_CHAR;

    private String locateBroker = null;

    private String locateIdentifier = null;

    private long previousLinkSrcSystemID = FixMessage.UNSET_LONG;

    private char contraOrderCapacity = FixMessage.UNSET_CHAR;

    private String orderFlowEntry = null;

    private String orderFlowClass = null;

    private String traderID = null;

    private String avgPriceAcct = null;

    private String legalEntity = null;

    private String securityID = null;

    private String securityAltID = null;

    private String securityAltIDSource = null;

    private String crossInstruction = null;

    private double sumOfStopExecQty = FixMessage.UNSET_DOUBLE;

    private long receiveTime = FixMessage.UNSET_LONG;

    private String crossRestrictionClientID = null;

    private String cxlReason = null;

    private double lULDLowerPriceBand = FixMessage.UNSET_DOUBLE;

    private double lULDUpperPriceBand = FixMessage.UNSET_DOUBLE;

    private long lULDPriceBandTimestamp = FixMessage.UNSET_LONG;

    private double conditionalOrderQty = FixMessage.UNSET_DOUBLE;

    private String ioiID = null;

    private String zExecID = null;

    private String actReport = null;

    private long noClearingInstructions = FixMessage.UNSET_LONG;

    private long clearingInstruction = FixMessage.UNSET_LONG;

    private String firmId = null;

    private String avgPriceAcctIDSource = null;

    private String tickSizePilotGroup = null;

    private String sourceFeed = null;

    private String customerSlang = null;

    private long rootSrcSystemID = FixMessage.UNSET_LONG;

    private long srcSystemID = FixMessage.UNSET_LONG;

    private String orderFlowCategory = null;

    private String executedBy = null;

    private String tempLastMkt = null;

    private long noTempContraBrokers = FixMessage.UNSET_LONG;

    private String tempContraBroker = null;

    private String tempContraBrokerSrc = null;

    private long leafSrcSystemID = FixMessage.UNSET_LONG;

    private char isCurrExecLevel = FixMessage.UNSET_CHAR;

    private String contraAccount = null;

    private String contraAccountSrc = null;

    private String contraAccountType = null;

    private String corellationClOrdID = null;

    private String previousLinkOrderID = null;

    private String rootOrderID = null;

    private String customPrice1 = null;

    private String strategyParameterValue = null;

    private String crossStrategy = null;

    private String crossID = null;

    private String execInst = null;

    private double minQty = FixMessage.UNSET_DOUBLE;

    private String reportToExch = null;

    private double lastParPx = FixMessage.UNSET_DOUBLE;

    public char msgType() {
        return MessageManifest.ExecutionReport;
    }

    public String orderID() {
        return orderID;
    }

    @Override
    public void orderID(String orderID) {
        this.orderID = orderID;
    }

    public String clOrdID() {
        return clOrdID;
    }

    @Override
    public void clOrdID(String clOrdID) {
        this.clOrdID = clOrdID;
    }

    public String execID() {
        return execID;
    }

    @Override
    public void execID(String execID) {
        this.execID = execID;
    }

    public String origClOrdID() {
        return origClOrdID;
    }

    @Override
    public void origClOrdID(String origClOrdID) {
        this.origClOrdID = origClOrdID;
    }

    public char execType() {
        return execType;
    }

    @Override
    public void execType(char execType) {
        this.execType = execType;
    }

    public char ordStatus() {
        return ordStatus;
    }

    @Override
    public void ordStatus(char ordStatus) {
        this.ordStatus = ordStatus;
    }

    public String account() {
        return account;
    }

    @Override
    public void account(String account) {
        this.account = account;
    }

    public char settlmntTyp() {
        return settlmntTyp;
    }

    @Override
    public void settlmntTyp(char settlmntTyp) {
        this.settlmntTyp = settlmntTyp;
    }

    public char side() {
        return side;
    }

    @Override
    public void side(char side) {
        this.side = side;
    }

    public String symbol() {
        return symbol;
    }

    @Override
    public void symbol(String symbol) {
        this.symbol = symbol;
    }

    public String symbolSfx() {
        return symbolSfx;
    }

    @Override
    public void symbolSfx(String symbolSfx) {
        this.symbolSfx = symbolSfx;
    }

    public String idSource() {
        return idSource;
    }

    @Override
    public void idSource(String idSource) {
        this.idSource = idSource;
    }

    public double orderQty() {
        return orderQty;
    }

    @Override
    public void orderQty(double orderQty) {
        this.orderQty = orderQty;
    }

    public char ordType() {
        return ordType;
    }

    @Override
    public void ordType(char ordType) {
        this.ordType = ordType;
    }

    public double price() {
        return price;
    }

    @Override
    public void price(double price) {
        this.price = price;
    }

    public double lastTraded() {
        return lastTraded;
    }

    @Override
    public void lastTraded(double lastTraded) {
        this.lastTraded = lastTraded;
    }

    public double lastTradedDelta() {
        return lastTradedDelta;
    }

    @Override
    public void lastTradedDelta(double lastTradedDelta) {
        this.lastTradedDelta = lastTradedDelta;
    }

    public double openQty() {
        return openQty;
    }

    @Override
    public void openQty(double openQty) {
        this.openQty = openQty;
    }

    public char timeInForce() {
        return timeInForce;
    }

    @Override
    public void timeInForce(char timeInForce) {
        this.timeInForce = timeInForce;
    }

    public double lastShares() {
        return lastShares;
    }

    @Override
    public void lastShares(double lastShares) {
        this.lastShares = lastShares;
    }

    public double lastPx() {
        return lastPx;
    }

    @Override
    public void lastPx(double lastPx) {
        this.lastPx = lastPx;
    }

    public String lastMkt() {
        return lastMkt;
    }

    @Override
    public void lastMkt(String lastMkt) {
        this.lastMkt = lastMkt;
    }

    public String lastCapacity() {
        return lastCapacity;
    }

    @Override
    public void lastCapacity(String lastCapacity) {
        this.lastCapacity = lastCapacity;
    }

    public char orderCapacity() {
        return orderCapacity;
    }

    @Override
    public void orderCapacity(char orderCapacity) {
        this.orderCapacity = orderCapacity;
    }

    public double leavesQty() {
        return leavesQty;
    }

    @Override
    public void leavesQty(double leavesQty) {
        this.leavesQty = leavesQty;
    }

    public double cumQty() {
        return cumQty;
    }

    @Override
    public void cumQty(double cumQty) {
        this.cumQty = cumQty;
    }

    public double avgPx() {
        return avgPx;
    }

    @Override
    public void avgPx(double avgPx) {
        this.avgPx = avgPx;
    }

    public String tradeDate() {
        return tradeDate;
    }

    @Override
    public void tradeDate(String tradeDate) {
        this.tradeDate = tradeDate;
    }

    public long transactTime() {
        return transactTime;
    }

    @Override
    public void transactTime(long transactTime, TimeUnit timeUnit) {
        transactTime(transactTime);
    }

    @Override
    public void transactTime(long transactTime) {
        this.transactTime = transactTime;
    }

    public long createdNS() {
        return createdNS;
    }

    @Override
    public void createdNS(long createdNS) {
        this.createdNS = createdNS;
    }

    public String text() {
        return text;
    }

    @Override
    public void text(String text) {
        this.text = text;
    }

    public double deltaQty() {
        return deltaQty;
    }

    @Override
    public void deltaQty(double deltaQty) {
        this.deltaQty = deltaQty;
    }

    public double deltaPx() {
        return deltaPx;
    }

    @Override
    public void deltaPx(double deltaPx) {
        this.deltaPx = deltaPx;
    }

    public char execTransType() {
        return execTransType;
    }

    @Override
    public void execTransType(char execTransType) {
        this.execTransType = execTransType;
    }

    public double cxlQty() {
        return cxlQty;
    }

    @Override
    public void cxlQty(double cxlQty) {
        this.cxlQty = cxlQty;
    }

    public String execRefID() {
        return execRefID;
    }

    @Override
    public void execRefID(String execRefID) {
        this.execRefID = execRefID;
    }

    public long ordRejReason() {
        return ordRejReason;
    }

    @Override
    public void ordRejReason(long ordRejReason) {
        this.ordRejReason = ordRejReason;
    }

    public long execRestatementReason() {
        return execRestatementReason;
    }

    @Override
    public void execRestatementReason(long execRestatementReason) {
        this.execRestatementReason = execRestatementReason;
    }

    public char rule80A() {
        return rule80A;
    }

    @Override
    public void rule80A(char rule80A) {
        this.rule80A = rule80A;
    }

    public double settlCurrAmt() {
        return settlCurrAmt;
    }

    @Override
    public void settlCurrAmt(double settlCurrAmt) {
        this.settlCurrAmt = settlCurrAmt;
    }

    public String currency() {
        return currency;
    }

    @Override
    public void currency(String currency) {
        this.currency = currency;
    }

    public String settlCurrency() {
        return settlCurrency;
    }

    @Override
    public void settlCurrency(String settlCurrency) {
        this.settlCurrency = settlCurrency;
    }

    public double settlCurrFxRate() {
        return settlCurrFxRate;
    }

    @Override
    public void settlCurrFxRate(double settlCurrFxRate) {
        this.settlCurrFxRate = settlCurrFxRate;
    }

    public char settlCurrFxRateCalc() {
        return settlCurrFxRateCalc;
    }

    @Override
    public void settlCurrFxRateCalc(char settlCurrFxRateCalc) {
        this.settlCurrFxRateCalc = settlCurrFxRateCalc;
    }

    public String ordLinkID() {
        return ordLinkID;
    }

    @Override
    public void ordLinkID(String ordLinkID) {
        this.ordLinkID = ordLinkID;
    }

    public String ordLinkType() {
        return ordLinkType;
    }

    @Override
    public void ordLinkType(String ordLinkType) {
        this.ordLinkType = ordLinkType;
    }

    public String bookingType() {
        return bookingType;
    }

    @Override
    public void bookingType(String bookingType) {
        this.bookingType = bookingType;
    }

    public String srcTargetCompId() {
        return srcTargetCompId;
    }

    @Override
    public void srcTargetCompId(String srcTargetCompId) {
        this.srcTargetCompId = srcTargetCompId;
    }

    public long orderVersion() {
        return orderVersion;
    }

    @Override
    public void orderVersion(long orderVersion) {
        this.orderVersion = orderVersion;
    }

    public long quoteTime() {
        return quoteTime;
    }

    @Override
    public void quoteTime(long quoteTime, TimeUnit timeUnit) {
        quoteTime(quoteTime);
    }

    @Override
    public void quoteTime(long quoteTime) {
        this.quoteTime = quoteTime;
    }

    public double bidPx() {
        return bidPx;
    }

    @Override
    public void bidPx(double bidPx) {
        this.bidPx = bidPx;
    }

    public double offerPx() {
        return offerPx;
    }

    @Override
    public void offerPx(double offerPx) {
        this.offerPx = offerPx;
    }

    public double bidSize() {
        return bidSize;
    }

    @Override
    public void bidSize(double bidSize) {
        this.bidSize = bidSize;
    }

    public double offerSize() {
        return offerSize;
    }

    @Override
    public void offerSize(double offerSize) {
        this.offerSize = offerSize;
    }

    public char locateReqd() {
        return locateReqd;
    }

    @Override
    public void locateReqd(char locateReqd) {
        this.locateReqd = locateReqd;
    }

    public String locateBroker() {
        return locateBroker;
    }

    @Override
    public void locateBroker(String locateBroker) {
        this.locateBroker = locateBroker;
    }

    public String locateIdentifier() {
        return locateIdentifier;
    }

    @Override
    public void locateIdentifier(String locateIdentifier) {
        this.locateIdentifier = locateIdentifier;
    }

    public long previousLinkSrcSystemID() {
        return previousLinkSrcSystemID;
    }

    @Override
    public void previousLinkSrcSystemID(long previousLinkSrcSystemID) {
        this.previousLinkSrcSystemID = previousLinkSrcSystemID;
    }

    public char contraOrderCapacity() {
        return contraOrderCapacity;
    }

    @Override
    public void contraOrderCapacity(char contraOrderCapacity) {
        this.contraOrderCapacity = contraOrderCapacity;
    }

    public String orderFlowEntry() {
        return orderFlowEntry;
    }

    @Override
    public void orderFlowEntry(String orderFlowEntry) {
        this.orderFlowEntry = orderFlowEntry;
    }

    public String orderFlowClass() {
        return orderFlowClass;
    }

    @Override
    public void orderFlowClass(String orderFlowClass) {
        this.orderFlowClass = orderFlowClass;
    }

    public String traderID() {
        return traderID;
    }

    @Override
    public void traderID(String traderID) {
        this.traderID = traderID;
    }

    public String avgPriceAcct() {
        return avgPriceAcct;
    }

    @Override
    public void avgPriceAcct(String avgPriceAcct) {
        this.avgPriceAcct = avgPriceAcct;
    }

    public String legalEntity() {
        return legalEntity;
    }

    @Override
    public void legalEntity(String legalEntity) {
        this.legalEntity = legalEntity;
    }

    public String securityID() {
        return securityID;
    }

    @Override
    public void securityID(String securityID) {
        this.securityID = securityID;
    }

    public String securityAltID() {
        return securityAltID;
    }

    @Override
    public void securityAltID(String securityAltID) {
        this.securityAltID = securityAltID;
    }

    public String securityAltIDSource() {
        return securityAltIDSource;
    }

    @Override
    public void securityAltIDSource(String securityAltIDSource) {
        this.securityAltIDSource = securityAltIDSource;
    }

    public String crossInstruction() {
        return crossInstruction;
    }

    @Override
    public void crossInstruction(String crossInstruction) {
        this.crossInstruction = crossInstruction;
    }

    public double sumOfStopExecQty() {
        return sumOfStopExecQty;
    }

    @Override
    public void sumOfStopExecQty(double sumOfStopExecQty) {
        this.sumOfStopExecQty = sumOfStopExecQty;
    }

    public long receiveTime() {
        return receiveTime;
    }

    @Override
    public void receiveTime(long receiveTime, TimeUnit timeUnit) {
        receiveTime(receiveTime);
    }

    @Override
    public void receiveTime(long receiveTime) {
        this.receiveTime = receiveTime;
    }

    public String crossRestrictionClientID() {
        return crossRestrictionClientID;
    }

    @Override
    public void crossRestrictionClientID(String crossRestrictionClientID) {
        this.crossRestrictionClientID = crossRestrictionClientID;
    }

    public String cxlReason() {
        return cxlReason;
    }

    @Override
    public void cxlReason(String cxlReason) {
        this.cxlReason = cxlReason;
    }

    public double lULDLowerPriceBand() {
        return lULDLowerPriceBand;
    }

    @Override
    public void lULDLowerPriceBand(double lULDLowerPriceBand) {
        this.lULDLowerPriceBand = lULDLowerPriceBand;
    }

    public double lULDUpperPriceBand() {
        return lULDUpperPriceBand;
    }

    @Override
    public void lULDUpperPriceBand(double lULDUpperPriceBand) {
        this.lULDUpperPriceBand = lULDUpperPriceBand;
    }

    public long lULDPriceBandTimestamp() {
        return lULDPriceBandTimestamp;
    }

    @Override
    public void lULDPriceBandTimestamp(long lULDPriceBandTimestamp, TimeUnit timeUnit) {
        lULDPriceBandTimestamp(lULDPriceBandTimestamp);
    }

    @Override
    public void lULDPriceBandTimestamp(long lULDPriceBandTimestamp) {
        this.lULDPriceBandTimestamp = lULDPriceBandTimestamp;
    }

    public double conditionalOrderQty() {
        return conditionalOrderQty;
    }

    @Override
    public void conditionalOrderQty(double conditionalOrderQty) {
        this.conditionalOrderQty = conditionalOrderQty;
    }

    public String ioiID() {
        return ioiID;
    }

    @Override
    public void ioiID(String ioiID) {
        this.ioiID = ioiID;
    }

    public String zExecID() {
        return zExecID;
    }

    @Override
    public void zExecID(String zExecID) {
        this.zExecID = zExecID;
    }

    public String actReport() {
        return actReport;
    }

    @Override
    public void actReport(String actReport) {
        this.actReport = actReport;
    }

    public long noClearingInstructions() {
        return noClearingInstructions;
    }

    @Override
    public void noClearingInstructions(long noClearingInstructions) {
        this.noClearingInstructions = noClearingInstructions;
    }

    public long clearingInstruction() {
        return clearingInstruction;
    }

    @Override
    public void clearingInstruction(long clearingInstruction) {
        this.clearingInstruction = clearingInstruction;
    }

    public String firmId() {
        return firmId;
    }

    @Override
    public void firmId(String firmId) {
        this.firmId = firmId;
    }

    public String avgPriceAcctIDSource() {
        return avgPriceAcctIDSource;
    }

    @Override
    public void avgPriceAcctIDSource(String avgPriceAcctIDSource) {
        this.avgPriceAcctIDSource = avgPriceAcctIDSource;
    }

    public String tickSizePilotGroup() {
        return tickSizePilotGroup;
    }

    @Override
    public void tickSizePilotGroup(String tickSizePilotGroup) {
        this.tickSizePilotGroup = tickSizePilotGroup;
    }

    public String sourceFeed() {
        return sourceFeed;
    }

    @Override
    public void sourceFeed(String sourceFeed) {
        this.sourceFeed = sourceFeed;
    }

    public String customerSlang() {
        return customerSlang;
    }

    @Override
    public void customerSlang(String customerSlang) {
        this.customerSlang = customerSlang;
    }

    public long rootSrcSystemID() {
        return rootSrcSystemID;
    }

    @Override
    public void rootSrcSystemID(long rootSrcSystemID) {
        this.rootSrcSystemID = rootSrcSystemID;
    }

    public long srcSystemID() {
        return srcSystemID;
    }

    @Override
    public void srcSystemID(long srcSystemID) {
        this.srcSystemID = srcSystemID;
    }

    public String orderFlowCategory() {
        return orderFlowCategory;
    }

    @Override
    public void orderFlowCategory(String orderFlowCategory) {
        this.orderFlowCategory = orderFlowCategory;
    }

    public String executedBy() {
        return executedBy;
    }

    @Override
    public void executedBy(String executedBy) {
        this.executedBy = executedBy;
    }

    public String tempLastMkt() {
        return tempLastMkt;
    }

    @Override
    public void tempLastMkt(String tempLastMkt) {
        this.tempLastMkt = tempLastMkt;
    }

    public long noTempContraBrokers() {
        return noTempContraBrokers;
    }

    @Override
    public void noTempContraBrokers(long noTempContraBrokers) {
        this.noTempContraBrokers = noTempContraBrokers;
    }

    public String tempContraBroker() {
        return tempContraBroker;
    }

    @Override
    public void tempContraBroker(String tempContraBroker) {
        this.tempContraBroker = tempContraBroker;
    }

    public String tempContraBrokerSrc() {
        return tempContraBrokerSrc;
    }

    @Override
    public void tempContraBrokerSrc(String tempContraBrokerSrc) {
        this.tempContraBrokerSrc = tempContraBrokerSrc;
    }

    public long leafSrcSystemID() {
        return leafSrcSystemID;
    }

    @Override
    public void leafSrcSystemID(long leafSrcSystemID) {
        this.leafSrcSystemID = leafSrcSystemID;
    }

    public char isCurrExecLevel() {
        return isCurrExecLevel;
    }

    @Override
    public void isCurrExecLevel(char isCurrExecLevel) {
        this.isCurrExecLevel = isCurrExecLevel;
    }

    public String contraAccount() {
        return contraAccount;
    }

    @Override
    public void contraAccount(String contraAccount) {
        this.contraAccount = contraAccount;
    }

    public String contraAccountSrc() {
        return contraAccountSrc;
    }

    @Override
    public void contraAccountSrc(String contraAccountSrc) {
        this.contraAccountSrc = contraAccountSrc;
    }

    public String contraAccountType() {
        return contraAccountType;
    }

    @Override
    public void contraAccountType(String contraAccountType) {
        this.contraAccountType = contraAccountType;
    }

    public String corellationClOrdID() {
        return corellationClOrdID;
    }

    @Override
    public void corellationClOrdID(String corellationClOrdID) {
        this.corellationClOrdID = corellationClOrdID;
    }

    public String previousLinkOrderID() {
        return previousLinkOrderID;
    }

    @Override
    public void previousLinkOrderID(String previousLinkOrderID) {
        this.previousLinkOrderID = previousLinkOrderID;
    }

    public String rootOrderID() {
        return rootOrderID;
    }

    @Override
    public void rootOrderID(String rootOrderID) {
        this.rootOrderID = rootOrderID;
    }

    public String customPrice1() {
        return customPrice1;
    }

    @Override
    public void customPrice1(String customPrice1) {
        this.customPrice1 = customPrice1;
    }

    public String strategyParameterValue() {
        return strategyParameterValue;
    }

    @Override
    public void strategyParameterValue(String strategyParameterValue) {
        this.strategyParameterValue = strategyParameterValue;
    }

    public String crossStrategy() {
        return crossStrategy;
    }

    @Override
    public void crossStrategy(String crossStrategy) {
        this.crossStrategy = crossStrategy;
    }

    public String crossID() {
        return crossID;
    }

    @Override
    public void crossID(String crossID) {
        this.crossID = crossID;
    }

    public String execInst() {
        return execInst;
    }

    @Override
    public void execInst(String execInst) {
        this.execInst = execInst;
    }

    public double minQty() {
        return minQty;
    }

    @Override
    public void minQty(double minQty) {
        this.minQty = minQty;
    }

    public String reportToExch() {
        return reportToExch;
    }

    @Override
    public void reportToExch(String reportToExch) {
        this.reportToExch = reportToExch;
    }

    public double lastParPx() {
        return lastParPx;
    }

    @Override
    public void lastParPx(double lastParPx) {
        this.lastParPx = lastParPx;
    }

    @Override
    public void reset() {
        ExecutionReport.super.reset();
    }
}
