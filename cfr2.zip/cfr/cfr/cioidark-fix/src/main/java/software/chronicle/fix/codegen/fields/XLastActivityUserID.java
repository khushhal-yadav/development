package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface XLastActivityUserID {
    /**
     * Tag number for this field
     */
    int FIELD = 10241;

    /**
     * @param xLastActivityUserID &gt; FIX TAG 10241
     */
    void xLastActivityUserID(String xLastActivityUserID);

    default String xLastActivityUserID() {
        throw new UnsupportedOperationException();
    }
}
