package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CxlRejResponseTo {
    /**
     * Tag number for this field
     */
    int FIELD = 434;

    char ORDER_CANCEL_REQUEST = '1';

    char ORDER_CANCEL_REPLACE_REQUEST = '2';

    /**
     * @param cxlRejResponseTo &gt; FIX TAG 434
     */
    void cxlRejResponseTo(char cxlRejResponseTo);

    default char cxlRejResponseTo() {
        throw new UnsupportedOperationException();
    }

    static String asString(char value) {
        switch (value) {
            case ORDER_CANCEL_REQUEST:
                    return "ORDER_CANCEL_REQUEST";
            case ORDER_CANCEL_REPLACE_REQUEST:
                    return "ORDER_CANCEL_REPLACE_REQUEST";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
