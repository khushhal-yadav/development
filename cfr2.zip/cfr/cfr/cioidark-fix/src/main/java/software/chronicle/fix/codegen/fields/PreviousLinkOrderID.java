package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface PreviousLinkOrderID {
    /**
     * Tag number for this field
     */
    int FIELD = 10184;

    /**
     * @param previousLinkOrderID &gt; FIX TAG 10184
     */
    void previousLinkOrderID(String previousLinkOrderID);

    default String previousLinkOrderID() {
        throw new UnsupportedOperationException();
    }
}
