package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface IOIID {
    /**
     * Tag number for this field
     */
    int FIELD = 23;

    /**
     * @param ioiID &gt; FIX TAG 23
     */
    void ioiID(String ioiID);

    default String ioiID() {
        throw new UnsupportedOperationException();
    }
}
