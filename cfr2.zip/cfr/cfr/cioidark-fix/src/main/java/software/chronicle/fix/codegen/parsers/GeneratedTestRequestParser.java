package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.TestRequest;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedTestRequestParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, TestRequest testRequest) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(testRequest);
            fix.testReqID(testRequest); // 112
            if (fix.checkFinished(testRequest, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, testRequest, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(testRequest.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(testRequest.msgSeqNum(), pos);
    }
}
