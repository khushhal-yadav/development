package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface RootOrderID {
    /**
     * Tag number for this field
     */
    int FIELD = 11210;

    /**
     * @param rootOrderID &gt; FIX TAG 11210
     */
    void rootOrderID(String rootOrderID);

    default String rootOrderID() {
        throw new UnsupportedOperationException();
    }
}
