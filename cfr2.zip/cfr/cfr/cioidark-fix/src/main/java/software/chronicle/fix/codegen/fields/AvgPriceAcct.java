package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface AvgPriceAcct {
    /**
     * Tag number for this field
     */
    int FIELD = 10051;

    /**
     * @param avgPriceAcct &gt; FIX TAG 10051
     */
    void avgPriceAcct(String avgPriceAcct);

    default String avgPriceAcct() {
        throw new UnsupportedOperationException();
    }
}
