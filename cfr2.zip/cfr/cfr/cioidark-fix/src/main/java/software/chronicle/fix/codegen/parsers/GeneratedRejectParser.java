package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.Reject;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedRejectParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, Reject reject) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(reject);
            fix.refSeqNum(reject); // 45
            fix.refTagID(reject); // 371
            fix.refMsgType(reject); // 372
            fix.sessionRejectReason(reject); // 373
            fix.text(reject); // 58
            fix.encodedTextLen(reject); // 354
            fix.encodedText(reject); // 355
            if (fix.checkFinished(reject, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, reject, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(reject.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(reject.msgSeqNum(), pos);
    }
}
