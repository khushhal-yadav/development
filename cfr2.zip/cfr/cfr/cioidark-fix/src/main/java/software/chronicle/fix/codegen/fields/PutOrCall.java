package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface PutOrCall {
    /**
     * Tag number for this field
     */
    int FIELD = 201;

    int PUT = 0;

    int CALL = 1;

    /**
     * @param putOrCall &gt; FIX TAG 201
     */
    void putOrCall(long putOrCall);

    default long putOrCall() {
        throw new UnsupportedOperationException();
    }

    static String asString(int value) {
        switch (value) {
            case PUT:
                    return "PUT";
            case CALL:
                    return "CALL";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
