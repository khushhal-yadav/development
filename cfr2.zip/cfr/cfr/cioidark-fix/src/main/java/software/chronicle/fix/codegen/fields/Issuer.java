package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface Issuer {
    /**
     * Tag number for this field
     */
    int FIELD = 106;

    /**
     * @param issuer &gt; FIX TAG 106
     */
    void issuer(String issuer);

    default String issuer() {
        throw new UnsupportedOperationException();
    }
}
