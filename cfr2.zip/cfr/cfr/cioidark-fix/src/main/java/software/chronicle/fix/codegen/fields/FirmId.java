package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface FirmId {
    /**
     * Tag number for this field
     */
    int FIELD = 10054;

    /**
     * @param firmId &gt; FIX TAG 10054
     */
    void firmId(String firmId);

    default String firmId() {
        throw new UnsupportedOperationException();
    }
}
