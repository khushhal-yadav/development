package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.codegen.messages.Logout;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public class DefaultLogout extends DefaultHeaderTrailer implements Logout, HeaderTrailer {
    private String text = null;

    private long encodedTextLen = FixMessage.UNSET_LONG;

    private String encodedText = null;

    public char msgType() {
        return MessageManifest.Logout;
    }

    public String text() {
        return text;
    }

    @Override
    public void text(String text) {
        this.text = text;
    }

    public long encodedTextLen() {
        return encodedTextLen;
    }

    @Override
    public void encodedTextLen(long encodedTextLen) {
        this.encodedTextLen = encodedTextLen;
    }

    public String encodedText() {
        return encodedText;
    }

    @Override
    public void encodedText(String encodedText) {
        this.encodedText = encodedText;
    }

    @Override
    public void reset() {
        Logout.super.reset();
    }
}
