package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.fields.BusinessRejectReason;
import software.chronicle.fix.codegen.fields.BusinessRejectRefID;
import software.chronicle.fix.codegen.fields.EncodedText;
import software.chronicle.fix.codegen.fields.EncodedTextLen;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.fields.RefMsgType;
import software.chronicle.fix.sessioncode.fields.RefSeqNum;
import software.chronicle.fix.sessioncode.fields.Text;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface BusinessMessageReject extends HeaderTrailer, RefSeqNum, RefMsgType, BusinessRejectRefID, BusinessRejectReason, Text, EncodedTextLen, EncodedText {
    @Deprecated
    static BusinessMessageReject newBusinessMessageReject(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.BusinessMessageReject);
        mg.bytes(bytes);
        return mg;
    }

    static BusinessMessageReject newBusinessMessageReject(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.BusinessMessageReject, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (refMsgType() == FixMessage.UNSET_CHAR) throw new RequiredTagMissing("refMsgType", 372);
        if (businessRejectReason() == FixMessage.UNSET_LONG) throw new RequiredTagMissing("businessRejectReason", 380);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        refSeqNum(FixMessage.UNSET_LONG);
        refMsgType(FixMessage.UNSET_CHAR);
        businessRejectRefID(null);
        businessRejectReason(FixMessage.UNSET_LONG);
        text(null);
        encodedTextLen(FixMessage.UNSET_LONG);
        encodedText(null);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((BusinessMessageReject) msg);
    }

    default void copyTo(BusinessMessageReject msg) {
        HeaderTrailer.super.copyTo(msg);
        if (refSeqNum() != FixMessage.UNSET_LONG) msg.refSeqNum(refSeqNum());
        if (refMsgType() != FixMessage.UNSET_CHAR) msg.refMsgType(refMsgType());
        if (businessRejectRefID() != null) msg.businessRejectRefID(businessRejectRefID());
        if (businessRejectReason() != FixMessage.UNSET_LONG) msg.businessRejectReason(businessRejectReason());
        if (text() != null) msg.text(text());
        if (encodedTextLen() != FixMessage.UNSET_LONG) msg.encodedTextLen(encodedTextLen());
        if (encodedText() != null) msg.encodedText(encodedText());
    }
}
