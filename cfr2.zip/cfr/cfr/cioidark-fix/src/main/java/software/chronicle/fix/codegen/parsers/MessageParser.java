package software.chronicle.fix.codegen.parsers;

import java.lang.Override;
import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.bytes.util.StringInternerBytes;
import net.openhft.chronicle.core.io.IORuntimeException;
import net.openhft.chronicle.wire.MessageHistory;
import net.openhft.chronicle.wire.WireIn;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.codegen.messages.BusinessMessageReject;
import software.chronicle.fix.codegen.messages.CioiDarkOrder;
import software.chronicle.fix.codegen.messages.DontKnowTrade;
import software.chronicle.fix.codegen.messages.ExecutionReport;
import software.chronicle.fix.codegen.messages.MarketDataSnapshotFullRefresh;
import software.chronicle.fix.codegen.messages.MessageFactory;
import software.chronicle.fix.codegen.messages.MessageNotifier;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.codegen.messages.OrderCancelReject;
import software.chronicle.fix.codegen.messages.OrderCancelReplaceRequest;
import software.chronicle.fix.codegen.messages.OrderCancelRequest;
import software.chronicle.fix.codegen.messages.RIOMessage;
import software.chronicle.fix.codegen.messages.datamodel.DefaultMessageFactory;
import software.chronicle.fix.pool.DateTimeParser;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.FixSessionProbes;
import software.chronicle.fix.staticcode.InvalidMessageException;
import software.chronicle.fix.staticcode.messages.FixMessage;
import software.chronicle.fix.staticcode.parsers.MessageParserBase;

/**
 * Generated at software.chronicle.fix.codegen.MessageParserGenerator.generate(MessageParserGenerator.java)
 */
public class MessageParser extends MessageParserBase {
    private MessageFactory messageFactory = new DefaultMessageFactory();

    private MessageParserBase sessionMessageParser = new SessionMessageParser();

    private transient GeneratedCoreFieldParser coreFieldParser;

    private boolean validateCheckSum;

    private GeneratedNewOrderSingleParser newOrderSingleParser = new GeneratedNewOrderSingleParser();

    private GeneratedOrderCancelRequestParser orderCancelRequestParser = new GeneratedOrderCancelRequestParser();

    private GeneratedOrderCancelReplaceRequestParser orderCancelReplaceRequestParser = new GeneratedOrderCancelReplaceRequestParser();

    private GeneratedExecutionReportParser executionReportParser = new GeneratedExecutionReportParser();

    private GeneratedOrderCancelRejectParser orderCancelRejectParser = new GeneratedOrderCancelRejectParser();

    private GeneratedDontKnowTradeParser dontKnowTradeParser = new GeneratedDontKnowTradeParser();

    private GeneratedRIOMessageParser rIOMessageParser = new GeneratedRIOMessageParser();

    private GeneratedMarketDataSnapshotFullRefreshParser marketDataSnapshotFullRefreshParser = new GeneratedMarketDataSnapshotFullRefreshParser();

    private GeneratedBusinessMessageRejectParser businessMessageRejectParser = new GeneratedBusinessMessageRejectParser();

    private GeneratedCioiDarkOrderParser cioiDarkOrderParser = new GeneratedCioiDarkOrderParser();

    public MessageParser() {
        stringPool = 1024;
        datePool = 1024;
        resetParser();
    }

    @Override
    public void readMarshallable(WireIn wire) throws IORuntimeException {
        super.readMarshallable(wire);
        resetParser();
    }

    void resetParser() {
        coreFieldParser = new GeneratedCoreFieldParser(
                new StringInternerBytes(stringPool), new DateTimeParser(datePool), validateCheckSum);
        coreFieldParser.unexpectedFieldHandler(unexpectedFieldHandler);
    }

    @Override
    public void parse(long startPos, char msgType, long msgSeqNum, @NotNull FixSessionHandler session, @NotNull Bytes bytes) {
        FixSessionProbes probes = session.probes();
        coreFieldParser().bytes(bytes);
        if (session.sourceId() > 0) MessageHistory.get().reset(session.sourceId(), msgSeqNum);
        MessageNotifier messageNotifier = (MessageNotifier) session.messageNotifier();
        FixMessage fixMessage = null;
        try {
            switch (msgType) {
                case 'D': {
                    NewOrderSingle msg = messageFactory.newOrderSingle();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    newOrderSingleParser.parse(startPos, coreFieldParser, msg);
                    probes.onMessageParsed(msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    messageNotifier.onNewOrderSingle(session, msg);
                    probes.onMessageProcessed(msg);
                    return;
                }
                case 'F': {
                    OrderCancelRequest msg = messageFactory.orderCancelRequest();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    orderCancelRequestParser.parse(startPos, coreFieldParser, msg);
                    probes.onMessageParsed(msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    messageNotifier.onOrderCancelRequest(session, msg);
                    probes.onMessageProcessed(msg);
                    return;
                }
                case 'G': {
                    OrderCancelReplaceRequest msg = messageFactory.orderCancelReplaceRequest();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    orderCancelReplaceRequestParser.parse(startPos, coreFieldParser, msg);
                    probes.onMessageParsed(msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    messageNotifier.onOrderCancelReplaceRequest(session, msg);
                    probes.onMessageProcessed(msg);
                    return;
                }
                case '8': {
                    ExecutionReport msg = messageFactory.executionReport();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    executionReportParser.parse(startPos, coreFieldParser, msg);
                    probes.onMessageParsed(msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    messageNotifier.onExecutionReport(session, msg);
                    probes.onMessageProcessed(msg);
                    return;
                }
                case '9': {
                    OrderCancelReject msg = messageFactory.orderCancelReject();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    orderCancelRejectParser.parse(startPos, coreFieldParser, msg);
                    probes.onMessageParsed(msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    messageNotifier.onOrderCancelReject(session, msg);
                    probes.onMessageProcessed(msg);
                    return;
                }
                case 'Q': {
                    DontKnowTrade msg = messageFactory.dontKnowTrade();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    dontKnowTradeParser.parse(startPos, coreFieldParser, msg);
                    probes.onMessageParsed(msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    messageNotifier.onDontKnowTrade(session, msg);
                    probes.onMessageProcessed(msg);
                    return;
                }
                case ('R' << 8) + 'I': {
                    RIOMessage msg = messageFactory.rIOMessage();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    rIOMessageParser.parse(startPos, coreFieldParser, msg);
                    probes.onMessageParsed(msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    messageNotifier.onRIOMessage(session, msg);
                    probes.onMessageProcessed(msg);
                    return;
                }
                case 'W': {
                    MarketDataSnapshotFullRefresh msg = messageFactory.marketDataSnapshotFullRefresh();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    marketDataSnapshotFullRefreshParser.parse(startPos, coreFieldParser, msg);
                    probes.onMessageParsed(msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    messageNotifier.onMarketDataSnapshotFullRefresh(session, msg);
                    probes.onMessageProcessed(msg);
                    return;
                }
                case 'j': {
                    BusinessMessageReject msg = messageFactory.businessMessageReject();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    businessMessageRejectParser.parse(startPos, coreFieldParser, msg);
                    probes.onMessageParsed(msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    messageNotifier.onBusinessMessageReject(session, msg);
                    probes.onMessageProcessed(msg);
                    return;
                }
                case 'x': {
                    CioiDarkOrder msg = messageFactory.cioiDarkOrder();
                    fixMessage = msg;
                    msg.msgSeqNum(msgSeqNum);
                    cioiDarkOrderParser.parse(startPos, coreFieldParser, msg);
                    probes.onMessageParsed(msg);
                    msg.validate();
                    session.msgSeqNum(msgSeqNum);
                    messageNotifier.onCioiDarkOrder(session, msg);
                    probes.onMessageProcessed(msg);
                    return;
                }
                default: {
                    sessionMessageParser.parse(startPos, msgType, msgSeqNum, session, bytes);
                }
            }
        } catch (InvalidMessageException e) {
            session.msgSeqNum(msgSeqNum);
            session.reject(msgSeqNum, e.getMessage(), msgType, e.getReason(), e.getTag());
        } finally {
            if (fixMessage != null) fixMessage.reset();
        }
    }

    public GeneratedCoreFieldParser coreFieldParser() {
        return coreFieldParser;
    }

    public MessageParser messageFactory(MessageFactory messageFactory) {
        this.messageFactory = messageFactory;
        return this;
    }
}
