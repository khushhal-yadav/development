package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface NoMDEntries {
    /**
     * Tag number for this field
     */
    int FIELD = 268;

    /**
     * @param noMDEntries &gt; FIX TAG 268
     */
    void noMDEntries(long noMDEntries);

    default long noMDEntries() {
        throw new UnsupportedOperationException();
    }
}
