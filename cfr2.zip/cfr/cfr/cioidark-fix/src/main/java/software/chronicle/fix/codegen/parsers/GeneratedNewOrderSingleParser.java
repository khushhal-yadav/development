package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.NewOrderSingle;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedNewOrderSingleParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, NewOrderSingle newOrderSingle) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(newOrderSingle);
            fix.clOrdID(newOrderSingle); // 11
            fix.side(newOrderSingle); // 54
            fix.orderQty(newOrderSingle); // 38
            fix.ordType(newOrderSingle); // 40
            fix.symbol(newOrderSingle); // 55
            fix.symbolSfx(newOrderSingle); // 65
            fix.idSource(newOrderSingle); // 22
            fix.handlInst(newOrderSingle); // 21
            fix.transactTime(newOrderSingle); // 60
            fix.account(newOrderSingle); // 1
            fix.price(newOrderSingle); // 44
            fix.timeInForce(newOrderSingle); // 59
            fix.createdNS(newOrderSingle); // 9999
            fix.lastTraded(newOrderSingle); // 11001
            fix.bidPx(newOrderSingle); // 132
            fix.offerPx(newOrderSingle); // 133
            fix.bidSize(newOrderSingle); // 134
            fix.offerSize(newOrderSingle); // 135
            fix.orderCapacity(newOrderSingle); // 528
            fix.rule80A(newOrderSingle); // 47
            fix.currency(newOrderSingle); // 15
            fix.settlCurrency(newOrderSingle); // 120
            fix.settlmntTyp(newOrderSingle); // 63
            fix.customerOrFirm(newOrderSingle); // 204
            fix.clientID(newOrderSingle); // 109
            fix.exDestination(newOrderSingle); // 100
            fix.locateReqd(newOrderSingle); // 114
            fix.ordLinkID(newOrderSingle); // 11053
            fix.ordLinkType(newOrderSingle); // 11052
            fix.bookingType(newOrderSingle); // 775
            fix.orderID(newOrderSingle); // 37
            fix.tradingAcct(newOrderSingle); // 10050
            fix.ioiID(newOrderSingle); // 23
            fix.quoteID(newOrderSingle); // 117
            fix.quoteTime(newOrderSingle); // 11048
            fix.targetStrategy(newOrderSingle); // 847
            fix.targetStrategyParameters(newOrderSingle); // 848
            fix.previousLinkSrcSystemID(newOrderSingle); // 10518
            fix.contraOrderCapacity(newOrderSingle); // 10158
            fix.orderFlowEntry(newOrderSingle); // 10201
            fix.orderFlowClass(newOrderSingle); // 10201
            fix.traderID(newOrderSingle); // 10039
            fix.avgPriceAcct(newOrderSingle); // 10051
            fix.legalEntity(newOrderSingle); // 10031
            fix.securityID(newOrderSingle); // 48
            fix.securityAltID(newOrderSingle); // 455
            fix.securityAltIDSource(newOrderSingle); // 456
            fix.crossInstruction(newOrderSingle); // 6438
            fix.noStrategyParameters(newOrderSingle); // 957
            fix.strategyParameterValue(newOrderSingle); // 960
            fix.receiveTime(newOrderSingle); // 10080
            fix.ordStatus(newOrderSingle); // 39
            fix.sumOfStopExecQty(newOrderSingle); // 10065
            fix.cxlQty(newOrderSingle); // 84
            fix.crossRestrictionClientID(newOrderSingle); // 10896
            fix.leavesQty(newOrderSingle); // 151
            fix.srcTargetCompId(newOrderSingle); // 10084
            fix.shortSaleExemptReason(newOrderSingle); // 1688
            fix.timeToLive(newOrderSingle); // 10014
            fix.avgPriceAcctIDSource(newOrderSingle); // 10428
            fix.tickSizePilotGroup(newOrderSingle); // 11319
            fix.sourceFeed(newOrderSingle); // 11328
            fix.customerSlang(newOrderSingle); // 8004
            fix.rootSrcSystemID(newOrderSingle); // 10515
            fix.optOutLockedIn(newOrderSingle); // 10565
            fix.srcSystemID(newOrderSingle); // 10005
            fix.orderFlowCategory(newOrderSingle); // 10202
            fix.executedBy(newOrderSingle); // 10021
            fix.tempLastMkt(newOrderSingle); // 10537
            fix.noTempContraBrokers(newOrderSingle); // 10533
            fix.tempContraBroker(newOrderSingle); // 10534
            fix.tempContraBrokerSrc(newOrderSingle); // 10535
            fix.leafSrcSystemID(newOrderSingle); // 10965
            fix.isCurrExecLevel(newOrderSingle); // 11027
            fix.contraAccount(newOrderSingle); // 10514
            fix.contraAccountSrc(newOrderSingle); // 11040
            fix.contraAccountType(newOrderSingle); // 11041
            fix.noClearingInstructions(newOrderSingle); // 576
            fix.clearingInstruction(newOrderSingle); // 577
            fix.corellationClOrdID(newOrderSingle); // 9717
            fix.previousLinkOrderID(newOrderSingle); // 10184
            fix.rootOrderID(newOrderSingle); // 11210
            fix.crossStrategy(newOrderSingle); // 7411
            fix.reportToExch(newOrderSingle); // 113
            fix.customPrice1(newOrderSingle); // 7491
            fix.minQty(newOrderSingle); // 110
            fix.execInst(newOrderSingle); // 18
            fix.locateBroker(newOrderSingle); // 5700
            fix.locateIdentifier(newOrderSingle); // 5701
            if (fix.checkFinished(newOrderSingle, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, newOrderSingle, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(newOrderSingle.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(newOrderSingle.msgSeqNum(), pos);
    }
}
