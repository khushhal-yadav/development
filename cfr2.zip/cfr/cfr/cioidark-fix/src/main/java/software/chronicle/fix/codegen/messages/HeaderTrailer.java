package software.chronicle.fix.codegen.messages;

import java.util.concurrent.TimeUnit;
import software.chronicle.fix.codegen.fields.DeliverToCompID;
import software.chronicle.fix.codegen.fields.DeliverToSubID;
import software.chronicle.fix.codegen.fields.OnBehalfOfCompID;
import software.chronicle.fix.codegen.fields.OnBehalfOfSubID;
import software.chronicle.fix.codegen.fields.OrigSendingTime;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateHeaderTrailer(MessageGenerator.java)
 */
public interface HeaderTrailer extends StandardHeaderTrailer, OnBehalfOfCompID, OnBehalfOfSubID, DeliverToCompID, DeliverToSubID, OrigSendingTime {
    default void reset() {
        StandardHeaderTrailer.super.reset();
        onBehalfOfCompID(null);
        onBehalfOfSubID(null);
        deliverToCompID(null);
        deliverToSubID(null);
        origSendingTime(FixMessage.UNSET_LONG);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((HeaderTrailer) msg);
    }

    default void copyTo(HeaderTrailer msg) {
        StandardHeaderTrailer.super.copyTo(msg);
        if (onBehalfOfCompID() != null) msg.onBehalfOfCompID(onBehalfOfCompID());
        if (onBehalfOfSubID() != null) msg.onBehalfOfSubID(onBehalfOfSubID());
        if (deliverToCompID() != null) msg.deliverToCompID(deliverToCompID());
        if (deliverToSubID() != null) msg.deliverToSubID(deliverToSubID());
        if (origSendingTime() != FixMessage.UNSET_LONG) msg.origSendingTime(origSendingTime());
    }

    default TimeUnit internalTimeUnit() {
        return TimeUnit.MILLISECONDS;
    }

    default void validate() {
    }
}
