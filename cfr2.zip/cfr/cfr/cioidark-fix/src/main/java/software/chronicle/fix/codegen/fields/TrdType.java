package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TrdType {
    /**
     * Tag number for this field
     */
    int FIELD = 828;

    /**
     * @param trdType &gt; FIX TAG 828
     */
    void trdType(long trdType);

    default long trdType() {
        throw new UnsupportedOperationException();
    }
}
