package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface RioMsgSeq {
    /**
     * Tag number for this field
     */
    int FIELD = 10655;

    /**
     * @param rioMsgSeq &gt; FIX TAG 10655
     */
    void rioMsgSeq(long rioMsgSeq);

    default long rioMsgSeq() {
        throw new UnsupportedOperationException();
    }
}
