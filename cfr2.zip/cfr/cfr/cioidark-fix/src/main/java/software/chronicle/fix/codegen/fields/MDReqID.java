package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MDReqID {
    /**
     * Tag number for this field
     */
    int FIELD = 262;

    /**
     * @param mDReqID &gt; FIX TAG 262
     */
    void mDReqID(String mDReqID);

    default String mDReqID() {
        throw new UnsupportedOperationException();
    }
}
