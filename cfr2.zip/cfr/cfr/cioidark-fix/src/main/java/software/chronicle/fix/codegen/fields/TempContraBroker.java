package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TempContraBroker {
    /**
     * Tag number for this field
     */
    int FIELD = 10534;

    /**
     * @param tempContraBroker &gt; FIX TAG 10534
     */
    void tempContraBroker(String tempContraBroker);

    default String tempContraBroker() {
        throw new UnsupportedOperationException();
    }
}
