package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface SumOfStopExecQty {
    /**
     * Tag number for this field
     */
    int FIELD = 10065;

    /**
     * @param sumOfStopExecQty &gt; FIX TAG 10065
     */
    void sumOfStopExecQty(double sumOfStopExecQty);

    default double sumOfStopExecQty() {
        throw new UnsupportedOperationException();
    }
}
