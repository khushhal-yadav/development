package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface RootOrderUniqID {
    /**
     * Tag number for this field
     */
    int FIELD = 10516;

    /**
     * @param rootOrderUniqID &gt; FIX TAG 10516
     */
    void rootOrderUniqID(String rootOrderUniqID);

    default String rootOrderUniqID() {
        throw new UnsupportedOperationException();
    }
}
