package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ContraAccountSrc {
    /**
     * Tag number for this field
     */
    int FIELD = 11040;

    /**
     * @param contraAccountSrc &gt; FIX TAG 11040
     */
    void contraAccountSrc(String contraAccountSrc);

    default String contraAccountSrc() {
        throw new UnsupportedOperationException();
    }
}
