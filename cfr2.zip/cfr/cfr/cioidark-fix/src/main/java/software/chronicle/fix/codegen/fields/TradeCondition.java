package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TradeCondition {
    /**
     * Tag number for this field
     */
    int FIELD = 277;

    String CASH = "A";

    String AVERAGE_PRICE_TRADE = "B";

    String CASH_TRADE = "C";

    String NEXT_DAY = "D";

    String OPENING_REOPENING_TRADE_DETAIL = "E";

    String INTRADAY_TRADE_DETAIL = "F";

    String RULE_127_TRADE = "G";

    String RULE_155_TRADE = "H";

    String SOLD_LAST = "I";

    String NEXT_DAY_TRADE = "J";

    String OPENED = "K";

    String SELLER = "L";

    String SOLD = "M";

    String STOPPED_STOCK = "N";

    /**
     * @param tradeCondition &gt; FIX TAG 277
     */
    void tradeCondition(String tradeCondition);

    default String tradeCondition() {
        throw new UnsupportedOperationException();
    }

    static String asString(String value) {
        return value;
    }
}
