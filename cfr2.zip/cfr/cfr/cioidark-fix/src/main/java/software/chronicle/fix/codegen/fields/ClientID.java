package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ClientID {
    /**
     * Tag number for this field
     */
    int FIELD = 109;

    /**
     * @param clientID &gt; FIX TAG 109
     */
    void clientID(String clientID);

    default String clientID() {
        throw new UnsupportedOperationException();
    }
}
