package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ContractMultiplier {
    /**
     * Tag number for this field
     */
    int FIELD = 231;

    /**
     * @param contractMultiplier &gt; FIX TAG 231
     */
    void contractMultiplier(double contractMultiplier);

    default double contractMultiplier() {
        throw new UnsupportedOperationException();
    }
}
