package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TempLastMkt {
    /**
     * Tag number for this field
     */
    int FIELD = 10537;

    /**
     * @param tempLastMkt &gt; FIX TAG 10537
     */
    void tempLastMkt(String tempLastMkt);

    default String tempLastMkt() {
        throw new UnsupportedOperationException();
    }
}
