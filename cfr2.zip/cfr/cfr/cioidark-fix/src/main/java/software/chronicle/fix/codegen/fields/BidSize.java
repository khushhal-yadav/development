package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface BidSize {
    /**
     * Tag number for this field
     */
    int FIELD = 134;

    /**
     * @param bidSize &gt; FIX TAG 134
     */
    void bidSize(double bidSize);

    default double bidSize() {
        throw new UnsupportedOperationException();
    }
}
