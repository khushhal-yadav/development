package software.chronicle.fix.codegen.messages;

import java.lang.Deprecated;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.MessageManifest;
import software.chronicle.fix.codegen.fields.Account;
import software.chronicle.fix.codegen.fields.AskPrice;
import software.chronicle.fix.codegen.fields.AvgPriceAcctIDSource;
import software.chronicle.fix.codegen.fields.BidPrice;
import software.chronicle.fix.codegen.fields.BidPx;
import software.chronicle.fix.codegen.fields.BookingType;
import software.chronicle.fix.codegen.fields.ClOrdID;
import software.chronicle.fix.codegen.fields.ClearingInstruction;
import software.chronicle.fix.codegen.fields.ClientID;
import software.chronicle.fix.codegen.fields.CorellationClOrdID;
import software.chronicle.fix.codegen.fields.CreatedNS;
import software.chronicle.fix.codegen.fields.CrossInstruction;
import software.chronicle.fix.codegen.fields.CrossRestrictionClientID;
import software.chronicle.fix.codegen.fields.CrossStrategy;
import software.chronicle.fix.codegen.fields.Currency;
import software.chronicle.fix.codegen.fields.CustomPrice1;
import software.chronicle.fix.codegen.fields.CustomerOrFirm;
import software.chronicle.fix.codegen.fields.CustomerSlang;
import software.chronicle.fix.codegen.fields.ExDestination;
import software.chronicle.fix.codegen.fields.ExecInst;
import software.chronicle.fix.codegen.fields.HandlInst;
import software.chronicle.fix.codegen.fields.IDSource;
import software.chronicle.fix.codegen.fields.IOIID;
import software.chronicle.fix.codegen.fields.LastTraded;
import software.chronicle.fix.codegen.fields.LastTradedDelta;
import software.chronicle.fix.codegen.fields.LocateReqd;
import software.chronicle.fix.codegen.fields.MinQty;
import software.chronicle.fix.codegen.fields.NoStrategyParameters;
import software.chronicle.fix.codegen.fields.OfferPx;
import software.chronicle.fix.codegen.fields.OrdLinkID;
import software.chronicle.fix.codegen.fields.OrdLinkType;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.OrderCapacity;
import software.chronicle.fix.codegen.fields.OrderID;
import software.chronicle.fix.codegen.fields.OrderQty;
import software.chronicle.fix.codegen.fields.OrigClOrdID;
import software.chronicle.fix.codegen.fields.PreviousLinkOrderID;
import software.chronicle.fix.codegen.fields.Price;
import software.chronicle.fix.codegen.fields.QuoteTime;
import software.chronicle.fix.codegen.fields.ReceiveTime;
import software.chronicle.fix.codegen.fields.RootOrderID;
import software.chronicle.fix.codegen.fields.Rule80A;
import software.chronicle.fix.codegen.fields.SecurityAltID;
import software.chronicle.fix.codegen.fields.SecurityAltIDSource;
import software.chronicle.fix.codegen.fields.SecurityID;
import software.chronicle.fix.codegen.fields.SettlCurrency;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.fields.SrcTargetCompId;
import software.chronicle.fix.codegen.fields.StrategyParameterValue;
import software.chronicle.fix.codegen.fields.Symbol;
import software.chronicle.fix.codegen.fields.SymbolSfx;
import software.chronicle.fix.codegen.fields.TickSizePilotGroup;
import software.chronicle.fix.codegen.fields.Tier;
import software.chronicle.fix.codegen.fields.TimeInForce;
import software.chronicle.fix.codegen.fields.TimeToLive;
import software.chronicle.fix.codegen.fields.TradingAcct;
import software.chronicle.fix.codegen.fields.TransactTime;
import software.chronicle.fix.codegen.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.RequiredTagMissing;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateMessage(MessageGenerator.java)
 */
public interface OrderCancelReplaceRequest extends HeaderTrailer, OrderID, ClOrdID, Side, OrderQty, MinQty, OrdType, OrigClOrdID, Symbol, SymbolSfx, IDSource, HandlInst, TransactTime, Account, Price, BidPx, OfferPx, QuoteTime, TimeInForce, CreatedNS, LastTraded, LastTradedDelta, BidPrice, AskPrice, OrderCapacity, ClientID, ExDestination, Currency, Rule80A, SettlCurrency, CustomerOrFirm, LocateReqd, OrdLinkID, OrdLinkType, BookingType, TradingAcct, CustomPrice1, Tier, NoStrategyParameters, StrategyParameterValue, CrossStrategy, CorellationClOrdID, PreviousLinkOrderID, RootOrderID, CustomerSlang, ReceiveTime, CrossRestrictionClientID, ExecInst, CrossInstruction, AvgPriceAcctIDSource, TickSizePilotGroup, ClearingInstruction, TimeToLive, SrcTargetCompId, IOIID, SecurityID, SecurityAltID, SecurityAltIDSource {
    @Deprecated
    static OrderCancelReplaceRequest newOrderCancelReplaceRequest(Bytes bytes) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.OrderCancelReplaceRequest);
        mg.bytes(bytes);
        return mg;
    }

    static OrderCancelReplaceRequest newOrderCancelReplaceRequest(Bytes bytes, FixSessionContext context) {
        MessageGenerator mg = new MessageGenerator(MessageManifest.OrderCancelReplaceRequest, context);
        mg.bytes(bytes);
        return mg;
    }

    default void validate() {
        HeaderTrailer.super.validate();
        if (clOrdID() == null) throw new RequiredTagMissing("clOrdID", 11);
        if (side() == FixMessage.UNSET_CHAR) throw new RequiredTagMissing("side", 54);
        if (ordType() == FixMessage.UNSET_CHAR) throw new RequiredTagMissing("ordType", 40);
        if (origClOrdID() == null) throw new RequiredTagMissing("origClOrdID", 41);
        if (symbol() == null) throw new RequiredTagMissing("symbol", 55);
        if (transactTime() == FixMessage.UNSET_LONG) throw new RequiredTagMissing("transactTime", 60);
    }

    default void reset() {
        HeaderTrailer.super.reset();
        orderID(null);
        clOrdID(null);
        side(FixMessage.UNSET_CHAR);
        orderQty(FixMessage.UNSET_DOUBLE);
        minQty(FixMessage.UNSET_DOUBLE);
        ordType(FixMessage.UNSET_CHAR);
        origClOrdID(null);
        symbol(null);
        symbolSfx(null);
        idSource(null);
        handlInst(FixMessage.UNSET_CHAR);
        transactTime(FixMessage.UNSET_LONG);
        account(null);
        price(FixMessage.UNSET_DOUBLE);
        bidPx(FixMessage.UNSET_DOUBLE);
        offerPx(FixMessage.UNSET_DOUBLE);
        quoteTime(FixMessage.UNSET_LONG);
        timeInForce(FixMessage.UNSET_CHAR);
        createdNS(FixMessage.UNSET_LONG);
        lastTraded(FixMessage.UNSET_DOUBLE);
        lastTradedDelta(FixMessage.UNSET_DOUBLE);
        bidPrice(FixMessage.UNSET_DOUBLE);
        askPrice(FixMessage.UNSET_DOUBLE);
        orderCapacity(FixMessage.UNSET_CHAR);
        clientID(null);
        exDestination(null);
        currency(null);
        rule80A(FixMessage.UNSET_CHAR);
        settlCurrency(null);
        customerOrFirm(FixMessage.UNSET_LONG);
        locateReqd(FixMessage.UNSET_CHAR);
        ordLinkID(null);
        ordLinkType(null);
        bookingType(null);
        tradingAcct(null);
        customPrice1(null);
        tier(FixMessage.UNSET_LONG);
        noStrategyParameters(null);
        strategyParameterValue(null);
        crossStrategy(null);
        corellationClOrdID(null);
        previousLinkOrderID(null);
        rootOrderID(null);
        customerSlang(null);
        receiveTime(FixMessage.UNSET_LONG);
        crossRestrictionClientID(null);
        execInst(null);
        crossInstruction(null);
        avgPriceAcctIDSource(null);
        tickSizePilotGroup(null);
        clearingInstruction(FixMessage.UNSET_LONG);
        timeToLive(FixMessage.UNSET_LONG);
        srcTargetCompId(null);
        ioiID(null);
        securityID(null);
        securityAltID(null);
        securityAltIDSource(null);
    }

    default void copyTo(StandardHeaderTrailer msg) {
        copyTo((OrderCancelReplaceRequest) msg);
    }

    default void copyTo(OrderCancelReplaceRequest msg) {
        HeaderTrailer.super.copyTo(msg);
        if (orderID() != null) msg.orderID(orderID());
        if (clOrdID() != null) msg.clOrdID(clOrdID());
        if (side() != FixMessage.UNSET_CHAR) msg.side(side());
        if (!Double.isNaN(orderQty())) msg.orderQty(orderQty());
        if (!Double.isNaN(minQty())) msg.minQty(minQty());
        if (ordType() != FixMessage.UNSET_CHAR) msg.ordType(ordType());
        if (origClOrdID() != null) msg.origClOrdID(origClOrdID());
        if (symbol() != null) msg.symbol(symbol());
        if (symbolSfx() != null) msg.symbolSfx(symbolSfx());
        if (idSource() != null) msg.idSource(idSource());
        if (handlInst() != FixMessage.UNSET_CHAR) msg.handlInst(handlInst());
        if (transactTime() != FixMessage.UNSET_LONG) msg.transactTime(transactTime());
        if (account() != null) msg.account(account());
        if (!Double.isNaN(price())) msg.price(price());
        if (!Double.isNaN(bidPx())) msg.bidPx(bidPx());
        if (!Double.isNaN(offerPx())) msg.offerPx(offerPx());
        if (quoteTime() != FixMessage.UNSET_LONG) msg.quoteTime(quoteTime());
        if (timeInForce() != FixMessage.UNSET_CHAR) msg.timeInForce(timeInForce());
        if (createdNS() != FixMessage.UNSET_LONG) msg.createdNS(createdNS());
        if (!Double.isNaN(lastTraded())) msg.lastTraded(lastTraded());
        if (!Double.isNaN(lastTradedDelta())) msg.lastTradedDelta(lastTradedDelta());
        if (!Double.isNaN(bidPrice())) msg.bidPrice(bidPrice());
        if (!Double.isNaN(askPrice())) msg.askPrice(askPrice());
        if (orderCapacity() != FixMessage.UNSET_CHAR) msg.orderCapacity(orderCapacity());
        if (clientID() != null) msg.clientID(clientID());
        if (exDestination() != null) msg.exDestination(exDestination());
        if (currency() != null) msg.currency(currency());
        if (rule80A() != FixMessage.UNSET_CHAR) msg.rule80A(rule80A());
        if (settlCurrency() != null) msg.settlCurrency(settlCurrency());
        if (customerOrFirm() != FixMessage.UNSET_LONG) msg.customerOrFirm(customerOrFirm());
        if (locateReqd() != FixMessage.UNSET_CHAR) msg.locateReqd(locateReqd());
        if (ordLinkID() != null) msg.ordLinkID(ordLinkID());
        if (ordLinkType() != null) msg.ordLinkType(ordLinkType());
        if (bookingType() != null) msg.bookingType(bookingType());
        if (tradingAcct() != null) msg.tradingAcct(tradingAcct());
        if (customPrice1() != null) msg.customPrice1(customPrice1());
        if (tier() != FixMessage.UNSET_LONG) msg.tier(tier());
        if (noStrategyParameters() != null) msg.noStrategyParameters(noStrategyParameters());
        if (strategyParameterValue() != null) msg.strategyParameterValue(strategyParameterValue());
        if (crossStrategy() != null) msg.crossStrategy(crossStrategy());
        if (corellationClOrdID() != null) msg.corellationClOrdID(corellationClOrdID());
        if (previousLinkOrderID() != null) msg.previousLinkOrderID(previousLinkOrderID());
        if (rootOrderID() != null) msg.rootOrderID(rootOrderID());
        if (customerSlang() != null) msg.customerSlang(customerSlang());
        if (receiveTime() != FixMessage.UNSET_LONG) msg.receiveTime(receiveTime());
        if (crossRestrictionClientID() != null) msg.crossRestrictionClientID(crossRestrictionClientID());
        if (execInst() != null) msg.execInst(execInst());
        if (crossInstruction() != null) msg.crossInstruction(crossInstruction());
        if (avgPriceAcctIDSource() != null) msg.avgPriceAcctIDSource(avgPriceAcctIDSource());
        if (tickSizePilotGroup() != null) msg.tickSizePilotGroup(tickSizePilotGroup());
        if (clearingInstruction() != FixMessage.UNSET_LONG) msg.clearingInstruction(clearingInstruction());
        if (timeToLive() != FixMessage.UNSET_LONG) msg.timeToLive(timeToLive());
        if (srcTargetCompId() != null) msg.srcTargetCompId(srcTargetCompId());
        if (ioiID() != null) msg.ioiID(ioiID());
        if (securityID() != null) msg.securityID(securityID());
        if (securityAltID() != null) msg.securityAltID(securityAltID());
        if (securityAltIDSource() != null) msg.securityAltIDSource(securityAltIDSource());
    }
}
