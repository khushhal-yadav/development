package software.chronicle.fix.codegen.messages.datamodel;

import java.lang.Override;
import java.lang.String;
import java.util.concurrent.TimeUnit;
import software.chronicle.fix.codegen.messages.HeaderTrailer;
import software.chronicle.fix.sessioncode.messages.datamodel.CoreHeaderTrailer;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.MessageGenerator.generateHeaderTrailer(MessageGenerator.java)
 */
public abstract class DefaultHeaderTrailer extends CoreHeaderTrailer implements HeaderTrailer {
    private String onBehalfOfCompID = null;

    private String onBehalfOfSubID = null;

    private String deliverToCompID = null;

    private String deliverToSubID = null;

    private long origSendingTime = FixMessage.UNSET_LONG;

    public String onBehalfOfCompID() {
        return onBehalfOfCompID;
    }

    @Override
    public void onBehalfOfCompID(String onBehalfOfCompID) {
        this.onBehalfOfCompID = onBehalfOfCompID;
    }

    public String onBehalfOfSubID() {
        return onBehalfOfSubID;
    }

    @Override
    public void onBehalfOfSubID(String onBehalfOfSubID) {
        this.onBehalfOfSubID = onBehalfOfSubID;
    }

    public String deliverToCompID() {
        return deliverToCompID;
    }

    @Override
    public void deliverToCompID(String deliverToCompID) {
        this.deliverToCompID = deliverToCompID;
    }

    public String deliverToSubID() {
        return deliverToSubID;
    }

    @Override
    public void deliverToSubID(String deliverToSubID) {
        this.deliverToSubID = deliverToSubID;
    }

    public long origSendingTime() {
        return origSendingTime;
    }

    @Override
    public void origSendingTime(long origSendingTime, TimeUnit timeUnit) {
        origSendingTime(origSendingTime);
    }

    @Override
    public void origSendingTime(long origSendingTime) {
        this.origSendingTime = origSendingTime;
    }
}
