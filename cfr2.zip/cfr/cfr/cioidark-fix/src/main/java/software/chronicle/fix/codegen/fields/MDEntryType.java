package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface MDEntryType {
    /**
     * Tag number for this field
     */
    int FIELD = 269;

    char BID = '0';

    char OFFER = '1';

    char TRADE = '2';

    char INDEX_VALUE = '3';

    char OPENING_PRICE = '4';

    char CLOSING_PRICE = '5';

    char SETTLEMENT_PRICE = '6';

    char TRADING_SESSION_HIGH_PRICE = '7';

    char TRADING_SESSION_LOW_PRICE = '8';

    char TRADING_SESSION_VWAP_PRICE = '9';

    /**
     * @param mDEntryType &gt; FIX TAG 269
     */
    void mDEntryType(char mDEntryType);

    default char mDEntryType() {
        throw new UnsupportedOperationException();
    }

    static String asString(char value) {
        switch (value) {
            case BID:
                    return "BID";
            case OFFER:
                    return "OFFER";
            case TRADE:
                    return "TRADE";
            case INDEX_VALUE:
                    return "INDEX_VALUE";
            case OPENING_PRICE:
                    return "OPENING_PRICE";
            case CLOSING_PRICE:
                    return "CLOSING_PRICE";
            case SETTLEMENT_PRICE:
                    return "SETTLEMENT_PRICE";
            case TRADING_SESSION_HIGH_PRICE:
                    return "TRADING_SESSION_HIGH_PRICE";
            case TRADING_SESSION_LOW_PRICE:
                    return "TRADING_SESSION_LOW_PRICE";
            case TRADING_SESSION_VWAP_PRICE:
                    return "TRADING_SESSION_VWAP_PRICE";
            default:
                    throw new IllegalArgumentException(value + " is not recognised");
        }
    }
}
