package software.chronicle.fix.codegen.fields;

import java.util.concurrent.TimeUnit;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface ReceiveTime {
    /**
     * Tag number for this field
     */
    int FIELD = 10080;

    /**
     * @param receiveTime &gt; FIX TAG 10080
     */
    void receiveTime(long receiveTime);

    default long receiveTime() {
        throw new UnsupportedOperationException();
    }

    default void receiveTime(long receiveTime, TimeUnit timeUnit) {
        throw new UnsupportedOperationException();
    }
}
