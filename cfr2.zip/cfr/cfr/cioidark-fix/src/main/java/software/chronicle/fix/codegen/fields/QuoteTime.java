package software.chronicle.fix.codegen.fields;

import java.util.concurrent.TimeUnit;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface QuoteTime {
    /**
     * Tag number for this field
     */
    int FIELD = 11048;

    /**
     * @param quoteTime &gt; FIX TAG 11048
     */
    void quoteTime(long quoteTime);

    default long quoteTime() {
        throw new UnsupportedOperationException();
    }

    default void quoteTime(long quoteTime, TimeUnit timeUnit) {
        throw new UnsupportedOperationException();
    }
}
