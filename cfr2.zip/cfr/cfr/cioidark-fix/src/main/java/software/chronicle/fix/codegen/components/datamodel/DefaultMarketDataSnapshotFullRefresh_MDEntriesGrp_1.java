package software.chronicle.fix.codegen.components.datamodel;

import java.lang.Override;
import java.lang.String;
import java.util.concurrent.TimeUnit;
import software.chronicle.fix.codegen.components.MarketDataSnapshotFullRefresh_MDEntriesGrp_1;
import software.chronicle.fix.datamodel.AbstractDataModel;
import software.chronicle.fix.staticcode.messages.FixMessage;

/**
 * Generated at software.chronicle.fix.codegen.ComponentGenerator.generateComponent(ComponentGenerator.java)
 */
public class DefaultMarketDataSnapshotFullRefresh_MDEntriesGrp_1 extends AbstractDataModel implements MarketDataSnapshotFullRefresh_MDEntriesGrp_1 {
    private char mDEntryType = FixMessage.UNSET_CHAR;

    private double mDEntryPx = FixMessage.UNSET_DOUBLE;

    private String currency = null;

    private double mDEntrySize = FixMessage.UNSET_DOUBLE;

    private String mDEntryDate = null;

    private String mDEntryTime = null;

    private char tickDirection = FixMessage.UNSET_CHAR;

    private String mDMkt = null;

    private String tradingSessionID = null;

    private String quoteCondition = null;

    private String tradeCondition = null;

    private String mDEntryOriginator = null;

    private String locationID = null;

    private String deskID = null;

    private char openCloseSettleFlag = FixMessage.UNSET_CHAR;

    private char timeInForce = FixMessage.UNSET_CHAR;

    private String expireDate = null;

    private long expireTime = FixMessage.UNSET_LONG;

    private double minQty = FixMessage.UNSET_DOUBLE;

    private String execInst = null;

    private long sellerDays = FixMessage.UNSET_LONG;

    private String orderID = null;

    private String quoteEntryID = null;

    private String mDEntryBuyer = null;

    private String mDEntrySeller = null;

    private long numberOfOrders = FixMessage.UNSET_LONG;

    private long mDEntryPositionNo = FixMessage.UNSET_LONG;

    private String text = null;

    private long encodedTextLen = FixMessage.UNSET_LONG;

    private String encodedText = null;

    public char mDEntryType() {
        return mDEntryType;
    }

    @Override
    public void mDEntryType(char mDEntryType) {
        this.mDEntryType = mDEntryType;
    }

    public double mDEntryPx() {
        return mDEntryPx;
    }

    @Override
    public void mDEntryPx(double mDEntryPx) {
        this.mDEntryPx = mDEntryPx;
    }

    public String currency() {
        return currency;
    }

    @Override
    public void currency(String currency) {
        this.currency = currency;
    }

    public double mDEntrySize() {
        return mDEntrySize;
    }

    @Override
    public void mDEntrySize(double mDEntrySize) {
        this.mDEntrySize = mDEntrySize;
    }

    public String mDEntryDate() {
        return mDEntryDate;
    }

    @Override
    public void mDEntryDate(String mDEntryDate) {
        this.mDEntryDate = mDEntryDate;
    }

    public String mDEntryTime() {
        return mDEntryTime;
    }

    @Override
    public void mDEntryTime(String mDEntryTime) {
        this.mDEntryTime = mDEntryTime;
    }

    public char tickDirection() {
        return tickDirection;
    }

    @Override
    public void tickDirection(char tickDirection) {
        this.tickDirection = tickDirection;
    }

    public String mDMkt() {
        return mDMkt;
    }

    @Override
    public void mDMkt(String mDMkt) {
        this.mDMkt = mDMkt;
    }

    public String tradingSessionID() {
        return tradingSessionID;
    }

    @Override
    public void tradingSessionID(String tradingSessionID) {
        this.tradingSessionID = tradingSessionID;
    }

    public String quoteCondition() {
        return quoteCondition;
    }

    @Override
    public void quoteCondition(String quoteCondition) {
        this.quoteCondition = quoteCondition;
    }

    public String tradeCondition() {
        return tradeCondition;
    }

    @Override
    public void tradeCondition(String tradeCondition) {
        this.tradeCondition = tradeCondition;
    }

    public String mDEntryOriginator() {
        return mDEntryOriginator;
    }

    @Override
    public void mDEntryOriginator(String mDEntryOriginator) {
        this.mDEntryOriginator = mDEntryOriginator;
    }

    public String locationID() {
        return locationID;
    }

    @Override
    public void locationID(String locationID) {
        this.locationID = locationID;
    }

    public String deskID() {
        return deskID;
    }

    @Override
    public void deskID(String deskID) {
        this.deskID = deskID;
    }

    public char openCloseSettleFlag() {
        return openCloseSettleFlag;
    }

    @Override
    public void openCloseSettleFlag(char openCloseSettleFlag) {
        this.openCloseSettleFlag = openCloseSettleFlag;
    }

    public char timeInForce() {
        return timeInForce;
    }

    @Override
    public void timeInForce(char timeInForce) {
        this.timeInForce = timeInForce;
    }

    public String expireDate() {
        return expireDate;
    }

    @Override
    public void expireDate(String expireDate) {
        this.expireDate = expireDate;
    }

    public long expireTime() {
        return expireTime;
    }

    @Override
    public void expireTime(long expireTime, TimeUnit timeUnit) {
        expireTime(expireTime);
    }

    @Override
    public void expireTime(long expireTime) {
        this.expireTime = expireTime;
    }

    public double minQty() {
        return minQty;
    }

    @Override
    public void minQty(double minQty) {
        this.minQty = minQty;
    }

    public String execInst() {
        return execInst;
    }

    @Override
    public void execInst(String execInst) {
        this.execInst = execInst;
    }

    public long sellerDays() {
        return sellerDays;
    }

    @Override
    public void sellerDays(long sellerDays) {
        this.sellerDays = sellerDays;
    }

    public String orderID() {
        return orderID;
    }

    @Override
    public void orderID(String orderID) {
        this.orderID = orderID;
    }

    public String quoteEntryID() {
        return quoteEntryID;
    }

    @Override
    public void quoteEntryID(String quoteEntryID) {
        this.quoteEntryID = quoteEntryID;
    }

    public String mDEntryBuyer() {
        return mDEntryBuyer;
    }

    @Override
    public void mDEntryBuyer(String mDEntryBuyer) {
        this.mDEntryBuyer = mDEntryBuyer;
    }

    public String mDEntrySeller() {
        return mDEntrySeller;
    }

    @Override
    public void mDEntrySeller(String mDEntrySeller) {
        this.mDEntrySeller = mDEntrySeller;
    }

    public long numberOfOrders() {
        return numberOfOrders;
    }

    @Override
    public void numberOfOrders(long numberOfOrders) {
        this.numberOfOrders = numberOfOrders;
    }

    public long mDEntryPositionNo() {
        return mDEntryPositionNo;
    }

    @Override
    public void mDEntryPositionNo(long mDEntryPositionNo) {
        this.mDEntryPositionNo = mDEntryPositionNo;
    }

    public String text() {
        return text;
    }

    @Override
    public void text(String text) {
        this.text = text;
    }

    public long encodedTextLen() {
        return encodedTextLen;
    }

    @Override
    public void encodedTextLen(long encodedTextLen) {
        this.encodedTextLen = encodedTextLen;
    }

    public String encodedText() {
        return encodedText;
    }

    @Override
    public void encodedText(String encodedText) {
        this.encodedText = encodedText;
    }

    @Override
    public void reset() {
        MarketDataSnapshotFullRefresh_MDEntriesGrp_1.super.reset();
    }

    public TimeUnit internalTimeUnit() {
        return TimeUnit.MILLISECONDS;
    }
}
