package software.chronicle.fix.codegen.fields;

import java.lang.String;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface OrderPlacer {
    /**
     * Tag number for this field
     */
    int FIELD = 10895;

    /**
     * @param orderPlacer &gt; FIX TAG 10895
     */
    void orderPlacer(String orderPlacer);

    default String orderPlacer() {
        throw new UnsupportedOperationException();
    }
}
