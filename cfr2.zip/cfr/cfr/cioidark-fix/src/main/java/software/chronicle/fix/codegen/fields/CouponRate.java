package software.chronicle.fix.codegen.fields;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface CouponRate {
    /**
     * Tag number for this field
     */
    int FIELD = 223;

    /**
     * @param couponRate &gt; FIX TAG 223
     */
    void couponRate(double couponRate);

    default double couponRate() {
        throw new UnsupportedOperationException();
    }
}
