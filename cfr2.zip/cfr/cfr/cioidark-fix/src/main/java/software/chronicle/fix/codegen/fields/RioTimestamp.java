package software.chronicle.fix.codegen.fields;

import java.util.concurrent.TimeUnit;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface RioTimestamp {
    /**
     * Tag number for this field
     */
    int FIELD = 10071;

    /**
     * @param rioTimestamp &gt; FIX TAG 10071
     */
    void rioTimestamp(long rioTimestamp);

    default long rioTimestamp() {
        throw new UnsupportedOperationException();
    }

    default void rioTimestamp(long rioTimestamp, TimeUnit timeUnit) {
        throw new UnsupportedOperationException();
    }
}
