package software.chronicle.fix.codegen.fields;

import java.util.concurrent.TimeUnit;

/**
 * Generated at software.chronicle.fix.codegen.FieldGenerator.generateField(FieldGenerator.java)
 */
public interface TimeToLive {
    /**
     * Tag number for this field
     */
    int FIELD = 10014;

    /**
     * @param timeToLive &gt; FIX TAG 10014
     */
    void timeToLive(long timeToLive);

    default long timeToLive() {
        throw new UnsupportedOperationException();
    }

    default void timeToLive(long timeToLive, TimeUnit timeUnit) {
        throw new UnsupportedOperationException();
    }
}
