package software.chronicle.fix.codegen.parsers;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.codegen.messages.Logout;
import software.chronicle.fix.staticcode.parsers.OneMessageParser;

/**
 * Generated at software.chronicle.fix.codegen.ParserGenerator.generateCode(ParserGenerator.java)
 */
public class GeneratedLogoutParser extends OneMessageParser {
    public void parse(long startPos, GeneratedCoreFieldParser fix, Logout logout) {
        fix.loadNextField();
        Bytes bytes = fix.bytes();
        long pos = bytes.readPosition();
        for (int i = 0, max = (int) (bytes.readRemaining() / 4); i < max; i++) {
            long pos2 = bytes.readPosition();
            //ordered in the order of the documentation;
            fix.standardHeader(logout);
            fix.text(logout); // 58
            fix.encodedTextLen(logout); // 354
            fix.encodedText(logout); // 355
            if (fix.checkFinished(logout, startPos)) return;
            long pos3 = bytes.readPosition();
            if (pos2 == pos3) {
                fix.unexpectedFieldHandler().onUnexpectedField(fix, logout, pos);
                if (pos3 == bytes.readPosition())
                        throw fix.createInvalidFieldException(logout.msgSeqNum(), pos);
            }
        }
        throw fix.failedToParse(logout.msgSeqNum(), pos);
    }
}
