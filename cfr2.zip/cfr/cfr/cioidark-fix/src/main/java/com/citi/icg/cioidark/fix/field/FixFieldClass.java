package com.citi.icg.cioidark.fix.field;


import java.util.Arrays;
import java.util.List;

import software.chronicle.fix.codegen.fields.Account;
import software.chronicle.fix.codegen.fields.ClOrdID;
import software.chronicle.fix.codegen.fields.CrossStrategy;
import software.chronicle.fix.codegen.fields.CustomPrice1;
import software.chronicle.fix.codegen.fields.OrdType;
import software.chronicle.fix.codegen.fields.OrderCapacity;
import software.chronicle.fix.codegen.fields.OrderQty;
import software.chronicle.fix.codegen.fields.OrigClOrdID;
import software.chronicle.fix.codegen.fields.Price;
import software.chronicle.fix.codegen.fields.ReceiveTime;
import software.chronicle.fix.codegen.fields.Side;
import software.chronicle.fix.codegen.fields.StrategyParameterValue;
import software.chronicle.fix.codegen.fields.Symbol;
import software.chronicle.fix.codegen.fields.TimeInForce;
import software.chronicle.fix.codegen.fields.TransactTime;
import software.chronicle.fix.sessioncode.fields.SenderCompID;

public class FixFieldClass {

    final public static List<Integer> FIX_CHAR_TYPE_FIELDS = Arrays.asList(OrdType.FIELD, Side.FIELD, OrderCapacity.FIELD, TimeInForce.FIELD);
    final public static List<Integer> FIX_STRING_TYPE_FIELDS = Arrays.asList(ClOrdID.FIELD, SenderCompID.FIELD, Symbol.FIELD, Account.FIELD,
            OrigClOrdID.FIELD, CustomPrice1.FIELD, StrategyParameterValue.FIELD, CrossStrategy.FIELD);
    final public static List<Integer> FIX_DOUBLE_TYPE_FIELDS = Arrays.asList(OrderQty.FIELD, Price.FIELD);
    final public static List<Integer> FIX_LONG_TYPE_FIELDS = Arrays.asList(TransactTime.FIELD, ReceiveTime.FIELD);


}
