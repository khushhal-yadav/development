package com.citi.icg.cioidark.fix.bench;

import java.util.concurrent.TimeUnit;

import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.BenchmarkMode;
import org.openjdk.jmh.annotations.Fork;
import org.openjdk.jmh.annotations.Measurement;
import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.annotations.OutputTimeUnit;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.State;
import org.openjdk.jmh.annotations.Warmup;
import org.openjdk.jmh.infra.Blackhole;
import org.openjdk.jmh.profile.CompilerProfiler;
import org.openjdk.jmh.profile.GCProfiler;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;

import com.citi.icg.cioidark.fix.CitiFixMessage;

@State(Scope.Thread)
@BenchmarkMode(Mode.SampleTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@Fork(1)
@Warmup(iterations = 5)
@Measurement(iterations = 10)
public class FixParserBenchmark {
	
	private String testMessage = "8=FIX.4.49=159135=D49=QFF56=CGMI115=BANKINTER50=QFFX_US86_I157=DFPBKT0052=20140620-08:16:39.000122=20140620-08:16:39.000-6=1403262008126-9=1403252199118-12=140325219911734=200660=20140620-11:00:08.123-17=ITPC54=110080=20140620-08:16:39.000-2=14171GH7qqm#0-1=14171GH7qqm#21=BNKINDMA11=14171GH7qqm#215=USD18=B 538=280.011042=340=244=59.2448=US075896100955=BBBY59=063=075=20140620100=AEE120=USD167=CS207=NASD421=USA10006=TBS;22=4528=A581=1779=20140620-11:00:08.12010005=610015=DES10016=PDB10031=0A10033=610036=B1E10037=QFF10038=B1E10039=B1E10040=S10041=TB10042=A10044=;8018=C4C_UKPROD_C2P_3^^^~10049=N10050=002825461309910051=002825461309910053=CDMA10075=05041=6035039=15043=09:30:00377=N561=100.021=110081=F1406201016388907098365130110083=QFF100169=Y660=10311210=14171GH7qqm100232=5808013=R10210=N10223=010203=USQFF10204=AEE10202=USDMA10184=14171GH7qqm10292=72910201=UKFF8001=BANKINTER8004=BNKINDMA8003=AEE6438=N58=000000603042743810515=610518=611083=304274381727=729111=280.0-20201=USA-20202=NASD-20203=60.68-20204=2233583.4-40044=59.24-20205=USD8015=ITPC-20206=2.02608E88014=Y-20207=true8007=?8005=B1E8027=PDB-QDMA@AEE-8003=AEE8022=PDB8023=20140620-21:00:0047=A12034=Y-20880=false-20881=false-44=60.688053=0-11210=14171GH7qqm-20002=ITPC-20001=ITPC-CGMI-20003=BANKINTER-10515=6-88=FIX.4.27472=996250=BDEFAULT-483=?-484=2085878-481=BBBY.O-482=BBBY-487=Y-20108=true-491=JZZ-20103=xRA-492=USD-489=BBBY UW-490=COM-493=100.010893=NON_PASSTHRU10892=NAM354=6355=IGNORE-100=NASD10=000";

	@Benchmark
	public CitiFixMessage fixParserBenchmark(Blackhole bh) {
		CitiFixMessage msg = new CitiFixMessage(testMessage);

		bh.consume(msg.getBeginString()); // 8=FIX.4.4
		bh.consume(msg.getBodyLength()); // 9=1591
		bh.consume(msg.getMsgType()); // 35=D
		bh.consume(msg.getSenderCompID()); // 49=QFF
		bh.consume(msg.getTargetCompID()); // 56=CGMI
		bh.consume(msg.getOnBehalfOfCompID()); // 115=BANKINTER
		bh.consume(msg.getSenderSubID()); // 50=QFFX_US86_I1
		bh.consume(msg.getTargetSubID()); // 57=DFPBKT00
		bh.consume(msg.getSendingTime()); // 52=20140620-08:16:39.000
		bh.consume(msg.getOrigSendingTime()); // 122=20140620-08:16:39.000
		bh.consume(msg.getLong(-6)); // -6=1403262008126
		bh.consume(msg.getLong(-9)); // -9=1403252199118
		bh.consume(msg.getLong(-12)); // -12=1403252199117
		bh.consume(msg.getMsgSeqNum()); // 34=2006
		bh.consume(msg.getTransactTime()); // 60=20140620-11:00:08.123
		bh.consume(msg.getTag(-17)); // -17=ITPC
		bh.consume(msg.getSide()); // 54=1
		bh.consume(msg.getReceiveTime()); // 10080=20140620-08:16:39.000
		bh.consume(msg.getTag(-2)); // -2=14171GH7qqm#0
		bh.consume(msg.getTag(-1)); // -1=14171GH7qqm#2
		bh.consume(msg.getAccount()); // 1=BNKINDMA
		bh.consume(msg.getClOrdID()); // 11=14171GH7qqm#2
		bh.consume(msg.getCurrency()); // 15=USD
		bh.consume(msg.getExecInst()); // 18=B 5
		bh.consume(msg.getOrderQty()); // 38=280.0
		bh.consume(msg.getAcctCategory()); // 11042=3
		bh.consume(msg.getOrdType()); // 40=2
		bh.consume(msg.getPrice()); // 44=59.24
		bh.consume(msg.getSecurityID()); // 48=US0758961009
		bh.consume(msg.getSymbol()); // 55=BBBY
		bh.consume(msg.getTimeInForce()); // 59=0
		bh.consume(msg.getSettlType()); // 63=0
		bh.consume(msg.getTradeDate()); // 75=20140620
		bh.consume(msg.getExDestination()); // 100=AEE
		bh.consume(msg.getSettlCurrency()); // 120=USD
		bh.consume(msg.getSecurityType()); // 167=CS
		bh.consume(msg.getSecurityExchange()); // 207=NASD
		bh.consume(msg.getCountry()); // 421=USA
		bh.consume(msg.getOptionalFields()); // 10006=TBS;
		bh.consume(msg.getSecurityIDSource()); // 22=4
		bh.consume(msg.getOrderCapacity()); // 528=A
		bh.consume(msg.getAccountType()); // 581=1
		bh.consume(msg.getLastUpdateTime()); // 779=20140620-11:00:08.120
		bh.consume(msg.getSrcSystemID()); // 10005=6
		bh.consume(msg.getSubSubDestination()); // 10015=DES
		bh.consume(msg.getModifiedBy()); // 10016=PDB
		bh.consume(msg.getLegalEntity()); // 10031=0A
		bh.consume(msg.getPriceRounding()); // 10033=6
		bh.consume(msg.getSalesPersonID()); // 10036=B1E
		bh.consume(msg.getInitiatorID()); // 10037=QFF
		bh.consume(msg.getCreditID()); // 10038=B1E
		bh.consume(msg.getTraderID()); // 10039=B1E
		bh.consume(msg.getBranchID()); // 10040=S
		bh.consume(msg.getTradeArea()); // 10041=TB
		bh.consume(msg.getRule80AF()); // 10042=A
		bh.consume(msg.getOrderComments()); // 10044=;8018=C4C_UKPROD_C2P_3^^^~
		bh.consume(msg.getCommOverrideF()); // 10049=N
		bh.consume(msg.getTradingAcct()); // 10050=0028254613099
		bh.consume(msg.getAvgPriceAcct()); // 10051=0028254613099
		bh.consume(msg.getChannelName()); // 10053=CDMA
		bh.consume(msg.getPreConfirmF()); // 10075=0
		bh.consume(msg.getTriggerID()); // 5041=603
		bh.consume(msg.getNoTriggers()); // 5039=1
		bh.consume(msg.getTriggerValue()); // 5043=09:30:00
		bh.consume(msg.getSolicitedFlag()); // 377=N
		bh.consume(msg.getRoundLot()); // 561=100.0
		bh.consume(msg.getHandlInst()); // 21=1
		bh.consume(msg.getOrigOrderId()); // 10081=F14062010163889070983651301
		bh.consume(msg.getSrcServer()); // 10083=QFF
		bh.consume(msg.getIsMarketMaker()); // 100169=Y
		bh.consume(msg.getAcctIDSource()); // 660=103
		bh.consume(msg.getRootOrderID()); // 11210=14171GH7qqm
		bh.consume(msg.getAggUnitID()); // 100232=580
		bh.consume(msg.getAutoMergeF()); // 8013=R
		bh.consume(msg.getSyncFlag()); // 10210=N
		bh.consume(msg.getFlowSubCategory()); // 10223=0
		bh.consume(msg.getOrderFlowClass()); // 10203=USQFF
		bh.consume(msg.getOrderFlowTarget()); // 10204=AEE
		bh.consume(msg.getOrderFlowCategory()); // 10202=USDMA
		bh.consume(msg.getPreviousLinkOrderID()); // 10184=14171GH7qqm
		bh.consume(msg.getOrderFlowDesk()); // 10292=729
		bh.consume(msg.getOrderFlowEntry()); // 10201=UKFF
		bh.consume(msg.getCustomerName()); // 8001=BANKINTER
		bh.consume(msg.getCustomerSlang()); // 8004=BNKINDMA
		bh.consume(msg.getRoutingHub()); // 8003=AEE
		bh.consume(msg.getCrossInstruction()); // 6438=N
		bh.consume(msg.getText()); // 58=0000006030427438
		bh.consume(msg.getRootSrcSystemID()); // 10515=6
		bh.consume(msg.getPreviousLinkSrcSystemID()); // 10518=6
		bh.consume(msg.getClientAccount()); // 11083=30427438
		bh.consume(msg.getInformationBarrierID()); // 1727=729
		bh.consume(msg.getMaxFloor()); // 111=280.0
		bh.consume(msg.getTag(-20201)); // -20201=USA
		bh.consume(msg.getTag(-20202)); // -20202=NASD
		bh.consume(msg.getTag(-20203)); // -20203=60.68
		bh.consume(msg.getTag(-20204)); // -20204=2233583.4
		bh.consume(msg.getTag(-40044)); // -40044=59.24
		bh.consume(msg.getTag(-20205)); // -20205=USD
		bh.consume(msg.getTag(8015)); // 8015=ITPC
		bh.consume(msg.getTag(-20206)); // -20206=2.02608E8
		bh.consume(msg.getTag(8014)); // 8014=Y
		bh.consume(msg.getTag(-20207)); // -20207=true
		bh.consume(msg.getTag(8007)); // 8007=?
		bh.consume(msg.getTag(8005)); // 8005=B1E
		bh.consume(msg.getTag(8027)); // 8027=PDB-QDMA@AEE
		bh.consume(msg.getTag(-8003)); // -8003=AEE
		bh.consume(msg.getTag(8022)); // 8022=PDB
		bh.consume(msg.getTag(8023)); // 8023=20140620-21:00:00
		bh.consume(msg.getTag(47)); // 47=A
		bh.consume(msg.getTag(12034)); // 12034=Y
		bh.consume(msg.getTag(-20880)); // -20880=false
		bh.consume(msg.getTag(-20881)); // -20881=false
		bh.consume(msg.getTag(-44)); // -44=60.68
		bh.consume(msg.getTag(8053)); // 8053=0
		bh.consume(msg.getTag(-11210)); // -11210=14171GH7qqm
		bh.consume(msg.getTag(-20002)); // -20002=ITPC
		bh.consume(msg.getTag(-20001)); // -20001=ITPC-CGMI
		bh.consume(msg.getTag(-20003)); // -20003=BANKINTER
		bh.consume(msg.getTag(-10515)); // -10515=6
		bh.consume(msg.getTag(-88)); // -88=FIX.4.2
		bh.consume(msg.getTag(7472)); // 7472=99
		bh.consume(msg.getTag(6250)); // 6250=BDEFAULT
		bh.consume(msg.getTag(-483)); // -483=?
		bh.consume(msg.getTag(-484)); // -484=2085878
		bh.consume(msg.getTag(-481)); // -481=BBBY.O
		bh.consume(msg.getTag(-482)); // -482=BBBY
		bh.consume(msg.getTag(-487)); // -487=Y
		bh.consume(msg.getTag(-20108)); // -20108=true
		bh.consume(msg.getTag(-491)); // -491=JZZ
		bh.consume(msg.getTag(-20103)); // -20103=xRA
		bh.consume(msg.getTag(-492)); // -492=USD
		bh.consume(msg.getTag(-489)); // -489=BBBY UW
		bh.consume(msg.getTag(-490)); // -490=COM
		bh.consume(msg.getTag(-493)); // -493=100.0
		bh.consume(msg.getTag(10893)); // 10893=NON_PASSTHRU
		bh.consume(msg.getTag(10892)); // 10892=NAM
		bh.consume(msg.getTag(354)); // 354=6
		bh.consume(msg.getTag(355)); // 355=IGNORE
		bh.consume(msg.getTag(-100)); // -100=NASD
		bh.consume(msg.getCheckSum()); // 10=000

		return msg;
	}
	
	public static void main(String[] argv) throws RunnerException {
		Options opt = new OptionsBuilder().include(".*" + FixParserBenchmark.class.getSimpleName() + ".*")
			.addProfiler(CompilerProfiler.class)
			.addProfiler(GCProfiler.class)
			.build();

		new Runner(opt).run();
	}

}
