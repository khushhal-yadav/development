package com.citi.icg.cioidark.idgen;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.junit.Test;


public class IDGeneratorTest {

	@Test
	public void testIDGen() throws Exception {
		final int n = 100_000;
		final int threads = 10;
		// Callable to generate a bunch of id's in a thread
		Callable<String[]> task = () -> {
			String[] values = new String[n+1];
			values[0] = String.format("ThreadID:%7s", Thread.currentThread().getId());
			for (int i = 1; i < n+1; i++) {
				values[i] = IDGenerator.newID();
			}
			return values;
		};
		// Run the id generation in multiple threads
		@SuppressWarnings("unchecked")
		Future<String[]>[] tasks = new Future[threads];
		String[][] results = new String[threads][];
		ExecutorService pool = Executors.newFixedThreadPool(threads);
		for (int i = 0; i < threads; i++) {
			tasks[i] = pool.submit(task);
		}
		// Gather the results
		for (int i = 0; i < threads; i++) {
			results[i] = tasks[i].get();
		}
		// Check to make sure there are no duplicates and output a few ids
		System.out.println("Sample Order IDs:");
		Set<String> ids = new HashSet<>();
		StringBuilder output = new StringBuilder();
		for (int i = 0; i < n+1; i++) {
			output = new StringBuilder();
			for (int t = 0; t < threads; t++) {
				String id = results[t][i];
				assertFalse("["+t+"]"+"["+i+"] "+ id, ids.contains(id));
				ids.add(id);
				if (t < 5) {
					output.append(id).append("   ");
				}
			}
			if (i < 10) {
				System.out.println(output);
			}
		}
	}
	
	@Test
	public void testNextClOrdID() {
		assertEquals("abc#0", IDGenerator.nextClOrdID("abc"));
		assertEquals("abc#1", IDGenerator.nextClOrdID("abc#0"));
		assertTrue(IDGenerator.nextClOrdID(null).endsWith("#0"));
		assertTrue(IDGenerator.nextClOrdID("").endsWith("#0"));
		assertEquals("#1", IDGenerator.nextClOrdID("#0"));
		assertEquals("##0", IDGenerator.nextClOrdID("##"));
		assertEquals("##blah#0", IDGenerator.nextClOrdID("##blah"));
	}
	
	@Test
	public void testErrorFilter() {
		assertTrue(containsErrorString("blablaherrorblabla"));
		assertFalse(containsErrorString("blablaherorblabla"));
		assertTrue(containsErrorString("blablaheRRorblabla"));
		assertTrue(containsErrorString("blahFATAL"));
		assertTrue(containsErrorString("blahFatAL"));
		assertTrue(containsErrorString("Fatalblah"));
	}

	private boolean containsErrorString(String idString) {
		return IDGenerator.idGen.get().containsErrorString(idString);
	}
}
