package com.citi.icg.cioidark.idgen;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Calendar;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Generates a unique series of non-sequential, monotonically increasing IDs for
 * each instance of this class. This class is thread-safe and does not require,
 * or use, locking when generating IDs from multiple threads.
 * <p>
 * The ID format is:
 * {@code [ YYJJJ | Random App ID + millisOfDay | threadID | sequenceCounter ]}
 * <p>
 * It does not require any shared information to maintain uniqueness among
 * multiple applications, instances, and threads. It will generate a unique
 * series of IDs depending on the millisecond of the century in which the thread
 * was initialized, plus a large random factor.
 * <p>
 * The IDs generated, retain all the well-loved characteristics of the Zeus
 * order ID generator used in Quantum 3:
 * <ul>
 * <li>They start with the Julian date, so it's easy to see at a glance if
 * you're dealing with a prior-day order.
 * <li>They are base-62 encoded so they're pretty short and easy to work with
 * when researching issues.
 * <li>And they end with a highly unique, lower-case, 4 character suffix
 * (base-36 encoded) which can be used most of the time to verbally convey an
 * order id over the phone in QA and production support situations.
 * </ul>
 * <p>
 * Here some example IDs:
 * 
 * <pre>
 * ThreadID: 12       ThreadID: 13
 * 152865tIXe1c0u5h   152865tIXe1d0whb
 * 152865tIXe1c0u5m   152865tIXe1d0whg
 * 152865tIXe1c0u5r   152865tIXe1d0whl
 * </pre>
 * 
 * And to avoid false alerts in log files, it won't generate IDs which contain
 * "error", "ception", "warn", or "fatal" in them (case-insensitive). This
 * little extra filtering only adds ~100 nanoseconds (0.1 microseconds) to id
 * generation time, which itself is ~100 nanoseconds.
 * 
 * @author Robert Gorlitsky
 * 
 */
public class IDGenerator {
	
	public static String newID() {
		return idGen.get().generateID();
	}
	
	public static String nextClOrdID(String clOrdID) {
		if (clOrdID == null || clOrdID.isEmpty()) {
			return newID() + "#0";
		}
		String next = clOrdID;
		int syncNum = 0;
		try {
			int idx = clOrdID.lastIndexOf('#');
			if (idx >= 0) {
				if (idx < clOrdID.length() - 1) {
					syncNum = Integer.parseInt(clOrdID.substring(idx+1)) + 1;
				}
				next = clOrdID.substring(0, idx);
			}
		} catch (Exception e) {
		} finally {
			next += "#" + syncNum;
		}
		return next;
	}
	
	/** Thread-local ID counter to avoid any locking. */
	static final ThreadLocal<PerThreadIDGenerator> idGen = ThreadLocal.withInitial(() -> new PerThreadIDGenerator());
	
	static class PerThreadIDGenerator {
		/** Base-62 encoding digits plus lower and upper-case letters **/
		private final int maxRadix = digits.length;
		/** Base-36 encoding for the sequence number id suffix to keep it lower-case for easy communication **/
		private final int radix = 36;
		private final int numDigits = 4;
		private final long maxCounter = (long) Math.pow(radix, numDigits);
		
		int yearOfCentury;
		int dayOfYear;
		long millisOfDay;
		
		/**
		 * Make a new character array containing a unique prefix with
		 * human-readable year and day-of-year and set the start position to the
		 * end of the prefix.
		 * 
		 * Reset counter to 0
		 */
		private PerThreadIDGenerator() {
			assert radix <= maxRadix;
			init();
		}

		void calcStartOfDay() {
			Calendar c = Calendar.getInstance();
			c.set(Calendar.HOUR_OF_DAY, 0);
			c.set(Calendar.MINUTE, 0);
			c.set(Calendar.SECOND, 0);
			c.set(Calendar.MILLISECOND, 0);
			yearOfCentury = c.get(Calendar.YEAR) % 100;
			dayOfYear = c.get(Calendar.DAY_OF_YEAR);
			millisOfDay = System.currentTimeMillis() - c.getTimeInMillis();
		}
		
		private void init() {
			calcStartOfDay();
			long threadID = Thread.currentThread().getId();
			StringBuilder sb = new StringBuilder().append(yearOfCentury)
					.append(String.format("%03d", dayOfYear))
					.append(encode(appInstanceUniquifier + millisOfDay, maxRadix))
					.append(encode(62 + threadID, maxRadix));
							   // +62 to the threadID so it starts off being 2 characters long so that the ID length doesn't suddenly increase by one after the first 62 threads are created
			
			startPos = sb.length();
			
			// Copy the prefix to the buffer
			buf = new char[startPos + numDigits];
			sb.getChars(0, startPos, buf, 0);
			
			// Pad the rest with zeros
			int pos = startPos + numDigits;
			while (--pos >= startPos) {
				buf[pos] = digits[0];
			}
			
			// Make each threads ID counter start far apart to avoid common
			// suffixes among thread for easier log searching using only the
			// last 4 characters of the id.
			idCounter = (((threadID) + 1) * 3000) + ThreadLocalRandom.current().nextInt(100);
			
			for (int i = 0; i < rndSkip; i++) {
				skip[i] = ThreadLocalRandom.current().nextInt(rndSkip) + 1;
			}
		}
		
		/** Character buffer to store the formatted id **/
		private char[] buf;
		/** Where in the buffer to put the encoded idCounter value */
		private int startPos;
		/** Unique value encoded into each ID */
		private long idCounter;
		
		/** Generate a unique ID string. */
		private String generateID() {
			String newID = "";
			do {
				if (idCounter >= maxCounter) {
					init();
				}
				
				long value = idCounter += rndSkip;
				pad(encode(value, buf, startPos, startPos + numDigits, radix));
				newID = new String(buf);
			} while (containsErrorString(newID));
			return newID;
		}

		/** Pad with zeros up to numDigits length */
		private void pad(int pos) {
			while (pos >= startPos) {
				buf[pos--] = digits[0];
			}
		}

		private String encode(long value, int radix) {
			char[] buf = new char[65];
			int charPos = 64;
			charPos = encode(value, buf, 1, charPos, radix);
			return new String(buf, charPos+1, 63 - charPos);
		}
		
		private int encode(long value, char[] buf, int startPos, int endPos, int radix) {
			value &= Long.MAX_VALUE; // fast absolute value
			int pos = endPos;
			while (--pos >= startPos && value != 0) {
				// Divide and reduce.
				long i = value / radix;
				buf[pos] = digits[(int) (value - (i * radix))];
				value = i;
			}
			return pos;
		}
		
		/** All possible chars for representing a number as a String */
	    final static char[] digits = {
	        '0' , '1' , '2' , '3' , '4' , '5' ,
	        '6' , '7' , '8' , '9' , 'a' , 'b' ,
	        'c' , 'd' , 'e' , 'f' , 'g' , 'h' ,
	        'i' , 'j' , 'k' , 'l' , 'm' , 'n' ,
	        'o' , 'p' , 'q' , 'r' , 's' , 't' ,
	        'u' , 'v' , 'w' , 'x' , 'y' , 'z' ,
	        'A' , 'B' , 'C' , 'D' , 'E' , 'F' ,
	        'G' , 'H' , 'I' , 'J' , 'K' , 'L' ,
	        'M' , 'N' , 'O' , 'P' , 'Q' , 'R' ,
	        'S' , 'T' , 'U' , 'V' , 'W' , 'X' ,
	        'Y' , 'Z'
	    };
	    
	    /** Make it so the id's are not consecutive **/
		final int rndSkip = 5;
	    final int[] skip = new int[rndSkip];
	    
	    /**
		 * Make it 1 billion times less likely to have an ID collision even if two
		 * apps start at the same moment in time.
		 */
		private static final long appInstanceUniquifier;
		static {
			long rnd = 0;
			try {
				rnd = SecureRandom.getInstance("SHA1PRNG").nextInt(100_000);
			} catch (NoSuchAlgorithmException e) {
				rnd = new Random().nextInt(1_000_000_000);
			} finally {
				appInstanceUniquifier = rnd;
			}
		}
		
		/**
		 * Make it so the id's don't contain character sequences like "error" or
		 * "fatal" which could cause false alerts when monitoring log files.
		 * <p>
		 * This check adds ~100 nanoseconds to the id generation (0.1 microseconds).
		 */
		private final String[] errorStrings = {"error", "ception", "fatal", "warn"};
		boolean containsErrorString(String newID) {
			if (newID == null) {
				return false;
			}
			newID = newID.toLowerCase();
			for (String errorString : errorStrings) {
				if (newID.contains(errorString)) {
					return true;
				}
			}
			return false;
		}
	}
}
