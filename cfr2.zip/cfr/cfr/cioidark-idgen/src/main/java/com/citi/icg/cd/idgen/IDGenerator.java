package com.citi.icg.cd.idgen;

public interface IDGenerator {
	
	String getExecID();
	String getCrossID();
}
