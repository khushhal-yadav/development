package com.citi.icg.cd.idgen;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;


public class USIDGenerator implements IDGenerator {
	
	private final SimpleDateFormat sdf = new SimpleDateFormat("HHmmssSSS");
	private static final int millisecondsInADay = 86400000; // 86400000 possible milliseconds in a day (0-86399999)
	private static final int daysInAYear = 366; // 366 possible days in a leap year (1-366)
	private char prefix;
	private int crossCount;
	private int zExecCount;
	private String instance;
	private int shiftedInstance;
	private static final long midnight;
	private static final long twoDigitYear;
	private static final long dayOfYear;
	private int maxSyncNum;
	private int length;
	private int radix;
	private char fillChar;
	
	static {
		Calendar midnightToday = Calendar.getInstance();
		midnightToday.set(Calendar.HOUR_OF_DAY, 0);
		midnightToday.set(Calendar.MINUTE, 0);
		midnightToday.set(Calendar.SECOND, 0);
		midnightToday.set(Calendar.MILLISECOND, 0);
		midnight = midnightToday.getTimeInMillis();
		String baseYear = Integer.toString(midnightToday.get(Calendar.YEAR));
		twoDigitYear = Long.parseLong(baseYear.substring(baseYear.length()-3)) * (daysInAYear+1) * millisecondsInADay;
		dayOfYear = (long) midnightToday.get(Calendar.DAY_OF_YEAR) * (long) millisecondsInADay;
	}
	
	public USIDGenerator(String instance) {
		this(instance, 1000, 11, 36, '0', 'B');
	}
	
	public USIDGenerator(String instance, int maxSyncNum, int length, int radix, char fillChar, char prefixChar){
		int inst = Integer.parseInt(instance);
		if(inst < 10)  {
			this.instance = "0" + instance;
		} else {
			this.instance = instance;
		}
		this.maxSyncNum = maxSyncNum;
		this.shiftedInstance = inst*maxSyncNum;
		this.length = length-1;
		this.radix = radix;
		this.fillChar = fillChar;
		this.prefix = prefixChar;
		//validateParameters();
	}

	@Override
	public String getCrossID() {
		StringBuilder sb = new StringBuilder(instance).append(getTime()).append(getSyncNum());
		return sb.toString();
	}
	
	/**
	 * Guaranteed 11 alphanumeric characters with the following max parameters:
	 * -year: 99 (fixed)
	 * -day: 366 (fixed)
	 * -milliseconds: 86399999 (fixed)
	 * -instance: 40
	 * -seqNum: 1000
	 * 
	 * Once validation is in place, it will be possible but not recommended to safely have more instances if you are in a year not close to 99
	 */
	@Override
	public String getExecID() {
		long currentTime = new Date().getTime();
		long julianCurrentDate = twoDigitYear + dayOfYear + (currentTime-midnight);
		long id = julianCurrentDate * (shiftedInstance+maxSyncNum) + shiftedInstance + getRadixSyncNum();
		return prefix + StringUtils.leftPad(Long.toString(id, radix), length, fillChar);
	}
	
	private synchronized String getTime(){
		return sdf.format(new Date());
	}
	
	private synchronized String getSyncNum(){
		if(crossCount >= 999){
			crossCount = 1;
		}else{
			crossCount++;
		}
		return formatCount(crossCount);
	}
	
	private synchronized int getRadixSyncNum() {
		if(zExecCount >= maxSyncNum-1) {
			zExecCount = 1;
		} else {
			zExecCount++;
		}
		return zExecCount;
	}
	
	private String formatCount(int count) {
		if(count<10){
			return "00" + count;
		}else if (count > 9 && count< 100){
			return "0" + count;
		}else{
			return String.valueOf(count);
		}
	}

/**
 * Add this validation later, since we need to verify that we can throw exceptions and still implement the IDGenerator interface
 
	protected void validateParameters() {
		if(radix < 0 || maxSyncNum < 0 || length < 1 || shiftedInstance < 0) {
			throw new Exception();
		}
		if(radix < Character.MIN_RADIX || radix > Character.MAX_RADIX) {
			throw new Exception();
		}
		BigInteger radixCombinations = BigInteger.valueOf(radix).pow(length);
		BigInteger parameterCombinations = BigInteger.valueOf(twoDigitYear).add(BigInteger.valueOf(dayOfYear)).add(BigInteger.valueOf(millisecondsInADay-1))
											.multiply(BigInteger.valueOf(shiftedInstance).add(BigInteger.valueOf(maxSyncNum))).add(BigInteger.valueOf(shiftedInstance)).add(BigInteger.valueOf(maxSyncNum-1));
//			((twoDigitYear + dayOfYear + (millisecondsInADay-1))*(shiftedInstance+maxSyncNum))+
//										(shiftedInstance)+(maxSyncNum-1);
		if(parameterCombinations.compareTo(radixCombinations) > 1) {
			throw new Exception();
		}
		if(radixCombinations.compareTo(BigInteger.valueOf(Long.MAX_VALUE)) > 1) {
			throw new Exception();
		}
	}
	*/
	
	
	public static void main(String[] args){
		USIDGenerator generator = new USIDGenerator("2", 1000, 11, 36, '0', 'B');
		for (int i = 0; i<1000; i++){
			System.out.println(generator.getCrossID());
		}
		System.out.println();
		for (int i = 0; i<1000; i++) {
			System.out.println(generator.getExecID());
		}
	}
}
