package com.citi.icg.cioidark.md;

import com.citi.icg.cioidark.chronicle.messaging.queue.GMDOut;
import org.apache.commons.configuration.ConfigurationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
public class MarketDataSystemPropertyTest {

    private MarketDataSystemProperty marketDataSystemProperty;

    private final GMDOut gmdOut = marketDataMessage -> {
    };

    @Before
    public void init() throws ConfigurationException {
        MarketDataApplicationContextProvider.initialize(gmdOut);
        marketDataSystemProperty = MarketDataApplicationContextProvider.getMarketDataSystemProperty();
    }

    @Test
    public void testMarketDataSystemProperties() {
        Assert.assertTrue(marketDataSystemProperty.isGmdSubscribeMarketData());
        Assert.assertEquals(2, marketDataSystemProperty.getGmdMarketDataFeedId());
        Assert.assertEquals(3, marketDataSystemProperty.getGmdMarketDataRetry());
        Assert.assertEquals(30000, marketDataSystemProperty.getGmdMarketDataRetryWaitInterval());
        Assert.assertEquals(System.getProperty("preferences.env") + "/gmd.client-" + System.getProperty("gmd.instance") + ".cfg",
                marketDataSystemProperty.getGmdConfigLocation());

        Assert.assertEquals(5, marketDataSystemProperty.getMarketDataTickDriverSubscriberCorePoolMinSize());
        Assert.assertEquals(0, marketDataSystemProperty.getMarketDataTickDriverSubscriberCorePoolMaxSize());
        Assert.assertEquals(15, marketDataSystemProperty.getMarketDataTickDriverSubscriberKeepAliveTime());
        Assert.assertEquals(2000, marketDataSystemProperty.getMarketDataTickDriverSubscriberCapacity());
    }

}