package com.citi.icg.cioidark.md.component.manager;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.SecurityMarketData;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.MarketDataSystemProperty;
import com.citi.icg.cioidark.md.component.drainer.MarketDataSubscriptionQueueDrainer;
import com.citi.icg.cioidark.md.component.driver.GMDTickDriver;
import com.citi.icg.cioidark.md.component.driver.TickDriver;
import com.citi.icg.cioidark.md.component.subscriber.MarketDataTickDriverSubscriber;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MarketDataApplicationContextProvider.class})
public class MarketDataSubscriptionManagerTest {

    @Mock
    private MarketDataSystemProperty marketDataSystemProperty;
    @Mock
    private MarketDataTickDriverSubscriber marketDataTickDriverSubscriber;
    @Mock
    private MarketDataTickDriverManager marketDataTickDriverManager;

    private final int retryCount = 3;
    private final long retryWaitInterval = 10;
    private MarketDataSubscriptionManager marketDataSubscriptionManager;

    @Before
    public void init() {
        PowerMockito.mockStatic(MarketDataApplicationContextProvider.class);
        PowerMockito.when(marketDataSystemProperty.getGmdMarketDataRetry()).thenReturn(retryCount);
        PowerMockito.when(marketDataSystemProperty.getGmdMarketDataRetryWaitInterval()).thenReturn(retryWaitInterval);
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSystemProperty())
                .thenReturn(marketDataSystemProperty);
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataTickDriverSubscriber())
                .thenReturn(marketDataTickDriverSubscriber);

        marketDataSubscriptionManager = new MarketDataSubscriptionManager();
    }

    @Test
    public void login() {
        loginForMarketData();
    }

    @Test
    public void loginFail() {
        final boolean login = marketDataSubscriptionManager.login(new GMDTickDriver());
        Assert.assertFalse(login);
    }

    @Test
    public void subscribeWithoutTickDriver() {

        loginForMarketData();
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        marketDataSubscriptionManager.setMarketDataOn(true);

        marketDataSubscriptionManager.subscribe("IBM", "IBM.M");

        Assert.assertTrue(marketDataSubscriptionManager.getSubscriptionMap().containsKey("IBM"));
        Assert.assertTrue(marketDataSubscriptionManager.isMarketDataOn());
        Assert.assertTrue(marketDataSubscriptionManager.getWaitingList().contains(new SecurityMarketData("IBM", "IBM.M")));

        Mockito.verify(marketDataSystemProperty, Mockito.times(1)).isGmdSubscribeMarketData();
        Mockito.verify(marketDataTickDriverSubscriber, Mockito.never()).subscribe(ArgumentMatchers.any(TickDriver.class), ArgumentMatchers.any(SecurityMarketData.class));

        marketDataSubscriptionManager.getSubscriptionMap().clear();
        marketDataSubscriptionManager.getWaitingList().clear();
    }

    @Test
    public void subscribe() {

        loginForMarketData();

        TickDriver tickDriver = new GMDTickDriver();
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        marketDataSubscriptionManager.setMarketDataOn(true);
        marketDataSubscriptionManager.setCurrentDriver(tickDriver);

        marketDataSubscriptionManager.subscribe("IBM", "IBM.M");

        Assert.assertTrue(marketDataSubscriptionManager.getSubscriptionMap().containsKey("IBM"));
        Assert.assertTrue(marketDataSubscriptionManager.isMarketDataOn());
        Assert.assertEquals(tickDriver, marketDataSubscriptionManager.getCurrentDriver());

        Mockito.verify(marketDataSystemProperty, Mockito.times(1)).isGmdSubscribeMarketData();
        Mockito.verify(marketDataTickDriverSubscriber, Mockito.times(1)).subscribe(tickDriver, new SecurityMarketData("IBM", "IBM.M"));


        marketDataSubscriptionManager.getSubscriptionMap().clear();
        marketDataSubscriptionManager.getWaitingList().clear();
    }

    @Test
    public void subscribeThrowsException() throws Exception {

        loginForMarketData();

        TickDriver tickDriver = new GMDTickDriver();
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        marketDataSubscriptionManager.setMarketDataOn(true);
        marketDataSubscriptionManager.setCurrentDriver(tickDriver);
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");

        PowerMockito.doThrow(new RuntimeException()).when(marketDataTickDriverSubscriber, "subscribe", tickDriver, ibmSecurityMarketData);

        marketDataSubscriptionManager.subscribe("IBM", "IBM.M");


        Mockito.verify(marketDataSystemProperty, Mockito.times(1)).isGmdSubscribeMarketData();
        Mockito.verify(marketDataTickDriverSubscriber, Mockito.times(1)).subscribe(tickDriver, ibmSecurityMarketData);

        marketDataSubscriptionManager.getSubscriptionMap().clear();
        marketDataSubscriptionManager.getWaitingList().clear();
    }

    @Test
    public void subscriptionAddedToWaitingList() {

        loginForMarketData();

        TickDriver tickDriver = new GMDTickDriver();
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        marketDataSubscriptionManager.setMarketDataOn(true);
        marketDataSubscriptionManager.setCurrentDriver(null);

        marketDataSubscriptionManager.subscribe("IBM", "IBM.M");

        Assert.assertTrue(marketDataSubscriptionManager.getSubscriptionMap().containsKey("IBM"));
        Assert.assertTrue(marketDataSubscriptionManager.getWaitingList().contains(new SecurityMarketData("IBM", "IBM.M")));

        Mockito.verify(marketDataSystemProperty, Mockito.times(1)).isGmdSubscribeMarketData();
        Mockito.verify(marketDataTickDriverSubscriber, Mockito.never()).subscribe(tickDriver, new SecurityMarketData("IBM", "IBM.M"));

        marketDataSubscriptionManager.getSubscriptionMap().clear();
        marketDataSubscriptionManager.getWaitingList().clear();
    }

    @Test
    public void subscribeWithMarketDataTurnedOff() {

        loginForMarketData();

        TickDriver tickDriver = new GMDTickDriver();
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        marketDataSubscriptionManager.setMarketDataOn(false);
        marketDataSubscriptionManager.setCurrentDriver(tickDriver);

        marketDataSubscriptionManager.subscribe("IBM", "IBM.M");

        Assert.assertTrue(marketDataSubscriptionManager.getSubscriptionMap().containsKey("IBM"));
        Assert.assertTrue(marketDataSubscriptionManager.getWaitingList().contains(new SecurityMarketData("IBM", "IBM.M")));

        Mockito.verify(marketDataSystemProperty, Mockito.times(1)).isGmdSubscribeMarketData();
        Mockito.verify(marketDataTickDriverSubscriber, Mockito.never()).subscribe(tickDriver, new SecurityMarketData("IBM", "IBM.M"));

        marketDataSubscriptionManager.getSubscriptionMap().clear();
        marketDataSubscriptionManager.getWaitingList().clear();
    }

    private void loginForMarketData() {
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataTickDriverManager())
                .thenReturn(marketDataTickDriverManager);

        final boolean login = marketDataSubscriptionManager.login(new GMDTickDriver());
        Assert.assertTrue(login);
    }

    @Test
    public void unsubscribe() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");

        loginForMarketData();

        TickDriver tickDriver = new GMDTickDriver();
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        marketDataSubscriptionManager.setMarketDataOn(true);
        marketDataSubscriptionManager.setCurrentDriver(tickDriver);

        marketDataSubscriptionManager.subscribe("IBM", "IBM.M");

        Assert.assertTrue(marketDataSubscriptionManager.getSubscriptionMap().containsKey("IBM"));

        Mockito.verify(marketDataSystemProperty, Mockito.times(1)).isGmdSubscribeMarketData();

        Mockito.verify(marketDataTickDriverSubscriber, Mockito.times(1)).subscribe(tickDriver, ibmSecurityMarketData);

        marketDataSubscriptionManager.unsubscribe("IBM");

        Mockito.verify(marketDataTickDriverSubscriber, Mockito.times(1)).unSubscribe(tickDriver, ibmSecurityMarketData);

        Assert.assertTrue(marketDataSubscriptionManager.getSubscriptionMap().isEmpty());

    }

    @Test
    public void unsubscribeWithMarketDataTurnedOff() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");

        loginForMarketData();

        TickDriver tickDriver = new GMDTickDriver();
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        marketDataSubscriptionManager.setMarketDataOn(true);
        marketDataSubscriptionManager.setCurrentDriver(tickDriver);

        marketDataSubscriptionManager.subscribe("IBM", "IBM.M");

        Assert.assertTrue(marketDataSubscriptionManager.getSubscriptionMap().containsKey("IBM"));

        Mockito.verify(marketDataSystemProperty, Mockito.times(1)).isGmdSubscribeMarketData();

        Mockito.verify(marketDataTickDriverSubscriber, Mockito.times(1)).subscribe(tickDriver, ibmSecurityMarketData);

        marketDataSubscriptionManager.setMarketDataOn(false);

        marketDataSubscriptionManager.unsubscribe("IBM");

        Mockito.verify(marketDataTickDriverSubscriber, Mockito.never()).unSubscribe(tickDriver, ibmSecurityMarketData);

        Assert.assertTrue(marketDataSubscriptionManager.getSubscriptionMap().containsKey("IBM"));

    }

    @Test
    public void unsubscribeThrowsException() throws Exception {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");

        loginForMarketData();

        TickDriver tickDriver = new GMDTickDriver();
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        marketDataSubscriptionManager.setMarketDataOn(true);
        marketDataSubscriptionManager.setCurrentDriver(tickDriver);

        marketDataSubscriptionManager.subscribe("IBM", "IBM.M");

        Assert.assertTrue(marketDataSubscriptionManager.getSubscriptionMap().containsKey("IBM"));

        Mockito.verify(marketDataSystemProperty, Mockito.times(1)).isGmdSubscribeMarketData();

        Mockito.verify(marketDataTickDriverSubscriber, Mockito.times(1)).subscribe(tickDriver, ibmSecurityMarketData);

        PowerMockito.doThrow(new RuntimeException()).when(marketDataTickDriverSubscriber, "unSubscribe", tickDriver, ibmSecurityMarketData);

        marketDataSubscriptionManager.unsubscribe("IBM");

        Mockito.verify(marketDataTickDriverSubscriber, Mockito.times(1)).unSubscribe(tickDriver, ibmSecurityMarketData);

        Assert.assertTrue(marketDataSubscriptionManager.getSubscriptionMap().containsKey("IBM"));
    }

    @Test
    public void logout() {
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataTickDriverManager())
                .thenReturn(marketDataTickDriverManager);
        final boolean logout = marketDataSubscriptionManager.logout();
        Assert.assertTrue(logout);

    }

    @Test
    public void drainQueue() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        marketDataSubscriptionManager.getWaitingList().add(ibmSecurityMarketData);
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSubscriptionQueueDrainer()).thenReturn(Mockito.mock(MarketDataSubscriptionQueueDrainer.class));

        marketDataSubscriptionManager.drainQueue();

    }

    @Test
    public void drainQueueWithEmptyList() {
        marketDataSubscriptionManager.getWaitingList().clear();
        marketDataSubscriptionManager.drainQueue();
    }

    @Test
    public void getRetryCount() {
        Assert.assertEquals(retryCount, marketDataSubscriptionManager.getRetryCount());
    }

    @Test
    public void getRetryCounter() {
        marketDataSubscriptionManager.incRetryCounter();
        Assert.assertNotEquals(1, marketDataSubscriptionManager.getRetryCount());
    }

    @Test
    public void globalStale() {
        marketDataSubscriptionManager.setGlobalStale(true);
        Assert.assertTrue(marketDataSubscriptionManager.isGlobalStale());
        marketDataSubscriptionManager.setGlobalStale(false);
        Assert.assertFalse(marketDataSubscriptionManager.isGlobalStale());
    }

    @Test
    public void symbolSet() {
        marketDataSubscriptionManager.emptySymbolSet();
        Assert.assertEquals(0, marketDataSubscriptionManager.getSymbolSetCount());
    }

    @Test
    public void getMarketDataTickDriverSubscriber() {
        login();
        Assert.assertEquals(marketDataTickDriverSubscriber, marketDataSubscriptionManager.getMarketDataTickDriverSubscriber());
    }

}