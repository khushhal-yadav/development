package com.citi.icg.cioidark.md.component.driver;

import com.citi.gmd.client.GMDContext;
import com.citi.gmd.client.callbacks.GMDEventListener;
import com.citi.gmd.client.config.GMDServerConfig;
import com.citi.gmd.client.messages.component.GMDConnectionEvent;
import com.citi.gmd.client.messages.component.GMDSubscription;
import com.citi.gmd.client.messages.constants.GMDAPIResponseCode;
import com.citi.gmd.client.sessions.GMDAbstractCallback;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.SecurityMarketData;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.MarketDataSource;
import com.citi.icg.cioidark.md.MarketDataSystemProperty;
import com.citi.icg.cioidark.md.component.exception.GMDInitializationException;
import com.citi.icg.cioidark.md.component.handler.GMDCallbackHandler;
import com.citi.icg.cioidark.md.component.manager.MarketDataSubscriptionManager;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MarketDataSubscriptionManager.class, MarketDataApplicationContextProvider.class, GMDContext.class})
public class GMDTickDriverTest {

    @Mock
    private MarketDataSystemProperty marketDataSystemProperty;
    @Mock
    private GMDContext gmdContext;
    @Mock
    private GMDCallbackHandler gmdCallbackHandler;

    private final String config = "gmd.config.path";
    private final short feedId = 2;

    private TickDriver gmdTickDriver;

    @Before
    public void initialize() {
        PowerMockito.mockStatic(MarketDataSubscriptionManager.class);
        PowerMockito.mockStatic(MarketDataApplicationContextProvider.class);
        PowerMockito.mockStatic(GMDContext.class);

        PowerMockito.when(marketDataSystemProperty.getGmdMarketDataFeedId()).thenReturn(feedId);
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSystemProperty())
                .thenReturn(marketDataSystemProperty);
        PowerMockito.when(GMDContext.getInstance()).thenReturn(gmdContext);

        gmdTickDriver = new GMDTickDriver();
    }

    @Test
    public void init() {
        PowerMockito.when(marketDataSystemProperty.getGmdConfigLocation()).thenReturn(config);
        PowerMockito.when(gmdContext.init(config)).thenReturn(GMDAPIResponseCode.SUCCESS);

        gmdTickDriver.init();

        Mockito.verify(gmdContext, Mockito.times(1)).registerEventListener(ArgumentMatchers.any(GMDEventListener.class));
    }

    @Test(expected = GMDInitializationException.class)
    public void initFailure() {
        PowerMockito.when(marketDataSystemProperty.getGmdConfigLocation()).thenReturn(config);
        PowerMockito.when(gmdContext.init(config)).thenReturn(GMDAPIResponseCode.ERROR_BAD_MESSAGE);

        gmdTickDriver.init();

        Mockito.verify(gmdContext, Mockito.never()).registerEventListener(ArgumentMatchers.any(GMDEventListener.class));
    }

    @Test(expected = GMDInitializationException.class)
    public void handleRegisterEvent() {
        final GMDServerConfig session = Mockito.mock(GMDServerConfig.class);
        gmdTickDriver.handleRegisterEvent(GMDConnectionEvent.LOGIN_SUCCESS, session);
        Assert.assertTrue(gmdTickDriver.getConnected());
        gmdTickDriver.handleRegisterEvent(GMDConnectionEvent.LOGGEDOFF, session);
        Assert.assertFalse(gmdTickDriver.getConnected());
        gmdTickDriver.handleRegisterEvent(GMDConnectionEvent.LOGIN_SUCCESS, session);
        Assert.assertTrue(gmdTickDriver.getConnected());
        gmdTickDriver.handleRegisterEvent(GMDConnectionEvent.DISCONNECTED, session);
        Assert.assertFalse(gmdTickDriver.getConnected());
        gmdTickDriver.handleRegisterEvent(GMDConnectionEvent.LOGIN_SUCCESS, session);
        Assert.assertTrue(gmdTickDriver.getConnected());
        gmdTickDriver.handleRegisterEvent(GMDConnectionEvent.CONNECT_FAILED, session);
        Assert.assertFalse(gmdTickDriver.getConnected());
        gmdTickDriver.handleRegisterEvent(GMDConnectionEvent.LOGIN_SUCCESS, session);
        Assert.assertTrue(gmdTickDriver.getConnected());
        gmdTickDriver.handleRegisterEvent(GMDConnectionEvent.LOGIN_FAILED, session);
        Assert.assertFalse(gmdTickDriver.getConnected());
    }

    @Test
    public void login() {
        PowerMockito.when(MarketDataApplicationContextProvider.getGmdCallbackHandler()).thenReturn(gmdCallbackHandler);
        final boolean login = gmdTickDriver.login();
        Assert.assertTrue(login);
        Assert.assertTrue(gmdTickDriver.getConnected());

        Mockito.verify(gmdContext, Mockito.times(1)).registerCallback(ArgumentMatchers.any(GMDAbstractCallback.class));
        Mockito.verify(gmdContext, Mockito.times(1)).connectAllSessions();
    }

    @Test
    public void logout() {
        PowerMockito.when(MarketDataApplicationContextProvider.getGmdCallbackHandler()).thenReturn(gmdCallbackHandler);
        gmdTickDriver.login();
        final boolean logout = gmdTickDriver.logout();
        Assert.assertTrue(logout);

        Mockito.verify(gmdContext, Mockito.times(1)).registerCallback(ArgumentMatchers.any(GMDAbstractCallback.class));
        Mockito.verify(gmdContext, Mockito.times(1)).connectAllSessions();
        Mockito.verify(gmdContext, Mockito.times(1)).shutDownAllSessions();

    }

    @Test
    public void subscribe() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        PowerMockito.when(gmdContext.subscribe(ArgumentMatchers.any(GMDSubscription.class))).thenReturn(GMDAPIResponseCode.SUCCESS);

        final boolean subscribe = gmdTickDriver.subscribe(ibmSecurityMarketData);
        Assert.assertTrue(subscribe);
        Assert.assertNotNull(gmdTickDriver.getBookSymbol(ibmSecurityMarketData.getMarketDataSymbol()));

        Mockito.verify(gmdContext, Mockito.times(1)).subscribe(ArgumentMatchers.any(GMDSubscription.class));

        gmdTickDriver.removeBookSymbol(ibmSecurityMarketData);
    }

    @Test
    public void subscribeFail() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        PowerMockito.when(gmdContext.subscribe(ArgumentMatchers.any(GMDSubscription.class))).thenReturn(GMDAPIResponseCode.ERROR_BAD_MESSAGE);

        final boolean subscribe = gmdTickDriver.subscribe(ibmSecurityMarketData);
        Assert.assertFalse(subscribe);
        Assert.assertNull(gmdTickDriver.getBookSymbol(ibmSecurityMarketData.getMarketDataSymbol()));

        Mockito.verify(gmdContext, Mockito.times(1)).subscribe(ArgumentMatchers.any(GMDSubscription.class));
    }

    @Test
    public void subscribeForAlreadySubscribedSymbol() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        PowerMockito.when(gmdContext.subscribe(ArgumentMatchers.any(GMDSubscription.class))).thenReturn(GMDAPIResponseCode.SUCCESS);

        boolean subscribe = gmdTickDriver.subscribe(ibmSecurityMarketData);
        Assert.assertTrue(subscribe);
        Assert.assertNotNull(gmdTickDriver.getBookSymbol(ibmSecurityMarketData.getMarketDataSymbol()));

        subscribe = gmdTickDriver.subscribe(ibmSecurityMarketData);
        Assert.assertTrue(subscribe);
        Assert.assertNotNull(gmdTickDriver.getBookSymbol(ibmSecurityMarketData.getMarketDataSymbol()));

        Mockito.verify(gmdContext, Mockito.times(1)).subscribe(ArgumentMatchers.any(GMDSubscription.class));

        gmdTickDriver.removeBookSymbol(ibmSecurityMarketData);

    }

    @Test
    public void unsubscribe() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        PowerMockito.when(gmdContext.subscribe(ArgumentMatchers.any(GMDSubscription.class))).thenReturn(GMDAPIResponseCode.SUCCESS);

        final boolean subscribe = gmdTickDriver.subscribe(ibmSecurityMarketData);
        Assert.assertTrue(subscribe);
        Assert.assertEquals(gmdTickDriver.getBookSymbol(ibmSecurityMarketData.getMarketDataSymbol()), ibmSecurityMarketData.getTicker());

        Mockito.verify(gmdContext, Mockito.times(1)).subscribe(ArgumentMatchers.any(GMDSubscription.class));

        PowerMockito.when(gmdContext.unsubscribe(ArgumentMatchers.any(GMDSubscription.class))).thenReturn(GMDAPIResponseCode.SUCCESS);

        final boolean unsubscribe = gmdTickDriver.unSubscribe(ibmSecurityMarketData);
        Assert.assertTrue(unsubscribe);
        Assert.assertNull(gmdTickDriver.getBookSymbol(ibmSecurityMarketData.getMarketDataSymbol()));

        Mockito.verify(gmdContext, Mockito.times(1)).unsubscribe(ArgumentMatchers.any(GMDSubscription.class));
    }

    @Test
    public void unsubscribeFail() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");

        PowerMockito.when(gmdContext.subscribe(ArgumentMatchers.any(GMDSubscription.class))).thenReturn(GMDAPIResponseCode.SUCCESS);

        final boolean subscribe = gmdTickDriver.subscribe(ibmSecurityMarketData);
        Assert.assertTrue(subscribe);
        Assert.assertEquals(gmdTickDriver.getBookSymbol(ibmSecurityMarketData.getMarketDataSymbol()), ibmSecurityMarketData.getTicker());

        Mockito.verify(gmdContext, Mockito.times(1)).subscribe(ArgumentMatchers.any(GMDSubscription.class));

        PowerMockito.when(gmdContext.unsubscribe(ArgumentMatchers.any(GMDSubscription.class))).thenReturn(GMDAPIResponseCode.ERROR_BAD_MESSAGE);

        final boolean unsubscribe = gmdTickDriver.unSubscribe(ibmSecurityMarketData);
        Assert.assertFalse(unsubscribe);
        Assert.assertEquals(gmdTickDriver.getBookSymbol(ibmSecurityMarketData.getMarketDataSymbol()), ibmSecurityMarketData.getTicker());

        Mockito.verify(gmdContext, Mockito.times(1)).unsubscribe(ArgumentMatchers.any(GMDSubscription.class));
    }

    @Test
    public void unsubscribeForAlreadyUnsubscribedSymbol() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");

        PowerMockito.when(gmdContext.subscribe(ArgumentMatchers.any(GMDSubscription.class))).thenReturn(GMDAPIResponseCode.SUCCESS);

        final boolean subscribe = gmdTickDriver.subscribe(ibmSecurityMarketData);
        Assert.assertTrue(subscribe);
        Assert.assertEquals(gmdTickDriver.getBookSymbol(ibmSecurityMarketData.getMarketDataSymbol()), ibmSecurityMarketData.getTicker());

        PowerMockito.when(gmdContext.unsubscribe(ArgumentMatchers.any(GMDSubscription.class))).thenReturn(GMDAPIResponseCode.SUCCESS);

        boolean unsubscribe = gmdTickDriver.unSubscribe(ibmSecurityMarketData);
        Assert.assertTrue(unsubscribe);
        Assert.assertNull(gmdTickDriver.getBookSymbol(ibmSecurityMarketData.getMarketDataSymbol()));

        unsubscribe = gmdTickDriver.unSubscribe(ibmSecurityMarketData);
        Assert.assertTrue(unsubscribe);
        Assert.assertNull(gmdTickDriver.getBookSymbol(ibmSecurityMarketData.getMarketDataSymbol()));

        Mockito.verify(gmdContext, Mockito.times(1)).unsubscribe(ArgumentMatchers.any(GMDSubscription.class));
    }

    @Test
    public void getMarketDataSource() {
        Assert.assertEquals(MarketDataSource.GMD, gmdTickDriver.getMarketDataSource());
    }

    @Test
    public void putAndRemoveSymbol() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        gmdTickDriver.putBookSymbol(ibmSecurityMarketData);
        Assertions.assertEquals("IBM", gmdTickDriver.getBookSymbol("IBM.M"));
        gmdTickDriver.removeBookSymbol(ibmSecurityMarketData);
        Assert.assertNull(gmdTickDriver.getBookSymbol("IBM.M"));
    }

}