package com.citi.icg.cioidark.md.component.manager;

import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.MarketDataSystemProperty;
import com.citi.icg.cioidark.md.component.driver.TickDriver;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MarketDataSubscriptionManager.class, MarketDataApplicationContextProvider.class})
public class MarketDataTickDriverManagerTest {

    @Mock
    private TickDriver tickDriver;
    @Mock
    private MarketDataSystemProperty marketDataSystemProperty;
    @Mock
    private MarketDataSubscriptionManager marketDataSubscriptionManager;

    private final int gmdMarketDataRetry = 3;

    private MarketDataTickDriverManager marketDataTickDriverManager;

    @Before
    public void init() {
        PowerMockito.mockStatic(MarketDataApplicationContextProvider.class);
        PowerMockito.when(marketDataSystemProperty.getGmdMarketDataRetry()).thenReturn(gmdMarketDataRetry);
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSystemProperty())
                .thenReturn(marketDataSystemProperty);
        PowerMockito.when(marketDataSubscriptionManager.getRetryCount()).thenReturn(gmdMarketDataRetry);
        marketDataTickDriverManager = new MarketDataTickDriverManager();
    }

    @Test
    public void runWithNoTickDriver() {
        marketDataTickDriverManager.setTickListener(null);
        marketDataTickDriverManager.run();
    }

    @Test
    public void runThrowsException() {
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSubscriptionManager())
                .thenReturn(marketDataSubscriptionManager);
        marketDataTickDriverManager.setTickListener(tickDriver);
        PowerMockito.when(tickDriver.login()).thenReturn(true);
        PowerMockito.when(tickDriver.getConnected()).thenThrow(new RuntimeException());
        PowerMockito.when(marketDataSubscriptionManager.getRetryCounter()).thenReturn(1);
        PowerMockito.when(marketDataSystemProperty.getGmdMarketDataRetry()).thenReturn(gmdMarketDataRetry);


        marketDataTickDriverManager.run();

        Mockito.verify(tickDriver, Mockito.times(1)).login();
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).setCurrentDriver(tickDriver);
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).setMarketDataOn(true);
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).drainQueue();
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).setGlobalStale(false);

    }

    @Test
    public void runWithTickLoginSuccess() {
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSubscriptionManager())
                .thenReturn(marketDataSubscriptionManager);
        marketDataTickDriverManager.setTickListener(tickDriver);
        PowerMockito.when(tickDriver.login()).thenReturn(true);
        PowerMockito.when(tickDriver.getConnected()).thenReturn(true);
        PowerMockito.when(marketDataSubscriptionManager.getRetryCounter()).thenReturn(1);
        PowerMockito.when(marketDataSystemProperty.getGmdMarketDataRetry()).thenReturn(gmdMarketDataRetry);


        marketDataTickDriverManager.run();

        Mockito.verify(tickDriver, Mockito.times(1)).login();
        Mockito.verify(marketDataSubscriptionManager, Mockito.times(1)).setCurrentDriver(tickDriver);
        Mockito.verify(marketDataSubscriptionManager, Mockito.times(1)).setMarketDataOn(true);
        Mockito.verify(marketDataSubscriptionManager, Mockito.times(1)).drainQueue();
        Mockito.verify(marketDataSubscriptionManager, Mockito.times(1)).setGlobalStale(false);
    }

    @Test
    public void logout() {
        marketDataTickDriverManager.setTickListener(tickDriver);
        PowerMockito.when(tickDriver.logout()).thenReturn(true);

        Assert.assertTrue(marketDataTickDriverManager.logout());
        Mockito.verify(tickDriver, Mockito.times(1)).logout();
    }

    @Test
    public void logoutFail() {
        marketDataTickDriverManager.setTickListener(tickDriver);
        PowerMockito.when(tickDriver.logout()).thenReturn(false);

        Assert.assertFalse(marketDataTickDriverManager.logout());
        Mockito.verify(tickDriver, Mockito.times(1)).logout();
    }

    @Test
    public void logoutWithNoRegisteredTickDriver() {
        marketDataTickDriverManager.setTickListener(null);

        Assert.assertFalse(marketDataTickDriverManager.logout());

        Mockito.verify(tickDriver, Mockito.never()).logout();
    }
}