package com.citi.icg.cioidark.md.gmd;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;
import com.citi.icg.cioidark.chronicle.messaging.queue.GMDOut;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.MarketDataDirector;
import com.citi.icg.cioidark.md.component.handler.MarketDataSubscriptionHandler;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MarketDataDirector.class, MarketDataApplicationContextProvider.class})
public class MarketDataImplTest {

    @Mock
    private GMDOut gmdOut;
    @Mock
    private MarketDataSubscriptionHandler marketDataSubscriptionHandler;
    @Mock
    private MarketDataDirector marketDataDirector;

    private MarketDataImpl marketDataImpl;

    @Before
    public void init() throws Exception {
        PowerMockito.mockStatic(MarketDataDirector.class);
        PowerMockito.mockStatic(MarketDataApplicationContextProvider.class);
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSubscriptionHandler())
                .thenReturn(marketDataSubscriptionHandler);
        PowerMockito.doNothing().when(marketDataDirector, "initialize", gmdOut);
        PowerMockito.when(MarketDataDirector.getInstance()).thenReturn(marketDataDirector);


        marketDataImpl = new MarketDataImpl(gmdOut);
    }

    @Test
    public void subscribeTick() throws Exception {
        final GMDTickSubscriptionMsg gmdTickSubscriptionMsg = new GMDTickSubscriptionMsg("bookSymbol", "marketSymbol", true);
        PowerMockito.doNothing().when(marketDataSubscriptionHandler, "processSubscriptionMessage", gmdTickSubscriptionMsg);

        marketDataImpl.subscribeTick(gmdTickSubscriptionMsg);

        Mockito.verify(marketDataSubscriptionHandler, Mockito.times(1)).processSubscriptionMessage(gmdTickSubscriptionMsg);
    }

}