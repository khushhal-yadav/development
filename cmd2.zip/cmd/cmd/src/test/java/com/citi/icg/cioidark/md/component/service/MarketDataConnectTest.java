package com.citi.icg.cioidark.md.component.service;

import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.MarketDataSystemProperty;
import com.citi.icg.cioidark.md.component.driver.TickDriver;
import com.citi.icg.cioidark.md.component.manager.MarketDataSubscriptionManager;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MarketDataSubscriptionManager.class, MarketDataApplicationContextProvider.class})
public class MarketDataConnectTest {

    @Mock
    private TickDriver tickDriver;
    @Mock
    private MarketDataSystemProperty marketDataSystemProperty;
    @Mock
    private MarketDataSubscriptionManager marketDataSubscriptionManager;

    private MarketDataConnect marketDataConnect;

    @Before
    public void init() throws Exception {
        PowerMockito.mockStatic(MarketDataApplicationContextProvider.class);

        PowerMockito.doNothing().when(tickDriver, "init");
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSystemProperty())
                .thenReturn(marketDataSystemProperty);
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSubscriptionManager())
                .thenReturn(marketDataSubscriptionManager);

        marketDataConnect = new MarketDataConnect(tickDriver);
    }

    @Test
    public void connect() {
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        PowerMockito.when(marketDataSubscriptionManager.login(tickDriver)).thenReturn(true);

        marketDataConnect.connect();

        Mockito.verify(marketDataSubscriptionManager, Mockito.times(1)).login(tickDriver);
    }

    @Test
    public void connectWithLoginFail() {
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        PowerMockito.when(marketDataSubscriptionManager.login(tickDriver)).thenReturn(false);

        marketDataConnect.connect();

        Mockito.verify(marketDataSubscriptionManager, Mockito.times(1)).login(tickDriver);
    }

    @Test
    public void connectWithGmdSubscriptionOff() {
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(false);
        marketDataConnect.connect();

        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).login(tickDriver);
    }

    @Test
    public void connectWithExceptionFlow() {
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenThrow(new RuntimeException());
        marketDataConnect.connect();

        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).login(tickDriver);
    }
}