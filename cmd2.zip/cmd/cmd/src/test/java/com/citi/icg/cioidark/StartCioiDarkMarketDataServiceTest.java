package com.citi.icg.cioidark;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 * Junit 5 test for simple StartCioiDarkMarketDataService - A step towards Junit 5 :)
 */
class StartCioiDarkMarketDataServiceTest
{
    @Test
    void testApp()
    {
        Assertions.assertEquals(2, 1+1);
    }
}
