package com.citi.icg.cioidark.md;

import com.citi.icg.cioidark.chronicle.messaging.message.admin.AbstractSystemProperty;
import com.citi.icg.cioidark.chronicle.messaging.queue.GMDOut;
import org.apache.commons.configuration.ConfigurationException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AbstractSystemProperty.class})
public class MarketDataApplicationContextProviderWithMockTest {

    private final GMDOut gmdOut = marketDataMessage -> {
    };

    @Test(expected = ConfigurationException.class)
    public void getMarketDataSystemPropertyThrowsException() throws Exception {
        PowerMockito.mockStatic(AbstractSystemProperty.class);
        PowerMockito.doReturn(null).when(AbstractSystemProperty.class, "getPropertyFiles");
        MarketDataApplicationContextProvider.initialize(gmdOut);
    }

    @Test
    public void getMarketDataSystemPropertyBeforeInitialization() {
        Assert.assertNull(MarketDataApplicationContextProvider.getMarketDataSystemProperty());
    }

}