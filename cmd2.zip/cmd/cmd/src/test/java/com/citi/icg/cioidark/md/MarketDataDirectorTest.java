package com.citi.icg.cioidark.md;

import com.citi.icg.cioidark.chronicle.messaging.queue.GMDOut;
import com.citi.icg.cioidark.md.component.service.MarketDataConnect;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(MarketDataApplicationContextProvider.class)
public class MarketDataDirectorTest {

    @Test
    public void getInstance() {
        Assert.assertEquals(MarketDataDirector.getInstance(), MarketDataDirector.getInstance());
    }

    @Test
    public void initialize() throws Exception {
        final GMDOut gmdOut = Mockito.mock(GMDOut.class);
        PowerMockito.mockStatic(MarketDataApplicationContextProvider.class);

        PowerMockito.doNothing().when(MarketDataApplicationContextProvider.class, "initialize", gmdOut);

        final MarketDataConnect marketDataConnect = Mockito.mock(MarketDataConnect.class);
        PowerMockito.doReturn(marketDataConnect).when(MarketDataApplicationContextProvider.class, "getMarketDataConnect");

        MarketDataDirector.getInstance().initialize(gmdOut);

        Mockito.verify(marketDataConnect, Mockito.times(1)).connect();
    }
}