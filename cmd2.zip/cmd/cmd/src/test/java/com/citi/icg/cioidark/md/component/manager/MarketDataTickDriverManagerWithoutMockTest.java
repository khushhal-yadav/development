package com.citi.icg.cioidark.md.component.manager;

import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.component.driver.TickDriver;
import org.apache.commons.configuration.ConfigurationException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Without mocking, with actual
 *
 * @see MarketDataSubscriptionManager
 */
@RunWith(PowerMockRunner.class)
public class MarketDataTickDriverManagerWithoutMockTest {

    @Mock
    private TickDriver tickDriver;

    private MarketDataTickDriverManager marketDataTickDriverManager = new MarketDataTickDriverManager();

    @Before
    public void init() throws ConfigurationException {
        MarketDataApplicationContextProvider.initialize(marketDataMessage -> {});
    }

    @Test
    public void runWithTickLoginFail() {

        marketDataTickDriverManager.setTickListener(tickDriver);
        PowerMockito.when(tickDriver.login()).thenReturn(false);

        marketDataTickDriverManager.run();

        Mockito.verify(tickDriver, Mockito.times(3)).login();
    }

}