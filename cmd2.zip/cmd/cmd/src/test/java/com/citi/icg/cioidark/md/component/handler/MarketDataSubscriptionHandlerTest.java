package com.citi.icg.cioidark.md.component.handler;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.component.manager.MarketDataSubscriptionManager;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MarketDataSubscriptionManager.class, MarketDataApplicationContextProvider.class})
public class MarketDataSubscriptionHandlerTest {

    @Mock
    private MarketDataSubscriptionManager marketDataSubscriptionManager;

    private MarketDataSubscriptionHandler marketDataSubscriptionHandler;

    public MarketDataSubscriptionHandlerTest() {}

    @Before
    public void init() {
        PowerMockito.mockStatic(MarketDataSubscriptionManager.class);
        PowerMockito.mockStatic(MarketDataApplicationContextProvider.class);
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSubscriptionManager())
                .thenReturn(marketDataSubscriptionManager);
        this.marketDataSubscriptionHandler = new MarketDataSubscriptionHandler();
    }

    @Test
    public void processSubscriptionMessage() {
        marketDataSubscriptionHandler.processSubscriptionMessage(new GMDTickSubscriptionMsg("TEST_BOOK", "TEST_MD", true));
        marketDataSubscriptionHandler.processSubscriptionMessage(new GMDTickSubscriptionMsg("TEST_BOOK", "TEST_MD", false));
        Mockito.verify(marketDataSubscriptionManager, Mockito.times(1)).subscribe("TEST_BOOK", "TEST_MD");
        Mockito.verify(marketDataSubscriptionManager, Mockito.times(1)).unsubscribe("TEST_BOOK");
    }

    @Test
    public void processSubscriptionMessageWithEmptyMarketDataSymbol() {
        marketDataSubscriptionHandler.processSubscriptionMessage(new GMDTickSubscriptionMsg("TEST_BOOK", "TEST_MD", true));
        marketDataSubscriptionHandler.processSubscriptionMessage(new GMDTickSubscriptionMsg("TEST_BOOK", "", true));
        Mockito.verify(marketDataSubscriptionManager, Mockito.times(1)).subscribe("TEST_BOOK", "TEST_MD");
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).unsubscribe("TEST_BOOK");
    }

    @Test
    public void processSubscriptionMessageWithEmptyBookAndMarketDataSymbolForUnSubscribe() {
        marketDataSubscriptionHandler.processSubscriptionMessage(new GMDTickSubscriptionMsg("", "", false));
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).unsubscribe("");
    }

    @Test
    public void processSubscriptionMessageWithEmptyBookAndMarketDataSymbolForSubscribe() {
        marketDataSubscriptionHandler.processSubscriptionMessage(new GMDTickSubscriptionMsg("", "", true));
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).subscribe("", "");
    }

    @Test
    public void processSubscriptionMessageWithEmptyBookAndNonEmptyMarketDataSymbolForSubscribe() {
        marketDataSubscriptionHandler.processSubscriptionMessage(new GMDTickSubscriptionMsg("", "TEST.MD", true));
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).subscribe("", "TEST.MD");
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).unsubscribe("");
    }


    @Test
    public void processSubscriptionMessageWithEmptyBookAndNonEmptyMarketDataSymbolForUnSubscribe() {
        marketDataSubscriptionHandler.processSubscriptionMessage(new GMDTickSubscriptionMsg("", "TEST.MD", false));
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).subscribe("", "TEST.MD");
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).unsubscribe("");
    }

    @Test
    public void processSubscriptionMessageWithNonEmptyBookAndNonEmptyMarketDataSymbolForSubscribe() {
        marketDataSubscriptionHandler.processSubscriptionMessage(new GMDTickSubscriptionMsg("TEST.MD", "", true));
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).subscribe("TEST.MD", "");
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).unsubscribe("TEST.MD");
    }


    @Test
    public void processSubscriptionMessageWithNonEmptyBookAndNonEmptyMarketDataSymbolForUnSubscribe() {
        marketDataSubscriptionHandler.processSubscriptionMessage(new GMDTickSubscriptionMsg("TEST.MD", "", false));
        Mockito.verify(marketDataSubscriptionManager, Mockito.never()).subscribe("TEST.MD", "");
        Mockito.verify(marketDataSubscriptionManager, Mockito.times(1)).unsubscribe("TEST.MD");
    }
}