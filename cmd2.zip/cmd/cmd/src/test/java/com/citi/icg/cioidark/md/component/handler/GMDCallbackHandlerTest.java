package com.citi.icg.cioidark.md.component.handler;


import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import com.citi.gmd.client.book.GMDAbstractBook;
import com.citi.gmd.client.messages.admin.GMDAdminRespMsg;
import com.citi.gmd.client.messages.component.GMDBasketQuoteMsg;
import com.citi.gmd.client.messages.component.GMDCacheClearMsg;
import com.citi.gmd.client.messages.component.GMDClosingTradeSummaryMsg;
import com.citi.gmd.client.messages.component.GMDEnhancedQuoteMsg;
import com.citi.gmd.client.messages.component.GMDFeedCfgInfoMsg;
import com.citi.gmd.client.messages.component.GMDFeedStatusMsg;
import com.citi.gmd.client.messages.component.GMDImbalanceMsg;
import com.citi.gmd.client.messages.component.GMDInstrumentStatusMsg;
import com.citi.gmd.client.messages.component.GMDLULDBandMsg;
import com.citi.gmd.client.messages.component.GMDLogOffRespMsg;
import com.citi.gmd.client.messages.component.GMDLogOnRejMsg;
import com.citi.gmd.client.messages.component.GMDLogOnRespMsg;
import com.citi.gmd.client.messages.component.GMDMktStatusMsg;
import com.citi.gmd.client.messages.component.GMDMsgHdr;
import com.citi.gmd.client.messages.component.GMDPassThruMsg;
import com.citi.gmd.client.messages.component.GMDPeggedOrderMsg;
import com.citi.gmd.client.messages.component.GMDPriceLevel;
import com.citi.gmd.client.messages.component.GMDQuoteMsg;
import com.citi.gmd.client.messages.component.GMDSnpshotCompleteNotification;
import com.citi.gmd.client.messages.component.GMDStaticInfoMsg;
import com.citi.gmd.client.messages.component.GMDSubRespMsg;
import com.citi.gmd.client.messages.component.GMDTradeMsg;
import com.citi.gmd.client.messages.component.GMDTradeMsgDetailed;
import com.citi.gmd.client.messages.component.GMDUnSubRespMsg;
import com.citi.gmd.client.messages.constants.GMDUpdateType;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.SecurityMarketData;
import com.citi.icg.cioidark.chronicle.messaging.queue.GMDOut;
import com.citi.icg.cioidark.enumeration.MarketDataStatus;
import com.citi.icg.cioidark.enumeration.ShortSaleRestriction;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.MarketDataSystemProperty;
import com.citi.icg.cioidark.md.component.driver.GMDTickDriver;
import com.citi.icg.cioidark.md.component.manager.MarketDataSubscriptionManager;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MarketDataSubscriptionManager.class, MarketDataApplicationContextProvider.class})
public class GMDCallbackHandlerTest {

    @Mock
    private GMDTickDriver gmdTickDriver;
    @Mock
    private MarketDataSubscriptionManager marketDataSubscriptionManager;
    @Mock
    private MarketDataSystemProperty marketDataSystemProperty;
    @Mock
    private GMDOut gmdOut;

    private final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");

    private GMDCallbackHandler gmdCallbackHandler;

    public GMDCallbackHandlerTest() {
    }

    @Before
    public void init() {

        PowerMockito.mockStatic(MarketDataSubscriptionManager.class);
        PowerMockito.mockStatic(MarketDataApplicationContextProvider.class);

        final HashMap<String, SecurityMarketData> subscriptionMap = new HashMap<>();
        subscriptionMap.put("IBM", ibmSecurityMarketData);
        PowerMockito.when(marketDataSubscriptionManager.getSubscriptionMap()).thenReturn(subscriptionMap);

        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSubscriptionManager())
                .thenReturn(marketDataSubscriptionManager);
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSystemProperty())
                .thenReturn(marketDataSystemProperty);

        PowerMockito.when(marketDataSystemProperty.getGmdOut()).thenReturn(gmdOut);

        gmdTickDriver = PowerMockito.mock(GMDTickDriver.class);
        PowerMockito.when(marketDataSubscriptionManager.getCurrentDriver()).thenReturn(gmdTickDriver);
        PowerMockito.spy(gmdTickDriver);
        PowerMockito.when(gmdTickDriver.getBookSymbol("IBM")).thenReturn("IBM");

        gmdCallbackHandler = new GMDCallbackHandler();
    }

    @Test
    public void handleQuoteMsg() {
        GMDQuoteMsg quoteMsg = new GMDQuoteMsg(2);
        quoteMsg.setSymbol("IBM");
        quoteMsg.setMsgHdr(new GMDMsgHdr());
        long timestamp = System.currentTimeMillis();
        quoteMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        GMDPriceLevel priceLevel = new GMDPriceLevel();
        priceLevel.setPrice((long) 1235000000);
        priceLevel.setSize(1234);
        priceLevel.setSide('S');
        quoteMsg.setQuoteAtIdx(0, priceLevel);

        GMDPriceLevel priceLevel2 = new GMDPriceLevel();
        priceLevel2.setPrice((long) 1235100000);
        priceLevel2.setSize(1234);
        priceLevel2.setSide('B');
        quoteMsg.setQuoteAtIdx(1, priceLevel2);

        gmdCallbackHandler.handleQuoteMsg(quoteMsg);

        final MarketDataMessage marketData = new MarketDataMessage(123.51, 123.5,
                1234, 1234, timestamp, "IBM");
        marketData.setStatusEvent(false);
        marketData.setSecurityMarketData(ibmSecurityMarketData);
        Mockito.verify(gmdOut, Mockito.times(1))
                .marketData(marketData);

    }

    @Test
    public void getMarketDataMEssageForGMDQuoteMsgSell() {

        GMDQuoteMsg quoteMsg = new GMDQuoteMsg(1);
        quoteMsg.setSymbol("IBM");
        quoteMsg.setMsgHdr(new GMDMsgHdr());
        long timestamp = System.currentTimeMillis();
        quoteMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        GMDPriceLevel priceLevel = new GMDPriceLevel();
        priceLevel.setPrice((long) 1235000000);
        priceLevel.setSize(1234);
        priceLevel.setSide('S');
        quoteMsg.setQuoteAtIdx(0, priceLevel);

        final MarketDataMessage gmdQuoteMsg = gmdCallbackHandler.getMarketData(quoteMsg);

        final MarketDataMessage marketData = new MarketDataMessage(0.0, 123.5,
                0.0, 1234.0, timestamp, "IBM");

        marketData.setStatusEvent(false);
        marketData.setSecurityMarketData(ibmSecurityMarketData);


        Assertions.assertEquals(marketData, gmdQuoteMsg);

    }

    @Test
    public void getGMDQuoteMsgForBuy() {

        GMDQuoteMsg quoteMsg = new GMDQuoteMsg(1);
        quoteMsg.setSymbol("IBM");
        quoteMsg.setMsgHdr(new GMDMsgHdr());
        long timestamp = System.currentTimeMillis();
        quoteMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        GMDPriceLevel priceLevel = new GMDPriceLevel();
        priceLevel.setPrice((long) 1235100000);
        priceLevel.setSize(1234);
        priceLevel.setSide('B');
        quoteMsg.setQuoteAtIdx(0, priceLevel);

        final MarketDataMessage gmdQuoteMsg = gmdCallbackHandler.getMarketData(quoteMsg);

        final MarketDataMessage marketData = new MarketDataMessage(123.51, 0.0,
                1234.0, 0.0, timestamp, "IBM");

        marketData.setStatusEvent(false);
        marketData.setSecurityMarketData(ibmSecurityMarketData);

        Assertions.assertEquals(marketData, gmdQuoteMsg);

    }

    @Test
    public void getGMDQuoteMsgForUnknownSide() {

        GMDQuoteMsg quoteMsg = new GMDQuoteMsg(1);
        quoteMsg.setSymbol("IBM");
        quoteMsg.setMsgHdr(new GMDMsgHdr());
        long timestamp = System.currentTimeMillis();
        quoteMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        GMDPriceLevel priceLevel = new GMDPriceLevel();
        priceLevel.setPrice((long) 1235100000);
        priceLevel.setSize(1234);
        priceLevel.setSide('X');
        quoteMsg.setQuoteAtIdx(0, priceLevel);

        final MarketDataMessage gmdQuoteMsg = gmdCallbackHandler.getMarketData(quoteMsg);

        Assertions.assertNull(gmdQuoteMsg);
    }

    @Test
    public void getGMDQuoteMsgForUnknownSideWithNoPrice() {

        GMDQuoteMsg quoteMsg = new GMDQuoteMsg(1);
        quoteMsg.setSymbol("IBM");
        quoteMsg.setMsgHdr(new GMDMsgHdr());
        long timestamp = System.currentTimeMillis();
        quoteMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        GMDPriceLevel priceLevel = new GMDPriceLevel();
        priceLevel.setSide('X');
        quoteMsg.setQuoteAtIdx(0, priceLevel);

        final MarketDataMessage gmdQuoteMsg = gmdCallbackHandler.getMarketData(quoteMsg);

        Assertions.assertNull(gmdQuoteMsg);
    }

    @Test
    public void handleQuoteMsgWithEmptySymbol() {
        GMDQuoteMsg quoteMsg = new GMDQuoteMsg(2);
        quoteMsg.setSymbol("");
        quoteMsg.setMsgHdr(new GMDMsgHdr());
        long timestamp = System.currentTimeMillis();
        quoteMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        GMDPriceLevel priceLevel = new GMDPriceLevel();
        priceLevel.setPrice((long) 1235000000);
        priceLevel.setSize(1234);
        priceLevel.setSide('S');
        quoteMsg.setQuoteAtIdx(0, priceLevel);

        GMDPriceLevel priceLevel2 = new GMDPriceLevel();
        priceLevel2.setPrice((long) 1235100000);
        priceLevel2.setSize(1234);
        priceLevel2.setSide('B');
        quoteMsg.setQuoteAtIdx(1, priceLevel2);

        gmdCallbackHandler.handleQuoteMsg(quoteMsg);

        Mockito.verify(gmdOut, Mockito.never()).marketData(ArgumentMatchers.any(MarketDataMessage.class));

    }

    @Test
    public void handleInstrumentStatusMsg() {

        long timestamp = System.currentTimeMillis();
        GMDInstrumentStatusMsg gmdInstrumentStatusMsg = new GMDInstrumentStatusMsg();
        gmdInstrumentStatusMsg.setMsgHdr(new GMDMsgHdr());
        gmdInstrumentStatusMsg.getMsgHdr().setUpdateTypeAndMoreInd((byte) 0);
        gmdInstrumentStatusMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        gmdInstrumentStatusMsg.setSymbol("IBM");
        gmdInstrumentStatusMsg.setRegulatoryTradingStatus('o');
        gmdInstrumentStatusMsg.setRegShoInd('0');
        gmdCallbackHandler.handleInstrumentStatusMsg(gmdInstrumentStatusMsg);

        final MarketDataMessage marketData = new MarketDataMessage(0.0, 0.0, "IBM", timestamp);
        marketData.setStatusEvent(true);
        marketData.setStatus(MarketDataStatus.OPENED_OR_TRADE_RESUME.value());
        marketData.setShortSaleRestricted(ShortSaleRestriction.SHORT_SALE_RESTRICTION_REMOVED.value());
        marketData.setCrossAttempt(true);
        marketData.setUpdateBook(true);

        Mockito.verify(gmdOut, Mockito.times(1))
                .marketData(marketData);
    }

    @Test
    public void handleInstrumentStatusMsgWithEmptySymbol() {

        long timestamp = System.currentTimeMillis();
        GMDInstrumentStatusMsg gmdInstrumentStatusMsg = new GMDInstrumentStatusMsg();
        gmdInstrumentStatusMsg.setMsgHdr(new GMDMsgHdr());
        gmdInstrumentStatusMsg.getMsgHdr().setUpdateTypeAndMoreInd((byte) 1);
        gmdInstrumentStatusMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        gmdInstrumentStatusMsg.setRegulatoryTradingStatus('A');
        gmdInstrumentStatusMsg.setSymbol("");
        gmdInstrumentStatusMsg.setRegShoInd('B');

        gmdCallbackHandler.handleInstrumentStatusMsg(gmdInstrumentStatusMsg);

        Mockito.verify(gmdOut, Mockito.never()).marketData(ArgumentMatchers.any(MarketDataMessage.class));
    }

    @Test
    public void handleInstrumentStatusMsgWithException() {

        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSubscriptionManager())
                .thenThrow(new RuntimeException());

        long timestamp = System.currentTimeMillis();
        GMDInstrumentStatusMsg gmdInstrumentStatusMsg = new GMDInstrumentStatusMsg();
        gmdInstrumentStatusMsg.setMsgHdr(new GMDMsgHdr());
        gmdInstrumentStatusMsg.getMsgHdr().setUpdateTypeAndMoreInd((byte) 1);
        gmdInstrumentStatusMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        gmdInstrumentStatusMsg.setRegulatoryTradingStatus('A');
        gmdInstrumentStatusMsg.setSymbol("");
        gmdInstrumentStatusMsg.setRegShoInd('B');
        gmdCallbackHandler.handleInstrumentStatusMsg(gmdInstrumentStatusMsg);

        Mockito.verify(gmdOut, Mockito.never()).marketData(ArgumentMatchers.any(MarketDataMessage.class));
    }

    @Test
    public void updateStatusForGMDUpdateTypeSnapshotMoreInd() {

        long timestamp = System.currentTimeMillis();
        GMDInstrumentStatusMsg gmdInstrumentStatusMsg = new GMDInstrumentStatusMsg();
        gmdInstrumentStatusMsg.setMsgHdr(new GMDMsgHdr());
        gmdInstrumentStatusMsg.getMsgHdr().setUpdateTypeAndMoreInd((byte) 1);
        gmdInstrumentStatusMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        gmdInstrumentStatusMsg.setSymbol("IBM");
        gmdInstrumentStatusMsg.setRegulatoryTradingStatus('c');
        gmdInstrumentStatusMsg.setRegShoInd('1');

        gmdCallbackHandler.handleInstrumentStatusMsg(gmdInstrumentStatusMsg);

        final MarketDataMessage marketData = new MarketDataMessage(0.0, 0.0, "IBM", timestamp);
        marketData.setStatusEvent(true);
        marketData.setStatus(MarketDataStatus.CLOSED.value());
        marketData.setShortSaleRestricted(ShortSaleRestriction.SHORT_SALE_RESTRICTION_ACTIVATED.value());
        marketData.setCrossAttempt(true);
        marketData.setUpdateBook(true);

        Mockito.verify(gmdOut, Mockito.times(1))
                .marketData(marketData);

    }

    @Test
    public void updateStatusForGMDUpdateTypeSnapshotLast() {

        long timestamp = System.currentTimeMillis();
        GMDInstrumentStatusMsg gmdInstrumentStatusMsg = new GMDInstrumentStatusMsg();
        gmdInstrumentStatusMsg.setMsgHdr(new GMDMsgHdr());
        gmdInstrumentStatusMsg.getMsgHdr().setUpdateTypeAndMoreInd((byte) 2);
        gmdInstrumentStatusMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        gmdInstrumentStatusMsg.setSymbol("IBM");
        gmdInstrumentStatusMsg.setRegulatoryTradingStatus('f');
        gmdInstrumentStatusMsg.setRegShoInd('2');

        gmdCallbackHandler.handleInstrumentStatusMsg(gmdInstrumentStatusMsg);

        final MarketDataMessage marketData = new MarketDataMessage(0.0, 0.0, "IBM", timestamp);
        marketData.setStatusEvent(true);
        marketData.setStatus(MarketDataStatus.HALTED.value());
        marketData.setShortSaleRestricted(ShortSaleRestriction.SHORT_SALE_RESTRICTION_ACTIVATED.value());
        marketData.setCrossAttempt(false);
        marketData.setUpdateBook(true);

        Mockito.verify(gmdOut, Mockito.times(1))
                .marketData(marketData);
    }

    @Test
    public void updateStatusForInvalidRegulatoryStatus() {

        long timestamp = System.currentTimeMillis();
        GMDInstrumentStatusMsg gmdInstrumentStatusMsg = new GMDInstrumentStatusMsg();
        gmdInstrumentStatusMsg.setMsgHdr(new GMDMsgHdr());
        gmdInstrumentStatusMsg.getMsgHdr().setUpdateTypeAndMoreInd((byte) 2);
        gmdInstrumentStatusMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        gmdInstrumentStatusMsg.setSymbol("IBM");
        gmdInstrumentStatusMsg.setRegulatoryTradingStatus('r');
        gmdInstrumentStatusMsg.setRegShoInd('2');

        gmdCallbackHandler.handleInstrumentStatusMsg(gmdInstrumentStatusMsg);

        final MarketDataMessage marketData = new MarketDataMessage(0.0, 0.0, "IBM", timestamp);
        marketData.setStatusEvent(true);
        marketData.setShortSaleRestricted(ShortSaleRestriction.SHORT_SALE_RESTRICTION_ACTIVATED.value());
        marketData.setStatus(MarketDataStatus.SNAPSHOT_UPDATE.value());
        marketData.setCrossAttempt(false);
        marketData.setUpdateBook(true);

        Mockito.verify(gmdOut, Mockito.times(1))
                .marketData(marketData);
    }

    @Test
    @PrepareForTest({MarketDataSubscriptionManager.class, MarketDataApplicationContextProvider.class, GMDCallbackHandler.class})
    public void updateStatusForValidGMDUpdateType() throws Exception {
        long timestamp = System.currentTimeMillis();
        GMDInstrumentStatusMsg gmdInstrumentStatusMsg = new GMDInstrumentStatusMsg();
        gmdInstrumentStatusMsg.setMsgHdr(new GMDMsgHdr());
        gmdInstrumentStatusMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        gmdInstrumentStatusMsg.getMsgHdr().setUpdateTypeAndMoreInd((byte) 0);
        gmdInstrumentStatusMsg.setSymbol("IBM");
        gmdInstrumentStatusMsg.setRegulatoryTradingStatus('q');
        gmdInstrumentStatusMsg.setRegShoInd('3');

        PowerMockito.mockStatic(GMDCallbackHandler.class);
        PowerMockito.doReturn(Collections.singletonList(GMDUpdateType.UPDATE))
                .when(GMDCallbackHandler.class, "getGmdUpdateTypes");

        gmdCallbackHandler.handleInstrumentStatusMsg(gmdInstrumentStatusMsg);

        final MarketDataMessage marketData = new MarketDataMessage(0.0, 0.0, "IBM", timestamp);
        marketData.setStatusEvent(true);
        marketData.setStatus(MarketDataStatus.QUOTEONLY.value());
        marketData.setCrossAttempt(false);
        marketData.setUpdateBook(true);

        Mockito.verify(gmdOut, Mockito.times(1))
                .marketData(marketData);

    }

    @Test
    @PrepareForTest({MarketDataSubscriptionManager.class, MarketDataApplicationContextProvider.class, GMDCallbackHandler.class})
    public void updateStatusForNotValidGMDUpdateType() throws Exception {
        long timestamp = System.currentTimeMillis();
        GMDInstrumentStatusMsg gmdInstrumentStatusMsg = new GMDInstrumentStatusMsg();
        gmdInstrumentStatusMsg.setMsgHdr(new GMDMsgHdr());
        gmdInstrumentStatusMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        gmdInstrumentStatusMsg.getMsgHdr().setUpdateTypeAndMoreInd((byte) 2);
        gmdInstrumentStatusMsg.setSymbol("IBM");
        gmdInstrumentStatusMsg.setRegulatoryTradingStatus('r');
        gmdInstrumentStatusMsg.setRegShoInd('3');

        PowerMockito.mockStatic(GMDCallbackHandler.class);
        PowerMockito.doReturn(Collections.singletonList(GMDUpdateType.UPDATE))
                .when(GMDCallbackHandler.class, "getGmdUpdateTypes");

        gmdCallbackHandler.handleInstrumentStatusMsg(gmdInstrumentStatusMsg);

        Mockito.verify(gmdOut, Mockito.never()).marketData(ArgumentMatchers.any(MarketDataMessage.class));

    }

    @Test
    public void handleLULDBandMsg() {

        long timestamp = System.currentTimeMillis();

        GMDLULDBandMsg gmdluldBandMsg = new GMDLULDBandMsg();
        gmdluldBandMsg.setSymbol("IBM");
        gmdluldBandMsg.setUpperLimitPrice(1250000000);
        gmdluldBandMsg.setLowerLimitPrice(1200000000);
        gmdluldBandMsg.setPriceBandEffectiveTime(timestamp);
        gmdluldBandMsg.setMsgHdr(new GMDMsgHdr());
        gmdluldBandMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        gmdCallbackHandler.handleLULDBandMsg(gmdluldBandMsg);

        final MarketDataMessage marketData = new MarketDataMessage(0.0, 0.0, "IBM", timestamp);
        marketData.setStatusEvent(true);
        marketData.setStatus(-1);
        marketData.setUpperLimit(gmdluldBandMsg.getUpperLimitPrice() / 10000000d);
        marketData.setLowerLimit(gmdluldBandMsg.getLowerLimitPrice() / 10000000d);
        if (timestamp == 0)
            marketData.setLULDTime(new Date());
        else
            marketData.setLULDTime(new Date(TimeUnit.NANOSECONDS.toMillis(timestamp)));

        Mockito.verify(gmdOut, Mockito.times(1)).marketData(marketData);
    }

    @Test
    public void handleLULDBandMsgWithEmptySymbol() {

        long timestamp = System.currentTimeMillis();

        GMDLULDBandMsg gmdluldBandMsg = new GMDLULDBandMsg();
        gmdluldBandMsg.setSymbol("");
        gmdluldBandMsg.setUpperLimitPrice(1250000000);
        gmdluldBandMsg.setLowerLimitPrice(1200000000);
        gmdluldBandMsg.setPriceBandEffectiveTime(timestamp);
        gmdluldBandMsg.setMsgHdr(new GMDMsgHdr());
        gmdluldBandMsg.getMsgHdr().setGmdSendTimeStamp(timestamp);
        gmdCallbackHandler.handleLULDBandMsg(gmdluldBandMsg);


        Mockito.verify(gmdOut, Mockito.never()).marketData(ArgumentMatchers.any(MarketDataMessage.class));
    }

    @Test
    public void handleTradeMsg() {
        gmdCallbackHandler.handleTradeMsg(Mockito.mock(GMDTradeMsg.class));
    }

    @Test
    public void handleImbalanceMsg() {
        gmdCallbackHandler.handleImbalanceMsg(Mockito.mock(GMDImbalanceMsg.class));
    }

    @Test
    public void handleCacheClearMsg() {
        gmdCallbackHandler.handleCacheClearMsg(Mockito.mock(GMDCacheClearMsg.class));
    }

    @Test
    public void handleStaticInfoMsg() {
        gmdCallbackHandler.handleStaticInfoMsg(Mockito.mock(GMDStaticInfoMsg.class));
    }

    @Test
    public void handleMarketStatusMsg() {
        gmdCallbackHandler.handleMarketStatusMsg(Mockito.mock(GMDMktStatusMsg.class));
    }

    @Test
    public void handleDetailedTradeMsg() {
        gmdCallbackHandler.handleDetailedTradeMsg(Mockito.mock(GMDTradeMsgDetailed.class));
    }

    @Test
    public void handlePeggedOrderMsg() {
        gmdCallbackHandler.handlePeggedOrderMsg(Mockito.mock(GMDPeggedOrderMsg.class));
    }

    @Test
    public void handleSubRespMsg() {
        gmdCallbackHandler.handleSubRespMsg(Mockito.mock(GMDSubRespMsg.class));
    }

    @Test
    public void handleUnSubRespMsg() {
        gmdCallbackHandler.handleUnSubRespMsg(Mockito.mock(GMDUnSubRespMsg.class));
    }

    @Test
    public void handleAdminRespMsg() {
        gmdCallbackHandler.handleAdminRespMsg(Mockito.mock(GMDAdminRespMsg.class));
    }

    @Test
    public void handleFeedStatusMsg() {
        gmdCallbackHandler.handleFeedStatusMsg(Mockito.mock(GMDFeedStatusMsg.class));
    }

    @Test
    public void handleFeedCfgInfoMsg() {
        gmdCallbackHandler.handleFeedCfgInfoMsg(Mockito.mock(GMDFeedCfgInfoMsg.class));
    }

    @Test
    public void handleLogOnRespMsg() {
        gmdCallbackHandler.handleLogOnRespMsg(Mockito.mock(GMDLogOnRespMsg.class));
    }

    @Test
    public void handleLogOffRespMsg() {
        gmdCallbackHandler.handleLogOffRespMsg(Mockito.mock(GMDLogOffRespMsg.class));
    }

    @Test
    public void handleLogonRej() {
        gmdCallbackHandler.handleLogonRej(Mockito.mock(GMDLogOnRejMsg.class));
    }

    @Test
    public void handleBasketQuoteMsg() {
        gmdCallbackHandler.handleBasketQuoteMsg(Mockito.mock(GMDBasketQuoteMsg.class));
    }

    @Test
    public void handlePassThruMsg() {
        gmdCallbackHandler.handlePassThruMsg(Mockito.mock(GMDPassThruMsg.class));
    }

    @Test
    public void handleSnapshotCompleteMsg() {
        gmdCallbackHandler.handleSnapshotCompleteMsg(Mockito.mock(GMDSnpshotCompleteNotification.class));
    }

    @Test
    public void handleEnhancedQuoteMsg() {
        gmdCallbackHandler.handleEnhancedQuoteMsg(Mockito.mock(GMDEnhancedQuoteMsg.class));
    }

    @Test
    public void handleClosingTradeSummaryMsg() {
        gmdCallbackHandler.handleClosingTradeSummaryMsg(Mockito.mock(GMDClosingTradeSummaryMsg.class));
    }

    @Test
    public void handleBookUpdate() {
        gmdCallbackHandler.handleBookUpdate(Mockito.mock(GMDAbstractBook.class));
    }


}