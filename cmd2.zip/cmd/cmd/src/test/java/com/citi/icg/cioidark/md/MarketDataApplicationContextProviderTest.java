package com.citi.icg.cioidark.md;

import com.citi.icg.cioidark.chronicle.messaging.queue.GMDOut;
import org.apache.commons.configuration.ConfigurationException;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(MarketDataSystemProperty.class)
public class MarketDataApplicationContextProviderTest {

    private final GMDOut gmdOut = marketDataMessage -> {};

    @Before
    public void init() throws ConfigurationException {
        MarketDataApplicationContextProvider.getMarketDataSystemProperty();
        MarketDataApplicationContextProvider.initialize(gmdOut);
    }

    @Test
    public void getMarketDataSystemProperty() {
        Assertions.assertEquals(MarketDataApplicationContextProvider.getMarketDataSystemProperty(),
                MarketDataApplicationContextProvider.getMarketDataSystemProperty());
    }

    @Test
    public void getMarketDataConnect() {
        Assertions.assertEquals(MarketDataApplicationContextProvider.getMarketDataConnect(),
                MarketDataApplicationContextProvider.getMarketDataConnect());
    }

    @Test
    public void getGmdCallbackHandler() {
        MarketDataApplicationContextProvider instance = MarketDataApplicationContextProvider.instance;
        Assertions.assertEquals(MarketDataApplicationContextProvider.getGmdCallbackHandler(),
                MarketDataApplicationContextProvider.getGmdCallbackHandler());
    }

    @Test
    public void getMarketDataSubscriptionManager() {
        Assertions.assertEquals(MarketDataApplicationContextProvider.getMarketDataSubscriptionManager(),
                MarketDataApplicationContextProvider.getMarketDataSubscriptionManager());
    }

    @Test
    public void getMarketDataTickDriverManager() {
        Assertions.assertEquals(MarketDataApplicationContextProvider.getMarketDataTickDriverManager(),
                MarketDataApplicationContextProvider.getMarketDataTickDriverManager());
    }

    @Test
    public void getMarketDataTickDriverSubscriber() {
        Assertions.assertEquals(MarketDataApplicationContextProvider.getMarketDataTickDriverSubscriber(),
                MarketDataApplicationContextProvider.getMarketDataTickDriverSubscriber());
    }

    @Test
    public void getMarketDataSubscriptionQueueDrainer() {
        Assertions.assertNotEquals(MarketDataApplicationContextProvider.getMarketDataSubscriptionQueueDrainer(),
                MarketDataApplicationContextProvider.getMarketDataSubscriptionQueueDrainer());
    }

    @Test
    public void getMarketDataSubscriptionHandler() {
        Assertions.assertNotEquals(MarketDataApplicationContextProvider.getMarketDataSubscriptionHandler(),
                MarketDataApplicationContextProvider.getMarketDataSubscriptionHandler());
    }
}