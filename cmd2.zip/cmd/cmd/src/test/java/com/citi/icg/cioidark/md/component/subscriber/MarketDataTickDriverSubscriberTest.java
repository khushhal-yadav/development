package com.citi.icg.cioidark.md.component.subscriber;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.SecurityMarketData;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.MarketDataSystemProperty;
import com.citi.icg.cioidark.md.component.driver.TickDriver;
import org.apache.commons.configuration.ConfigurationException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
public class MarketDataTickDriverSubscriberTest {

    private MarketDataTickDriverSubscriber marketDataTickDriverSubscriber;

    @Before
    public void init() throws ConfigurationException {
        MarketDataApplicationContextProvider.initialize(marketDataMessage -> {});
        marketDataTickDriverSubscriber = new MarketDataTickDriverSubscriber(MarketDataApplicationContextProvider.getMarketDataSystemProperty());
    }

    @Test
    public void subscribe() throws InterruptedException {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        final TickDriver tickDriver = Mockito.mock(TickDriver.class);
        PowerMockito.when(tickDriver.subscribe(ibmSecurityMarketData)).thenReturn(true);

        marketDataTickDriverSubscriber.subscribe(tickDriver, ibmSecurityMarketData);

        Thread.sleep(1000);

        Mockito.verify(tickDriver, Mockito.times(1)).subscribe(ibmSecurityMarketData);
    }

    @Test
    public void subscribeFail() throws InterruptedException {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        final TickDriver tickDriver = Mockito.mock(TickDriver.class);
        PowerMockito.when(tickDriver.subscribe(ibmSecurityMarketData)).thenReturn(false);

        marketDataTickDriverSubscriber.subscribe(tickDriver, ibmSecurityMarketData);

        Thread.sleep(1000);

        Mockito.verify(tickDriver, Mockito.times(1)).subscribe(ibmSecurityMarketData);
    }

    @Test
    public void subscribeWithNullTickDriver() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        final TickDriver tickDriver = Mockito.mock(TickDriver.class);
        PowerMockito.when(tickDriver.subscribe(ibmSecurityMarketData)).thenReturn(false);

        marketDataTickDriverSubscriber.subscribe(null, ibmSecurityMarketData);

        Mockito.verify(tickDriver, Mockito.never()).subscribe(ibmSecurityMarketData);
    }

    @Test
    public void unSubscribe() throws InterruptedException {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        final TickDriver tickDriver = Mockito.mock(TickDriver.class);
        PowerMockito.when(tickDriver.unSubscribe(ibmSecurityMarketData)).thenReturn(true);

        marketDataTickDriverSubscriber.unSubscribe(tickDriver, ibmSecurityMarketData);

        Thread.sleep(1000);

        Mockito.verify(tickDriver, Mockito.times(1)).unSubscribe(ibmSecurityMarketData);
    }

    @Test
    public void unSubscribeFail() throws InterruptedException {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        final TickDriver tickDriver = Mockito.mock(TickDriver.class);
        PowerMockito.when(tickDriver.unSubscribe(ibmSecurityMarketData)).thenReturn(false);

        marketDataTickDriverSubscriber.unSubscribe(tickDriver, ibmSecurityMarketData);

        Thread.sleep(1000);

        Mockito.verify(tickDriver, Mockito.times(1)).unSubscribe(ibmSecurityMarketData);
    }

    @Test
    public void unSubscribeWithNullTickDriver() {
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        final TickDriver tickDriver = Mockito.mock(TickDriver.class);
        PowerMockito.when(tickDriver.unSubscribe(ibmSecurityMarketData)).thenReturn(false);

        marketDataTickDriverSubscriber.unSubscribe(null, ibmSecurityMarketData);

        Mockito.verify(tickDriver, Mockito.never()).unSubscribe(ibmSecurityMarketData);
    }

    @Test
    public void instantiation() {
        final MarketDataSystemProperty marketDataSystemProperty = Mockito.mock(MarketDataSystemProperty.class);
        PowerMockito.when(marketDataSystemProperty.getMarketDataTickDriverSubscriberCorePoolMinSize()).thenReturn(2);
        PowerMockito.when(marketDataSystemProperty.getMarketDataTickDriverSubscriberCorePoolMaxSize()).thenReturn(10);
        PowerMockito.when(marketDataSystemProperty.getMarketDataTickDriverSubscriberKeepAliveTime()).thenReturn(1000L);
        PowerMockito.when(marketDataSystemProperty.getMarketDataTickDriverSubscriberCapacity()).thenReturn(100);

        new MarketDataTickDriverSubscriber(marketDataSystemProperty);

        Mockito.verify(marketDataSystemProperty, Mockito.times(1)).getMarketDataTickDriverSubscriberCorePoolMinSize();
        Mockito.verify(marketDataSystemProperty, Mockito.times(2)).getMarketDataTickDriverSubscriberCorePoolMaxSize();
        Mockito.verify(marketDataSystemProperty, Mockito.times(1)).getMarketDataTickDriverSubscriberKeepAliveTime();
        Mockito.verify(marketDataSystemProperty, Mockito.times(1)).getMarketDataTickDriverSubscriberCapacity();

        final MarketDataSystemProperty marketDataSystemPropertyWithZeroCorePoolMaxSize = Mockito.mock(MarketDataSystemProperty.class);

        PowerMockito.when(marketDataSystemPropertyWithZeroCorePoolMaxSize.getMarketDataTickDriverSubscriberCorePoolMinSize()).thenReturn(2);
        PowerMockito.when(marketDataSystemPropertyWithZeroCorePoolMaxSize.getMarketDataTickDriverSubscriberCorePoolMaxSize()).thenReturn(0);
        PowerMockito.when(marketDataSystemPropertyWithZeroCorePoolMaxSize.getMarketDataTickDriverSubscriberKeepAliveTime()).thenReturn(1000L);
        PowerMockito.when(marketDataSystemPropertyWithZeroCorePoolMaxSize.getMarketDataTickDriverSubscriberCapacity()).thenReturn(100);

        new MarketDataTickDriverSubscriber(marketDataSystemPropertyWithZeroCorePoolMaxSize);

        Mockito.verify(marketDataSystemPropertyWithZeroCorePoolMaxSize, Mockito.times(1)).getMarketDataTickDriverSubscriberCorePoolMinSize();
        Mockito.verify(marketDataSystemPropertyWithZeroCorePoolMaxSize, Mockito.times(1)).getMarketDataTickDriverSubscriberCorePoolMaxSize();
        Mockito.verify(marketDataSystemPropertyWithZeroCorePoolMaxSize, Mockito.times(1)).getMarketDataTickDriverSubscriberKeepAliveTime();
        Mockito.verify(marketDataSystemPropertyWithZeroCorePoolMaxSize, Mockito.times(1)).getMarketDataTickDriverSubscriberCapacity();

    }

}