package com.citi.icg.cioidark.md.component.drainer;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.SecurityMarketData;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.MarketDataSystemProperty;
import com.citi.icg.cioidark.md.component.driver.TickDriver;
import com.citi.icg.cioidark.md.component.manager.MarketDataSubscriptionManager;
import com.citi.icg.cioidark.md.component.subscriber.MarketDataTickDriverSubscriber;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MarketDataSubscriptionManager.class, MarketDataApplicationContextProvider.class})
public class MarketDataSubscriptionQueueDrainerTest {

    @Mock
    private MarketDataSubscriptionManager marketDataSubscriptionManager;
    @Mock
    private TickDriver tickDriver;
    @Mock
    private MarketDataTickDriverSubscriber marketDataTickDriverSubscriber;
    @Mock
    private MarketDataSystemProperty marketDataSystemProperty;

    private MarketDataSubscriptionQueueDrainer marketDataSubscriptionQueueDrainer;

    @Before
    public void init() {
        PowerMockito.mockStatic(MarketDataSubscriptionManager.class);
        PowerMockito.mockStatic(MarketDataApplicationContextProvider.class);
        PowerMockito.when(marketDataSubscriptionManager.getCurrentDriver()).thenReturn(tickDriver);
        PowerMockito.when(marketDataSubscriptionManager.getMarketDataTickDriverSubscriber()).thenReturn(marketDataTickDriverSubscriber);
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSubscriptionManager())
                .thenReturn(marketDataSubscriptionManager);
        PowerMockito.when(MarketDataApplicationContextProvider.getMarketDataSystemProperty())
                .thenReturn(marketDataSystemProperty);
        this.marketDataSubscriptionQueueDrainer = new MarketDataSubscriptionQueueDrainer();
    }

    @Test
    public void drainMarketDataSubscriptionQueue() {
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        PowerMockito.when(marketDataSubscriptionManager.isMarketDataOn()).thenReturn(true);
        Set<SecurityMarketData> waitingList = new HashSet<>();
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        final SecurityMarketData vodSecurityMarketData = new SecurityMarketData("VOD", "VOD.M");
        waitingList.add(ibmSecurityMarketData);
        waitingList.add(vodSecurityMarketData);
        PowerMockito.when(marketDataSubscriptionManager.getWaitingList()).thenReturn(waitingList);

        marketDataSubscriptionQueueDrainer.run();

        Mockito.verify(marketDataTickDriverSubscriber, Mockito.times(1)).subscribe(tickDriver, ibmSecurityMarketData);
        Mockito.verify(marketDataTickDriverSubscriber, Mockito.times(1)).subscribe(tickDriver, vodSecurityMarketData);
    }

    @Test
    public void drainMarketDataSubscriptionQueueWithGmdSubscriptionOff() {
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(false);
        PowerMockito.when(marketDataSubscriptionManager.isMarketDataOn()).thenReturn(true);
        Set<SecurityMarketData> waitingList = new HashSet<>();
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        final SecurityMarketData vodSecurityMarketData = new SecurityMarketData("VOD", "VOD.M");
        waitingList.add(ibmSecurityMarketData);
        waitingList.add(vodSecurityMarketData);
        PowerMockito.when(marketDataSubscriptionManager.getWaitingList()).thenReturn(waitingList);

        marketDataSubscriptionQueueDrainer.run();

        Mockito.verify(marketDataTickDriverSubscriber, Mockito.never()).subscribe(ArgumentMatchers.any(TickDriver.class), ArgumentMatchers.any(SecurityMarketData.class));
    }

    @Test
    public void drainMarketDataSubscriptionQueueWithMarketDataOff() {
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        PowerMockito.when(marketDataSubscriptionManager.isMarketDataOn()).thenReturn(false);
        Set<SecurityMarketData> waitingList = new HashSet<>();
        final SecurityMarketData ibmSecurityMarketData = new SecurityMarketData("IBM", "IBM.M");
        final SecurityMarketData vodSecurityMarketData = new SecurityMarketData("VOD", "VOD.M");
        waitingList.add(ibmSecurityMarketData);
        waitingList.add(vodSecurityMarketData);
        PowerMockito.when(marketDataSubscriptionManager.getWaitingList()).thenReturn(waitingList);

        marketDataSubscriptionQueueDrainer.run();

        Mockito.verify(marketDataTickDriverSubscriber, Mockito.never()).subscribe(ArgumentMatchers.any(TickDriver.class), ArgumentMatchers.any(SecurityMarketData.class));
    }

    @Test
    public void drainMarketDataSubscriptionQueueWithEmptySubscriptionQueue() {
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        PowerMockito.when(marketDataSubscriptionManager.isMarketDataOn()).thenReturn(true);
        PowerMockito.when(marketDataSubscriptionManager.getWaitingList()).thenReturn(Collections.emptySet());

        marketDataSubscriptionQueueDrainer.run();

        Mockito.verify(marketDataTickDriverSubscriber, Mockito.never()).subscribe(ArgumentMatchers.any(TickDriver.class), ArgumentMatchers.any(SecurityMarketData.class));
    }

    @Test
    public void drainMarketDataSubscriptionQueueWithExceptionFlow() {
        PowerMockito.when(marketDataSystemProperty.isGmdSubscribeMarketData()).thenReturn(true);
        PowerMockito.when(marketDataSubscriptionManager.isMarketDataOn()).thenReturn(true);
        PowerMockito.when(marketDataSubscriptionManager.getWaitingList()).thenThrow(new NullPointerException());

        marketDataSubscriptionQueueDrainer.run();

        Mockito.verify(marketDataTickDriverSubscriber, Mockito.never()).subscribe(ArgumentMatchers.any(TickDriver.class), ArgumentMatchers.any(SecurityMarketData.class));
    }
}