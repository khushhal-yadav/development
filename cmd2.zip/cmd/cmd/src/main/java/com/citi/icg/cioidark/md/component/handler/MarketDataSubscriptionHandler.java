package com.citi.icg.cioidark.md.component.handler;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.util.BooleanUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * MarketData subscription handler to handle
 *
 * @author ky54595
 * @see GMDTickSubscriptionMsg
 */
public class MarketDataSubscriptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataSubscriptionHandler.class.getName());

    public void processSubscriptionMessage(GMDTickSubscriptionMsg gmdTickSubscriptionMsg) {
        String bookSymbol = gmdTickSubscriptionMsg.getBookSymbol();
        String marketDataSymbol = gmdTickSubscriptionMsg.getMarketDataSymbol();
        boolean subscribe = gmdTickSubscriptionMsg.isSubscribe();

        logger.info("Subscribe: {} bookSymbol: {} marketDataSymbol: {} ", subscribe, bookSymbol, marketDataSymbol);
        BooleanUtil.ifTrueExecuteOrElse(
                subscribe
                        && StringUtils.isNotEmpty(bookSymbol.trim())
                        && StringUtils.isNotEmpty(marketDataSymbol.trim()),
                () -> MarketDataApplicationContextProvider.getMarketDataSubscriptionManager().subscribe(bookSymbol, marketDataSymbol),
                () -> BooleanUtil.ifTrueExecute(
                        !subscribe && StringUtils.isNotEmpty(bookSymbol.trim()),
                        () -> MarketDataApplicationContextProvider.getMarketDataSubscriptionManager().unsubscribe(bookSymbol)
                )
        );
    }
}
