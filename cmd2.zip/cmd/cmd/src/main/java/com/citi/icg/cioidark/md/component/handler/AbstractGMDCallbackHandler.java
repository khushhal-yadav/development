package com.citi.icg.cioidark.md.component.handler;

import com.citi.gmd.client.book.GMDAbstractBook;
import com.citi.gmd.client.callbacks.GMDComponentCallback;
import com.citi.gmd.client.messages.admin.GMDAdminRespMsg;
import com.citi.gmd.client.messages.component.GMDBasketQuoteMsg;
import com.citi.gmd.client.messages.component.GMDCacheClearMsg;
import com.citi.gmd.client.messages.component.GMDClosingTradeSummaryMsg;
import com.citi.gmd.client.messages.component.GMDEnhancedQuoteMsg;
import com.citi.gmd.client.messages.component.GMDFeedCfgInfoMsg;
import com.citi.gmd.client.messages.component.GMDFeedStatusMsg;
import com.citi.gmd.client.messages.component.GMDImbalanceMsg;
import com.citi.gmd.client.messages.component.GMDLogOffRespMsg;
import com.citi.gmd.client.messages.component.GMDLogOnRejMsg;
import com.citi.gmd.client.messages.component.GMDLogOnRespMsg;
import com.citi.gmd.client.messages.component.GMDMktStatusMsg;
import com.citi.gmd.client.messages.component.GMDPassThruMsg;
import com.citi.gmd.client.messages.component.GMDPeggedOrderMsg;
import com.citi.gmd.client.messages.component.GMDSnpshotCompleteNotification;
import com.citi.gmd.client.messages.component.GMDStaticInfoMsg;
import com.citi.gmd.client.messages.component.GMDSubRespMsg;
import com.citi.gmd.client.messages.component.GMDTradeMsg;
import com.citi.gmd.client.messages.component.GMDTradeMsgDetailed;
import com.citi.gmd.client.messages.component.GMDUnSubRespMsg;

abstract class AbstractGMDCallbackHandler extends GMDComponentCallback {

    @Override
    public void handleImbalanceMsg(GMDImbalanceMsg gmdImbalanceMsg) {
    }

    @Override
    public void handleCacheClearMsg(GMDCacheClearMsg gmdCacheClearMsg) {
    }

    @Override
    public void handleStaticInfoMsg(GMDStaticInfoMsg gmdStaticInfoMsg) {
    }

    @Override
    public void handleMarketStatusMsg(GMDMktStatusMsg gmdMktStatusMsg) {
    }

    @Override
    public void handleDetailedTradeMsg(GMDTradeMsgDetailed gmdTradeMsgDetailed) {
    }

    @Override
    public void handlePeggedOrderMsg(GMDPeggedOrderMsg gmdPeggedOrderMsg) {
    }

    @Override
    public void handleSubRespMsg(GMDSubRespMsg gmdSubRespMsg) {
    }

    @Override
    public void handleUnSubRespMsg(GMDUnSubRespMsg gmdUnSubRespMsg) {
    }

    @Override
    public void handleAdminRespMsg(GMDAdminRespMsg gmdAdminRespMsg) {
    }

    @Override
    public void handleFeedStatusMsg(GMDFeedStatusMsg gmdFeedStatusMsg) {
    }

    @Override
    public void handleFeedCfgInfoMsg(GMDFeedCfgInfoMsg gmdFeedCfgInfoMsg) {
    }

    @Override
    public void handleLogOnRespMsg(GMDLogOnRespMsg gmdLogOnRespMsg) {
    }

    @Override
    public void handleLogOffRespMsg(GMDLogOffRespMsg gmdLogOffRespMsg) {
    }

    @Override
    public void handleLogonRej(GMDLogOnRejMsg gmdLogOnRejMsg) {
    }

    @Override
    public void handleBasketQuoteMsg(GMDBasketQuoteMsg gmdBasketQuoteMsg) {
    }

    @Override
    public void handlePassThruMsg(GMDPassThruMsg gmdPassThruMsg) {
    }

    @Override
    public void handleSnapshotCompleteMsg(GMDSnpshotCompleteNotification gmdSnpshotCompleteNotification) {
    }

    @Override
    public void handleEnhancedQuoteMsg(GMDEnhancedQuoteMsg gmdEnhancedQuoteMsg) {
    }

    @Override
    public void handleClosingTradeSummaryMsg(GMDClosingTradeSummaryMsg gmdClosingTradeSummaryMsg) {
    }

    @Override
    public void handleBookUpdate(GMDAbstractBook gmdAbstractBook) {
    }

    @Override
    public void handleTradeMsg(GMDTradeMsg gmdTradeMsg) {
    }

}
