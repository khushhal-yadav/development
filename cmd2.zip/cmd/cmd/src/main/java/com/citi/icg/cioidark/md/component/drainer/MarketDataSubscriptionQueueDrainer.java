package com.citi.icg.cioidark.md.component.drainer;

import java.util.Set;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.SecurityMarketData;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.component.driver.TickDriver;
import com.citi.icg.cioidark.md.component.manager.MarketDataSubscriptionManager;
import com.citi.icg.cioidark.util.BooleanUtil;
import com.citi.icg.cioidark.util.Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Task to drain symbol lists which were not able to subscribe for market data and were added to
 *
 * @author ky54595
 * @see MarketDataSubscriptionManager#waitingList
 */
public class MarketDataSubscriptionQueueDrainer implements Runnable {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataSubscriptionQueueDrainer.class.getSimpleName());

    @Override
    public void run() {
        drainMarketDataSubscriptionQueue();
    }

    private void drainMarketDataSubscriptionQueue() {
        try {
            BooleanUtil.ifTrueExecute(
                    MarketDataApplicationContextProvider.getMarketDataSystemProperty().isGmdSubscribeMarketData(),
                    () -> BooleanUtil.ifTrueExecuteOrElse(
                            MarketDataApplicationContextProvider.getMarketDataSubscriptionManager().isMarketDataOn(),
                            () -> {
                                Set<SecurityMarketData> waitingList
                                        = MarketDataApplicationContextProvider.getMarketDataSubscriptionManager().getWaitingList();
                                BooleanUtil.ifFalseExecute(
                                        waitingList.isEmpty(),
                                        () -> {
                                            logger.info("draining queue");
                                            TickDriver listener
                                                    = MarketDataApplicationContextProvider.getMarketDataSubscriptionManager().getCurrentDriver();
                                            waitingList.forEach(symbolInfo
                                                    -> MarketDataApplicationContextProvider.getMarketDataSubscriptionManager().getMarketDataTickDriverSubscriber().subscribe(listener, symbolInfo));
                                        }
                                );
                                waitingList.clear();
                            },
                            () -> logger.info("nothing to drain, exiting...")
                    )
            );

        } catch (Exception ex) {
            logger.warn("run|error|" + Util.getStackTrace(ex));
        }
    }

}
