package com.citi.icg.cioidark.md.component.driver;

import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import com.citi.gmd.client.GMDContext;
import com.citi.gmd.client.config.GMDServerConfig;
import com.citi.gmd.client.messages.component.GMDConnectionEvent;
import com.citi.gmd.client.messages.component.GMDSubscription;
import com.citi.gmd.client.messages.constants.GMDAPIResponseCode;
import com.citi.gmd.client.messages.constants.GMDSubscriptionType;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.SecurityMarketData;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.MarketDataSource;
import com.citi.icg.cioidark.md.component.exception.GMDInitializationException;
import com.citi.icg.cioidark.md.component.handler.GMDCallbackHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class to interact with GMD api and registering callback
 *
 * @author ky54595
 * @see GMDCallbackHandler
 * for the GMD callback methods
 */
public class GMDTickDriver implements TickDriver {

    private static final Logger logger = LoggerFactory.getLogger(GMDTickDriver.class.getName());
    private static final String ITRLS_ALERT_FOR_GMD_TICK_IGNORE = "ITRSALERT|GMD Tick ignore set for symbol {}";


    private final short feedId = MarketDataApplicationContextProvider.getMarketDataSystemProperty().getGmdMarketDataFeedId();

    private volatile boolean connected = false;
    private final GMDContext context = GMDContext.getInstance();
    private final ConcurrentMap<String, String> gmdToBookSymbols = new ConcurrentHashMap<>();
    private ConcurrentMap<String, String> ignoreMDTicks = new ConcurrentHashMap<>();

    @Override
    public void init() {
        String config = MarketDataApplicationContextProvider.getMarketDataSystemProperty().getGmdConfigLocation();
        GMDAPIResponseCode status = context.init(config);
        if (GMDAPIResponseCode.SUCCESS != status) {
            logger.error("Initialization of GMD API failed. Status: {}. File location: {}", status, config);
            throw new GMDInitializationException("Unable to initialize GMD API");
        }

        context.registerEventListener(this::handleRegisterEvent);
    }

    @Override
    public void handleRegisterEvent(GMDConnectionEvent event, GMDServerConfig session) {
        logger.info("Event: {}, Server Config: {}", event, session);
        switch (event) {
            case LOGIN_SUCCESS:
                connected = true;
                break;
            case LOGIN_FAILED:
                connected = false;
                throw new GMDInitializationException(
                        String.format("Unable to connect to GMD server. Server config: %s", session));
            case LOGGEDOFF:
            case DISCONNECTED:
                connected = false;
                break;
            default:
                connected = false;
                break;
        }
    }

    @Override
    public boolean login() {
        logger.info("Initialize connections to GMD");
        GMDCallbackHandler gmdCallbackHandler = MarketDataApplicationContextProvider.getGmdCallbackHandler();
        context.registerCallback(gmdCallbackHandler);
        context.connectAllSessions();
        connected = true;
        logger.info("Successfully connected to GMD");
        return connected;
    }

    @Override
    public boolean logout() {
        logger.info("Close connections to GMD");
        context.shutDownAllSessions();
        logger.info("Successfully disconnect from GMD");
        return connected;
    }

    @Override
    public boolean subscribe(SecurityMarketData securityMarketData) {
        logger.info("Subscribing to: {}", securityMarketData.getTicker());
        // check if already subscribed
        if (gmdToBookSymbols.containsKey(securityMarketData.getMarketDataSymbol())) {
            logger.warn("Already subscribed to: {}", securityMarketData.getTicker());
            return true;
        }

        GMDSubscription gmdSubscription = new GMDSubscription();
        gmdSubscription.setSymbol(securityMarketData.getMarketDataSymbol());
        gmdSubscription.setIsRange((byte) 0);
        gmdSubscription.setKeepSubActiveIfSymNotFound((byte) 1);
        gmdSubscription.setSubType(GMDSubscriptionType.GMD_CLIENT_SUBTYPE_SNAPSHOTUPDATES);
        gmdSubscription.setFeedId(feedId);
        GMDAPIResponseCode rc = context.subscribe(gmdSubscription);
        if (GMDAPIResponseCode.SUCCESS != rc) {
            logger.error("Failed to subscribe for symbol {}, Error: {}", securityMarketData.getTicker(), rc.toString());
            return false;
        }
        logger.info("Successfully subscribed to: {}", securityMarketData.getTicker());
        gmdToBookSymbols.put(securityMarketData.getMarketDataSymbol(), securityMarketData.getTicker());
        return true;
    }

    @Override
    public boolean unSubscribe(SecurityMarketData securityMarketData) {
        logger.info("UnSubscribing for: {}", securityMarketData.getMarketDataSymbol());

        // check if already not subscribed
        if (!gmdToBookSymbols.containsKey(securityMarketData.getMarketDataSymbol())) {
            logger.warn("{} not subscribed to, cannot un-subscribe!", securityMarketData.getMarketDataSymbol());
            return true;
        }
        GMDSubscription gmdSubscription = new GMDSubscription();
        gmdSubscription.setSymbol(securityMarketData.getMarketDataSymbol());
        gmdSubscription.setIsRange((byte) 0);
        gmdSubscription.setKeepSubActiveIfSymNotFound((byte) 0);
        gmdSubscription.setSubType(GMDSubscriptionType.GMD_CLIENT_SUBTYPE_UPDATESONLY);
        gmdSubscription.setFeedId(feedId);
        GMDAPIResponseCode rc = context.unsubscribe(gmdSubscription);
        if (GMDAPIResponseCode.SUCCESS != rc) {
            logger.error("Failed to unSubscribe for symbol {}, Error: {}", securityMarketData.getMarketDataSymbol(), rc.toString());
            return false;
        }
        logger.info("Successfully unsubscribed for: {}", securityMarketData.getMarketDataSymbol());
        gmdToBookSymbols.remove(securityMarketData.getMarketDataSymbol());
        return true;
    }

    @Override
    public MarketDataSource getMarketDataSource() {
        return MarketDataSource.GMD;
    }

    @Override
    public boolean getConnected() {
        return connected;
    }

    @Override
    public String getBookSymbol(String gmdSymbol) {
        final String symbol = gmdToBookSymbols.get(gmdSymbol);

        if (!ignoreMDTicks.keySet().contains(Optional.ofNullable(symbol).orElse("")))
            return symbol;

        logger.warn(ITRLS_ALERT_FOR_GMD_TICK_IGNORE, symbol);
            return null;

    }

    @Override
    public void putBookSymbol(SecurityMarketData securityMarketData) {
        gmdToBookSymbols.put(securityMarketData.getMarketDataSymbol(), securityMarketData.getTicker());
    }

    @Override
    public void removeBookSymbol(SecurityMarketData securityMarketData) {
        gmdToBookSymbols.remove(securityMarketData.getMarketDataSymbol());
    }

    @Override
    public void ignoreMDTicks(String symbol) {
        ignoreMDTicks.put(symbol, symbol);
    }

    @Override
    public void resumeMDTicks(String symbol) {
        ignoreMDTicks.remove(symbol);
    }

}
