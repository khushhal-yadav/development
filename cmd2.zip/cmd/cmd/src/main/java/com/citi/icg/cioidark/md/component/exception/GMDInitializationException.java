package com.citi.icg.cioidark.md.component.exception;

public class GMDInitializationException extends RuntimeException {

    public GMDInitializationException(String message) {
        super(message);
    }
}
