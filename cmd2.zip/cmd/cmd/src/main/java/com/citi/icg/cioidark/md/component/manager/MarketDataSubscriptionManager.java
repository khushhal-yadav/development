package com.citi.icg.cioidark.md.component.manager;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.SecurityMarketData;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.component.drainer.MarketDataSubscriptionQueueDrainer;
import com.citi.icg.cioidark.md.component.driver.TickDriver;
import com.citi.icg.cioidark.md.component.subscriber.MarketDataTickDriverSubscriber;
import com.citi.icg.cioidark.util.BooleanUtil;
import com.citi.icg.cioidark.util.Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * provide an api for MarketData subscription management and spawn various monitors and dependent components
 *
 * @author ky54595
 * @see MarketDataTickDriverManager
 * @see MarketDataSubscriptionQueueDrainer
 * @see MarketDataTickDriverManager
 */
public class MarketDataSubscriptionManager {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataSubscriptionManager.class.getSimpleName());
    private volatile TickDriver currentTickDriver = null;    // a list of listener passed in
    private volatile boolean isMarketDataOn = false;
    private volatile boolean isGlobalStale = false;//global stale
    private MarketDataTickDriverSubscriber marketDataTickDriverSubscriber;
    private final Map<String, SecurityMarketData> subscriptionMap = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, String> symbolSet = new ConcurrentHashMap<>();
    private final Set<SecurityMarketData> waitingList = new HashSet<>();
    private final int retryCount = MarketDataApplicationContextProvider.getMarketDataSystemProperty().getGmdMarketDataRetry();
    private volatile int retryCounter = 0;

    public synchronized boolean login(TickDriver tickDriver) {
        try {
            marketDataTickDriverSubscriber = MarketDataApplicationContextProvider.getMarketDataTickDriverSubscriber();
            setGlobalStale(true);
            setMarketDataOn(false);
            emptySymbolSet();

            startTickDriverManager(tickDriver);

        } catch (Exception ex) {
            logger.warn("login|error|" + Util.getStackTrace(ex));
            return false;
        }
        return true;
    }

    private void startTickDriverManager(final TickDriver tickDriver) {
        MarketDataTickDriverManager marketDataTickDriverManager =
                MarketDataApplicationContextProvider.getMarketDataTickDriverManager();
        marketDataTickDriverManager.setTickListener(tickDriver);
        Thread tickDriverManagerThread = new Thread(marketDataTickDriverManager);
        tickDriverManagerThread.start();
    }

    public void subscribe(String bookSymbol, String marketDataSymbol) {
        logger.debug("Subscribe to MarketData Book symbol:" + bookSymbol + "marketDataSymbol" + marketDataSymbol);
        try {
            BooleanUtil.ifTrueExecute(
                    MarketDataApplicationContextProvider.getMarketDataSystemProperty().isGmdSubscribeMarketData(),
                    () -> {
                        SecurityMarketData subSymbol = new SecurityMarketData(bookSymbol, marketDataSymbol);
                        logger.info("MarketDataSubscriptionManager subscribe: " + this.isMarketDataOn
                                + " currentTickDriver: " + currentTickDriver);
                        BooleanUtil.ifTrueExecuteOrElse(
                                (!this.isMarketDataOn) || (currentTickDriver == null),
                                () -> {
                                    this.waitingList.add(subSymbol);
                                    subscriptionMap.put(bookSymbol, subSymbol);
                                    logger.info("MarketDataSubscriptionManager subscribe: added to waitingList "
                                            + subSymbol);
                                },
                                () -> {
                                    marketDataTickDriverSubscriber.subscribe(currentTickDriver, subSymbol);
                                    subscriptionMap.put(bookSymbol, subSymbol);
                                }
                        );
                    }
            );
        } catch (Exception ex) {
            logger.warn("subscribe|" + bookSymbol + "| " + Util.getStackTrace(ex));
        }
    }

    //Get the best known market data symbol we have and disconnect from it based on the passed in book symbol
    public void unsubscribe(String symbol) {
        try {
            BooleanUtil.ifTrueExecuteOrElse(
                    isMarketDataOn(),
                    () -> {
                        SecurityMarketData disconnectSymbol = subscriptionMap
                                .getOrDefault(symbol, new SecurityMarketData(symbol, symbol));
                        marketDataTickDriverSubscriber.unSubscribe(currentTickDriver, disconnectSymbol);
                        subscriptionMap.remove(symbol);
                    },
                    () -> logger.info("market data off, not able to unSubscribe | {}", symbol)
            );
        } catch (Exception ex) {
            logger.warn("unSubscribe| {} | {} ", symbol, Util.getStackTrace(ex));
        }
    }

    public boolean logout() {
        MarketDataApplicationContextProvider.getMarketDataTickDriverManager().logout();
        setMarketDataOn(false);
        return true;
    }


    public boolean isMarketDataOn() {
        return isMarketDataOn;
    }

    public void setMarketDataOn(boolean isDataOn) {
        isMarketDataOn = isDataOn;
        logger.info("MarketDataOn|" + isDataOn + "|Thread|" + Thread.currentThread().getId());
    }

    public boolean isGlobalStale() {
        return isGlobalStale;
    }

    public void setGlobalStale(boolean isStale) {
        isGlobalStale = isStale;
        logger.info("GlobalStale|" + isGlobalStale + "|Thread|" + Thread.currentThread().getId());
    }

    public TickDriver getCurrentDriver() {
        return currentTickDriver;
    }

    public void setCurrentDriver(TickDriver listener) {
        currentTickDriver = listener;
    }

    public Map<String, SecurityMarketData> getSubscriptionMap() {
        return subscriptionMap;
    }

    public int getSymbolSetCount() {
        return symbolSet.size();
    }

    public void addToSymbolSet(String symbol) {
        this.symbolSet.put(symbol, symbol);
    }

    /*
     * symbolSet is used to calculate stale ratio in StaleMarketDataMonitor.
     * it contains a set of symbols receiving subscriptions
     */
    public void emptySymbolSet() {
        symbolSet.clear();
    }

    public MarketDataTickDriverSubscriber getMarketDataTickDriverSubscriber() {
        return marketDataTickDriverSubscriber;
    }

    public Set<SecurityMarketData> getWaitingList() {
        return waitingList;
    }

    public void drainQueue() {
        BooleanUtil.ifTrueExecuteOrElse(
                !getWaitingList().isEmpty(),
                () -> {
                    MarketDataSubscriptionQueueDrainer queueDrainer = MarketDataApplicationContextProvider.getMarketDataSubscriptionQueueDrainer();
                    Thread mkThread = new Thread(queueDrainer);
                    mkThread.start();
                },
                () -> logger.info("nothing to drain")
        );
    }

    public void ignoreMDTicks(String symbol) {
        currentTickDriver.ignoreMDTicks(symbol);
    }

    public void resumeMDTicks(String symbol) {
        currentTickDriver.resumeMDTicks(symbol);
    }


    public int getRetryCount() {
        return retryCount;
    }

    public int getRetryCounter() {
        return retryCounter;
    }

    public synchronized void incRetryCounter() {
        this.retryCounter++;
    }
}
