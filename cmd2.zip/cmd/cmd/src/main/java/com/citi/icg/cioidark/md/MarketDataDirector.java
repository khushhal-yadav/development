package com.citi.icg.cioidark.md;

import com.citi.icg.cioidark.chronicle.messaging.queue.GMDOut;
import org.apache.commons.configuration.ConfigurationException;

/**
 * Service responsible to initialize the application on start up
 *
 * @author ky54595
 */
public class MarketDataDirector {

    private static final MarketDataDirector director = new MarketDataDirector();

    private MarketDataDirector() {
    }

    public static MarketDataDirector getInstance() {
        return director;
    }

    public void initialize(GMDOut gmdOut) throws ConfigurationException {
        MarketDataApplicationContextProvider.initialize(gmdOut);
        MarketDataApplicationContextProvider.getMarketDataConnect().connect();
    }

}
