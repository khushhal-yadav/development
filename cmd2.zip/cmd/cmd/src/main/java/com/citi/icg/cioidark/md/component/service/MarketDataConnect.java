package com.citi.icg.cioidark.md.component.service;

import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.component.driver.TickDriver;
import com.citi.icg.cioidark.util.BooleanUtil;
import com.citi.icg.cioidark.util.Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Service to connect(initialize and login) registered tick drivers for marketData subscription
 *
 * @author ky54595
 */
public class MarketDataConnect {

    private final Logger logger = LoggerFactory.getLogger(MarketDataConnect.class);

    private final TickDriver tickDriver;

    public MarketDataConnect(TickDriver tickDriver) {
        this.tickDriver = tickDriver;
    }

    public void connect() {
        try {
            tickDriver.init();
            BooleanUtil.ifTrueExecuteOrElse(
                    MarketDataApplicationContextProvider.getMarketDataSystemProperty().isGmdSubscribeMarketData(),
                    () -> BooleanUtil.ifTrueExecuteOrElse(
                            MarketDataApplicationContextProvider.getMarketDataSubscriptionManager().login(this.tickDriver),
                            () -> logger.warn("Successfully login to MarketDataManager for Tick Drivers"),
                            () -> logger.warn("ITRSALERT|Error login to MarketDataManager")
                    )
                    ,
                    () -> logger.warn("GMD MarketData subscription if off: {}",
                            MarketDataApplicationContextProvider.getMarketDataSystemProperty().isGmdSubscribeMarketData())
            );

        } catch (Exception ex) {
            logger.warn("Error login to MarketDataManager|" + Util.getStackTrace(ex));
        }
    }
}
