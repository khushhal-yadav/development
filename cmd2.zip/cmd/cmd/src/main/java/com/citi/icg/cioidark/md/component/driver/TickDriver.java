package com.citi.icg.cioidark.md.component.driver;

import com.citi.gmd.client.config.GMDServerConfig;
import com.citi.gmd.client.messages.component.GMDConnectionEvent;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.SecurityMarketData;
import com.citi.icg.cioidark.md.MarketDataSource;

public interface TickDriver {
    boolean login();

    boolean logout();

    boolean subscribe(SecurityMarketData symInfo);

    boolean unSubscribe(SecurityMarketData symbol);

    MarketDataSource getMarketDataSource();

    boolean getConnected();

    void init();

    String getBookSymbol(String gmdSymbol);

    void putBookSymbol(SecurityMarketData securityMarketData);

    void removeBookSymbol(SecurityMarketData securityMarketData);

    void handleRegisterEvent(GMDConnectionEvent event, GMDServerConfig session);

    void ignoreMDTicks(String symbol);

    void resumeMDTicks(String symbol);


}
