package com.citi.icg.cioidark.md.component.subscriber;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.citi.icg.cioidark.chronicle.messaging.message.gmd.SecurityMarketData;
import com.citi.icg.cioidark.md.MarketDataSystemProperty;
import com.citi.icg.cioidark.md.component.driver.GMDTickDriver;
import com.citi.icg.cioidark.md.component.driver.TickDriver;
import com.citi.icg.cioidark.util.BooleanUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Subscribe
 *
 * @author ky54595
 * @see GMDTickDriver for
 * @see SecurityMarketData to MarketData
 */
public class MarketDataTickDriverSubscriber {
    private static final Logger logger = LoggerFactory.getLogger(MarketDataTickDriverSubscriber.class.getSimpleName());

    private final int corePoolMinSize;
    private final int corePoolMaxSize;
    private final int capacity;
    private final long keepAliveTime;
    private final ExecutorService tpe;

    public MarketDataTickDriverSubscriber(MarketDataSystemProperty marketDataSystemProperty) {
        this.corePoolMinSize = marketDataSystemProperty.getMarketDataTickDriverSubscriberCorePoolMinSize();
        this.corePoolMaxSize = BooleanUtil.ifTrueEvaluateOtherwiseReturnDefault(
                marketDataSystemProperty.getMarketDataTickDriverSubscriberCorePoolMaxSize() != 0,
                marketDataSystemProperty::getMarketDataTickDriverSubscriberCorePoolMaxSize,
                Integer.MAX_VALUE
        );
        this.keepAliveTime = marketDataSystemProperty.getMarketDataTickDriverSubscriberKeepAliveTime();
        this.capacity = marketDataSystemProperty.getMarketDataTickDriverSubscriberCapacity();
        tpe = new ThreadPoolExecutor(this.corePoolMinSize, this.corePoolMaxSize, this.keepAliveTime, TimeUnit.SECONDS,
                new ArrayBlockingQueue<>(this.capacity));

        logger.info("MarketDataTickDriverSubscriber initialized: {}", this.toString());
    }

    public void subscribe(final TickDriver tickDriver, final SecurityMarketData securityMarketData) {
        BooleanUtil.ifNotNullExecuteOrElse(
                tickDriver,
                () -> tpe.execute(() -> {
                    logger.info("Subscribing for tickDriver: " + tickDriver);
                    boolean connected = tickDriver.subscribe(securityMarketData);
                    if (!connected)
                        logger.warn("ITRSALERT|Unable to subscribe market data for securityMarketData: {}", securityMarketData.getTicker());
                    else
                        logger.info("Subscribed to TickDriver for securityMarketData: {}", securityMarketData);
                }),
                () -> logger.warn("tickDriver NULL")
        );
    }

    public void unSubscribe(final TickDriver tickDriver, final SecurityMarketData securityMarketData) {
        BooleanUtil.ifNotNullExecuteOrElse(
                tickDriver,
                () -> tpe.execute(() -> {
                    logger.info("Un-subscribing for tickDriver: " + tickDriver);
                    boolean connected = tickDriver.unSubscribe(securityMarketData);
                    if (!connected)
                        logger.warn("ITRSALERT|Unable to un-subscribe market for securityMarketData: {}", securityMarketData);
                    else
                        logger.info("Un-subscribed to TickDriver for securityMarketData: {}", securityMarketData);
                }),
                () -> logger.warn("tickDriver NULL")
        );
    }

    @Override
    public String toString() {
        return "MarketDataTickDriverSubscriber{" +
                "corePoolMinSize=" + corePoolMinSize +
                ", corePoolMaxSize=" + corePoolMaxSize +
                ", capacity=" + capacity +
                ", keepAliveTime=" + keepAliveTime +
                '}';
    }
}
