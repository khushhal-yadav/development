package com.citi.icg.cioidark.md;

import com.citi.icg.cioidark.chronicle.messaging.message.admin.AbstractSystemProperty;
import com.citi.icg.cioidark.chronicle.messaging.queue.GMDOut;
import org.apache.commons.configuration.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * To hold system properties for Market data service
 *
 * @author ky54595
 */
public class MarketDataSystemProperty extends AbstractSystemProperty {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataSystemProperty.class.getName());
    private final GMDOut gmdOut;
    private final boolean gmdSubscribeMarketData;
    private final short gmdMarketDataFeedId;
    private final int gmdMarketDataRetry;
    private final long gmdMarketDataRetryWaitInterval;
    private final String gmdConfigLocation;
    private final int marketDataTickDriverSubscriberCorePoolMinSize;
    private int marketDataTickDriverSubscriberCorePoolMaxSize;
    private final long marketDataTickDriverSubscriberKeepAliveTime;
    private final int marketDataTickDriverSubscriberCapacity;

    //only construction injection of properties, *ABSOLUTELY NO SETTERS
    public MarketDataSystemProperty(GMDOut gmdOut) throws ConfigurationException {
        super("md.properties");

        this.gmdOut = gmdOut;
        this.gmdSubscribeMarketData = systemProperties.getBoolean("gmd.subscribeMarketData");
        this.gmdMarketDataFeedId = systemProperties.getShort("gmd.marketData.feedId");
        this.gmdMarketDataRetry = systemProperties.getInt("gmd.marketData.retry");
        this.gmdMarketDataRetryWaitInterval = systemProperties.getLong("gmd.marketData.retryWaitInterval");
        this.gmdConfigLocation = System.getProperty("preferences.env") + "/gmd.client-" + System.getProperty("gmd.instance") + ".cfg";
        this.marketDataTickDriverSubscriberCorePoolMinSize = systemProperties.getInt("gmd.marketDataTickDriverSubscriber.corePoolMinSize");
        this.marketDataTickDriverSubscriberKeepAliveTime = systemProperties.getLong("gmd.marketDataTickDriverSubscriber.keepAliveTime");
        this.marketDataTickDriverSubscriberCapacity = systemProperties.getInt("gmd.marketDataTickDriverSubscriber.capacity");

        logger.info("MarketDataSystemProperty loaded: {}", this.toString());
    }

    public GMDOut getGmdOut() {
        return gmdOut;
    }

    public boolean isGmdSubscribeMarketData() {
        return gmdSubscribeMarketData;
    }

    public short getGmdMarketDataFeedId() {
        return gmdMarketDataFeedId;
    }

    public int getGmdMarketDataRetry() {
        return gmdMarketDataRetry;
    }

    public long getGmdMarketDataRetryWaitInterval() {
        return gmdMarketDataRetryWaitInterval;
    }

    public String getGmdConfigLocation() {
        return gmdConfigLocation;
    }

    public int getMarketDataTickDriverSubscriberCorePoolMinSize() {
        return marketDataTickDriverSubscriberCorePoolMinSize;
    }

    public int getMarketDataTickDriverSubscriberCorePoolMaxSize() {
        return marketDataTickDriverSubscriberCorePoolMaxSize;
    }

    public long getMarketDataTickDriverSubscriberKeepAliveTime() {
        return marketDataTickDriverSubscriberKeepAliveTime;
    }

    public int getMarketDataTickDriverSubscriberCapacity() {
        return marketDataTickDriverSubscriberCapacity;
    }

    @Override
    public String toString() {
        return "MarketDataSystemProperty{" +
                "gmdOut=" + gmdOut +
                ", gmdSubscribeMarketData=" + gmdSubscribeMarketData +
                ", gmdMarketDataFeedId=" + gmdMarketDataFeedId +
                ", gmdMarketDataRetry=" + gmdMarketDataRetry +
                ", gmdMarketDataRetryWaitInterval=" + gmdMarketDataRetryWaitInterval +
                ", gmdConfigLocation='" + gmdConfigLocation + '\'' +
                ", marketDataTickDriverSubscriberCorePoolMinSize=" + marketDataTickDriverSubscriberCorePoolMinSize +
                ", marketDataTickDriverSubscriberCorePoolMaxSize=" + marketDataTickDriverSubscriberCorePoolMaxSize +
                ", marketDataTickDriverSubscriberKeepAliveTime=" + marketDataTickDriverSubscriberKeepAliveTime +
                ", marketDataTickDriverSubscriberCapacity=" + marketDataTickDriverSubscriberCapacity +
                '}';
    }
}
