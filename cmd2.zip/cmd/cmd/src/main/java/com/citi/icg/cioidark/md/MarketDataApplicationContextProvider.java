package com.citi.icg.cioidark.md;

import java.util.Objects;

import com.citi.icg.cioidark.chronicle.messaging.queue.GMDOut;
import com.citi.icg.cioidark.md.component.drainer.MarketDataSubscriptionQueueDrainer;
import com.citi.icg.cioidark.md.component.driver.GMDTickDriver;
import com.citi.icg.cioidark.md.component.handler.GMDCallbackHandler;
import com.citi.icg.cioidark.md.component.handler.MarketDataSubscriptionHandler;
import com.citi.icg.cioidark.md.component.manager.MarketDataSubscriptionManager;
import com.citi.icg.cioidark.md.component.manager.MarketDataTickDriverManager;
import com.citi.icg.cioidark.md.component.service.MarketDataConnect;
import com.citi.icg.cioidark.md.component.subscriber.MarketDataTickDriverSubscriber;
import org.apache.commons.configuration.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Application context holder for the application
 *
 * @author ky54595
 */
public class MarketDataApplicationContextProvider {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataApplicationContextProvider.class.getName());
    static final MarketDataApplicationContextProvider instance = new MarketDataApplicationContextProvider();

    private static MarketDataSystemProperty marketDataSystemProperty;

    private static MarketDataConnect marketDataConnect;

    private static GMDCallbackHandler gmdCallbackHandler;

    private static MarketDataSubscriptionManager marketDataSubscriptionManager;
    private static MarketDataTickDriverManager marketDataTickDriverManager;

    private static MarketDataTickDriverSubscriber marketDataTickDriverSubscriber;

    private MarketDataApplicationContextProvider() {}

    public static synchronized void initialize(final GMDOut gmdOut) throws ConfigurationException {

        if (Objects.isNull(marketDataSystemProperty )) {
            try {
                marketDataSystemProperty = new MarketDataSystemProperty(gmdOut);
            } catch (ConfigurationException e) {
                logger.error("ITRSALERT| System property file not found, exiting, {} ", e);
                throw e;
            }
        }

        if (Objects.isNull(marketDataConnect))
            marketDataConnect = new MarketDataConnect(new GMDTickDriver());

        if (Objects.isNull(gmdCallbackHandler))
            gmdCallbackHandler = new GMDCallbackHandler();

        if (Objects.isNull(marketDataSubscriptionManager))
            marketDataSubscriptionManager = new MarketDataSubscriptionManager();

        if (Objects.isNull(marketDataTickDriverManager))
            marketDataTickDriverManager = new MarketDataTickDriverManager();

        if (Objects.isNull(marketDataTickDriverSubscriber))
            marketDataTickDriverSubscriber = new MarketDataTickDriverSubscriber(getMarketDataSystemProperty());

        logger.info("MARKETDATA Context Initialized!");

    }

    public static MarketDataSystemProperty getMarketDataSystemProperty() {
        return marketDataSystemProperty;
    }

    public static MarketDataConnect getMarketDataConnect() {
        return marketDataConnect;
    }

    public static GMDCallbackHandler getGmdCallbackHandler() {
        return gmdCallbackHandler;
    }

    public static MarketDataSubscriptionManager getMarketDataSubscriptionManager() {
        return marketDataSubscriptionManager;
    }

    public static MarketDataTickDriverManager getMarketDataTickDriverManager() {
        return marketDataTickDriverManager;
    }

    public static MarketDataTickDriverSubscriber getMarketDataTickDriverSubscriber() {
        return marketDataTickDriverSubscriber;
    }

    public static MarketDataSubscriptionQueueDrainer getMarketDataSubscriptionQueueDrainer() {
        return new MarketDataSubscriptionQueueDrainer();
    }

    public static MarketDataSubscriptionHandler getMarketDataSubscriptionHandler() {
        return new MarketDataSubscriptionHandler();
    }

}
