package com.citi.icg.cioidark.md.component.handler;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

import com.citi.gmd.client.messages.component.GMDInstrumentStatusMsg;
import com.citi.gmd.client.messages.component.GMDLULDBandMsg;
import com.citi.gmd.client.messages.component.GMDQuoteMsg;
import com.citi.gmd.client.messages.constants.GMDUpdateType;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.MarketDataMessage;
import com.citi.icg.cioidark.chronicle.messaging.queue.GMDOut;
import com.citi.icg.cioidark.enumeration.MarketDataStatus;
import com.citi.icg.cioidark.enumeration.ShortSaleRestriction;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.component.manager.MarketDataSubscriptionManager;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * GMD callback handler to handle callback for various GMD messages
 *
 * @author ky54595
 */
public class GMDCallbackHandler extends AbstractGMDCallbackHandler {

    private static final Logger logger = LoggerFactory.getLogger(GMDCallbackHandler.class.getName());
    private static final String ITRLS_ALERT_FOR_LOOKUP = "ITRSALERT|Unable to look up book symbol for market data symbol {}";

    private static final List<GMDUpdateType> gmdUpdateTypes = Arrays.asList(GMDUpdateType.SNAPSHOT_MOREIND, GMDUpdateType.SNAPSHOT_LAST, GMDUpdateType.UPDATE);
    private final GMDOut gmdOut;

    public GMDCallbackHandler() {
        gmdOut = MarketDataApplicationContextProvider.getMarketDataSystemProperty().getGmdOut();
    }

    @Override
    public void handleQuoteMsg(GMDQuoteMsg gmdQuoteMsg) {
        final MarketDataMessage marketData = getMarketData(gmdQuoteMsg);

        if (Objects.isNull(marketData))
            return;

        gmdOut.marketData(marketData);

        logger.debug(gmdQuoteMsg.toString());
    }

    MarketDataMessage getMarketData(GMDQuoteMsg gmdQuoteMsg) {

        final MarketDataSubscriptionManager marketDataSubscriptionManager = MarketDataApplicationContextProvider.getMarketDataSubscriptionManager();
        final String symbol = marketDataSubscriptionManager.getCurrentDriver()
                .getBookSymbol(gmdQuoteMsg.getSymbol().toString());
        if (StringUtils.isEmpty(symbol)) {
            logger.error(ITRLS_ALERT_FOR_LOOKUP, gmdQuoteMsg.getSymbol());
            return null;
        }

        double bid = 0.0;
        double offer = 0.0;
        int bSize = 0;
        int oSize = 0;

        for (int ndx = 0; ndx < gmdQuoteMsg.getNumOfElems(); ndx++) {
            char side = gmdQuoteMsg.getQuoteAtIdx((byte) ndx).getSide();
            switch (side) {
                case 'S':
                    offer = gmdQuoteMsg.getQuoteAtIdx((byte) ndx).getPrice() / 10000000d;
                    oSize = gmdQuoteMsg.getQuoteAtIdx((byte) ndx).getSize();
                    break;
                case 'B':
                    bid = gmdQuoteMsg.getQuoteAtIdx((byte) ndx).getPrice() / 10000000d;
                    bSize = gmdQuoteMsg.getQuoteAtIdx((byte) ndx).getSize();
                    break;
                default:
                    if (gmdQuoteMsg.getQuoteAtIdx((byte) ndx).getPrice() != 0)
                        logger.error("ITRSALERT|Unknown side received from GMD with GMDQuoteMsg: [{}]", gmdQuoteMsg);
                    return null;
            }
        }

        MarketDataMessage marketData = new MarketDataMessage(bid, offer, bSize, oSize,
                gmdQuoteMsg.getMsgHdr().getGmdSendTimeStamp(), symbol);
        marketData.setStatusEvent(false);
        marketData.setMarketDataArrivedTime(System.currentTimeMillis());
        marketData.setSecurityMarketData(marketDataSubscriptionManager.getSubscriptionMap().get(symbol));
        marketDataSubscriptionManager.addToSymbolSet(symbol);

        return marketData;
    }

    @Override
    public void handleInstrumentStatusMsg(GMDInstrumentStatusMsg gmdInstrumentStatusMsg) {
        try {
            logger.info(gmdInstrumentStatusMsg.toString() + "[update type=" + gmdInstrumentStatusMsg.getUpdateType() + ",InstStatus=" + gmdInstrumentStatusMsg.getInstStatus() + ",RegulatoryTradingStatus=" + gmdInstrumentStatusMsg.getRegulatoryTradingStatus() + "]");
            String symbol = MarketDataApplicationContextProvider.getMarketDataSubscriptionManager().getCurrentDriver()
                    .getBookSymbol(gmdInstrumentStatusMsg.getSymbol().toString());

            if (StringUtils.isEmpty(symbol)) {
                logger.error(ITRLS_ALERT_FOR_LOOKUP, gmdInstrumentStatusMsg.getSymbol());
                return;
            }

            updateStatus(gmdInstrumentStatusMsg, symbol);
        } catch (Exception e) {
            logger.error("Exception encountered while processing GMD status message", e);
        }
    }

    @Override
    public void handleLULDBandMsg(GMDLULDBandMsg gmdluldBandMsg) {

        logger.debug(gmdluldBandMsg.toString());
        String symbol = MarketDataApplicationContextProvider.getMarketDataSubscriptionManager().getCurrentDriver()
                .getBookSymbol(gmdluldBandMsg.getSymbol().toString());

        if (StringUtils.isEmpty(symbol)) {
            logger.error(ITRLS_ALERT_FOR_LOOKUP, gmdluldBandMsg.getSymbol());
            return;
        }

        gmdOut.marketData(getMarketData(gmdluldBandMsg, symbol));
    }

    private MarketDataMessage getMarketData(GMDLULDBandMsg gmdluldBandMsg, String symbol) {
        final long gmdSendTimeStamp = gmdluldBandMsg.getMsgHdr().getGmdSendTimeStamp();
        MarketDataMessage marketData = new MarketDataMessage(0.0, 0.0, symbol, gmdSendTimeStamp);
        marketData.setStatusEvent(true);
        marketData.setStatus(-1);
        marketData.setUpperLimit(gmdluldBandMsg.getUpperLimitPrice() / 10000000d);
        marketData.setLowerLimit(gmdluldBandMsg.getLowerLimitPrice() / 10000000d);
        if (gmdSendTimeStamp == 0)
            marketData.setLULDTime(new Date());
        else
            marketData.setLULDTime(new Date(TimeUnit.NANOSECONDS.toMillis(gmdSendTimeStamp)));

        return marketData;
    }

    private void updateStatus(GMDInstrumentStatusMsg gmdInstrumentStatusMsg, String symbol) {
        //check if it if snapshot message
        if (getGmdUpdateTypes().contains(gmdInstrumentStatusMsg.getUpdateType()))
            gmdOut.marketData(getMarketData(gmdInstrumentStatusMsg, symbol));
    }

    private MarketDataMessage getMarketData(GMDInstrumentStatusMsg gmdInstrumentStatusMsg, String symbol) {

        boolean crossAttempt = false;
        boolean updateBook = false;

        final MarketDataMessage marketData = new MarketDataMessage(0.0, 0.0, symbol,
                gmdInstrumentStatusMsg.getMsgHdr().getGmdSendTimeStamp());
        marketData.setStatusEvent(true);
        marketData.setStatus(MarketDataStatus.SNAPSHOT_UPDATE.value());

        switch (gmdInstrumentStatusMsg.getRegulatoryTradingStatus()) {
            case 'o': //both market open and trade halt resume
                marketData.setStatus(MarketDataStatus.OPENED_OR_TRADE_RESUME.value());
                crossAttempt = true;
                updateBook = true;
                break;
            case 'c': //GMDInstStatusTypes.CLOSED.getValue():
                marketData.setStatus(MarketDataStatus.CLOSED.value());
                crossAttempt = true;
                updateBook = true;
                break;
            case 'f':
                marketData.setStatus(MarketDataStatus.HALTED.value());
                updateBook = true;
                break;
            case 'q':
                marketData.setStatus(MarketDataStatus.QUOTEONLY.value());
                updateBook = true;
                break;
            default:
                break;
        }

        // Short sell logic
        switch (gmdInstrumentStatusMsg.getRegShoInd()) {
            case '0':
                marketData.setShortSaleRestricted(ShortSaleRestriction.SHORT_SALE_RESTRICTION_REMOVED.value());
                crossAttempt = true;
                updateBook = true;
                break;
            case '1':
            case '2':
                marketData.setShortSaleRestricted(ShortSaleRestriction.SHORT_SALE_RESTRICTION_ACTIVATED.value());
                updateBook = true;
                break;
            default:
                break;
        }

        marketData.setCrossAttempt(crossAttempt);
        marketData.setUpdateBook(updateBook);

        return marketData;
    }

    private static List<GMDUpdateType> getGmdUpdateTypes() {
        return gmdUpdateTypes;
    }

}
