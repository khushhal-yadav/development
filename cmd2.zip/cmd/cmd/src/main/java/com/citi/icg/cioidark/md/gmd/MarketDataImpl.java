package com.citi.icg.cioidark.md.gmd;

import com.citi.icg.cioidark.chronicle.messaging.message.admin.IgnoreMDTick;
import com.citi.icg.cioidark.chronicle.messaging.message.gmd.GMDTickSubscriptionMsg;
import com.citi.icg.cioidark.chronicle.messaging.queue.GMDIn;
import com.citi.icg.cioidark.chronicle.messaging.queue.GMDOut;
import com.citi.icg.cioidark.chronicle.service.AbstractChronicleService;
import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.MarketDataDirector;
import org.apache.commons.configuration.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Implementation class for chronicle market data service
 * @author ky54595
 */
@SuppressWarnings({"WeakerAccess", "unused"}) //Suppressed warnings as this class is being used as chronicle service impl class
public class MarketDataImpl extends AbstractChronicleService implements GMDIn {

    private final static Logger logger = LoggerFactory.getLogger(MarketDataImpl.class);

    public MarketDataImpl(GMDOut gmdOut) throws ConfigurationException {
        MarketDataDirector.getInstance().initialize(gmdOut);
    }

    @Override
    public void subscribeTick(final GMDTickSubscriptionMsg inboundMessage) {
        logger.info("MARKETDATA_IN: GMDTickSubscriptionMsg message received | {}", inboundMessage);

        GMDTickSubscriptionMsg gmdTickSubscriptionMsg = new GMDTickSubscriptionMsg();
        inboundMessage.copyTo(gmdTickSubscriptionMsg);

        MarketDataApplicationContextProvider.getMarketDataSubscriptionHandler()
                .processSubscriptionMessage(gmdTickSubscriptionMsg);
    }

    @Override
    public void ignoreMDTick(final IgnoreMDTick ignoreMDTick) {

        logger.info("MARKETDATA_IN: IgnoreMDTick message received | {}", ignoreMDTick);

        if (ignoreMDTick.isIgnore())
            MarketDataApplicationContextProvider.getMarketDataSubscriptionManager()
                .ignoreMDTicks(ignoreMDTick.getSymbol());
        else
            MarketDataApplicationContextProvider.getMarketDataSubscriptionManager()
                    .resumeMDTicks(ignoreMDTick.getSymbol());
    }
}
