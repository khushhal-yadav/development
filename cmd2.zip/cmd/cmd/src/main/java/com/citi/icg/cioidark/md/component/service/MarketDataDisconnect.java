package com.citi.icg.cioidark.md.component.service;

import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.util.BooleanUtil;
import com.citi.icg.cioidark.util.Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MarketDataDisconnect {

    private final static Logger logger = LoggerFactory.getLogger(MarketDataConnect.class);

    public void disconnect() {
        logger.info("disconnecting/logging out market data");
        try {
            BooleanUtil.ifTrueExecuteOrElse(
                    MarketDataApplicationContextProvider.getMarketDataSystemProperty().isGmdSubscribeMarketData(),
                    () -> BooleanUtil.ifTrueExecuteOrElse(
                            MarketDataApplicationContextProvider.getMarketDataSubscriptionManager().logout(),
                            () -> logger.warn("Successfully disconnected/logged out market data"),
                            () -> logger.warn("ITRSALERT|Error in log out to MarketDataManager")
                    ),
                    () -> {
                        logger.info("MarketData subscription is turned off {}",
                                MarketDataApplicationContextProvider.getMarketDataSystemProperty().isGmdSubscribeMarketData());
                    }
            );
        } catch (Exception ex) {
            logger.warn("Error disconnected/logged out to MarketDataManager|" + Util.getStackTrace(ex));
        }

    }
}
