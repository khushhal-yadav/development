package com.citi.icg.cioidark.md.component.manager;

import com.citi.icg.cioidark.md.MarketDataApplicationContextProvider;
import com.citi.icg.cioidark.md.component.driver.TickDriver;
import com.citi.icg.cioidark.util.BooleanUtil;
import com.citi.icg.cioidark.util.Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MarketDataTickDriverManager implements Runnable {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataTickDriverManager.class.getSimpleName());

    private TickDriver tickDriver;

    public void setTickListener(TickDriver tickDriver) {
        this.tickDriver = tickDriver;
    }

    public void run() {
        MarketDataSubscriptionManager marketDataSubscriptionManager =
                MarketDataApplicationContextProvider.getMarketDataSubscriptionManager();

        try {
            if (tickDriver == null) {
                logger.warn("No TickDrivers registered");
                return;
            }

            boolean isLoginSuccess = tickerDriverLogin(marketDataSubscriptionManager);

            if (!isLoginSuccess) {
                logger.error("ITRSALERT|Exceed MAX retry for TickDriver login | %d",
                        marketDataSubscriptionManager.getRetryCount());
                return;
            }
            logger.info("Successfully login to|" + tickDriver.getMarketDataSource());

            BooleanUtil.ifTrueExecute(
                    tickDriver.getConnected(),
                    () -> updateMarketDataManagerOnLoginSuccess(marketDataSubscriptionManager)
            );

        } catch (Exception ex) {
            logger.warn("ITRSALERT|error login into market data|retry"
                    + marketDataSubscriptionManager.getRetryCounter() + "|"
                    + Util.getStackTrace(ex));
        }
    }

    private boolean tickerDriverLogin(MarketDataSubscriptionManager marketDataSubscriptionManager) {
        logger.info("Trying to login to|" + tickDriver.getMarketDataSource());

        boolean isLoginSuccess = false;

        while (marketDataSubscriptionManager.getRetryCounter() < marketDataSubscriptionManager.getRetryCount() && !isLoginSuccess) {
            isLoginSuccess = tickDriver.login();

            if (!isLoginSuccess) {
                final long gmdMarketDataRetryWaitInterval = MarketDataApplicationContextProvider.getMarketDataSystemProperty().getGmdMarketDataRetryWaitInterval();
                marketDataSubscriptionManager.incRetryCounter();
                logger.warn("Error login into market data, sleeping for {} secs before retrying", gmdMarketDataRetryWaitInterval);
                try {
                    Thread.sleep(20000);
                } catch (InterruptedException e) {
                    logger.warn("Market data retry wait thread interrupted");
                    Thread.currentThread().interrupt();
                }
            }
        }

        return isLoginSuccess;
    }

    private void updateMarketDataManagerOnLoginSuccess(MarketDataSubscriptionManager marketDataSubscriptionManager) {
        marketDataSubscriptionManager.setCurrentDriver(tickDriver);
        marketDataSubscriptionManager.setMarketDataOn(true);
        marketDataSubscriptionManager.drainQueue();
        marketDataSubscriptionManager.setGlobalStale(false);
    }

    public boolean logout() {
        return BooleanUtil.ifNotNullEvaluateOrElse(
                tickDriver,
                () -> {
                    logger.info("logging out TickDriver| {}", tickDriver.toString());
                    return tickDriver.logout();
                },
                () -> {
                    logger.info("No tick driver registered to log out");
                    return false;
                }
        );
    }
}
